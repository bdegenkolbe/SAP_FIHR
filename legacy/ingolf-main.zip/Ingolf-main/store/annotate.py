# -*- coding: utf-8 -*-
"""Textannotation (CONCEPT.md §8) — stdlib-Stufe ohne spaCy.

Pipeline je Patient: narrative Texte aus den FHIR-Ressourcen ziehen ->
Terminologie-Matching (Lexikon aus den Condition-/Medikations-Codes des Stores
+ eingebautes Fachlexikon) -> deutsche Negations-/Unsicherheitserkennung
(NegEx-Variante) -> nlp_annotation + FTS5-Volltextindex.

spaCy/GERNERMED kann später als zusätzlicher Extraktor eingehängt werden
(gleiche Ablage), ohne dass sich die Abfrageseite ändert.
"""
from __future__ import annotations

import re
import sqlite3

# Fenstergröße (Zeichen) für Negations-/Unsicherheits-Trigger vor dem Treffer
_WINDOW = 60

_NEG_PRE = ("kein hinweis auf", "kein anhalt für", "kein", "keine", "keinen",
            "ohne", "nicht", "ausschluss von", "ausschluss einer", "negativ für")
_NEG_POST = ("ausgeschlossen", "nicht nachweisbar", "verneint", "unauffällig")
_UNC_PRE = ("v.a.", "v. a.", "verdacht auf", "fraglich", "möglicherweise", "dd",
            "z.n.", "z. n.", "zustand nach")

# Eingebautes Fachlexikon (gastroenterologischer Kern; wird durch Store-Codes ergänzt)
_BUILTIN = [
    ("Fettleber", "CONDITION", "ICD-10-GM", "K76.0"),
    ("Steatosis hepatis", "CONDITION", "ICD-10-GM", "K76.0"),
    ("Steatosis", "CONDITION", "ICD-10-GM", "K76.0"),
    ("Insulinresistenz", "CONDITION", "LOCAL", "insulinresistenz"),
    ("Zöliakie", "CONDITION", "ICD-10-GM", "K90.0"),
    ("Helicobacter", "CONDITION", "LOCAL", "helicobacter"),
    ("H.p.", "CONDITION", "LOCAL", "helicobacter"),
    ("Reflux", "CONDITION", "ICD-10-GM", "K21"),
    ("Gastritis", "CONDITION", "ICD-10-GM", "K29"),
    ("Colitis ulcerosa", "CONDITION", "ICD-10-GM", "K51"),
    ("Morbus Crohn", "CONDITION", "ICD-10-GM", "K50"),
    ("Divertikulose", "CONDITION", "ICD-10-GM", "K57"),
    ("Polyp", "CONDITION", "ICD-10-GM", "K63.5"),
    ("Zirrhose", "CONDITION", "ICD-10-GM", "K74"),
    ("Leberzirrhose", "CONDITION", "ICD-10-GM", "K74.6"),
    ("Hepatitis", "CONDITION", "ICD-10-GM", "K75"),
    ("Pankreatitis", "CONDITION", "ICD-10-GM", "K85"),
]

_TAG_RE = re.compile(r"<[^>]+>")


def _texts_of(resource: dict) -> list[str]:
    """Narrative Textfelder einer Ressource (bereits de-identifiziert exportiert)."""
    texts: list[str] = []

    def add(v):
        if isinstance(v, str) and v.strip():
            texts.append(_TAG_RE.sub(" ", v).strip())

    add(resource.get("valueString"))
    add(resource.get("description"))
    add(resource.get("conclusion"))
    for note in resource.get("note", []) or []:
        add(note.get("text"))
    # eingebettete Text-Anhaenge (map_documents legt den Volltext base64 ab)
    for content in resource.get("content", []) or []:
        att = content.get("attachment") or {}
        if att.get("data") and str(att.get("contentType", "")).startswith("text/"):
            import base64
            try:
                add(base64.b64decode(att["data"]).decode("utf-8", errors="replace"))
            except (ValueError, TypeError):
                pass
    for rng in resource.get("referenceRange", []) or []:
        pass  # Referenzbereiche sind keine narrativen Befunde
    text = resource.get("text") or {}
    add(text.get("div"))
    for section in resource.get("section", []) or []:
        add((section.get("text") or {}).get("div"))
    return texts


def _lexicon(conn) -> list[tuple[str, str, str, str]]:
    """Lexikon = eingebaute Begriffe + Codes/Displays aus dem Store."""
    lex = list(_BUILTIN)
    rows = conn.execute(
        "SELECT DISTINCT json_extract(content,'$.code.coding[0].code') AS code,"
        "       coalesce(json_extract(content,'$.code.coding[0].display'),"
        "                json_extract(content,'$.code.text')) AS term"
        " FROM fhir_resource WHERE resource_type='Condition' AND status='active'"
    ).fetchall()
    for r in rows:
        if r["term"] and r["code"] and len(r["term"]) >= 4:
            lex.append((r["term"], "CONDITION", "ICD-10-GM", r["code"]))
    rows = conn.execute(
        "SELECT DISTINCT json_extract(content,'$.medicationCodeableConcept.text') AS term,"
        "  json_extract(content,'$.medicationCodeableConcept.coding[1].code') AS atc"
        " FROM fhir_resource WHERE resource_type='MedicationStatement' AND status='active'"
    ).fetchall()
    for r in rows:
        if r["term"] and len(r["term"]) >= 4:
            lex.append((r["term"], "DRUG", "ATC", r["atc"] or r["term"].lower()))
    # längste Begriffe zuerst, doppelte Terme raus
    seen: set[str] = set()
    out = []
    for term, etype, system, code in sorted(lex, key=lambda x: -len(x[0])):
        if term.lower() not in seen:
            seen.add(term.lower())
            out.append((term, etype, system, code))
    return out


def _classify(text_lower: str, start: int, end: int) -> tuple[bool, bool]:
    """(negated, uncertain) anhand der Trigger im Fenster vor/nach dem Treffer."""
    pre = text_lower[max(0, start - _WINDOW):start]
    post = text_lower[end:end + _WINDOW]
    negated = any(t in pre for t in _NEG_PRE) or any(t in post for t in _NEG_POST)
    uncertain = any(t in pre for t in _UNC_PRE)
    return negated, uncertain


def annotate_text(conn, resource_type: str, resource_id: str, pseudonym: str | None,
                  body: str, effective: str | None,
                  lexicon: list[tuple[str, str, str, str]]) -> int:
    lower = body.lower()
    n = 0
    for term, etype, system, code in lexicon:
        for m in re.finditer(re.escape(term.lower()), lower):
            negated, uncertain = _classify(lower, m.start(), m.end())
            snippet = body[max(0, m.start() - 40):m.end() + 40].strip()
            conn.execute(
                "INSERT INTO nlp_annotation (resource_type, resource_id, pseudonym,"
                " span_start, span_end, text_snippet, entity_type, code_system, code,"
                " negated, uncertain, effective_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (resource_type, resource_id, pseudonym, m.start(), m.end(), snippet,
                 etype, system, code, int(negated), int(uncertain), effective),
            )
            n += 1
    return n


def _fts_available(conn) -> bool:
    try:
        conn.execute("SELECT 1 FROM fts_text LIMIT 1")
        return True
    except sqlite3.OperationalError:
        return False


def ingest_overlay_annotations(conn, resource_type: str, resource_id: str,
                               pseudonym: str | None, resource: dict,
                               effective: str | None) -> int:
    """Übernimmt das Dokument-Intelligence-Overlay (agent/annotate.py,
    Extension .../document-annotations) in nlp_annotation, damit Analyse und
    Suche dokumentabgeleitete Konzepte (SNOMED/ICD/...) abfragen können."""
    n = 0
    for ext in resource.get("extension", []) or []:
        if not str(ext.get("url", "")).endswith("/document-annotations"):
            continue
        for item in ext.get("extension", []) or []:
            fields = {e.get("url"): e for e in item.get("extension", []) or []}
            coding = (fields.get("concept") or {}).get("valueCoding") or {}
            span = ((fields.get("span") or {}).get("valueString") or "0:0").split(":")
            context = (fields.get("context") or {}).get("valueString") or ""
            conn.execute(
                "INSERT INTO nlp_annotation (resource_type, resource_id, pseudonym,"
                " span_start, span_end, text_snippet, entity_type, code_system, code,"
                " negated, uncertain, effective_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (resource_type, resource_id, pseudonym,
                 int(span[0] or 0), int(span[-1] or 0),
                 (fields.get("text") or {}).get("valueString"),
                 "DOC_CONCEPT", coding.get("system"), coding.get("code"),
                 int("negated" in context), int("uncertain" in context), effective),
            )
            n += 1
    return n


def annotate_patient(conn, pseudonym: str | None) -> int:
    """(Re-)Annotation aller aktiven Ressourcen eines Patienten."""
    if pseudonym is None:
        return 0
    conn.execute("DELETE FROM nlp_annotation WHERE pseudonym = ?", (pseudonym,))
    fts = _fts_available(conn)
    if fts:
        rowids = [r["rowid"] for r in conn.execute(
            "SELECT rowid FROM fts_text WHERE pseudonym = ?", (pseudonym,))]
        for rid in rowids:
            conn.execute("DELETE FROM fts_text WHERE rowid = ?", (rid,))

    lexicon = _lexicon(conn)
    n = 0
    rows = conn.execute(
        "SELECT resource_type, id, effective, content FROM fhir_resource"
        " WHERE pseudonym=? AND status='active'", (pseudonym,),
    ).fetchall()
    import json
    for row in rows:
        resource = json.loads(row["content"])
        n += ingest_overlay_annotations(conn, row["resource_type"], row["id"],
                                        pseudonym, resource, row["effective"])
        texts = _texts_of(resource)
        if not texts:
            continue
        body = "\n".join(texts)
        n += annotate_text(conn, row["resource_type"], row["id"], pseudonym, body,
                           row["effective"], lexicon)
        if fts:
            conn.execute(
                "INSERT INTO fts_text (resource_type, resource_id, pseudonym, effective,"
                " body) VALUES (?,?,?,?,?)",
                (row["resource_type"], row["id"], pseudonym, row["effective"], body),
            )
    conn.commit()
    return n


def search_fulltext(conn, query: str, negated: bool | None = False,
                    limit: int = 100) -> list[dict]:
    """Facettierte Volltextsuche: FTS5-Treffer, optional gefiltert auf
    nicht-negierte Annotationen desselben Begriffs."""
    if not _fts_available(conn):
        return []
    hits = conn.execute(
        "SELECT resource_type, resource_id, pseudonym, effective,"
        " snippet(fts_text, 4, '<mark>', '</mark>', ' … ', 12) AS snippet"
        " FROM fts_text WHERE fts_text MATCH ? LIMIT ?",
        (query, limit),
    ).fetchall()
    if negated is None:
        return hits
    out = []
    for h in hits:
        ann = conn.execute(
            "SELECT max(negated) AS neg FROM nlp_annotation"
            " WHERE resource_type=? AND resource_id=? AND code IS NOT NULL"
            "   AND instr(lower(text_snippet), lower(?)) > 0",
            (h["resource_type"], h["resource_id"], query.strip('"')),
        ).fetchone()
        is_neg = bool(ann["neg"]) if ann and ann["neg"] is not None else False
        if is_neg == bool(negated):
            out.append({**h, "negated": is_neg})
    return out
