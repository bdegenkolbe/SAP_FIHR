# -*- coding: utf-8 -*-
"""Re-ID-Vault: Pseudonym -> Quell-ID/PatientNr, verschlüsselt (SCHEMA.md 3.4).

Werteverschlüsselung mit dem Master-Secret (das per DPAPI geschützt on-prem liegt,
siehe installer/first_run.py): AES-GCM, wenn das Paket `cryptography` verfügbar ist,
sonst stdlib-Fallback als HMAC-SHA256-CTR-Stromchiffre + HMAC-Tag (encrypt-then-MAC).
Der Schlüssel liegt NIE in der DB. Rückauflösung nur über Break-Glass (server/).
"""
from __future__ import annotations

import hashlib
import hmac
import secrets


def _derive(master: bytes, purpose: bytes) -> bytes:
    return hmac.new(master, b"vault:" + purpose, hashlib.sha256).digest()


def _keystream(key: bytes, nonce: bytes, length: int) -> bytes:
    out = b""
    counter = 0
    while len(out) < length:
        out += hmac.new(key, nonce + counter.to_bytes(4, "big"), hashlib.sha256).digest()
        counter += 1
    return out[:length]


def encrypt(master: bytes, plaintext: str) -> bytes:
    data = plaintext.encode("utf-8")
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        nonce = secrets.token_bytes(12)
        ct = AESGCM(_derive(master, b"aes")[:32]).encrypt(nonce, data, None)
        return b"AGCM" + nonce + ct
    except ImportError:
        enc_key = _derive(master, b"enc")
        mac_key = _derive(master, b"mac")
        nonce = secrets.token_bytes(16)
        ct = bytes(a ^ b for a, b in zip(data, _keystream(enc_key, nonce, len(data))))
        tag = hmac.new(mac_key, nonce + ct, hashlib.sha256).digest()
        return b"HCTR" + nonce + tag + ct


def decrypt(master: bytes, blob: bytes) -> str:
    kind, body = blob[:4], blob[4:]
    if kind == b"AGCM":
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        nonce, ct = body[:12], body[12:]
        return AESGCM(_derive(master, b"aes")[:32]).decrypt(nonce, ct, None).decode("utf-8")
    if kind == b"HCTR":
        enc_key = _derive(master, b"enc")
        mac_key = _derive(master, b"mac")
        nonce, tag, ct = body[:16], body[16:48], body[48:]
        expect = hmac.new(mac_key, nonce + ct, hashlib.sha256).digest()
        if not hmac.compare_digest(tag, expect):
            raise ValueError("Vault-Eintrag: Integritätsprüfung fehlgeschlagen")
        return bytes(a ^ b for a, b in zip(ct, _keystream(enc_key, nonce, len(ct)))).decode("utf-8")
    raise ValueError("Unbekanntes Vault-Format")


def store_mapping(conn, master: bytes, pseudonym: str, source_id: str | int,
                  source_nr: str | int | None, date_shift_days: int) -> None:
    conn.execute(
        "INSERT OR REPLACE INTO vault_patient_pseudonym"
        " (pseudonym, source_id_enc, source_nr_enc, date_shift_days)"
        " VALUES (?,?,?,?)",
        (pseudonym, encrypt(master, str(source_id)),
         encrypt(master, str(source_nr)) if source_nr is not None else None,
         date_shift_days),
    )
    conn.commit()


def resolve(conn, master: bytes, pseudonym: str) -> dict | None:
    row = conn.execute(
        "SELECT * FROM vault_patient_pseudonym WHERE pseudonym = ?", (pseudonym,)
    ).fetchone()
    if not row:
        return None
    return {
        "pseudonym": pseudonym,
        "source_id": decrypt(master, row["source_id_enc"]),
        "source_nr": decrypt(master, row["source_nr_enc"]) if row["source_nr_enc"] else None,
        "date_shift_days": row["date_shift_days"],
    }
