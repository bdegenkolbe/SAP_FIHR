-- Lokales Schema (SQLite/SQLCipher) — Übersetzung von docs/SCHEMA.md §3–4
-- (PostgreSQL) gemäß docs/DEPLOYMENT.md §5: Präfixe statt Schemas, JSON1 +
-- generierte Spalten statt jsonb/GIN, append-only-Audit per Trigger.

PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- ===== sec: Benutzerverwaltung (SCHEMA.md 3.1) =============================
CREATE TABLE IF NOT EXISTS sec_app_user (
  id            TEXT PRIMARY KEY,              -- uuid
  username      TEXT NOT NULL UNIQUE,
  full_name     TEXT NOT NULL,
  email         TEXT UNIQUE,
  password_hash TEXT NOT NULL,                 -- Argon2id (Fallback pbkdf2$)
  mfa_secret    BLOB,                          -- TOTP-Secret, verschlüsselt (Master-Key)
  mfa_enabled   INTEGER NOT NULL DEFAULT 0,
  status        TEXT NOT NULL DEFAULT 'active'
                CHECK (status IN ('active','locked','disabled')),
  failed_logins INTEGER NOT NULL DEFAULT 0,
  last_login_at TEXT,
  password_changed_at TEXT NOT NULL DEFAULT (datetime('now')),
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  created_by    TEXT REFERENCES sec_app_user(id),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sec_role (
  id   TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT
);

CREATE TABLE IF NOT EXISTS sec_permission (
  id   TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS sec_role_permission (
  role_id TEXT NOT NULL REFERENCES sec_role(id) ON DELETE CASCADE,
  perm_id TEXT NOT NULL REFERENCES sec_permission(id) ON DELETE CASCADE,
  PRIMARY KEY (role_id, perm_id)
);

CREATE TABLE IF NOT EXISTS sec_user_role (
  user_id TEXT NOT NULL REFERENCES sec_app_user(id) ON DELETE CASCADE,
  role_id TEXT NOT NULL REFERENCES sec_role(id) ON DELETE CASCADE,
  PRIMARY KEY (user_id, role_id)
);

CREATE TABLE IF NOT EXISTS sec_session (
  id         TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES sec_app_user(id),
  token_hash TEXT NOT NULL,                    -- nur Hash speichern
  issued_at  TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at TEXT NOT NULL,
  ip         TEXT,
  user_agent TEXT,
  revoked_at TEXT
);

CREATE TABLE IF NOT EXISTS sec_recovery_code (
  user_id   TEXT NOT NULL REFERENCES sec_app_user(id) ON DELETE CASCADE,
  code_hash TEXT NOT NULL,
  used_at   TEXT,
  PRIMARY KEY (user_id, code_hash)
);

CREATE TABLE IF NOT EXISTS sec_login_versuch (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL,
  ts       TEXT NOT NULL DEFAULT (datetime('now')),
  success  INTEGER NOT NULL,
  ip       TEXT
);

-- ===== audit: append-only Log mit Hash-Kette (SCHEMA.md 3.2) ===============
CREATE TABLE IF NOT EXISTS audit_event (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  ts          TEXT NOT NULL DEFAULT (datetime('now')),
  user_id     TEXT REFERENCES sec_app_user(id),
  action      TEXT NOT NULL,        -- login, logout, export.run, patient.view, reid.request, ...
  object_type TEXT,
  object_id   TEXT,
  detail      TEXT,                 -- JSON
  ip          TEXT,
  success     INTEGER NOT NULL DEFAULT 1,
  prev_hash   TEXT,                 -- Hash-Verkettung gegen Manipulation
  row_hash    TEXT
);

-- append-only: UPDATE/DELETE technisch verhindern
CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit_event
BEGIN SELECT RAISE(ABORT, 'audit_event ist append-only'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit_event
BEGIN SELECT RAISE(ABORT, 'audit_event ist append-only'); END;

-- ===== etl: Watermarks + Export-Jobs (SCHEMA.md 3.3) =======================
CREATE TABLE IF NOT EXISTS etl_watermark (
  source_table    TEXT PRIMARY KEY,
  strategy        TEXT NOT NULL,               -- rowversion | createdpoint | reconcile
  last_rowversion TEXT,                        -- 8-Byte-HWM als Hex
  last_created    TEXT,
  last_run_at     TEXT,
  rows_loaded     INTEGER
);

CREATE TABLE IF NOT EXISTS etl_export_job (
  id          TEXT PRIMARY KEY,
  started_by  TEXT REFERENCES sec_app_user(id),
  started_at  TEXT NOT NULL DEFAULT (datetime('now')),
  finished_at TEXT,
  mode        TEXT NOT NULL,                   -- full | incremental | reconcile | single
  privacy     TEXT NOT NULL,                   -- off | pseudonymize | anonymize
  target      TEXT NOT NULL DEFAULT 'fhir',
  status      TEXT NOT NULL DEFAULT 'running', -- running | success | failed | partial
  scope       TEXT,                            -- JSON
  stats       TEXT,                            -- JSON {resources, patients, ...}
  error       TEXT
);

CREATE TABLE IF NOT EXISTS etl_export_job_table (
  job_id            TEXT NOT NULL REFERENCES etl_export_job(id) ON DELETE CASCADE,
  source_table      TEXT NOT NULL,
  rows_read         INTEGER,
  resources_written INTEGER,
  status            TEXT,
  PRIMARY KEY (job_id, source_table)
);

-- ===== vault: Pseudonym -> Quell-ID, verschlüsselt (SCHEMA.md 3.4) =========
-- Zugriff nur über Break-Glass (Recht data.read.clear); Werte mit Master-Key
-- verschlüsselt (store/vault.py), Schlüssel liegt NIE in dieser DB.
CREATE TABLE IF NOT EXISTS vault_patient_pseudonym (
  pseudonym        TEXT PRIMARY KEY,
  source_id_enc    BLOB NOT NULL,
  source_nr_enc    BLOB,
  date_shift_days  INTEGER NOT NULL,
  created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ===== fhir: Ressourcen-Store (SCHEMA.md 4.1) ==============================
CREATE TABLE IF NOT EXISTS fhir_resource (
  resource_type TEXT NOT NULL,
  id            TEXT NOT NULL,
  version_id    INTEGER NOT NULL DEFAULT 1,
  status        TEXT NOT NULL DEFAULT 'active',   -- active | deleted
  last_updated  TEXT NOT NULL DEFAULT (datetime('now')),
  pseudonym     TEXT,
  content       TEXT NOT NULL,                    -- FHIR-Ressource (JSON)
  source_job    TEXT REFERENCES etl_export_job(id),
  -- generierte Spalten (JSON1) für schnelle Filter statt GIN-Index
  effective     TEXT GENERATED ALWAYS AS (
    coalesce(json_extract(content,'$.effectiveDateTime'),
             json_extract(content,'$.recordedDate'),
             json_extract(content,'$.authoredOn'),
             json_extract(content,'$.period.start'),
             json_extract(content,'$.start'),
             json_extract(content,'$.date'))) STORED,
  code_primary  TEXT GENERATED ALWAYS AS (
    coalesce(json_extract(content,'$.code.coding[0].code'),
             json_extract(content,'$.medicationCodeableConcept.coding[0].code'))) STORED,
  PRIMARY KEY (resource_type, id)
);
CREATE INDEX IF NOT EXISTS ix_fhir_pseudo    ON fhir_resource (pseudonym);
CREATE INDEX IF NOT EXISTS ix_fhir_updated   ON fhir_resource (resource_type, last_updated);
CREATE INDEX IF NOT EXISTS ix_fhir_effective ON fhir_resource (pseudonym, effective);
CREATE INDEX IF NOT EXISTS ix_fhir_code      ON fhir_resource (resource_type, code_primary);

CREATE TABLE IF NOT EXISTS fhir_resource_history (
  resource_type TEXT NOT NULL,
  id            TEXT NOT NULL,
  version_id    INTEGER NOT NULL,
  changed_at    TEXT NOT NULL DEFAULT (datetime('now')),
  operation     TEXT,                              -- create | update | delete
  content       TEXT,
  job_id        TEXT REFERENCES etl_export_job(id),
  PRIMARY KEY (resource_type, id, version_id)
);

CREATE TABLE IF NOT EXISTS fhir_reference (
  src_type TEXT NOT NULL, src_id TEXT NOT NULL, field TEXT NOT NULL,
  ref_type TEXT NOT NULL, ref_id TEXT NOT NULL,
  PRIMARY KEY (src_type, src_id, field, ref_type, ref_id)
);

-- ===== nlp: Annotationen (SCHEMA.md 4.3) ===================================
CREATE TABLE IF NOT EXISTS nlp_annotation (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  resource_type TEXT NOT NULL,
  resource_id   TEXT NOT NULL,
  pseudonym     TEXT,
  span_start    INTEGER, span_end INTEGER,
  text_snippet  TEXT,
  entity_type   TEXT,                 -- CONDITION | DRUG | LAB | ...
  code_system   TEXT,                 -- ICD-10-GM | ATC | LOINC | LOCAL
  code          TEXT,
  negated       INTEGER NOT NULL DEFAULT 0,
  uncertain     INTEGER NOT NULL DEFAULT 0,
  effective_at  TEXT
);
CREATE INDEX IF NOT EXISTS ix_nlp_code   ON nlp_annotation (code_system, code, negated);
CREATE INDEX IF NOT EXISTS ix_nlp_pseudo ON nlp_annotation (pseudonym);

-- ===== Kataloge / Referenzdaten (CONCEPT.md 13.4) ==========================
CREATE TABLE IF NOT EXISTS ref_resource (
  resource_type TEXT NOT NULL,       -- ObservationDefinition | Medication | ...
  id            TEXT NOT NULL,
  catalog       TEXT NOT NULL,       -- labor | vitalparameter | medikament | goae | meddok
  version       TEXT,
  valid_from    TEXT,
  valid_to      TEXT,
  content       TEXT NOT NULL,
  PRIMARY KEY (resource_type, id)
);
CREATE INDEX IF NOT EXISTS ix_ref_catalog ON ref_resource (catalog);

-- ===== Einstellungen (App-Konfiguration, kein Secret!) =====================
CREATE TABLE IF NOT EXISTS app_setting (
  key   TEXT PRIMARY KEY,
  value TEXT
);
