# -*- coding: utf-8 -*-
"""Lokaler verschlüsselter Store (No-Admin): SQLCipher, Fallback plain SQLite.

Öffnet data/clinical.db, initialisiert das Schema (store/schema.sql, Übersetzung
von docs/SCHEMA.md §3–4) und stellt Hilfen für Audit (Hash-Kette) und Settings
bereit. SQLCipher wird genutzt, wenn `sqlcipher3` importierbar ist; sonst plain
SQLite mit deutlicher Warnung (nur Entwicklung).
"""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import sys
import uuid
from pathlib import Path

SCHEMA_PATH = Path(__file__).with_name("schema.sql")


def connect(path: str | os.PathLike, key: bytes | str | None = None):
    """Verbindung öffnen. `key` aktiviert SQLCipher (wenn verfügbar)."""
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    conn = None
    if key:
        try:
            import sqlcipher3  # type: ignore
            conn = sqlcipher3.connect(str(path))
            hexkey = key.hex() if isinstance(key, bytes) else hashlib.sha256(key.encode()).hexdigest()
            conn.execute(f"PRAGMA key = \"x'{hexkey}'\"")
        except ImportError:
            sys.stderr.write("[WARN] sqlcipher3 nicht verfuegbar - Store ist NICHT "
                             "verschluesselt (nur fuer Entwicklung akzeptabel).\n")
    if conn is None:
        conn = sqlite3.connect(str(path))
    conn.row_factory = _dict_row
    conn.execute("PRAGMA foreign_keys = ON")
    # Server-Prozess + Sync-Subprozess teilen sich die DB (WAL): bei Sperre warten
    conn.execute("PRAGMA busy_timeout = 5000")
    return conn


def _dict_row(cursor, row):
    return {d[0]: row[i] for i, d in enumerate(cursor.description)}


def init_schema(conn) -> None:
    conn.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
    # FTS5-Volltextindex (narrative Texte) - nur wenn FTS5 einkompiliert ist
    try:
        conn.execute(
            "CREATE VIRTUAL TABLE IF NOT EXISTS fts_text USING fts5("
            " resource_type, resource_id, pseudonym, effective, body,"
            " tokenize='unicode61 remove_diacritics 2')"
        )
    except sqlite3.OperationalError:  # pragma: no cover
        sys.stderr.write("[WARN] SQLite ohne FTS5 - Volltextsuche deaktiviert.\n")
    conn.commit()


def open_store(path: str | os.PathLike, key: bytes | str | None = None):
    conn = connect(path, key)
    init_schema(conn)
    return conn


# ---- Audit mit Hash-Kette (BENUTZERVERWALTUNG.md §6) -----------------------

def audit(conn, action: str, user_id: str | None = None, object_type: str | None = None,
          object_id: str | None = None, detail: dict | None = None,
          ip: str | None = None, success: bool = True) -> None:
    prev = conn.execute(
        "SELECT row_hash FROM audit_event ORDER BY id DESC LIMIT 1"
    ).fetchone()
    prev_hash = prev["row_hash"] if prev else ""
    detail_json = json.dumps(detail, ensure_ascii=False, sort_keys=True) if detail else None
    payload = "|".join(str(x) for x in
                       (prev_hash, user_id, action, object_type, object_id,
                        detail_json, ip, int(success)))
    row_hash = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    conn.execute(
        "INSERT INTO audit_event (user_id, action, object_type, object_id, detail, ip,"
        " success, prev_hash, row_hash) VALUES (?,?,?,?,?,?,?,?,?)",
        (user_id, action, object_type, object_id, detail_json, ip, int(success),
         prev_hash, row_hash),
    )
    conn.commit()


def verify_audit_chain(conn) -> tuple[bool, int]:
    """Prüft die Hash-Kette; Rückgabe (ok, geprüfte Einträge)."""
    prev_hash = ""
    n = 0
    for row in conn.execute("SELECT * FROM audit_event ORDER BY id"):
        payload = "|".join(str(x) for x in
                           (prev_hash, row["user_id"], row["action"], row["object_type"],
                            row["object_id"], row["detail"], row["ip"], row["success"]))
        expected = hashlib.sha256(payload.encode("utf-8")).hexdigest()
        if row["prev_hash"] != prev_hash or row["row_hash"] != expected:
            return False, n
        prev_hash = row["row_hash"]
        n += 1
    return True, n


# ---- Settings ---------------------------------------------------------------

def get_setting(conn, key: str, default: str | None = None) -> str | None:
    row = conn.execute("SELECT value FROM app_setting WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(conn, key: str, value: str) -> None:
    conn.execute("INSERT INTO app_setting (key, value) VALUES (?, ?)"
                 " ON CONFLICT(key) DO UPDATE SET value = excluded.value", (key, value))
    conn.commit()


def new_id() -> str:
    return str(uuid.uuid4())
