# -*- coding: utf-8 -*-
"""Load-Schritt: FHIR-Bundles (agent/export.py) -> lokaler Store (fhir_resource).

Idempotenter Upsert per (resource_type, id); Änderung -> version_id++ + History-
Eintrag (SCHEMA.md 4.1). Extrahiert Referenzen (fhir_reference), pflegt den
denormalisierten Patientenbezug (pseudonym) und stößt die NLP-Annotation an.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from store.db import audit, new_id

_REF_RE = re.compile(r"^(?:urn:uuid:)?([A-Za-z]+)?/?([A-Za-z0-9\-.]{1,64})$")


def _resource_id(entry: dict) -> tuple[str, str]:
    res = entry["resource"]
    rid = res.get("id")
    if not rid:
        rid = (entry.get("fullUrl") or "").replace("urn:uuid:", "")
    return res["resourceType"], rid


def _iter_references(obj, field=""):
    if isinstance(obj, dict):
        ref = obj.get("reference")
        if isinstance(ref, str):
            yield field, ref
        for k, v in obj.items():
            if k != "reference":
                yield from _iter_references(v, k if not field else f"{field}.{k}")
    elif isinstance(obj, list):
        for v in obj:
            yield from _iter_references(v, field)


def _parse_ref(ref: str) -> tuple[str, str] | None:
    if ref.startswith("urn:uuid:"):
        return ("Patient", ref.replace("urn:uuid:", ""))  # Export nutzt urn:uuid nur fürs Subject
    if "/" in ref:
        rtype, rid = ref.split("/", 1)
        return (rtype, rid)
    return None


def upsert_resource(conn, resource: dict, pseudonym: str | None,
                    job_id: str | None = None, resource_id: str | None = None) -> str:
    """Rückgabe: 'create' | 'update' | 'unchanged'."""
    rtype = resource["resourceType"]
    rid = resource_id or resource.get("id")
    if not rid:
        raise ValueError(f"Ressource ohne id: {rtype}")
    content = json.dumps(resource, ensure_ascii=False, sort_keys=True)

    row = conn.execute(
        "SELECT version_id, content FROM fhir_resource WHERE resource_type=? AND id=?",
        (rtype, rid),
    ).fetchone()
    if row is None:
        conn.execute(
            "INSERT INTO fhir_resource (resource_type, id, version_id, status, pseudonym,"
            " content, source_job, last_updated) VALUES (?,?,?,?,?,?,?,datetime('now'))",
            (rtype, rid, 1, "active", pseudonym, content, job_id),
        )
        conn.execute(
            "INSERT OR REPLACE INTO fhir_resource_history (resource_type, id, version_id,"
            " operation, content, job_id) VALUES (?,?,?,?,?,?)",
            (rtype, rid, 1, "create", content, job_id),
        )
        op = "create"
    elif row["content"] == content:
        op = "unchanged"
    else:
        new_version = row["version_id"] + 1
        conn.execute(
            "UPDATE fhir_resource SET version_id=?, content=?, pseudonym=?, status='active',"
            " source_job=?, last_updated=datetime('now') WHERE resource_type=? AND id=?",
            (new_version, content, pseudonym, job_id, rtype, rid),
        )
        conn.execute(
            "INSERT OR REPLACE INTO fhir_resource_history (resource_type, id, version_id,"
            " operation, content, job_id) VALUES (?,?,?,?,?,?)",
            (rtype, rid, new_version, "update", content, job_id),
        )
        op = "update"

    if op != "unchanged":
        conn.execute("DELETE FROM fhir_reference WHERE src_type=? AND src_id=?", (rtype, rid))
        for field, ref in _iter_references(resource):
            parsed = _parse_ref(ref)
            if parsed:
                conn.execute(
                    "INSERT OR IGNORE INTO fhir_reference (src_type, src_id, field,"
                    " ref_type, ref_id) VALUES (?,?,?,?,?)",
                    (rtype, rid, field or "-", parsed[0], parsed[1]),
                )
    return op


def load_bundle(conn, bundle: dict, job_id: str | None = None,
                annotate: bool = True) -> dict:
    """Ein Export-Bundle (collection, ein Patient) in den Store übernehmen."""
    pseudonym = bundle.get("id", "").replace("export-", "") or None
    stats = {"create": 0, "update": 0, "unchanged": 0}
    seen: list[tuple[str, str]] = []
    for entry in bundle.get("entry", []):
        rtype, rid = _resource_id(entry)
        res = dict(entry["resource"])
        res.setdefault("id", rid)
        op = upsert_resource(conn, res, pseudonym, job_id=job_id)
        stats[op] += 1
        seen.append((rtype, rid))
    conn.commit()
    if annotate:
        from store.annotate import annotate_patient
        annotate_patient(conn, pseudonym)
    return {"pseudonym": pseudonym, "resources": len(seen), **stats}


def load_directory(conn, fhir_dir: str | Path, started_by: str | None = None,
                   mode: str = "full", privacy: str = "pseudonymize") -> dict:
    """Alle Bundles eines Exportlaufs (out/fhir/*.json) übernehmen (mit Job-Protokoll)."""
    job_id = new_id()
    conn.execute(
        "INSERT INTO etl_export_job (id, started_by, mode, privacy, target)"
        " VALUES (?,?,?,?,'fhir')",
        (job_id, started_by, mode, privacy),
    )
    conn.commit()
    totals = {"patients": 0, "resources": 0, "create": 0, "update": 0, "unchanged": 0}
    error = None
    try:
        for path in sorted(Path(fhir_dir).glob("*.json")):
            bundle = json.loads(path.read_text(encoding="utf-8"))
            result = load_bundle(conn, bundle, job_id=job_id)
            totals["patients"] += 1
            totals["resources"] += result["resources"]
            for k in ("create", "update", "unchanged"):
                totals[k] += result[k]
        status = "success"
    except Exception as exc:  # Job als failed protokollieren, dann weiterreichen
        status, error = "failed", str(exc)
        raise
    finally:
        conn.execute(
            "UPDATE etl_export_job SET finished_at=datetime('now'), status=?, stats=?,"
            " error=? WHERE id=?",
            (status, json.dumps(totals), error, job_id),
        )
        conn.commit()
        audit(conn, "export.load", user_id=started_by, object_type="export_job",
              object_id=job_id, detail=totals, success=status == "success")
    return {"job_id": job_id, **totals}


def reconcile_deletes(conn, present: list[tuple[str, str]], pseudonym: str,
                      job_id: str | None = None) -> int:
    """Ressourcen eines Patienten, die im aktuellen Voll-Export fehlen, auf
    status='deleted' setzen (CONCEPT.md 4.3a)."""
    keys = set(present)
    n = 0
    rows = conn.execute(
        "SELECT resource_type, id, version_id, content FROM fhir_resource"
        " WHERE pseudonym=? AND status='active'", (pseudonym,),
    ).fetchall()
    for row in rows:
        if (row["resource_type"], row["id"]) not in keys:
            conn.execute(
                "UPDATE fhir_resource SET status='deleted', version_id=version_id+1,"
                " last_updated=datetime('now') WHERE resource_type=? AND id=?",
                (row["resource_type"], row["id"]),
            )
            conn.execute(
                "INSERT OR REPLACE INTO fhir_resource_history (resource_type, id,"
                " version_id, operation, content, job_id) VALUES (?,?,?,?,?,?)",
                (row["resource_type"], row["id"], row["version_id"] + 1, "delete",
                 row["content"], job_id),
            )
            n += 1
    conn.commit()
    return n
