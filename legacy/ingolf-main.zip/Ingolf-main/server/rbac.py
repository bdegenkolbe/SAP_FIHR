# -*- coding: utf-8 -*-
"""Rollen & Rechte (docs/BENUTZERVERWALTUNG.md §2/§3).

Rechte sind additiv; die Klardaten-Sperre gewinnt immer: Rollen ohne
`patient.view.clear` sehen nie Klartext, egal welche weiteren Rollen sie haben —
umgesetzt als Deny-Liste je Rolle (deny gewinnt).
"""
from __future__ import annotations

from store.db import new_id

PERMISSIONS = [
    "patient.search.clear", "patient.search.pseudo",
    "patient.view.clear", "patient.view.pseudo",
    "text.read",
    "analysis.run",
    "export.run", "export.research",
    "reid.request",
    "user.manage", "role.manage", "keys.manage", "settings.manage",
    "etl.manage",
    "audit.read",
]

# Rolle -> (Rechte, Deny-Liste, Default-Datenmodus)
ROLES: dict[str, tuple[list[str], list[str], str]] = {
    "owner": (PERMISSIONS, [], "clear"),
    "clinician": ([
        "patient.search.clear", "patient.search.pseudo",
        "patient.view.clear", "patient.view.pseudo",
        "text.read", "analysis.run",
    ], [], "clear"),
    "mfa": ([
        "patient.search.clear", "patient.search.pseudo",
        "patient.view.pseudo",
    ], ["analysis.run", "export.research", "reid.request"], "clear"),
    "analyst": ([
        "patient.search.pseudo", "patient.view.pseudo",
        "text.read", "analysis.run",
    ], ["patient.view.clear", "patient.search.clear", "reid.request"], "pseudonym"),
    "researcher": ([
        "patient.search.pseudo", "patient.view.pseudo",
        "analysis.run", "export.research",
    ], ["patient.view.clear", "patient.search.clear", "text.read", "reid.request"],
        "anonym"),
    "auditor": (["audit.read"],
                ["patient.view.clear", "patient.view.pseudo"], "pseudonym"),
    "admin_tech": (["etl.manage"],
                   ["patient.view.clear", "patient.view.pseudo", "text.read"], "pseudonym"),
}

DEFAULT_MODE = {name: mode for name, (_, _, mode) in ROLES.items()}


def seed(conn) -> None:
    """Rollen-/Rechte-Katalog idempotent einspielen."""
    for code in PERMISSIONS:
        conn.execute("INSERT OR IGNORE INTO sec_permission (id, code) VALUES (?,?)",
                     (new_id(), code))
    for name, (perms, _deny, _mode) in ROLES.items():
        conn.execute("INSERT OR IGNORE INTO sec_role (id, name) VALUES (?,?)",
                     (new_id(), name))
        role_id = conn.execute("SELECT id FROM sec_role WHERE name=?", (name,)).fetchone()["id"]
        for code in perms:
            perm_id = conn.execute("SELECT id FROM sec_permission WHERE code=?",
                                   (code,)).fetchone()["id"]
            conn.execute("INSERT OR IGNORE INTO sec_role_permission (role_id, perm_id)"
                         " VALUES (?,?)", (role_id, perm_id))
    conn.commit()


def permissions_of(conn, user_id: str) -> set[str]:
    """Effektive Rechte: additiv über Rollen, Deny gewinnt."""
    roles = [r["name"] for r in conn.execute(
        "SELECT r.name FROM sec_user_role ur JOIN sec_role r ON r.id = ur.role_id"
        " WHERE ur.user_id = ?", (user_id,))]
    granted: set[str] = set()
    denied: set[str] = set()
    for name in roles:
        perms, deny, _mode = ROLES.get(name, ([], [], "pseudonym"))
        granted.update(perms)
        denied.update(deny)
    return granted - denied


def default_mode(conn, user_id: str) -> str:
    """Default-Datenmodus: klar nur, wenn eine Rolle Klarzugriff vorsieht."""
    roles = [r["name"] for r in conn.execute(
        "SELECT r.name FROM sec_user_role ur JOIN sec_role r ON r.id = ur.role_id"
        " WHERE ur.user_id = ?", (user_id,))]
    modes = [DEFAULT_MODE.get(r, "pseudonym") for r in roles]
    if "clear" in modes and "patient.view.clear" in permissions_of(conn, user_id):
        return "clear"
    if "anonym" in modes and "pseudonym" not in modes:
        return "anonym"
    return "pseudonym"
