# -*- coding: utf-8 -*-
"""Versorgungsanalyse (docs/UI_SPEC.md §5): Kohorten-Builder, KPIs, Verläufe,
Forschungsexport. Aggregatschutz: Fallzahlen < MIN_CELL werden maskiert."""
from __future__ import annotations

import json
import statistics
from datetime import date

MIN_CELL = 5  # Aggregatschutz (UI_SPEC §5)


def _derivation_filter(derivation: str) -> str:
    """SQL-Zusatz je Provenienz: structured schliesst NLP-abgeleitete Ressourcen
    aus, nlp nur diese (DOKUMENTE_ANNOTATION.md §5, Confidence-/Provenance-Gate)."""
    if derivation == "structured":
        return " AND content NOT LIKE '%nlp-provenance%'"
    if derivation == "nlp":
        return " AND content LIKE '%nlp-provenance%'"
    return ""


def _codes(criterion: dict) -> list[str]:
    """Ein Code (code) oder Mehrfachauswahl (codes) -> Liste (ODER-verknüpft)."""
    vals = criterion.get("codes") or ([criterion["code"]] if criterion.get("code") else [])
    return [str(v) for v in vals if v]


def _pseudonyms_for(conn, criterion: dict, derivation: str = "all") -> set[str]:
    ctype = criterion.get("type")
    if ctype == "icd":
        codes = _codes(criterion)
        if not codes:
            return set()
        clause = " OR ".join("code_primary LIKE ?" for _ in codes)
        rows = conn.execute(
            "SELECT DISTINCT pseudonym FROM fhir_resource WHERE resource_type='Condition'"
            f" AND status='active' AND ({clause})" + _derivation_filter(derivation),
            tuple(c.upper() + "%" for c in codes)).fetchall()
    elif ctype == "concept":
        # Dokument-Konzept (SNOMED/ICD/...) aus der Dokument-Intelligence-Ebene
        include_uncertain = bool(criterion.get("include_uncertain", False))
        rows = conn.execute(
            "SELECT DISTINCT pseudonym FROM nlp_annotation"
            " WHERE entity_type='DOC_CONCEPT' AND negated=0"
            "   AND (code LIKE ? OR lower(text_snippet) LIKE lower(?))"
            + ("" if include_uncertain else " AND uncertain=0"),
            (str(criterion.get("code", "")) + "%",
             "%" + str(criterion.get("term", criterion.get("code", ""))) + "%")).fetchall()
    elif ctype == "atc":
        codes = _codes(criterion)
        if not codes:
            return set()
        clause = " OR ".join("content LIKE ?" for _ in codes)
        rows = conn.execute(
            "SELECT DISTINCT pseudonym FROM fhir_resource"
            " WHERE resource_type='MedicationStatement' AND status='active'"
            f" AND ({clause})" + _derivation_filter(derivation),
            tuple(f'%"{c.upper()}%' for c in codes)).fetchall()
    elif ctype == "medname":
        # Medikament ohne ATC-Code: Filter ueber den Praeparatenamen
        term = str(criterion.get("term") or "")
        if not term:
            return set()
        rows = conn.execute(
            "SELECT DISTINCT pseudonym FROM fhir_resource"
            " WHERE resource_type='MedicationStatement' AND status='active'"
            " AND json_extract(content,'$.medicationCodeableConcept.text') LIKE ?"
            + _derivation_filter(derivation), (term + "%",)).fetchall()
    elif ctype == "lab":
        op = {">": ">", ">=": ">=", "<": "<", "<=": "<=", "=": "="}[criterion.get("op", ">")]
        rows = conn.execute(
            "SELECT DISTINCT pseudonym FROM fhir_resource WHERE resource_type='Observation'"
            " AND status='active'"
            " AND (code_primary LIKE ? OR json_extract(content,'$.code.text') LIKE ?)"
            f" AND CAST(json_extract(content,'$.valueQuantity.value') AS REAL) {op} ?",
            (criterion["code"] + "%", "%" + criterion["code"] + "%",
             float(criterion["value"]))).fetchall()
    elif ctype == "gender":
        values = criterion.get("values") or [criterion.get("value")]
        values = [v for v in values if v]
        if not values:
            return set()
        marks = ",".join("?" for _ in values)
        rows = conn.execute(
            "SELECT DISTINCT id AS pseudonym FROM fhir_resource"
            " WHERE resource_type='Patient' AND status='active'"
            f" AND json_extract(content,'$.gender') IN ({marks})", values).fetchall()
    elif ctype == "age":
        # min/max oder Mehrfachauswahl von Altersbaendern (bands: [[50,59],...])
        bands = criterion.get("bands") or [[criterion.get("min", 0),
                                            criterion.get("max", 150)]]
        year_now = date.today().year
        conds, params = [], []
        for mn, mx in bands:
            conds.append("(CAST(substr(json_extract(content,'$.birthDate'),1,4) AS INT)"
                         " BETWEEN ? AND ?)")
            params += [year_now - int(mx), year_now - int(mn)]
        rows = conn.execute(
            "SELECT DISTINCT id AS pseudonym FROM fhir_resource"
            " WHERE resource_type='Patient' AND status='active'"
            " AND (" + " OR ".join(conds) + ")", params).fetchall()
    elif ctype == "text":
        want_negated = int(bool(criterion.get("negated", False)))
        rows = conn.execute(
            "SELECT DISTINCT pseudonym FROM nlp_annotation WHERE negated=?"
            " AND (lower(text_snippet) LIKE lower(?) OR code LIKE ?)",
            (want_negated, f"%{criterion['term']}%", criterion["term"] + "%")).fetchall()
    elif ctype == "period":
        rows = conn.execute(
            "SELECT DISTINCT pseudonym FROM fhir_resource WHERE status='active'"
            " AND effective >= ? AND effective <= ?",
            (criterion.get("from", "0000"), criterion.get("to", "9999"))).fetchall()
    else:
        raise ValueError(f"Unbekanntes Kriterium: {ctype}")
    return {r["pseudonym"] for r in rows if r["pseudonym"]}


def _universe(conn) -> set[str]:
    return {r["id"] for r in conn.execute(
        "SELECT id FROM fhir_resource WHERE resource_type='Patient'"
        " AND status='active'")}


def _eval_node(conn, node: dict, derivation: str, universe: set[str]) -> set[str]:
    """Rekursive Auswertung. Drei Knotenformen:
    - Sequenz  {items: [...], ops: [...]} — UI-Baukasten: Terme von links nach
      rechts gefaltet, ops[i] verknüpft das Zwischenergebnis mit items[i+1]
      (and | or | and-not | or-not). Klammern = verschachtelte Sequenzen.
    - Gruppe   {op: AND|OR, criteria: [...]} — flache Alt-/API-Form.
    - Kriterium (alles andere).
    `not: true` negiert jeden Knoten (Komplement gegen alle Patienten)."""
    if "items" in node:
        items = node.get("items", [])
        ops = node.get("ops", [])
        if not items:
            out: set[str] = set()
        else:
            out = _eval_node(conn, items[0], derivation, universe)
            for i, item in enumerate(items[1:]):
                op = str(ops[i] if i < len(ops) else "and").lower()
                rhs = _eval_node(conn, item, derivation, universe)
                if op == "or":
                    out |= rhs
                elif op in ("and-not", "andnot"):
                    out -= rhs
                elif op in ("or-not", "ornot"):
                    out |= (universe - rhs)
                else:                       # and (Default)
                    out &= rhs
    elif "criteria" in node:
        sets = [_eval_node(conn, c, derivation, universe)
                for c in node.get("criteria", [])]
        if not sets:
            out = set()
        elif str(node.get("op", "AND")).upper() == "OR":
            out = set().union(*sets)
        else:
            out = set.intersection(*sets)
    else:
        out = _pseudonyms_for(conn, node, derivation)
    if node.get("not"):
        out = universe - out
    return out


def build_cohort(conn, definition: dict) -> set[str]:
    derivation = definition.get("derivation", "all")   # structured | nlp | all
    expr = definition.get("expr")
    if expr:
        if not expr.get("items") and "criteria" not in expr and "type" not in expr:
            return set()
        return _eval_node(conn, expr, derivation, _universe(conn))
    criteria = definition.get("criteria", [])
    if not criteria:
        return set()
    return _eval_node(conn, {"op": definition.get("op", "AND"), "criteria": criteria},
                      derivation, _universe(conn))


def mask(n: int) -> int | str:
    return n if n == 0 or n >= MIN_CELL else f"<{MIN_CELL}"


# Kohorten-Mitgliedschaft als EIN JSON-Parameter statt einem SQL-Platzhalter je
# Patient: grosse Kohorten (z. B. I10 ueber die ganze Praxis) sprengen sonst das
# SQLite-Variablenlimit ('too many SQL variables').
_IN_COHORT = " IN (SELECT value FROM json_each(?))"


def cohort_stats(conn, definition: dict, lab_code: str | None = None) -> dict:
    cohort = build_cohort(conn, definition)
    size = len(cohort)
    if size == 0:
        return {"size": 0, "therapy": [], "co_diagnoses": [], "lab_trend": [],
                "gender": {}, "age_bands": {}}
    pjson = json.dumps(sorted(cohort))

    # ATC steht je nach Quelle an Position 0 oder 1 der Codierliste (PZN+ATC,
    # nur ATC, nur PZN) -> ueber das system-Feld ermitteln statt starrem Index
    _atc = ("CASE WHEN json_extract(content,'$.medicationCodeableConcept.coding[1].system')"
            " LIKE '%/atc' THEN json_extract(content,'$.medicationCodeableConcept.coding[1].code')"
            " WHEN json_extract(content,'$.medicationCodeableConcept.coding[0].system')"
            " LIKE '%/atc' THEN json_extract(content,'$.medicationCodeableConcept.coding[0].code')"
            " END")
    therapy = [dict(r) for r in conn.execute(
        f"SELECT {_atc} AS atc,"
        "  json_extract(content,'$.medicationCodeableConcept.text') AS name,"
        "  COUNT(DISTINCT pseudonym) AS n"
        " FROM fhir_resource WHERE resource_type='MedicationStatement' AND status='active'"
        f" AND pseudonym{_IN_COHORT} GROUP BY 1,2 ORDER BY n DESC LIMIT 10", (pjson,))]
    co_diag = [dict(r) for r in conn.execute(
        "SELECT code_primary AS icd,"
        "  json_extract(content,'$.code.coding[0].display') AS display,"
        "  COUNT(DISTINCT pseudonym) AS n"
        " FROM fhir_resource WHERE resource_type='Condition' AND status='active'"
        f" AND pseudonym{_IN_COHORT} AND code_primary IS NOT NULL"
        " GROUP BY 1 ORDER BY n DESC LIMIT 10", (pjson,))]

    gender: dict[str, int | str] = {}
    for r in conn.execute(
            "SELECT json_extract(content,'$.gender') AS g, COUNT(*) AS n FROM fhir_resource"
            f" WHERE resource_type='Patient' AND status='active' AND id{_IN_COHORT}"
            " GROUP BY 1", (pjson,)):
        gender[r["g"] or "unknown"] = mask(r["n"])

    age_bands: dict[str, int | str] = {}
    year_now = date.today().year
    for r in conn.execute(
            "SELECT CAST(substr(json_extract(content,'$.birthDate'),1,4) AS INT) AS y"
            f" FROM fhir_resource WHERE resource_type='Patient' AND status='active'"
            f" AND id{_IN_COHORT}", (pjson,)):
        if r["y"]:
            band = f"{(year_now - r['y']) // 10 * 10}–{(year_now - r['y']) // 10 * 10 + 9}"
            age_bands[band] = age_bands.get(band, 0) + 1
    age_bands = {k: mask(v) for k, v in sorted(age_bands.items())}

    lab_trend = []
    if lab_code:
        buckets: dict[str, list[float]] = {}
        for r in conn.execute(
                "SELECT effective, CAST(json_extract(content,'$.valueQuantity.value') AS REAL)"
                " AS v FROM fhir_resource WHERE resource_type='Observation'"
                " AND status='active'"
                " AND (code_primary LIKE ? OR json_extract(content,'$.code.text') LIKE ?)"
                f" AND pseudonym{_IN_COHORT} AND effective IS NOT NULL",
                (lab_code + "%", "%" + lab_code + "%", pjson)):
            eff = str(r["effective"] or "")
            # tolerant gegen Jahres-/Monatsangaben ("2023", "2023-05") aus echten Daten
            if r["v"] is None or len(eff) < 7 or not eff[5:7].isdigit():
                continue
            quarter = f"{eff[:4]}-Q{(int(eff[5:7]) - 1) // 3 + 1}"
            buckets.setdefault(quarter, []).append(r["v"])
        lab_trend = [{"period": q, "median": round(statistics.median(vs), 2),
                      "n": mask(len(vs))} for q, vs in sorted(buckets.items())]

    return {"size": size,
            "therapy": [{**t, "n": mask(t["n"])} for t in therapy],
            "co_diagnoses": [{**c, "n": mask(c["n"])} for c in co_diag],
            "gender": gender, "age_bands": age_bands, "lab_trend": lab_trend}


def research_export(conn, definition: dict, anonymize_extra: bool = True) -> list[dict]:
    """Forschungsexport (pseudonym/anonym): Ressourcen der Kohorte als Liste.
    anonymize_extra reduziert birthDate auf das Jahr (falls nicht schon geschehen)."""
    cohort = sorted(build_cohort(conn, definition))
    out = []
    if not cohort:
        return out
    pjson = json.dumps(cohort)
    for r in conn.execute(
            "SELECT content FROM fhir_resource WHERE status='active'"
            f" AND (pseudonym{_IN_COHORT} OR (resource_type='Patient' AND id{_IN_COHORT}))"
            " ORDER BY pseudonym, resource_type, id", (pjson, pjson)):
        res = json.loads(r["content"])
        if anonymize_extra and res.get("resourceType") == "Patient" and res.get("birthDate"):
            res["birthDate"] = res["birthDate"][:4]
        out.append(res)
    return out
