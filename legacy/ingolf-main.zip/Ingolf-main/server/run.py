#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Launcher für die Startmenü-Verknüpfung (docs/SETUP.md).

Ermittelt das Installationsverzeichnis (%LOCALAPPDATA%\\GreenbayClinical bzw.
Repo-Root im Dev-Betrieb) aus der eigenen Lage (app/server/run.py -> zwei Ebenen
hoch), setzt die GREENBAY_*-Umgebung, startet Uvicorn nur auf 127.0.0.1 und
öffnet den Browser. Kein Adminrecht, kein Dienst.
"""
from __future__ import annotations

import os
import sys
import threading
import webbrowser
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent.parent      # .../app  (oder Repo-Root)
BASE = APP_ROOT.parent if APP_ROOT.name == "app" else APP_ROOT  # Installationsordner

sys.path.insert(0, str(APP_ROOT))


def _port() -> int:
    cfg_path = BASE / "config" / "config.yaml"
    if cfg_path.exists():
        try:
            import yaml
            cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
            return int((cfg.get("server") or {}).get("port", 8710))
        except Exception:
            pass
    return int(os.environ.get("GREENBAY_PORT", "8710"))


def main() -> int:
    os.environ.setdefault("GREENBAY_HOME", str(BASE))
    os.environ.setdefault("GREENBAY_DB", str(BASE / "data" / "clinical.db"))
    os.environ.setdefault("GREENBAY_SECRET", str(BASE / "secret" / "master.bin"))
    port = _port()
    url = f"http://127.0.0.1:{port}/"

    import uvicorn
    from server.runtime import get_runtime
    try:
        get_runtime()  # Master-Secret + DB früh prüfen -> klare Fehlermeldung
    except RuntimeError as exc:
        print(f"[FEHLER] {exc}")
        print("Ersteinrichtung ausführen: python installer/first_run.py --appdir", BASE)
        return 1

    threading.Timer(1.5, lambda: webbrowser.open(url)).start()
    print(f"GREENBAY clinical läuft: {url}  (Beenden: Strg+C)")
    uvicorn.run("server.main:app", host="127.0.0.1", port=port, log_level="warning")
    return 0


if __name__ == "__main__":
    sys.exit(main())
