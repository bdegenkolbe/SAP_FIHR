# -*- coding: utf-8 -*-
"""Zentrale Anwendungseinstellungen (UI-Bereich „Einstellungen").

Alle Laufzeit-Konfigurationen liegen hier: Datenschutz-Schalter (privacy),
Dokument-Intelligence (annotation), Analyse-Provenienz, FHIR-Profil, Theme.
Persistenz: app_setting im Store (autoritativ für den Server) + Write-Through
in config/config.yaml (privacy-/annotation-Block), damit der Agent/Nachtlauf
dieselben Einstellungen nutzt. Secrets gehören NICHT hierher.
"""
from __future__ import annotations

import os
from pathlib import Path

from store.db import get_setting, set_setting

# key -> (erlaubte Werte | "bool" | "float" | "str", Default, config.yaml-Pfad oder None)
SCHEMA: dict[str, tuple] = {
    "fhir_profile":            (("r4", "mii", "kbv"), "r4", ("fhir", "profile")),
    "theme":                   (("light", "dark"), "light", None),
    # Default: Klardaten-Praxisbetrieb (alle Daten bleiben im Haus). Pseudonymi-
    # sierung/Gate sind Export-Optionen und werden hier bewusst zugeschaltet.
    "privacy_mode":            (("off", "pseudonymize", "anonymize"), "off",
                                ("privacy", "mode")),
    "privacy_gate":            (("enforce", "warn", "off"), "off", ("privacy", "gate")),
    "privacy_free_text_deid":  ("bool", "false", ("privacy", "free_text_deid")),
    "privacy_keep_filenames":  ("bool", "false", ("privacy", "keep_filenames")),
    "privacy_date_shift":      ("bool", "true", ("privacy", "date_shift")),
    "annotation_enabled":      ("bool", "false", ("annotation", "enabled")),
    "annotation_ocr":          ("bool", "false", ("annotation", "ocr")),
    "annotation_min_confidence": ("float", "0.6", ("annotation", "min_confidence")),
    "annotation_terminology_server": ("str", "", ("annotation", "terminology_server")),
    "analysis_include_nlp":    (("all", "structured", "nlp"), "all", None),
    # Anmeldung: TOTP-Pflicht. Standard AUS (Einzelplatz in der Praxis, physisch
    # gesichert); fuer Mehrplatz/exponierte Installationen auf "required" stellen.
    # Passwort + Rollen/Audit bleiben immer aktiv.
    "auth_mfa":                (("required", "off"), "off", None),
    # Quellverbindung (SQL Server) — Passwort läuft separat über /api/admin/source
    "source_host":             ("str", "", ("source", "host")),
    "source_port":             ("str", "1433", ("source", "port")),
    "source_database":         ("str", "EUGASTRO", ("source", "database")),
    "source_auth":             (("sql", "windows"), "sql", ("source", "auth")),
    "source_username":         ("str", "", ("source", "username")),
    # Sync-Zeitplan (Scheduled Task; Anwendung best effort über schtasks)
    "sync_time":               ("str", "03:30", None),
    "sync_enabled":            ("bool", "true", None),
    "load_since":              ("str", "", None),   # Stichtag für Läufe (leer = alles)
    # KI-Integration Stufe 0 (docs/KI_INTEGRATION.md): extern bereitgestellte
    # Endpunkte; API-Key DPAPI-geschützt in secret/aikey.bin (nie in Config/DB).
    "ai_provider":             (("off", "anthropic", "openai", "custom"), "off",
                                ("ai", "provider")),
    "ai_base_url":             ("str", "", ("ai", "base_url")),
    "ai_model":                ("str", "", ("ai", "model")),
    # Abwärtskompatibel (früherer Schlüssel):
    "privacy_mode_policy":     (("pseudonymize", "anonymize"), "pseudonymize", None),
}


def config_path() -> Path | None:
    base = os.environ.get("GREENBAY_HOME")
    if not base:
        return None
    return Path(base) / "config" / "config.yaml"


def validate(key: str, value: str) -> str:
    if key not in SCHEMA:
        raise ValueError(f"Unbekannte Einstellung: {key}")
    allowed, _default, _cfg = SCHEMA[key]
    value = str(value).strip()
    if allowed == "bool":
        if value.lower() not in ("true", "false"):
            raise ValueError(f"{key}: true|false erwartet")
        return value.lower()
    if allowed == "float":
        v = float(value)
        if not 0.0 <= v <= 1.0:
            raise ValueError(f"{key}: Wert 0..1 erwartet")
        return str(v)
    if allowed == "str":
        return value
    if value not in allowed:
        raise ValueError(f"{key}: erlaubt sind {allowed}")
    return value


def get_all(conn) -> dict:
    return {key: get_setting(conn, key, default)
            for key, (_a, default, _c) in SCHEMA.items()}


def set_many(conn, values: dict) -> dict:
    """Validiert, speichert in app_setting und schreibt config.yaml fort."""
    cleaned = {k: validate(k, v) for k, v in values.items()}
    for k, v in cleaned.items():
        set_setting(conn, k, v)
    _write_through(cleaned)
    return cleaned


def _typed(key: str, value: str):
    if key == "source_port":
        try:
            return int(value)
        except ValueError:
            return 1433
    allowed = SCHEMA[key][0]
    if allowed == "bool":
        return value == "true"
    if allowed == "float":
        return float(value)
    return value


def _dpapi_protect(raw: bytes) -> bytes:
    """DB-Passwort DPAPI-gebunden ablegen (Gegenstück: agent/export._unprotect)."""
    try:
        import win32crypt
        return win32crypt.CryptProtectData(raw, "GREENBAY clinical db password",
                                           None, None, None, 0)
    except ImportError:
        import sys
        sys.stderr.write("[WARN] DPAPI nicht verfügbar - DB-Passwort nur Dev-geschützt.\n")
        return b"DEV\x00" + raw


def store_db_password(password: str) -> str | None:
    """Schreibt secret/dbpass.bin und liefert den password_ref-Pfad (relativ)."""
    base = os.environ.get("GREENBAY_HOME")
    if not base:
        return None
    secret_dir = Path(base) / "secret"
    secret_dir.mkdir(parents=True, exist_ok=True)
    (secret_dir / "dbpass.bin").write_bytes(_dpapi_protect(password.encode("utf-8")))
    try:
        os.chmod(secret_dir / "dbpass.bin", 0o600)
    except OSError:
        pass
    return "secret/dbpass.bin"


def store_secret_file(name: str, value: str) -> str | None:
    """Beliebiges Secret DPAPI-geschützt unter secret/<name>.bin ablegen
    (z. B. KI-API-Key). Liefert den relativen Pfad."""
    base = os.environ.get("GREENBAY_HOME")
    if not base:
        return None
    secret_dir = Path(base) / "secret"
    secret_dir.mkdir(parents=True, exist_ok=True)
    path = secret_dir / f"{name}.bin"
    path.write_bytes(_dpapi_protect(value.encode("utf-8")))
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return f"secret/{name}.bin"


def read_secret_file(name: str) -> str | None:
    """Gegenstück zu store_secret_file (DPAPI/DEV-Präfix)."""
    base = os.environ.get("GREENBAY_HOME")
    if not base:
        return None
    path = Path(base) / "secret" / f"{name}.bin"
    if not path.exists():
        return None
    blob = path.read_bytes()
    if blob.startswith(b"DEV\x00"):
        return blob[4:].decode("utf-8")
    try:
        import win32crypt
        return win32crypt.CryptUnprotectData(blob, None, None, None, 0)[1].decode("utf-8")
    except ImportError:
        return None


def ensure_config_file() -> Path | None:
    """config/config.yaml anlegen, falls GREENBAY_HOME gesetzt aber Datei fehlt
    (die UI ist jetzt der primäre Konfigurationsweg)."""
    path = config_path()
    if path is None:
        return None
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("source: {}\nprivacy: {}\n", encoding="utf-8")
    return path


def _write_through(cleaned: dict) -> None:
    """privacy-/annotation-/source-/fhir-Blöcke in config/config.yaml aktualisieren,
    damit Agent-Läufe (Nachtlauf, CLI) dieselben Einstellungen verwenden.
    Ohne GREENBAY_HOME wird still übersprungen; sonst wird die Datei bei Bedarf
    angelegt (die UI ist der primäre Konfigurationsweg)."""
    path = ensure_config_file() if any(SCHEMA[k][2] for k in cleaned) else config_path()
    if path is None or not path.exists():
        return
    try:
        import yaml
        cfg = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        for key, value in cleaned.items():
            target = SCHEMA[key][2]
            if not target:
                continue
            section, field = target
            cfg.setdefault(section, {})[field] = _typed(key, value)
        path.write_text(yaml.safe_dump(cfg, allow_unicode=True, sort_keys=False),
                        encoding="utf-8")
    except Exception:
        # Write-Through ist best effort; app_setting bleibt autoritativ im Server
        pass
