# -*- coding: utf-8 -*-
"""Patientenauswahl + 360°-Sicht (docs/UI_SPEC.md §3/§4) über dem lokalen Store."""
from __future__ import annotations

import json
from datetime import date


def _d(x) -> dict:
    """x, wenn dict, sonst {} - echte Quelldaten liefern an CodeableConcept-
    Stellen gelegentlich Listen/null ('list' object has no attribute 'get')."""
    return x if isinstance(x, dict) else {}


def _coding0(cc) -> dict:
    """Erstes coding eines CodeableConcept - tolerant gegen null/leere Listen
    (echte Quelldaten liefern beides; die Demo-Daten taten das nie)."""
    if not isinstance(cc, dict):
        return {}
    codings = cc.get("coding") or []
    return codings[0] if codings and isinstance(codings[0], dict) else {}


def _first(lst) -> dict:
    """Erstes Element einer Liste, sonst {} (tolerant gegen null/[]/Fremdtypen)."""
    return lst[0] if isinstance(lst, list) and lst and isinstance(lst[0], dict) else {}


def _age(birth: str | None) -> int | None:
    if not birth:
        return None
    try:
        year = int(birth[:4])
    except ValueError:
        return None
    today = date.today()
    if len(birth) >= 10:
        born = date.fromisoformat(birth[:10])
        return today.year - born.year - ((today.month, today.day) < (born.month, born.day))
    return today.year - year


def _patient_summary(conn, pseudonym: str) -> dict:
    pat_row = conn.execute(
        "SELECT content FROM fhir_resource WHERE resource_type='Patient' AND pseudonym=?"
        " AND status='active'", (pseudonym,)).fetchone()
    pat = json.loads(pat_row["content"]) if pat_row else {}

    diagnoses = conn.execute(
        "SELECT DISTINCT code_primary AS icd,"
        "  json_extract(content,'$.code.coding[0].display') AS display"
        " FROM fhir_resource WHERE resource_type='Condition' AND pseudonym=?"
        " AND status='active' AND code_primary IS NOT NULL"
        " ORDER BY effective DESC LIMIT 5", (pseudonym,)).fetchall()

    last_lab = conn.execute(
        "SELECT json_extract(content,'$.code.text') AS name,"
        "  json_extract(content,'$.valueQuantity.value') AS value,"
        "  json_extract(content,'$.valueQuantity.unit') AS unit,"
        "  json_extract(content,'$.interpretation[0].coding[0].code') AS flag,"
        "  effective"
        " FROM fhir_resource WHERE resource_type='Observation' AND pseudonym=?"
        "  AND status='active'"
        "  AND json_extract(content,'$.category[0].coding[0].code')='laboratory'"
        " ORDER BY effective DESC LIMIT 1", (pseudonym,)).fetchone()

    meds = conn.execute(
        "SELECT COUNT(*) AS n FROM fhir_resource WHERE resource_type='MedicationStatement'"
        " AND pseudonym=? AND status='active'"
        " AND json_extract(content,'$.status')='active'", (pseudonym,)).fetchone()["n"]

    last_visit = conn.execute(
        "SELECT max(effective) AS d FROM fhir_resource"
        " WHERE pseudonym=? AND status='active' AND resource_type IN"
        " ('Encounter','Observation','Condition','DiagnosticReport')", (pseudonym,)
    ).fetchone()["d"]

    cave = conn.execute(
        "SELECT COUNT(*) AS n FROM fhir_resource WHERE pseudonym=? AND status='active'"
        " AND resource_type IN ('Flag','AllergyIntolerance')", (pseudonym,)).fetchone()["n"]

    # Klardaten-Modus (privacy off): Name ist in der Patient-Ressource enthalten
    # und wird angezeigt; bei Pseudonymisierung existiert das Feld nicht.
    name0 = _first(pat.get("name"))
    display_name = ", ".join(x for x in [
        name0.get("family"),
        " ".join(g for g in (name0.get("given") or []) if g)] if x) or None

    return {
        "pseudonym": pseudonym,
        "name": display_name,
        "gender": pat.get("gender"),
        "birthDate": pat.get("birthDate"),
        "age": _age(pat.get("birthDate")),
        "diagnoses": [dict(d) for d in diagnoses],
        "last_lab": dict(last_lab) if last_lab else None,
        "medication_count": meds,
        "last_visit": last_visit,
        "cave_count": cave,
    }


def search(conn, q: str = "", icd: str | None = None, atc: str | None = None,
           limit: int = 50, offset: int = 0) -> dict:
    """Suche über Pseudonym / ICD / ATC / Freitextbegriff (UI_SPEC §3)."""
    pseudonyms: set[str] | None = None

    def restrict(found: set[str]):
        nonlocal pseudonyms
        pseudonyms = found if pseudonyms is None else (pseudonyms & found)

    if icd:
        rows = conn.execute(
            "SELECT DISTINCT pseudonym FROM fhir_resource WHERE resource_type='Condition'"
            " AND status='active' AND code_primary LIKE ?", (icd + "%",)).fetchall()
        restrict({r["pseudonym"] for r in rows})
    if atc:
        rows = conn.execute(
            "SELECT DISTINCT pseudonym FROM fhir_resource"
            " WHERE resource_type='MedicationStatement' AND status='active'"
            " AND content LIKE ?", (f'%"{atc.upper()}%',)).fetchall()
        restrict({r["pseudonym"] for r in rows})
    if q:
        q_like = f"%{q}%"
        rows = conn.execute(
            "SELECT DISTINCT pseudonym FROM fhir_resource WHERE status='active' AND ("
            " pseudonym LIKE ? OR (resource_type='Condition' AND ("
            "   code_primary LIKE ? OR content LIKE ?)))",
            (q_like, f"{q}%", q_like)).fetchall()
        found = {r["pseudonym"] for r in rows}
        ann = conn.execute(
            "SELECT DISTINCT pseudonym FROM nlp_annotation WHERE negated=0 AND ("
            " lower(text_snippet) LIKE lower(?) OR code LIKE ?)",
            (q_like, f"{q}%")).fetchall()
        found |= {r["pseudonym"] for r in ann}
        restrict(found)

    if pseudonyms is None:
        rows = conn.execute(
            "SELECT id FROM fhir_resource WHERE resource_type='Patient' AND status='active'"
            " ORDER BY id").fetchall()
        pseudonyms = {r["id"] for r in rows}

    ordered = sorted(p for p in pseudonyms if p)
    total = len(ordered)
    page = ordered[offset:offset + limit]
    return {"total": total,
            "items": [_patient_summary(conn, p) for p in page]}


def patient360(conn, pseudonym: str) -> dict | None:
    """Komplette 360°-Sicht (UI_SPEC §4): KPIs, Timeline, Tab-Daten."""
    pat_row = conn.execute(
        "SELECT content FROM fhir_resource WHERE resource_type='Patient' AND id=?"
        " AND status='active'", (pseudonym,)).fetchone()
    if not pat_row:
        return None
    summary = _patient_summary(conn, pseudonym)

    def rows_of(rtype: str, extra: str = "", params: tuple = ()):
        return [json.loads(r["content"]) for r in conn.execute(
            f"SELECT content FROM fhir_resource WHERE resource_type=? AND pseudonym=?"
            f" AND status='active' {extra} ORDER BY effective", (rtype, pseudonym, *params))]

    conditions = rows_of("Condition")
    observations = rows_of("Observation")
    labs, vitals, narratives = [], [], []
    for o in observations:
        cat = _coding0(_first(o.get("category"))).get("code")
        (labs if cat == "laboratory" else
         vitals if cat == "vital-signs" else narratives).append(o)

    # Labor-Zeitreihen je Analyt (UI: Sparklines/Charts mit Referenzbereich)
    lab_series: dict[str, dict] = {}
    for o in labs:
        codings = _d(o.get("code")).get("coding") or []
        last_coding = codings[-1] if codings and isinstance(codings[-1], dict) else {}
        code = last_coding.get("code") or _d(o.get("code")).get("text") or "?"
        entry = lab_series.setdefault(code, {
            "code": code,
            "name": _d(o.get("code")).get("text") or code,
            "unit": _d(o.get("valueQuantity")).get("unit"),
            "reference": _first(o.get("referenceRange")).get("text"),
            "points": [],
        })
        vq = _d(o.get("valueQuantity"))
        if vq and o.get("effectiveDateTime"):
            flag = _coding0(_first(o.get("interpretation"))).get("code")
            entry["points"].append({"t": o["effectiveDateTime"], "v": vq.get("value"),
                                    "flag": flag})

    au_days = 0
    au_docs = rows_of("DocumentReference")
    compositions = rows_of("Composition")
    for d in au_docs:
        t = _d(d.get("type")).get("text") or ""
        if "au" in t.lower() or "arbeitsunf" in t.lower():
            au_days += 1

    timeline = []
    for res in (conditions + labs + vitals + narratives + rows_of("MedicationStatement")
                + rows_of("Encounter") + rows_of("Appointment") + au_docs + compositions
                + rows_of("DiagnosticReport")):
        period = res.get("period") if isinstance(res.get("period"), dict) else {}
        eff = (res.get("effectiveDateTime") or res.get("recordedDate")
               or res.get("authoredOn") or period.get("start")
               or res.get("start") or res.get("date"))
        label = (_d(res.get("code")).get("text")
                 or _coding0(res.get("code")).get("display")
                 or _d(res.get("medicationCodeableConcept")).get("text")
                 or _d(res.get("type")).get("text")
                 or res.get("title") or res.get("description")
                 or res.get("comment") or "")
        flag = _coding0(_first(res.get("interpretation"))).get("code")
        critical = flag in ("HH", "LL", "A") or (
            res.get("resourceType") == "Condition"
            and _coding0(res.get("verificationStatus")).get("code") == "confirmed"
            and str(label).lower().startswith(("akut", "karzinom")))
        if eff and isinstance(eff, str):
            timeline.append({"date": eff, "type": res.get("resourceType"), "label": label,
                             "id": res.get("id"), "flag": flag, "critical": bool(critical)})
    timeline.sort(key=lambda e: e["date"])

    return {
        **summary,
        "kpis": {
            "active_diagnoses": len({_coding0(c.get("code")).get("code")
                                     or _d(c.get("code")).get("text")
                                     for c in conditions} - {None}),
            "active_medication": summary["medication_count"],
            "labs_total": len(labs),
            "labs_flagged": sum(1 for o in labs if o.get("interpretation")),
            "au_entries": au_days,
        },
        "timeline": timeline,
        "conditions": conditions,
        "lab_series": sorted(lab_series.values(), key=lambda s: s["name"] or ""),
        "vitals": vitals,
        "medications": rows_of("MedicationStatement") + rows_of("MedicationRequest"),
        "documents": au_docs + compositions,
        "appointments": rows_of("Appointment"),
        "billing": rows_of("Encounter") + rows_of("Claim") + rows_of("Invoice")
        + rows_of("Coverage"),
        "flags": rows_of("Flag") + rows_of("AllergyIntolerance"),
    }
