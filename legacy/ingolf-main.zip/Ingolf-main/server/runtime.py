# -*- coding: utf-8 -*-
"""Laufzeitkontext des lokalen Servers: DB-Pfad, Master-Secret, Store-Verbindung.

Master-Secret-Auflösung (docs/CONCEPT.md 13.6):
1. ENV GREENBAY_MASTER_SECRET (Hex oder UTF-8) — Tests/Dev/Task-Aufruf
2. secret/master.bin — per DPAPI (CurrentUser) geschützt (installer/first_run.py);
   Nicht-Windows-Dev-Fallback: 'DEV\\x00'-Präfix
Kein Secret -> Serverstart bricht ab (bewusst; ohne Schlüssel kein Vault/TOTP).
"""
from __future__ import annotations

import os
import sys
import threading
from pathlib import Path

from store.db import open_store

BASE_DIR = Path(os.environ.get("GREENBAY_HOME", "."))
DB_PATH = Path(os.environ.get("GREENBAY_DB", BASE_DIR / "data" / "clinical.db"))
SECRET_PATH = Path(os.environ.get("GREENBAY_SECRET", BASE_DIR / "secret" / "master.bin"))


def load_master_secret() -> bytes:
    env = os.environ.get("GREENBAY_MASTER_SECRET")
    if env:
        try:
            return bytes.fromhex(env)
        except ValueError:
            return env.encode("utf-8")
    if SECRET_PATH.exists():
        blob = SECRET_PATH.read_bytes()
        if blob.startswith(b"DEV\x00"):
            sys.stderr.write("[WARN] Master-Secret ohne DPAPI-Schutz (Dev-Modus).\n")
            return blob[4:]
        try:
            import win32crypt  # pywin32, nur Windows
            return win32crypt.CryptUnprotectData(blob, None, None, None, 0)[1]
        except ImportError as exc:
            raise RuntimeError(
                "secret/master.bin ist DPAPI-geschützt, aber pywin32 fehlt."
            ) from exc
    raise RuntimeError(
        "Kein Master-Secret: GREENBAY_MASTER_SECRET setzen oder Ersteinrichtung "
        "(installer/first_run.py) ausführen."
    )


class Runtime:
    """Ein Prozess, eine DB-Verbindung je Thread (SQLite)."""

    def __init__(self, db_path: Path | str | None = None, master: bytes | None = None):
        self.db_path = Path(db_path or DB_PATH)
        self.master = master if master is not None else load_master_secret()
        self._local = threading.local()

    @property
    def conn(self):
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = open_store(self.db_path, key=self.master)
            from server import rbac
            rbac.seed(conn)
            self._local.conn = conn
        return conn


_runtime: Runtime | None = None


def get_runtime() -> Runtime:
    global _runtime
    if _runtime is None:
        _runtime = Runtime()
    return _runtime


def set_runtime(rt: Runtime) -> None:
    """Für Tests: Laufzeit mit eigener DB/eigenem Secret injizieren."""
    global _runtime
    _runtime = rt
