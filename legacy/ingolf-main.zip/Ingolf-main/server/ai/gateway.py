# -*- coding: utf-8 -*-
"""KI-Gateway Stufe 0 (docs/KI_INTEGRATION.md §2): Chat-Kanal zu extern
bereitgestellten Endpunkten (Anthropic / OpenAI-kompatibel / custom).

stdlib-only (urllib). Der API-Key liegt DPAPI-geschützt in secret/aikey.bin
und verlässt den Server nur Richtung konfigurierten Endpunkt. Jeder Aufruf
wird vom Aufrufer auditiert (ai.* im Audit-Log).
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request

DEFAULT_MODEL = {"anthropic": "claude-sonnet-5", "openai": "gpt-4o"}
DEFAULT_URL = {"anthropic": "https://api.anthropic.com",
               "openai": "https://api.openai.com"}
TIMEOUT = 120


class AiError(RuntimeError):
    pass


def _post(url: str, headers: dict, payload: dict) -> dict:
    req = urllib.request.Request(
        url, data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json", **headers}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:500]
        raise AiError(f"KI-Endpunkt HTTP {e.code}: {detail}") from e
    except urllib.error.URLError as e:
        raise AiError(f"KI-Endpunkt nicht erreichbar: {e.reason}") from e


def chat(provider: str, api_key: str, system: str, user: str,
         model: str = "", base_url: str = "", max_tokens: int = 1500) -> str:
    """Ein Chat-Turn -> Antworttext. provider: anthropic | openai | custom
    (custom = OpenAI-kompatible API unter base_url)."""
    if provider == "anthropic":
        url = (base_url or DEFAULT_URL["anthropic"]).rstrip("/") + "/v1/messages"
        body = _post(url, {"x-api-key": api_key, "anthropic-version": "2023-06-01"}, {
            "model": model or DEFAULT_MODEL["anthropic"],
            "max_tokens": max_tokens,
            "system": system,
            "messages": [{"role": "user", "content": user}],
        })
        return "".join(b.get("text", "") for b in body.get("content", [])
                       if b.get("type") == "text").strip()
    if provider in ("openai", "custom"):
        url = (base_url or DEFAULT_URL["openai"]).rstrip("/") + "/v1/chat/completions"
        body = _post(url, {"Authorization": f"Bearer {api_key}"}, {
            "model": model or DEFAULT_MODEL["openai"],
            "max_tokens": max_tokens,
            "messages": [{"role": "system", "content": system},
                         {"role": "user", "content": user}],
        })
        choices = body.get("choices") or [{}]
        return ((choices[0].get("message") or {}).get("content") or "").strip()
    raise AiError(f"Unbekannter Provider: {provider}")
