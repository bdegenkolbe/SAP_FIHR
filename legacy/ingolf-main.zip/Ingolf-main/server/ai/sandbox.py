# -*- coding: utf-8 -*-
"""Code-Interpreter-Client der Plattform (docs/KI_INTEGRATION.md §3.5).

RemoteSandbox spricht den Sandbox-Service (sandbox-service/, Profil B) an —
eine Session je UI-Session, Dateien rein/raus, Zellen ausführen. Die Sandbox
erhält nur explizit hineingegebene Dateien; jeder Transfer wird vom Aufrufer
auditiert (Manifest mit Hashes, ai_call/ai_sandbox_session folgen mit Stufe 0/3).

LocalSandbox (Profil A, No-Admin) folgt später hinter derselben Schnittstelle.
"""
from __future__ import annotations

import hashlib
import json
import urllib.error
import urllib.request


class SandboxUnavailable(Exception):
    pass


class RemoteSandbox:
    """Client für den Sandbox-Service. Eine Instanz = eine Session."""

    def __init__(self, base_url: str, token: str, timeout: int = 60):
        self.base = base_url.rstrip("/")
        self.token = token
        self.timeout = timeout
        self.session_id: str | None = None
        self.manifest: list[dict] = []   # hineingelegte Dateien (Name, SHA256, Größe)

    # -- HTTP ---------------------------------------------------------------
    def _call(self, method: str, path: str, body: bytes | dict | None = None,
              raw: bool = False):
        data = None
        headers = {"Authorization": "Bearer " + self.token}
        if isinstance(body, dict):
            data = json.dumps(body).encode("utf-8")
            headers["Content-Type"] = "application/json"
        elif isinstance(body, bytes):
            data = body
            headers["Content-Type"] = "application/octet-stream"
        req = urllib.request.Request(self.base + path, data=data, headers=headers,
                                     method=method)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                payload = resp.read()
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", "replace")[:300]
            raise SandboxUnavailable(f"Sandbox-Service {exc.code}: {detail}")
        except urllib.error.URLError as exc:
            raise SandboxUnavailable(f"Sandbox-Service nicht erreichbar: {exc.reason}")
        return payload if raw else json.loads(payload or b"{}")

    # -- Lebenszyklus ---------------------------------------------------------
    def create(self) -> str:
        self.session_id = self._call("POST", "/sessions")["id"]
        return self.session_id

    def _sid(self) -> str:
        if not self.session_id:
            self.create()
        return self.session_id

    def close(self) -> None:
        if self.session_id:
            try:
                self._call("DELETE", f"/sessions/{self.session_id}")
            finally:
                self.session_id = None

    # -- Arbeiten -------------------------------------------------------------
    def upload(self, name: str, data: bytes) -> dict:
        result = self._call("PUT", f"/sessions/{self._sid()}/files/{name}", body=data)
        entry = {"name": name, "size": len(data),
                 "sha256": hashlib.sha256(data).hexdigest()}
        self.manifest.append(entry)
        return entry

    def download(self, name: str) -> bytes:
        return self._call("GET", f"/sessions/{self._sid()}/files/{name}", raw=True)

    def files(self) -> list[dict]:
        return self._call("GET", f"/sessions/{self._sid()}/files")["files"]

    def exec(self, code: str, cell_timeout: int = 30) -> dict:
        """Eine Zelle ausführen. Rückgabe: {ok, stdout, stderr, error, artifacts,
        duration_ms} — Artefakte anschließend per download() abholen."""
        return self._call("POST", f"/sessions/{self._sid()}/exec",
                          body={"code": code, "cell_timeout": cell_timeout})

    def __enter__(self):
        self.create()
        return self

    def __exit__(self, *_exc):
        self.close()
