# -*- coding: utf-8 -*-
"""Authentifizierung (docs/BENUTZERVERWALTUNG.md §4): Argon2id (Fallback PBKDF2),
TOTP (RFC 6238, stdlib), Sessions (nur Token-Hash gespeichert), Rate-Limit,
Recovery-Codes. Kein Mailversand nötig (Einzelplatz)."""
from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import struct
import time
from datetime import datetime, timedelta, timezone

from store.db import audit, new_id
from store import vault as vaultmod

SESSION_TTL_MINUTES = 60
MAX_FAILED_LOGINS = 5
LOCK_MINUTES = 15


# ---- Passwort ---------------------------------------------------------------

def hash_password(pw: str) -> str:
    try:
        from argon2 import PasswordHasher
        return PasswordHasher().hash(pw)
    except ImportError:
        salt = secrets.token_bytes(16)
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, 200_000)
        return "pbkdf2$" + base64.b64encode(salt).decode() + "$" + base64.b64encode(dk).decode()


def verify_password(stored: str, pw: str) -> bool:
    if stored.startswith("pbkdf2$"):
        _, salt_b64, dk_b64 = stored.split("$")
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), base64.b64decode(salt_b64), 200_000)
        return hmac.compare_digest(dk, base64.b64decode(dk_b64))
    try:
        from argon2 import PasswordHasher
        from argon2.exceptions import VerifyMismatchError
        try:
            PasswordHasher().verify(stored, pw)
            return True
        except VerifyMismatchError:
            return False
    except ImportError:
        return False


# ---- TOTP (RFC 6238, stdlib) -------------------------------------------------

def totp_new_secret() -> str:
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")


def totp_uri(secret: str, user: str) -> str:
    return f"otpauth://totp/GREENBAY%20clinical:{user}?secret={secret}&issuer=GREENBAY"


def totp_code(secret: str, at: int | None = None) -> str:
    key = base64.b32decode(secret + "=" * (-len(secret) % 8))
    counter = int((at if at is not None else time.time()) // 30)
    digest = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    code = (struct.unpack(">I", digest[offset:offset + 4])[0] & 0x7FFFFFFF) % 1_000_000
    return f"{code:06d}"


def totp_verify(secret: str, code: str, at: int | None = None) -> bool:
    now = at if at is not None else int(time.time())
    return any(hmac.compare_digest(totp_code(secret, now + drift * 30), code.strip())
               for drift in (-1, 0, 1))


# ---- Benutzer ----------------------------------------------------------------

class AuthError(Exception):
    pass


def register_user(conn, master: bytes, username: str, full_name: str,
                  password_hash: str, totp_secret: str, recovery_codes: list[str],
                  roles: list[str], created_by: str | None = None,
                  mfa_required: bool = True) -> str:
    """Kern der Benutzeranlage (genutzt von create_user und First-Run-Wizard):
    nimmt bereits gehashtes Passwort + vorhandenes TOTP-Secret entgegen."""
    user_id = new_id()
    conn.execute(
        "INSERT INTO sec_app_user (id, username, full_name, password_hash, mfa_secret,"
        " mfa_enabled, created_by) VALUES (?,?,?,?,?,?,?)",
        (user_id, username, full_name, password_hash,
         vaultmod.encrypt(master, totp_secret), int(mfa_required), created_by),
    )
    for role in roles:
        row = conn.execute("SELECT id FROM sec_role WHERE name=?", (role,)).fetchone()
        if not row:
            raise AuthError(f"Unbekannte Rolle: {role}")
        conn.execute("INSERT OR IGNORE INTO sec_user_role (user_id, role_id) VALUES (?,?)",
                     (user_id, row["id"]))
    for code in recovery_codes:
        conn.execute("INSERT INTO sec_recovery_code (user_id, code_hash) VALUES (?,?)",
                     (user_id, hashlib.sha256(code.encode()).hexdigest()))
    conn.commit()
    audit(conn, "user.create", user_id=created_by, object_type="app_user",
          object_id=user_id, detail={"username": username, "roles": roles})
    return user_id


def create_user(conn, master: bytes, username: str, full_name: str, password: str,
                roles: list[str], created_by: str | None = None,
                mfa_required: bool = True) -> dict:
    totp_secret = totp_new_secret()
    recovery = [secrets.token_hex(4) + "-" + secrets.token_hex(4) for _ in range(8)]
    user_id = register_user(conn, master, username, full_name, hash_password(password),
                            totp_secret, recovery, roles, created_by=created_by,
                            mfa_required=mfa_required)
    return {"id": user_id, "username": username, "totp_secret": totp_secret,
            "totp_uri": totp_uri(totp_secret, username), "recovery_codes": recovery}


def _user_by_name(conn, username: str):
    return conn.execute("SELECT * FROM sec_app_user WHERE username=?", (username,)).fetchone()


def _check_rate_limit(conn, username: str) -> None:
    since = (datetime.now(timezone.utc) - timedelta(minutes=LOCK_MINUTES)) \
        .strftime("%Y-%m-%d %H:%M:%S")
    row = conn.execute(
        "SELECT COUNT(*) AS n, max(ts) AS last FROM sec_login_versuch"
        " WHERE username=? AND success=0 AND ts > ?", (username, since),
    ).fetchone()
    if row["n"] >= MAX_FAILED_LOGINS:
        try:
            last = datetime.strptime(row["last"], "%Y-%m-%d %H:%M:%S") \
                .replace(tzinfo=timezone.utc)
            rest = max(1, int((last + timedelta(minutes=LOCK_MINUTES)
                               - datetime.now(timezone.utc)).total_seconds() // 60) + 1)
            hinweis = f" Wieder möglich in ca. {rest} Min."
        except (TypeError, ValueError):
            hinweis = f" Wieder möglich nach {LOCK_MINUTES} Min. Wartezeit."
        raise AuthError("Konto vorübergehend gesperrt (zu viele Fehlversuche)." + hinweis)


def login(conn, master: bytes, username: str, password: str,
          totp: str | None = None, recovery_code: str | None = None,
          ip: str | None = None, require_mfa: bool = True) -> dict:
    """Login-Flow: Passwort + TOTP (oder Recovery-Code). Rückgabe Session-Token.
    require_mfa=False (Einstellung auth_mfa=off, Einzelplatz-Praxis): nur Passwort."""
    _check_rate_limit(conn, username)
    user = _user_by_name(conn, username)

    def fail(reason: str):
        conn.execute("INSERT INTO sec_login_versuch (username, success, ip) VALUES (?,0,?)",
                     (username, ip))
        conn.commit()
        audit(conn, "login", user_id=user["id"] if user else None,
              detail={"username": username, "reason": reason}, ip=ip, success=False)
        raise AuthError("Anmeldung fehlgeschlagen.")

    if user is None or user["status"] != "active":
        fail("unknown_or_inactive")
    if not verify_password(user["password_hash"], password):
        fail("bad_password")

    if user["mfa_enabled"] and require_mfa:
        if recovery_code:
            code_hash = hashlib.sha256(recovery_code.strip().encode()).hexdigest()
            row = conn.execute(
                "SELECT rowid FROM sec_recovery_code WHERE user_id=? AND code_hash=?"
                " AND used_at IS NULL", (user["id"], code_hash)).fetchone()
            if not row:
                fail("bad_recovery_code")
            conn.execute("UPDATE sec_recovery_code SET used_at=datetime('now')"
                         " WHERE rowid=?", (row["rowid"],))
        else:
            secret = vaultmod.decrypt(master, user["mfa_secret"])
            if not totp or not totp_verify(secret, totp):
                fail("bad_totp")

    token = secrets.token_urlsafe(32)
    expires = (datetime.now(timezone.utc) + timedelta(minutes=SESSION_TTL_MINUTES)) \
        .strftime("%Y-%m-%d %H:%M:%S")
    conn.execute(
        "INSERT INTO sec_session (id, user_id, token_hash, expires_at, ip)"
        " VALUES (?,?,?,?,?)",
        (new_id(), user["id"], hashlib.sha256(token.encode()).hexdigest(), expires, ip),
    )
    conn.execute("UPDATE sec_app_user SET failed_logins=0, last_login_at=datetime('now')"
                 " WHERE id=?", (user["id"],))
    # Erfolgreicher Login setzt den Brute-Force-Zähler zurück — alte Fehlversuche
    # (z. B. vergessener TOTP-Code) wirken nicht in die Zukunft nach.
    conn.execute("DELETE FROM sec_login_versuch WHERE username=? AND success=0",
                 (username,))
    conn.execute("INSERT INTO sec_login_versuch (username, success, ip) VALUES (?,1,?)",
                 (username, ip))
    conn.commit()
    audit(conn, "login", user_id=user["id"], ip=ip, success=True)
    return {"token": token, "user_id": user["id"], "username": user["username"],
            "expires_at": expires}


def session_user(conn, token: str):
    """Session-Token -> Benutzerzeile (oder None)."""
    if not token:
        return None
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    row = conn.execute(
        "SELECT s.*, u.username, u.full_name, u.status FROM sec_session s"
        " JOIN sec_app_user u ON u.id = s.user_id"
        " WHERE s.token_hash=? AND s.revoked_at IS NULL"
        "   AND s.expires_at > datetime('now')", (token_hash,),
    ).fetchone()
    if row is None or row["status"] != "active":
        return None
    return row


def logout(conn, token: str) -> None:
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    row = conn.execute("SELECT id, user_id FROM sec_session WHERE token_hash=?",
                       (token_hash,)).fetchone()
    if row:
        conn.execute("UPDATE sec_session SET revoked_at=datetime('now') WHERE id=?",
                     (row["id"],))
        conn.commit()
        audit(conn, "logout", user_id=row["user_id"])


def reauth(conn, master: bytes, user_id: str, password: str, totp: str | None,
           require_mfa: bool = True) -> bool:
    """Re-Authentifizierung vor sensiblen Aktionen (Break-Glass etc.)."""
    user = conn.execute("SELECT * FROM sec_app_user WHERE id=?", (user_id,)).fetchone()
    if not user or not verify_password(user["password_hash"], password):
        return False
    if user["mfa_enabled"] and require_mfa:
        secret = vaultmod.decrypt(master, user["mfa_secret"])
        if not totp or not totp_verify(secret, totp):
            return False
    return True
