# -*- coding: utf-8 -*-
"""GREENBAY clinical — lokaler Anwendungsserver (nur 127.0.0.1, No-Admin).

Start:  python -m server.main   (oder: uvicorn server.main:app --host 127.0.0.1)

Setzt docs/UI_SPEC.md + docs/BENUTZERVERWALTUNG.md um: Auth (Passwort+TOTP),
RBAC-geschützte Endpunkte, Datenschutz-Weiche (Modus-Badge), Break-Glass mit
Re-Auth + Begründung + Audit, Kohortenanalyse mit Aggregatschutz, Kataloge,
Verwaltung (Benutzer, Audit, ETL-Status), Einstellungen (FHIR-Profil).
"""
from __future__ import annotations

import json
from pathlib import Path

from fastapi import Body, Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from server import analysis, auth, patients, rbac
from server.runtime import get_runtime
from store import vault as vaultmod
from store.db import audit, verify_audit_chain

app = FastAPI(title="GREENBAY clinical", version="1.0.0", docs_url=None, redoc_url=None)

UI_DIR = Path(__file__).resolve().parent.parent / "ui" / "app"
DESIGN_DIR = Path(__file__).resolve().parent.parent / "ui" / "design"


# ---- Auth-Dependency ---------------------------------------------------------

class Principal:
    def __init__(self, row, permissions: set[str], mode: str):
        self.user_id = row["user_id"]
        self.username = row["username"]
        self.full_name = row["full_name"]
        self.permissions = permissions
        self.mode = mode  # clear | pseudonym | anonym

    def need(self, *perms: str):
        if not set(perms) & self.permissions:
            raise HTTPException(403, "Keine Berechtigung: " + ", ".join(perms))


def principal(authorization: str = Header(default="")) -> Principal:
    rt = get_runtime()
    token = authorization.removeprefix("Bearer ").strip()
    row = auth.session_user(rt.conn, token)
    if row is None:
        raise HTTPException(401, "Nicht angemeldet oder Session abgelaufen.")
    perms = rbac.permissions_of(rt.conn, row["user_id"])
    mode = rbac.default_mode(rt.conn, row["user_id"])
    return Principal(row, perms, mode)


# ---- Setup & Auth --------------------------------------------------------------

def _mfa_required(conn) -> bool:
    from store.db import get_setting
    return get_setting(conn, "auth_mfa", "off") != "off"


@app.get("/api/status")
def status():
    rt = get_runtime()
    n_users = rt.conn.execute("SELECT COUNT(*) AS n FROM sec_app_user").fetchone()["n"]
    n_res = rt.conn.execute("SELECT COUNT(*) AS n FROM fhir_resource"
                            " WHERE status='active'").fetchone()["n"]
    return {"setup_required": n_users == 0, "resources": n_res,
            "mfa_required": _mfa_required(rt.conn)}


@app.post("/api/setup")
def setup(payload: dict = Body(...)):
    """First-Run-Bootstrap (BENUTZERVERWALTUNG §4): legt genau einen owner an."""
    rt = get_runtime()
    n = rt.conn.execute("SELECT COUNT(*) AS n FROM sec_app_user").fetchone()["n"]
    if n > 0:
        raise HTTPException(409, "Setup bereits abgeschlossen.")
    if len(payload.get("password", "")) < 12:
        raise HTTPException(422, "Passwort: mindestens 12 Zeichen.")
    result = auth.create_user(
        rt.conn, rt.master, payload["username"], payload.get("full_name", payload["username"]),
        payload["password"], roles=["owner"], mfa_required=True,
    )
    return result  # enthält TOTP-URI + Recovery-Codes (einmalige Anzeige!)


@app.post("/api/login")
def login(request: Request, payload: dict = Body(...)):
    rt = get_runtime()
    try:
        session = auth.login(rt.conn, rt.master, payload.get("username", ""),
                             payload.get("password", ""), totp=payload.get("totp"),
                             recovery_code=payload.get("recovery_code"),
                             ip=request.client.host if request.client else None,
                             require_mfa=_mfa_required(rt.conn))
    except auth.AuthError as exc:
        raise HTTPException(401, str(exc))
    perms = rbac.permissions_of(rt.conn, session["user_id"])
    mode = rbac.default_mode(rt.conn, session["user_id"])
    return {**session, "permissions": sorted(perms), "mode": mode}


@app.post("/api/logout")
def logout(authorization: str = Header(default="")):
    rt = get_runtime()
    auth.logout(rt.conn, authorization.removeprefix("Bearer ").strip())
    return {"ok": True}


@app.get("/api/me")
def me(p: Principal = Depends(principal)):
    return {"username": p.username, "full_name": p.full_name,
            "permissions": sorted(p.permissions), "mode": p.mode}


# ---- Patienten -----------------------------------------------------------------

@app.get("/api/patients")
def patients_search(q: str = "", icd: str = "", atc: str = "", limit: int = 50,
                    offset: int = 0, p: Principal = Depends(principal)):
    p.need("patient.search.pseudo", "patient.search.clear")
    rt = get_runtime()
    return patients.search(rt.conn, q=q, icd=icd or None, atc=atc or None,
                           limit=min(limit, 200), offset=offset)


@app.get("/api/patients/{pseudonym}")
def patient_view(pseudonym: str, p: Principal = Depends(principal)):
    p.need("patient.view.pseudo", "patient.view.clear")
    rt = get_runtime()
    try:
        data = patients.patient360(rt.conn, pseudonym)
    except Exception as exc:
        # Ursache an die UI melden statt anonymem 500 (Details im Server-Log)
        import traceback
        traceback.print_exc()
        raise HTTPException(500, f"360°-Sicht fehlgeschlagen: {exc}") from exc
    if data is None:
        raise HTTPException(404, "Pseudonym unbekannt.")
    if "text.read" not in p.permissions:
        data.pop("documents", None)
    audit(rt.conn, "patient.view", user_id=p.user_id, object_type="patient",
          object_id=pseudonym)
    return data


@app.post("/api/patients/{pseudonym}/reid")
def break_glass(pseudonym: str, payload: dict = Body(...),
                p: Principal = Depends(principal)):
    """Break-Glass (BENUTZERVERWALTUNG §5): Re-Auth + Begründung + Audit."""
    p.need("reid.request")
    rt = get_runtime()
    reason = (payload.get("reason") or "").strip()
    if len(reason) < 10:
        raise HTTPException(422, "Begründung (Zweckbindung) ist Pflicht (min. 10 Zeichen).")
    if not auth.reauth(rt.conn, rt.master, p.user_id, payload.get("password", ""),
                       payload.get("totp"), require_mfa=_mfa_required(rt.conn)):
        audit(rt.conn, "reid.request", user_id=p.user_id, object_type="patient",
              object_id=pseudonym, detail={"reason": reason}, success=False)
        raise HTTPException(401, "Re-Authentifizierung fehlgeschlagen.")
    resolved = vaultmod.resolve(rt.conn, rt.master, pseudonym)
    audit(rt.conn, "reid.request", user_id=p.user_id, object_type="patient",
          object_id=pseudonym, detail={"reason": reason}, success=resolved is not None)
    if resolved is None:
        raise HTTPException(404, "Kein Vault-Eintrag zu diesem Pseudonym.")
    return {"pseudonym": pseudonym, "source_id": resolved["source_id"],
            "source_nr": resolved["source_nr"], "reason": reason,
            "hinweis": "Zugriff protokolliert (append-only Audit)."}


# ---- Volltextsuche & Analyse ---------------------------------------------------

@app.get("/api/search/text")
def text_search(q: str, negated: bool = False, p: Principal = Depends(principal)):
    p.need("analysis.run")
    rt = get_runtime()
    from store.annotate import search_fulltext
    return {"query": q, "hits": search_fulltext(rt.conn, q, negated=negated)}


@app.post("/api/analysis/cohort")
def cohort(definition: dict = Body(...), p: Principal = Depends(principal)):
    p.need("analysis.run")
    rt = get_runtime()
    from store.db import get_setting
    definition.setdefault("derivation",
                          get_setting(rt.conn, "analysis_include_nlp", "all"))
    try:
        stats = analysis.cohort_stats(rt.conn, definition,
                                      lab_code=definition.get("lab_trend"))
    except (KeyError, ValueError) as exc:
        raise HTTPException(422, f"Ungültige Kohortendefinition: {exc}")
    except Exception as exc:
        import traceback
        traceback.print_exc()
        raise HTTPException(500, f"Kohortenberechnung fehlgeschlagen: {exc}") from exc
    stats["size_masked"] = analysis.mask(stats["size"])
    audit(rt.conn, "query.run", user_id=p.user_id, object_type="cohort",
          detail={"definition": definition, "size": stats["size"]})
    return stats


@app.post("/api/analysis/export")
def research_export(definition: dict = Body(...), p: Principal = Depends(principal)):
    p.need("export.research")
    rt = get_runtime()
    try:
        resources = analysis.research_export(rt.conn, definition,
                                             anonymize_extra=p.mode == "anonym")
    except Exception as exc:
        import traceback
        traceback.print_exc()
        raise HTTPException(500, f"Forschungsexport fehlgeschlagen: {exc}") from exc
    audit(rt.conn, "deid.export", user_id=p.user_id, object_type="cohort",
          detail={"definition": definition, "resources": len(resources),
                  "mode": p.mode})
    return JSONResponse({"resourceType": "Bundle", "type": "collection",
                         "entry": [{"resource": r} for r in resources]})


# ---- Kataloge ------------------------------------------------------------------

@app.get("/api/catalogs")
def catalogs(p: Principal = Depends(principal)):
    rt = get_runtime()
    rows = rt.conn.execute(
        "SELECT catalog, resource_type, COUNT(*) AS n, max(version) AS version"
        " FROM ref_resource GROUP BY catalog, resource_type ORDER BY catalog").fetchall()
    return {"catalogs": [dict(r) for r in rows]}


@app.get("/api/catalogs/{catalog}")
def catalog_entries(catalog: str, q: str = "", limit: int = 100,
                    p: Principal = Depends(principal)):
    rt = get_runtime()
    rows = rt.conn.execute(
        "SELECT content FROM ref_resource WHERE catalog=? AND content LIKE ?"
        " ORDER BY id LIMIT ?", (catalog, f"%{q}%", min(limit, 500))).fetchall()
    return {"entries": [json.loads(r["content"]) for r in rows]}


# ---- Verwaltung ----------------------------------------------------------------

@app.get("/api/admin/users")
def users_list(p: Principal = Depends(principal)):
    p.need("user.manage")
    rt = get_runtime()
    rows = rt.conn.execute(
        "SELECT u.id, u.username, u.full_name, u.status, u.mfa_enabled, u.last_login_at,"
        " group_concat(r.name) AS roles FROM sec_app_user u"
        " LEFT JOIN sec_user_role ur ON ur.user_id = u.id"
        " LEFT JOIN sec_role r ON r.id = ur.role_id"
        " GROUP BY u.id ORDER BY u.username").fetchall()
    return {"users": [dict(r) for r in rows],
            "roles": sorted(rbac.ROLES), "matrix": rbac.ROLES}


@app.post("/api/admin/users")
def user_create(payload: dict = Body(...), p: Principal = Depends(principal)):
    p.need("user.manage")
    rt = get_runtime()
    roles = payload.get("roles", [])
    if not roles:
        raise HTTPException(422, "Mindestens eine Rolle angeben.")
    if len(payload.get("password", "")) < 12:
        raise HTTPException(422, "Passwort: mindestens 12 Zeichen.")
    try:
        return auth.create_user(rt.conn, rt.master, payload["username"],
                                payload.get("full_name", payload["username"]),
                                payload["password"], roles=roles, created_by=p.user_id)
    except auth.AuthError as exc:
        raise HTTPException(422, str(exc))


@app.post("/api/admin/users/{user_id}/status")
def user_status(user_id: str, payload: dict = Body(...),
                p: Principal = Depends(principal)):
    p.need("user.manage")
    rt = get_runtime()
    status_new = payload.get("status")
    if status_new not in ("active", "locked", "disabled"):
        raise HTTPException(422, "status: active|locked|disabled")
    rt.conn.execute("UPDATE sec_app_user SET status=?, updated_at=datetime('now')"
                    " WHERE id=?", (status_new, user_id))
    rt.conn.commit()
    audit(rt.conn, "role.change", user_id=p.user_id, object_type="app_user",
          object_id=user_id, detail={"status": status_new})
    return {"ok": True}


@app.get("/api/admin/audit")
def audit_log(limit: int = 200, p: Principal = Depends(principal)):
    p.need("audit.read")
    rt = get_runtime()
    rows = rt.conn.execute(
        "SELECT a.*, u.username FROM audit_event a"
        " LEFT JOIN sec_app_user u ON u.id = a.user_id"
        " ORDER BY a.id DESC LIMIT ?", (min(limit, 1000),)).fetchall()
    ok, checked = verify_audit_chain(rt.conn)
    return {"chain_valid": ok, "chain_checked": checked,
            "events": [dict(r) for r in rows]}


@app.post("/api/admin/source")
def source_save(payload: dict = Body(...), p: Principal = Depends(principal)):
    """Quellverbindung (SQL Server) aus der UI: Felder + optional Passwort.
    Das Passwort wird DPAPI-geschützt als secret/dbpass.bin abgelegt und nie
    im Klartext gespeichert oder zurückgegeben."""
    p.need("settings.manage")
    from server import settings as S
    rt = get_runtime()
    # immer den kompletten source-Block schreiben (fehlende Felder = aktueller Stand),
    # damit die config.yaml fuer den Agenten vollstaendig ist
    current = S.get_all(rt.conn)
    fields = {k: payload.get(k, current[k])
              for k in ("source_host", "source_port", "source_database",
                        "source_auth", "source_username")}
    try:
        cleaned = S.set_many(rt.conn, fields)
    except ValueError as exc:
        raise HTTPException(422, str(exc))
    password_stored = False
    if payload.get("password"):
        ref = S.store_db_password(payload["password"])
        if ref is None:
            raise HTTPException(422, "GREENBAY_HOME nicht gesetzt - Passwort kann nicht "
                                     "abgelegt werden (Ersteinrichtung nutzen).")
        # password_ref in der Config verankern
        path = S.ensure_config_file()
        import yaml
        cfg = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        cfg.setdefault("source", {})["password_ref"] = ref
        cfg["source"].pop("password", None)
        path.write_text(yaml.safe_dump(cfg, allow_unicode=True, sort_keys=False),
                        encoding="utf-8")
        password_stored = True
    audit(rt.conn, "settings.change", user_id=p.user_id,
          detail={**cleaned, "password_stored": password_stored})
    return {"ok": True, "password_stored": password_stored}


@app.post("/api/admin/source/test")
def source_test(payload: dict = Body(default={}), p: Principal = Depends(principal)):
    """Verbindungstest gegen die Quelle (read-only), direkt aus der UI."""
    p.need("settings.manage", "etl.manage")
    from server import settings as S
    rt = get_runtime()
    s = S.get_all(rt.conn)
    host = payload.get("source_host") or s["source_host"]
    if not host:
        raise HTTPException(422, "Kein Host konfiguriert.")
    result = {"ok": False, "host": host}
    try:
        import pytds
        # Benannte Instanz ("HOST\INSTANZ"): dsn komplett uebergeben, Port weglassen —
        # pytds loest den Instanz-Port ueber den SQL Server Browser (UDP 1434) auf.
        kwargs = dict(
            dsn=host,
            database=payload.get("source_database") or s["source_database"],
            user=payload.get("source_username") or s["source_username"] or None,
            password=payload.get("password") or _stored_db_password(),
            login_timeout=10)
        if "\\" not in host:
            kwargs["port"] = int(payload.get("source_port") or s["source_port"] or 1433)
        conn = pytds.connect(**kwargs)
        cur = conn.cursor()
        cur.execute("SELECT @@VERSION")
        result["server_version"] = str(cur.fetchone()[0]).splitlines()[0]
        cur.execute("SELECT COUNT(*) FROM dbo.Patient")
        result["patients"] = int(cur.fetchone()[0])
        cur.execute("SELECT IS_ROLEMEMBER('db_datareader')")
        result["datareader"] = bool(cur.fetchone()[0])
        conn.close()
        result["ok"] = True
    except Exception as exc:
        result["error"] = str(exc) or exc.__class__.__name__
        if "\\" in host and "timeout" in (str(exc) + exc.__class__.__name__).lower():
            result["hint"] = ("Benannte Instanz: Auf dem DB-Server muss der Dienst "
                              "'SQL Server Browser' laufen und UDP 1434 erreichbar sein. "
                              "Alternativ den festen TCP-Port der Instanz ermitteln und "
                              "als Host nur den Servernamen (ohne \\Instanz) plus Port "
                              "eintragen.")
    audit(rt.conn, "source.test", user_id=p.user_id, detail={"host": host,
          "ok": result["ok"]}, success=result["ok"])
    return result


def _stored_db_password() -> str | None:
    import os as _os
    base = _os.environ.get("GREENBAY_HOME")
    if not base:
        return None
    blob_path = Path(base) / "secret" / "dbpass.bin"
    if not blob_path.exists():
        return None
    blob = blob_path.read_bytes()
    if blob.startswith(b"DEV\x00"):
        return blob[4:].decode("utf-8")
    try:
        import win32crypt
        return win32crypt.CryptUnprotectData(blob, None, None, None, 0)[1].decode("utf-8")
    except ImportError:
        return None


@app.post("/api/admin/sync")
def sync_start(payload: dict = Body(default={}), p: Principal = Depends(principal)):
    """Sync-Knopf: startet den Export als Hintergrundprozess (agent/export.py --db).
    Fortschritt läuft über etl_export_job.stats (UI pollt /api/admin/etl)."""
    p.need("etl.manage", "user.manage")
    import os as _os
    import subprocess
    import sys as _sys
    from server import settings as S
    rt = get_runtime()

    running = rt.conn.execute(
        "SELECT id FROM etl_export_job WHERE status='running' AND mode != 'reference'"
        " AND started_at > datetime('now','-12 hours')").fetchone()
    if running and not payload.get("force"):
        raise HTTPException(409, f"Es läuft bereits ein Sync (Job {running['id'][:8]}). "
                                 "Falls der Lauf abgestürzt ist: erneut mit force starten.")
    if running and payload.get("force"):
        rt.conn.execute("UPDATE etl_export_job SET status='failed', "
                        "finished_at=datetime('now'), error='abgebrochen (force-Neustart)'"
                        " WHERE id=?", (running["id"],))
        rt.conn.commit()

    base = _os.environ.get("GREENBAY_HOME")
    cfg = S.config_path()
    if not base or cfg is None or not cfg.exists():
        raise HTTPException(422, "Quellverbindung fehlt - zuerst unter Einstellungen "
                                 "konfigurieren und Verbindung testen.")
    mode = payload.get("mode", "incremental")
    if mode not in ("full", "incremental"):
        raise HTTPException(422, "mode: full|incremental")
    repo = Path(__file__).resolve().parent.parent
    cmd = [_sys.executable, str(repo / "agent" / "export.py"),
           "--config", str(cfg), "--mode", mode,
           "--out", str(Path(base) / "data" / "out"),
           "--db", str(rt.db_path)]
    since = payload.get("since") or S.get_all(rt.conn).get("load_since")
    if since:
        cmd += ["--since", since]
    log_path = Path(base) / "logs" / "sync.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_offset = log_path.stat().st_size if log_path.exists() else 0
    jobs_before = rt.conn.execute("SELECT COUNT(*) AS c FROM etl_export_job").fetchone()["c"]
    child_env = {**_os.environ, "PYTHONUTF8": "1"}   # Umlaute im Log statt cp1252-Bruch
    with open(log_path, "ab") as log:
        proc = subprocess.Popen(cmd, stdout=log, stderr=log, cwd=str(repo), env=child_env)
    # Stirbt der Prozess sofort (z. B. Importfehler der Laufzeit), gibt es keinen
    # Job-Eintrag und der Klick wirkte folgenlos -> kurz beobachten und das
    # Log-Ende als Fehlermeldung an die UI geben.
    import time as _time
    deadline = _time.monotonic() + 3
    while _time.monotonic() < deadline and proc.poll() is None:
        _time.sleep(0.25)
    if proc.poll() is not None and proc.returncode != 0:
        jobs_after = rt.conn.execute(
            "SELECT COUNT(*) AS c FROM etl_export_job").fetchone()["c"]
        if jobs_after == jobs_before:      # kein Job -> Fehler waere unsichtbar
            tail = ""
            try:
                with open(log_path, "rb") as lf:
                    lf.seek(log_offset)
                    tail = lf.read().decode("utf-8", "replace").strip()
            except OSError:
                pass
            audit(rt.conn, "export.run", user_id=p.user_id, success=False,
                  detail={"mode": mode, "exit": proc.returncode,
                          "error": tail[-500:] or None})
            raise HTTPException(500, f"Sync-Prozess sofort beendet (Exit "
                                f"{proc.returncode}). {tail[-600:] or 'Details: logs/sync.log'}")
    audit(rt.conn, "export.run", user_id=p.user_id,
          detail={"mode": mode, "since": since or None})
    return {"ok": True, "mode": mode, "since": since or None,
            "log": str(log_path)}


@app.post("/api/admin/catalogs/build")
def catalogs_build(p: Principal = Depends(principal)):
    """Referenzkataloge (LaborIdent, Vitalparameter, Medikamente, GOÄ, MedDok-
    Kategorien) aus der Quell-DB in den Store laden - als Hintergrundprozess,
    Protokoll in logs/reference.log."""
    p.need("etl.manage", "user.manage")
    import os as _os
    import subprocess
    import sys as _sys
    from server import settings as S
    rt = get_runtime()
    if rt.conn.execute(
            "SELECT 1 FROM etl_export_job WHERE status='running' AND mode='reference'"
            " AND started_at > datetime('now','-2 hours')").fetchone():
        raise HTTPException(409, "Es läuft bereits ein Katalog-Lauf.")
    base = _os.environ.get("GREENBAY_HOME")
    cfg = S.config_path()
    if not base or cfg is None or not cfg.exists():
        raise HTTPException(422, "Quellverbindung fehlt - zuerst unter Einstellungen "
                                 "konfigurieren und Verbindung testen.")
    repo = Path(__file__).resolve().parent.parent
    cmd = [_sys.executable, str(repo / "reference" / "build_reference.py"),
           "--config", str(cfg), "--out", str(Path(base) / "data" / "out"),
           "--db", str(rt.db_path)]
    log_path = Path(base) / "logs" / "reference.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    child_env = {**_os.environ, "PYTHONUTF8": "1"}
    with open(log_path, "ab") as log:
        subprocess.Popen(cmd, stdout=log, stderr=log, cwd=str(repo), env=child_env)
    audit(rt.conn, "catalogs.build", user_id=p.user_id)
    return {"ok": True, "log": str(log_path)}


@app.post("/api/admin/sync/stop")
def sync_stop(p: Principal = Depends(principal)):
    """Laufenden Sync abbrechen: Export-Prozess beenden (PID steht im Job) und
    Job als abgebrochen markieren. Der Resume-Checkpoint bleibt erhalten -
    der naechste Lauf setzt beim letzten fertigen Patienten wieder auf."""
    p.need("etl.manage", "user.manage")
    import json as _json
    import os as _os
    rt = get_runtime()
    stopped = []
    for job in rt.conn.execute(
            "SELECT id, stats FROM etl_export_job WHERE status='running'").fetchall():
        pid = None
        try:
            pid = (_json.loads(job["stats"] or "{}")).get("pid")
        except ValueError:
            pass
        if pid:
            try:
                _os.kill(int(pid), 15)   # Windows: TerminateProcess
            except (OSError, ValueError):
                pass                     # Prozess lebt nicht mehr - nur Job aufraeumen
        rt.conn.execute(
            "UPDATE etl_export_job SET status='failed', finished_at=datetime('now'),"
            " error='abgebrochen (Benutzer)' WHERE id=?", (job["id"],))
        stopped.append(job["id"][:8])
    rt.conn.commit()
    audit(rt.conn, "export.stop", user_id=p.user_id, detail={"jobs": stopped})
    return {"ok": True, "stopped": stopped}


@app.post("/api/admin/store/reset")
def store_reset(payload: dict = Body(default={}), p: Principal = Depends(principal)):
    """Analyse-/Klinikdaten leeren (noetig beim Wechsel des Datenmodus, s.
    agent/export.check_mode_switch). Benutzer, Rollen, Audit und Kataloge
    bleiben erhalten. Bestaetigung: {"confirm": "LOESCHEN"}."""
    p.need("etl.manage", "user.manage")
    if payload.get("confirm") != "LOESCHEN":
        raise HTTPException(422, 'Bestätigung fehlt (confirm: "LOESCHEN").')
    rt = get_runtime()
    if rt.conn.execute("SELECT 1 FROM etl_export_job WHERE status='running'").fetchone():
        raise HTTPException(409, "Es läuft ein Sync - zuerst abbrechen.")
    deleted: dict[str, int] = {}
    for t in ("fhir_resource", "fhir_resource_history", "fhir_reference",
              "nlp_annotation", "vault_patient_pseudonym", "etl_watermark",
              "etl_export_job_table", "etl_export_job"):
        deleted[t] = rt.conn.execute(f"DELETE FROM {t}").rowcount
    try:
        rt.conn.execute("DELETE FROM fts_text")
    except Exception:
        pass                       # FTS5 nicht verfuegbar -> Tabelle existiert nicht
    rt.conn.execute("DELETE FROM app_setting WHERE key='store_privacy_mode'")
    rt.conn.commit()
    audit(rt.conn, "store.reset", user_id=p.user_id, detail=deleted)
    return {"ok": True, "deleted": deleted}


@app.get("/api/admin/sync/log")
def sync_log(lines: int = 400, name: str = "sync", full: bool = False,
             p: Principal = Depends(principal)):
    """Laufprotokoll (logs/sync.log bzw. logs/reference.log) für die UI.
    full=1 liefert die ganze Datei (Download); sonst das Ende (Vorschau)."""
    p.need("etl.manage", "user.manage")
    if name not in ("sync", "reference"):
        raise HTTPException(422, "name: sync|reference")
    import os as _os
    base = _os.environ.get("GREENBAY_HOME")
    log_path = Path(base) / "logs" / f"{name}.log" if base else None
    if not log_path or not log_path.exists():
        return {"log": "", "path": str(log_path) if log_path else None}
    if full:
        data = log_path.read_bytes()[-20_000_000:].decode("utf-8", "replace")
        return {"log": data, "path": str(log_path)}
    data = log_path.read_bytes()[-200_000:].decode("utf-8", "replace")
    tail = "\n".join(data.splitlines()[-max(1, min(int(lines), 2000)):])
    return {"log": tail, "path": str(log_path)}


@app.get("/api/admin/etl")
def etl_status(p: Principal = Depends(principal)):
    p.need("etl.manage", "user.manage")
    rt = get_runtime()
    jobs = [dict(r) for r in rt.conn.execute(
        "SELECT * FROM etl_export_job ORDER BY started_at DESC LIMIT 50")]
    watermarks = [dict(r) for r in rt.conn.execute(
        "SELECT * FROM etl_watermark ORDER BY source_table")]
    counts = [dict(r) for r in rt.conn.execute(
        "SELECT resource_type, COUNT(*) AS n FROM fhir_resource WHERE status='active'"
        " GROUP BY resource_type ORDER BY n DESC")]
    return {"jobs": jobs, "watermarks": watermarks, "resources": counts}


# ---- Einstellungen -------------------------------------------------------------

@app.get("/api/settings")
def settings_get(p: Principal = Depends(principal)):
    from server import settings as S
    rt = get_runtime()
    # Write-Through ist möglich, sobald GREENBAY_HOME gesetzt ist —
    # die config.yaml wird beim ersten Speichern automatisch angelegt.
    return {**S.get_all(rt.conn), "config_write_through": S.config_path() is not None}


@app.post("/api/settings")
def settings_set(payload: dict = Body(...), p: Principal = Depends(principal)):
    p.need("settings.manage")
    from server import settings as S
    rt = get_runtime()
    # KI-API-Key: nie in app_setting/config, sondern DPAPI-Datei (wie DB-Passwort)
    ai_key = payload.pop("ai_api_key", None)
    key_stored = False
    if ai_key:
        key_stored = S.store_secret_file("aikey", str(ai_key)) is not None
    try:
        cleaned = S.set_many(rt.conn, payload)
    except ValueError as exc:
        raise HTTPException(422, str(exc))
    audit(rt.conn, "settings.change", user_id=p.user_id,
          detail={**cleaned, **({"ai_api_key": "gespeichert"} if key_stored else {})})
    return {"ok": True, "ai_key_stored": key_stored, **cleaned}


@app.post("/api/ai/analyze")
def ai_analyze(payload: dict = Body(...), p: Principal = Depends(principal)):
    """KI-Assistenz (Stufe 1, docs/KI_INTEGRATION.md): strukturierte Analyse von
    Labor/Diagnosen/Medikation eines Patienten über den konfigurierten
    KI-Endpunkt. Audit-pflichtig; Ergebnis ist ein Entwurf (ai-provenance)."""
    p.need("patient.view.pseudo", "patient.view.clear")
    from server import settings as S
    from server.ai import gateway
    rt = get_runtime()
    s = S.get_all(rt.conn)
    provider = s.get("ai_provider", "off")
    if provider == "off":
        raise HTTPException(422, "KI ist nicht konfiguriert - Einstellungen → "
                                 "KI-Integration (Provider + API-Key).")
    api_key = S.read_secret_file("aikey")
    if not api_key:
        raise HTTPException(422, "Kein API-Key hinterlegt (Einstellungen → KI-Integration).")
    pseudonym = str(payload.get("pseudonym") or "")
    data = patients.patient360(rt.conn, pseudonym)
    if data is None:
        raise HTTPException(404, "Pseudonym unbekannt.")
    question = str(payload.get("question") or "").strip()

    # Kompakte, strukturierte Zusammenfassung als Kontext (keine Volltexte)
    lines = [f"Patient {pseudonym}, Alter {data.get('age')}, "
             f"Geschlecht {data.get('gender')}"]
    lines.append("Diagnosen: " + "; ".join(
        f"{(c.get('code') or {}).get('coding', [{}])[0].get('code', '?')} "
        f"{(c.get('code') or {}).get('text', '')}".strip()
        for c in (data.get("conditions") or [])[-25:]) or "keine")
    lines.append("Medikation: " + "; ".join(
        (m.get("medicationCodeableConcept") or {}).get("text") or "?"
        for m in (data.get("medications") or [])[-25:]) or "keine")
    for series in (data.get("lab_series") or [])[:40]:
        pts = [f"{pt['t'][:10]}={pt['v']}{'(' + pt['flag'] + ')' if pt.get('flag') else ''}"
               for pt in series.get("points", [])[-6:] if pt.get("v") is not None]
        if pts:
            lines.append(f"Labor {series.get('name')} [{series.get('unit') or ''}]"
                         f" Ref {series.get('reference') or '-'}: " + ", ".join(pts))
    system = ("Du bist ein klinisches Assistenzsystem in einer gastroenterologischen "
              "Praxis. Analysiere die strukturierten Patientendaten: auffällige "
              "Laborverläufe, mögliche Zusammenhänge zwischen Diagnosen, Medikation "
              "und Laborwerten, offene diagnostische Lücken. Antworte auf Deutsch, "
              "knapp und strukturiert (Markdown). Kennzeichne Unsicherheiten. "
              "Du gibst keine Therapieanweisungen, sondern Hinweise zur ärztlichen "
              "Bewertung.")
    user = "\n".join(lines) + ("\n\nFrage: " + question if question else
                               "\n\nBitte eine strukturierte Gesamteinschätzung.")
    try:
        answer = gateway.chat(provider, api_key, system, user,
                              model=s.get("ai_model", ""),
                              base_url=s.get("ai_base_url", ""))
    except gateway.AiError as exc:
        audit(rt.conn, "ai.analyze", user_id=p.user_id, object_type="patient",
              object_id=pseudonym, success=False, detail={"error": str(exc)[:300]})
        raise HTTPException(502, str(exc))
    audit(rt.conn, "ai.analyze", user_id=p.user_id, object_type="patient",
          object_id=pseudonym,
          detail={"provider": provider, "model": s.get("ai_model") or "default",
                  "question": question[:200] or None, "chars": len(answer)})
    return {"ok": True, "provider": provider, "answer": answer,
            "disclaimer": "KI-generierter Entwurf - keine ärztliche Bewertung."}


# ---- Statisches UI --------------------------------------------------------------

MOCKUP_DIR = Path(__file__).resolve().parent.parent / "ui" / "mockups"

if DESIGN_DIR.exists():
    app.mount("/design", StaticFiles(directory=DESIGN_DIR), name="design")
if MOCKUP_DIR.exists():  # klickbare Prototypen (u.a. PVS-Sicht, Dokument-Viewer)
    app.mount("/mockups", StaticFiles(directory=MOCKUP_DIR, html=True), name="mockups")
if UI_DIR.exists():
    app.mount("/app", StaticFiles(directory=UI_DIR, html=True), name="ui")

    @app.get("/")
    def index():
        return FileResponse(UI_DIR / "index.html")


def main():  # pragma: no cover
    import uvicorn
    uvicorn.run("server.main:app", host="127.0.0.1", port=8420)


if __name__ == "__main__":  # pragma: no cover
    main()
