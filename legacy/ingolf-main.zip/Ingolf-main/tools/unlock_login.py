#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Login-Sperre sofort aufheben (Brute-Force-Zähler leeren).

Für den Fall, dass sich der einzige Owner ausgesperrt hat (Einzelplatz-Praxis:
niemand sonst kann entsperren). Läuft direkt gegen die lokale Store-DB —
physischer Zugriff auf den Rechner vorausgesetzt, der Vorgang wird auditiert.

    python tools/unlock_login.py [--appdir %LOCALAPPDATA%\\GreenbayClinical] [--user NAME]
"""
from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--appdir", default=os.environ.get("GREENBAY_HOME", "."))
    ap.add_argument("--user", help="nur dieses Konto entsperren (Default: alle)")
    args = ap.parse_args()

    os.environ.setdefault("GREENBAY_HOME", args.appdir)
    os.environ.setdefault("GREENBAY_DB",
                          os.path.join(args.appdir, "data", "clinical.db"))
    os.environ.setdefault("GREENBAY_SECRET",
                          os.path.join(args.appdir, "secret", "master.bin"))

    from server.runtime import Runtime
    from store.db import audit
    rt = Runtime()
    if args.user:
        cur = rt.conn.execute("DELETE FROM sec_login_versuch WHERE username=?",
                              (args.user,))
    else:
        cur = rt.conn.execute("DELETE FROM sec_login_versuch")
    rt.conn.commit()
    audit(rt.conn, "login.unlock", detail={"user": args.user or "*",
                                           "geloescht": cur.rowcount,
                                           "weg": "tools/unlock_login.py"})
    print(f"Login-Sperre aufgehoben ({cur.rowcount} Fehlversuche gelöscht"
          f"{', Konto ' + args.user if args.user else ''}).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
