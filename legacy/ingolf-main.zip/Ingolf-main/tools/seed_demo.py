#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Demo-Seed ohne Praxis-DB: baut data/clinical.db mit synthetischen Patienten
(über die echte Export-Kette), Vault-Einträgen und einem Owner-Konto.

    python tools/seed_demo.py [--db data/clinical.db] [--patients 8]

Gibt Login-Daten + TOTP-Secret aus. Danach:
    GREENBAY_MASTER_SECRET=<secret> python -m server.main
"""
from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tests"))

MASTER = "demo-master-secret-0123456789abcdef"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="data/clinical.db")
    ap.add_argument("--patients", type=int, default=8)
    args = ap.parse_args()

    from store.db import open_store
    from store.load import load_bundle
    from store.vault import store_mapping
    from server import auth, rbac
    from util_demo import build_demo_bundles

    conn = open_store(args.db, key=MASTER)
    rbac.seed(conn)

    bundles, privacy = build_demo_bundles(args.patients, secret=MASTER, annotate=True)
    for pid, nr, bundle in bundles:
        load_bundle(conn, bundle)
        store_mapping(conn, MASTER.encode(), bundle["id"].replace("export-", ""),
                      pid, nr, privacy._shift_days(pid))
    print(f"{len(bundles)} Demo-Patienten geladen -> {args.db}")

    if conn.execute("SELECT COUNT(*) AS n FROM sec_app_user").fetchone()["n"] == 0:
        owner = auth.create_user(conn, MASTER.encode(), "owner", "Demo-Praxisinhaber",
                                 "demo-owner-passwort-123", ["owner"])
        print("\nOwner-Konto angelegt:")
        print("  Benutzer:  owner")
        print("  Passwort:  demo-owner-passwort-123")
        print(f"  TOTP-URI:  {owner['totp_uri']}")
        print(f"  Aktueller TOTP-Code: {auth.totp_code(owner['totp_secret'])}")
    conn.close()
    print(f"\nServer starten:\n  GREENBAY_MASTER_SECRET={MASTER} "
          f"GREENBAY_DB={args.db} python -m server.main\n  -> http://127.0.0.1:8420/")


if __name__ == "__main__":
    main()
