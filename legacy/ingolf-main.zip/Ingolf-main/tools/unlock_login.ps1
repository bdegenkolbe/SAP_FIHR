# GREENBAY clinical — Login-Sperre aufheben (PowerShell)
#
# Hebt die Brute-Force-Sperre sofort auf (loescht die Fehlversuchs-Zaehler in
# der lokalen Store-DB). Fuer den Einzelplatz gedacht, wenn sich der Owner
# ausgesperrt hat. Der Server kann dabei weiterlaufen.
#
# Ausfuehren:  Rechtsklick -> "Mit PowerShell ausfuehren"
#      oder :  powershell -ExecutionPolicy Bypass -File unlock_login.ps1
# Optionen  :  -User bdegenkolbe   (nur dieses Konto)
#              -AppDir "C:\...\GreenbayClinical"   (abweichender Installationsort)

param(
    [string]$AppDir = "$env:LOCALAPPDATA\GreenbayClinical",
    [string]$User = ""
)

$ErrorActionPreference = "Stop"

if ($User -and $User -notmatch '^[\w.\-@]+$') {
    Write-Host "[FEHLER] Ungueltiger Benutzername: $User" -ForegroundColor Red
    exit 1
}

$app = Join-Path $AppDir "app"
if (-not (Test-Path (Join-Path $app "server\runtime.py"))) {
    Write-Host "[FEHLER] Installation nicht gefunden unter: $AppDir" -ForegroundColor Red
    Write-Host "         Ggf. -AppDir 'Pfad\zu\GreenbayClinical' angeben."
    exit 1
}

$env:GREENBAY_HOME = $AppDir
$py = Join-Path $AppDir "python\python.exe"
if (-not (Test-Path $py)) { $py = "python" }

$code = @"
import sys
sys.path.insert(0, r'$app')   # embeddable Python legt cwd nicht auf sys.path
from server.runtime import Runtime
rt = Runtime()
user = '$User'
if user:
    cur = rt.conn.execute('DELETE FROM sec_login_versuch WHERE username=?', (user,))
else:
    cur = rt.conn.execute('DELETE FROM sec_login_versuch')
rt.conn.commit()
from store.db import audit
audit(rt.conn, 'login.unlock', detail={'user': user or '*', 'geloescht': cur.rowcount,
                                       'weg': 'tools/unlock_login.ps1'})
print(f'Login-Sperre aufgehoben ({cur.rowcount} Fehlversuche geloescht).')
"@

Push-Location $app
try {
    & $py -c $code
    if ($LASTEXITCODE -ne 0) { throw "Python-Aufruf fehlgeschlagen (Code $LASTEXITCODE)." }
    Write-Host "Jetzt im Browser 'Erneut versuchen' und mit Passwort anmelden." -ForegroundColor Green
} finally {
    Pop-Location
}

if ($Host.Name -eq "ConsoleHost" -and -not $env:GB_NO_PAUSE) {
    Read-Host "ENTER zum Schliessen"
}
