# Konzepterweiterung: Dokument-Intelligence-Layer

**Ziel:** Aus gespeicherten Dokumenten (eingescannte Befunde, Fremdarztbriefe, Word-/PDF-
Anhänge) werden lesbare, kodierte und analysierbare klinische Objekte. Drei Ausbaustufen,
aufeinander aufbauend:

1. **Anzeigen** — Dokumente in der 360°-Patientensicht öffnen und lesen (PDF/Bild/Text).
2. **Annotieren** — Volltext gewinnen und mit SNOMED CT (primär) sowie ICD-10-GM / LOINC /
   ATC kodieren, inkl. Negation/Verdacht/Familienanamnese.
3. **Analysieren** — die dokumentabgeleiteten Konzepte wie strukturierte Daten in Kohorten,
   Qualitätsindikatoren und Forschungsexport nutzen.

Dieses Dokument ist die Bauanleitung für Claude Code. Die Module liegen bereits als Gerüst
im Repo (`agent/documents.py`, `agent/annotate.py`, `reference/terminology.py`,
`agent/extract_anhaenge.py`) und sind lauffähig-syntaktisch, mit defensiven optionalen
Imports. Der base64→PDF-Roundtrip und die Magic-Byte-Erkennung sind verifiziert (siehe §8).

---

## 1. Datenquellen für Dokumente

| Quelle | Inhalt | Zustand |
|---|---|---|
| `dbo.MedDokAnhang` (26.315) | eingescannte/angehängte Dateien als BLOB (`AnhangData`/`AnhangFs`) | binär, gemischt |
| `MedDok` BRIEF/EAB/E | Arztbriefe/Epikrisen | Text bereits strukturiert (Composition) |
| `MedDok` FREITEXT/Befund | Freitextbefunde | Text/HTML vorhanden |

Verteilung der Anhänge (verifiziert): **docx 21.832** (Haupttyp), **pdf 1.759** (ø 66 KB,
max 18,8 MB, teils Scans), rtf 1.487 (meist 0-Byte-Platzhalter), jpg 143, tif 5, doc 4.
**Wichtig:** ~1.000 `FileName`-Werte haben **keine echte Endung** (dort steht ein Zeitstempel
wie `..._2024_09_03_25`). Deshalb wird der Typ **immer per Magic-Bytes** bestimmt, nie per
Endung (`agent/documents.detect_type`).

---

## 2. Pipeline-Architektur

```
                       (läuft komplett IN DER PRAXIS / im lokalen Agenten)
 ┌────────────┐   BLOB    ┌──────────────┐  Text  ┌──────────────┐ Annotationen ┌───────────────┐
 │ MedDokAnhang│──────────▶│ documents.py │───────▶│ annotate.py  │─────────────▶│ FHIR-Store    │
 │  / MedDok   │  read-only│ Typ+OCR+Text │        │ NER+Kontext  │  + derived   │ (verschlüsselt)│
 └────────────┘           └──────────────┘        │  Binding     │  Condition/  └───────┬───────┘
                                  ▲                │              │  Observation         │
                          Magic-Bytes              └──────┬───────┘                      │
                          (nicht Endung)                  │ Konzept-Lookup               ▼
                                                   ┌──────┴───────┐            ┌──────────────────┐
                                                   │terminology.py│            │ UI: Viewer + Highlight│
                                                   │SNOMED/ICD/…  │            │ Analyse: Kohorten     │
                                                   └──────────────┘            └──────────────────┘
```

Kein Dokumenttext verlässt die Praxis. Ein optionaler Terminologieserver kann on-premise
laufen (Snowstorm/Ontoserver); nur Suchbegriffe/Codes gehen dorthin, keine Patiententexte.

---

## 3. Stufe 1 — Anzeige in der Patientensicht

- Jeder Anhang ist bereits eine **FHIR `DocumentReference`** (`map_anhaenge`). Für die Anzeige
  gilt: Metadaten immer, Bytes on-demand.
- **On-demand-Abruf:** Standardmäßig trägt die DocumentReference nur ein Handle
  (`attachment.url = meddok-anhang:<FsRowGuid>`). Beim Öffnen holt der lokale Server die Bytes
  frisch aus der DB (oder aus dem lokalen verschlüsselten Cache), nie über eine Analyse-Session.
- **Viewer:** PDF inline (Browser-nativ), Bilder inline, docx→HTML (mammoth) oder als Download.
  Ampel/Badge zeigt, ob das Dokument bereits annotiert ist.
- **Neuer Tab „Dokumente"** in der 360°-Sicht: Liste (Datum, Typ, Quelle, Annotations-Status)
  → Klick öffnet den **Dokument-Viewer** (`ui/mockups/dokumentsicht.html`) mit Volltext links
  und farbig hinterlegten Annotationen; rechts die kodierten Konzepte (SNOMED/ICD) mit
  Negation/Verdacht-Kennzeichnung.

## 4. Stufe 2 — Annotation

### 4.1 Textgewinnung (`agent/documents.py`)
- Typ per Magic-Bytes; Text aus docx (python-docx, Fallback XML-Strip), pdf (pypdf/pdfminer),
  rtf (striprtf), txt.
- **OCR-Hook** für Scan-PDFs und Bilder (pdf2image + pytesseract, `deu`); Heuristik: PDF mit
  Seiten aber < 40 Zeichen Text ⇒ vermutlich Scan ⇒ OCR.
- Fehlt ein Parser, wird sauber auf „Dokument sichtbar, aber nicht annotiert" degradiert.

### 4.2 Konzept-Binding (`reference/terminology.py`)
- **Primär SNOMED CT**, ergänzt um ICD-10-GM (Diagnosen/DRG), LOINC (Labor), ATC (Medikation).
- Zwei austauschbare Provider hinter einem Interface:
  - `LocalCatalogProvider` — Dictionary-Matching (longest-match, Wortgrenzen, Offsets) gegen
    lokale Kataloge; ohne Online-Dienst; SNOMED nur mit lokalem RF2-Snapshot.
  - `FhirTerminologyProvider` — `$expand`/`$validate-code`/`$translate` gegen einen (ggf.
    on-premise) Terminologieserver; erlaubt saubere SNOMED-Validierung und ICD↔SNOMED-Mapping.
  - `CompositeProvider` — lokal zuerst, Server als Ergänzung.
- **SNOMED-CT-Lizenz:** Deutschland ist SNOMED-International-Mitglied, NRC ist das BfArM; die
  Nutzung im deutschen Gesundheitswesen ist über die nationale Lizenz möglich, erfordert i. d. R.
  eine (kostenfreie) Affiliate-Registrierung über BfArM/MLDS. **Lizenz-/Registrierungsstatus vor
  Produktivbindung final prüfen.** ICD-10-GM, ATC (amtlich) und LOINC sind frei nutzbar.

### 4.3 Kontext & Negation (`agent/annotate.py`)
- Sektionierung (Anamnese/Befund/Diagnose/Prozedur/Therapie/Labor) für kontextsensitive Deutung.
- Deutsches NegEx/ConText-Lexikon: **negiert** (kein/ohne/ausgeschlossen), **Verdacht** (V. a.,
  fraglich), **Familienanamnese** (Vater/Mutter/familiär), **historisch** (Z. n., vorbekannt).
- Abbildung auf FHIR-Status: negiert→`refuted`, Verdacht→`provisional`, sonst `confirmed`.
- **Härtungspunkte** (im Gerüst markiert): NegEx auf **Satzgrenzen** scopen (im Demo „blutet"
  eine Negation über den Satz), echte **Token-Offsets** statt Substring-Suche, Abkürzungs- und
  Maßeinheiten-Handling, Dublettenauflösung mehrfach genannter Konzepte.

### 4.4 FHIR-Repräsentation
- **Overlay am DocumentReference:** Extension `…/document-annotations` mit je Annotation
  `span` (Zeichen-Offsets), `concept` (Coding), `status`, `score`, `context`, `section`.
  → Damit rendert die UI das Highlighting exakt über dem Volltext.
- **Abgeleitete Ressourcen für die Analyse:** akzeptierte Konzepte (Score ≥ Schwelle, nicht
  familiär) werden zu `Condition` (Disorder/ICD) bzw. `Observation` (Finding/Prozedur/Labor),
  jeweils mit `derivedFrom`=Dokument und `…/nlp-provenance` (Ableitung=nlp, Konfidenz, Quelle,
  Span). Negierte Konzepte werden nicht als aktive Diagnose abgeleitet.
- **Trennung strukturiert vs. NLP:** dokumentabgeleitete Ressourcen sind über die
  NLP-Provenance klar als solche markiert und in der Analyse ein-/ausblendbar.

## 5. Stufe 3 — Nutzung in der Analyse

- **Kohorten-Kriterium „Dokument-Konzept (SNOMED)"** im Analysetool: findet Patienten anhand
  von Konzepten, die **nur** im Freitext/Befund stehen (z. B. „stenosierender Verlauf", der
  nicht als ICD kodiert wurde) — mit Filter auf Status (gesichert/Verdacht) und Confidence.
- **Qualitätsindikatoren** können Text-Evidenz einbeziehen (z. B. „Impfstatus im Dokument
  erwähnt?"), transparent getrennt von strukturierten Quellen.
- **Confidence- & Provenance-Gate:** Analysen können auf `derivation=structured`,
  `nlp` oder beides gestellt werden; kleine Fallzahlen werden weiter maskiert (n < 5).
- **Rückverlinkung:** jedes analytische Treffer-Konzept zeigt per `derivedFrom` das Quelldokument
  und den markierten Textspan (Nachvollziehbarkeit/Audit).

## 6. Datenschutz & Governance (an bestehende Weiche gekoppelt)
- Extraktion/OCR/Annotation laufen ausschließlich lokal; Klartext verlässt die Praxis nicht.
- Im **Pseudonym-Modus** wird der Dokument-Volltext vor Anzeige/Export de-identifiziert
  (`privacy.text`), das Annotations-Overlay bleibt (Offsets zeigen dann auf den de-id-Text).
- Klartext-Dokumentansicht ist an Rolle/Break-Glass gebunden (siehe `BENUTZERVERWALTUNG.md`).
- OCR-/NLP-Ergebnisse sind append-only auditierbar; Modell-/Lexikon-Version wird mitgeführt.

## 7. Betrieb & Performance
- **Backfill** rechenintensiv (v. a. OCR der Scan-PDFs). Batch-Lauf, fortsetzbar, mit HWM je
  `MedDokAnhang.Id`; OCR nur bei Bedarf (Heuristik) und optional GPU-los mit `--jobs`.
- **Inkrementell:** neue/aktualisierte Anhänge und MedDok-Texte über bestehende rowversion-HWM.
- **Caching:** extrahierter Text + Annotationen liegen im verschlüsselten Store; BLOB-Bytes
  werden nicht dupliziert (on-demand aus Quelle/FILESTREAM).

## 8. Verifiziert (Sandbox, synthetisch)
- **base64 → PDF-Roundtrip** bit-identisch (SHA-1 gleich), Ergebnis als gültige PDF erkannt.
- **Magic-Byte-Erkennung** korrekt für pdf/docx/jpg/png/tiff/rtf/leer — auch bei FileName ohne
  echte Endung (Zeitstempel-Artefakt).
- **Annotationslauf** an synthetischem Gastro-Befund: Offsets, Negation, Verdacht,
  Familienanamnese erkannt; negierte/familiäre Konzepte korrekt nicht als aktive Diagnose
  abgeleitet.
- Kein echtes PHI wurde in die Session gezogen; der Massen-Extrakt läuft über
  `agent/extract_anhaenge.py` lokal in der Praxis.

## 9. Aufgaben für Claude Code (Umsetzungsreihenfolge)
1. `documents.py`: reale Parser-Deps aktivieren (python-docx, pypdf, striprtf, pdf2image,
   pytesseract, Pillow, mammoth) in `requirements.txt`; Tesseract-`deu` im Setup dokumentieren.
2. `extract_anhaenge.py`: gegen echte DB testen; FILESTREAM-Pfad (`AnhangFs`) ergänzen.
3. `terminology.py`: Katalog-Loader `build_reference.py` um `dict_*.json` (ICD/LOINC/ATC)
   erweitern; optional lokalen SNOMED-RF2-Import.
4. `annotate.py`: NegEx auf Satzgrenzen scopen, Token-Offsets, Dublettenlogik; Schwellen/
   Whitelist je Sektion konfigurierbar.
5. `export.py`: neuen Schritt „annotate documents" einhängen (Overlay an DocumentReference,
   derived Ressourcen ins Bundle), Flags `--annotate`, `--ocr`, `--terminology-server URL`.
6. UI: Tab „Dokumente" + `dokumentsicht.html` (Viewer+Highlight) in die App integrieren;
   Analysetool um Kriterium „Dokument-Konzept (SNOMED)" erweitern.
7. Einstellungen: Terminologie-Quelle, OCR an/aus, Confidence-Schwelle, NLP-in-Analyse an/aus.
