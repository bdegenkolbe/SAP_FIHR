# UI-Spezifikation

Interaktive Prototypen liegen unter `ui/mockups/` (mit `index.html` als Launcher). Das
Design-System (Tokens/Komponenten) ist in `ui/design/tokens.css` als Single Source of Truth
definiert. Dieses Dokument beschreibt Screens, Zustände und Interaktionen.

## 1. Design-System (GREENBAY CI)

- **Farben:** Primär `#1A1A1A`, Sekundär `#00BCFF`, Akzent `#EE00EE`; Logo-Gradient
  Pink `#E8007A` → Violett `#6600EE` → Blau `#0028D0` → Teal `#00C8BE` (für Hervorhebungen,
  aktive Navigation, Diagramm-Akzente). Klinische Semantik: grün = ok, gelb = grenzwertig,
  rot = kritisch, blau = Info.
- **Typografie:** Exo 2 (300–800), Fallback Arial.
- **Radius/Schatten:** 12–16 px, weiche Schatten; luftige Abstände (8-Punkt-Raster).
- **Prinzip:** ruhige, moderne Klinik-Ästhetik; Farbe sparsam und bedeutungstragend
  (Ampel + Marken-Akzent), keine Deko-Farbe auf Datenflächen. Dark-Mode als Token-Variante
  vorgesehen (invertierte `--bg`/`--surface`/`--ink`).
- **Logo:** Produktion nutzt `ui/design/greenbay-logo.png`; die Mockups zeigen aus
  Gewichts-/Renderinggründen eine CSS-Wortmarke im offiziellen Gradienten.
- **Barrierefreiheit:** Kontrast AA, Fokusringe, Tastaturnavigation, `prefers-reduced-motion`,
  Semantik über Farbe **und** Text/Icon (nie Farbe allein).

## 2. Globale Struktur

- **Linke Rail:** Patienten · Analyse · Kataloge · Verwaltung · Einstellungen.
- **Topbar:** Wortmarke, globale Suche, **Modus-Badge** (rot Klar / grün Pseudonym),
  Nutzer-Chip. Der Modus-Badge ist auf **jedem** Screen sichtbar.
- **Leerzustände/Ladezustände/Fehler:** jede Datenfläche hat Skeleton-Loader, Empty-State
  (mit Handlungsvorschlag) und Fehlerzustand (mit Retry).

## 3. Screen: Patientenauswahl (`patientenauswahl.html`)

- Große Suche über Pseudonym/ICD/ATC/PZN/Laborwert; Facetten-Filter als Chips
  (Diagnose, Alter, Laborschwelle, Medikation …), kombinierbar (UND/ODER).
- Trefferliste: Pseudonym, Alter/Geschlecht, aktive Diagnosen (ICD-Tags), letzter Laborwert
  (Ampel-Pill), Medikationszahl, letzter Besuch. Zeile klickbar → 360°-Sicht.
- Aktion „Als Kohorte analysieren" übergibt den Filter an das Analysetool.
- Zustände: 0 Treffer (Empty), >10.000 (Hinweis auf Filter), Ladeskeleton je Zeile.

## 4. Screen: 360°-Patientensicht (`patientensicht.html`)

- **Kopf:** Pseudonym/Name (modusabhängig), Alter/Geschlecht, Versicherung (Coverage),
  CAVE/Allergie-Flags, Break-Glass-Button.
- **KPI-Kacheln:** aktive Diagnosen, Dauermedikation (+ Wechselwirkungshinweis),
  Laborwerte/auffällig, AU-Tage.
- **Tabs:** Übersicht · Diagnosen · Labor · Medikation · AU & Dokumente · Termine · Abrechnung.
  - *Übersicht:* Behandlungs-Timeline (chronologisch, kritische Ereignisse rot) + aktive
    Probleme + Labor-Trend-Sparklines (mit Referenzbereich aus Katalog).
  - *Labor:* Zeitreihen je Analyt, Referenzbereiche (geschlechtsspezifisch aus
    `LaborIdentKatalog`), Tabellen-/Grafikumschaltung.
  - *Medikation:* Dauermedikation + Historie; Wirkstoff/ATC/PZN aufgelöst; Medikationsplan (BMP).
  - *AU & Dokumente:* eAU-Zeitachse (Erst/Folge, bis-Datum), Arztbriefe (Composition),
    Anhänge (DocumentReference).
- Datenquelle sind die FHIR-Ressourcen des Exports; Mapping siehe `docs/CONCEPT.md`.

## 5. Screen: Versorgungsanalyse (`analysetool.html`)

- **Kohorten-Builder:** Kriterien als Token (Diagnose, Alter, Zeitraum, Therapie …),
  UND/ODER-Verknüpfung, „Kohorte berechnen".
- **KPIs & Charts:** Kohortengröße, Kennzahlen, Therapieverteilung (Donut),
  Begleitdiagnosen (Balken), Verlaufskurven (Median über Zeit), **frei definierbare
  Qualitäts-/Versorgungsindikatoren** (FHIR-`Measure`-artig, Referenz aus Katalog/Leitlinie).
- **Export:** „Als FHIR-Measure speichern" und **Forschungsexport (pseudonym/anonym)**.
- Governance: Analysetool arbeitet nie auf Klardaten; Aggregatschutz (kleine Fallzahlen
  maskieren, z. B. n < 5) ist vorgesehen.

## 6. Weitere Screens (spezifiziert, Mockup folgt bei Bedarf)

- **Kataloge:** LaborIdentKatalog (Referenzbereiche), Medikament/ATC/Wirkstoff, GOÄ-Eigenziffern,
  MedDok-Kategorien; Anzeige + Aktualisierungs-/Versionsstand (siehe CONCEPT.md Katalog-Lebenszyklus).
- **Verwaltung:** Benutzer & Rollen, Rechtematrix, Break-Glass-Protokoll, ETL-Status,
  Backup/Restore, Schlüssel/Secret. Details in `docs/BENUTZERVERWALTUNG.md`.
- **Einstellungen:** Quellverbindung (DB), Datenschutzmodus-Policy, **FHIR-Profil-Auswahl
  (R4 · MII-KDS · KBV)**, Katalog-Quellen, Zeitplan (Task), Sprache, Theme (Light/Dark).

## 7. FHIR-Profil-Umschaltung

Das Zielprofil ist in den Einstellungen wählbar und wirkt auf Validierung und
`meta.profile` der erzeugten Ressourcen:

- **R4 (bare):** Standard, maximale Kompatibilität (aktuell implementiert).
- **MII-KDS:** Medizininformatik-Initiative-Kerndatensatz-Profile (Person, Diagnose, Labor,
  Medikation …) — für Forschungsnetz-Kompatibilität.
- **KBV:** KBV-Basisprofile / ISiK-nahe Profile — für Versorgungskontext.

Umsetzung: profilspezifische `meta.profile`-URLs + optionale Profilvalidierung; der
Mapping-Kern bleibt gleich, ein Profil-Layer setzt Pflichtfelder/Slicing. Auswahl pro Export
speicherbar; Doppelausleitung (z. B. R4 **und** MII) möglich.
