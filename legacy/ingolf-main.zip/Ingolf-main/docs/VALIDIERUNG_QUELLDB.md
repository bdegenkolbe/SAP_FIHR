# Validierung der Quell-DB (x2praxisdb) über Claude Desktop / MCP

Dieses Paket prüft alle Annahmen der Ladeskripte (`agent/export.py`) gegen die
echte medatixx-Datenbank — read-only, ausschließlich Schema-, Aggregat- und
Enum-Abfragen.

**Wichtig (Datenschutz):** Über den MCP-Server nur die Abfragen aus diesem
Dokument ausführen. Keine `SELECT *` auf Patiententabellen, keine Namen,
keine Freitexte — die Ergebnisse verlassen mit Claude Desktop die Praxis.
Alle Abfragen hier liefern nur Strukturdaten, Zählwerte und Codes.

**Auftrag an Claude Desktop** (so übergeben): *"Führe die nummerierten
SQL-Abfragen V1–V11 nacheinander read-only aus und gib mir je Abfrage das
vollständige Ergebnis als Tabelle zurück. Wenn eine Abfrage mit 'Ungültiger
Spaltenname' fehlschlägt, notiere den Spaltennamen als Befund und fahre fort.
Führe keine anderen Abfragen aus."*

Die Ergebnisse anschließend hier zurückgeben — daraus leite ich die
Mapper-Korrekturen ab (z. B. echte Abrechnungsweg-Spalten am Schein,
`Eau.State`-Enum, Blutdruck-Speicherung).

---

## V1 — Spaltenabgleich: erwartete Spalten vs. echtes Schema (Kernprüfung)

Listet alle Spalten, die die Ladeskripte verwenden, die es aber in der DB
**nicht** gibt. Sollwert: möglichst leer (bekannt fehlend: `Schein.IsPrivat`).

```sql
WITH erwartet (tab, col) AS (SELECT * FROM (VALUES
 ('Patient','Id'),('Patient','PatientNr'),('Patient','Name'),('Patient','Vorname'),
 ('Patient','Titel'),('Patient','Geschlecht'),('Patient','Geburtsjahr'),
 ('Patient','Geburtsmonat'),('Patient','Geburtstag'),('Patient','VerstorbenAm'),
 ('Patient','Strasse'),('Patient','Hausnummer'),('Patient','Postleitzahl'),
 ('Patient','Wohnort'),('Patient','Laenderkennzeichen'),('Patient','IsPrivat'),
 ('Patient','VersichertenNr'),('Patient','IkNr'),('Patient','Versichertenart'),
 ('Patient','PatientSeit'),('Patient','LetzterBesuchAm'),('Patient','Staatsangehoerigkeit'),
 ('MedDok','Id'),('MedDok','Id_Schein'),('MedDok','ReferenceDateTime'),
 ('MedDok','Id_MedDokKategorie'),('MedDok','Detail'),('MedDok','Id_Patient'),
 ('MedDokKategorie','Id'),('MedDokKategorie','Kuerzel'),
 ('Schein','Id'),('Schein','Scheinart'),('Schein','Scheinuntergruppe'),
 ('Schein','AusstellungsDateTime'),('Schein','ScheinGueltigVon'),('Schein','Quartal'),
 ('Schein','Abrechnungsquartal'),('Schein','KassenName'),('Schein','Iknr'),
 ('Schein','IsStationaer'),('Schein','UeberweisungVon'),('Schein','UeberweisungAn'),
 ('Schein','WeiterbehandelnderArzt'),('Schein','IsZielauftrag'),('Schein','Auftrag'),
 ('Schein','DiagnoseVerdacht'),('Schein','BsnrUeberweiser'),('Schein','LanrUeberweiser'),
 ('Schein','IsIgel'),('Schein','IsPrivat'),('Schein','RechnungsTyp'),
 ('Schein','HzvVertragKennung'),('Schein','HonorarAnlageId'),('Schein','Id_Patient'),
 ('SchedulerAppointment','Id'),('SchedulerAppointment','StartDateTime'),
 ('SchedulerAppointment','EndDateTime'),('SchedulerAppointment','Subject'),
 ('SchedulerAppointment','BesuchsgrundText'),('SchedulerAppointment','Info'),
 ('SchedulerAppointment','AppointmentKept'),('SchedulerAppointment','IsMarkedAsCancelled'),
 ('SchedulerAppointment','IsDeleted'),('SchedulerAppointment','Id_Patient'),
 ('Laborbogen','Id'),('Laborbogen','Id_LaborHeader'),('Laborbogen','Datum'),
 ('Laborbogen','Kuerzel'),('Laborbogen','Grenzwertindikator'),('Laborbogen','Details'),
 ('Laborbogen','Id_Patient'),('Laborbogen','IsAnforderung'),
 ('PatientVitalparameterRecord','Id'),('PatientVitalparameterRecord','Datum'),
 ('PatientVitalparameterRecord','Id_Patient'),
 ('PatientVitalparameterValue','Id'),('PatientVitalparameterValue','Id_VitalparameterRecord'),
 ('PatientVitalparameterValue','Id_Vitalparameter'),('PatientVitalparameterValue','Value'),
 ('Vitalparameter','Id'),('Vitalparameter','Name'),('Vitalparameter','DisplayName'),
 ('Vitalparameter','Masseinheit'),
 ('VerordnungV2','Id'),('VerordnungV2','Pzn'),('VerordnungV2','ItemType'),
 ('VerordnungV2','ReferenceDateTime'),('VerordnungV2','ReichtBis'),
 ('VerordnungV2','AbgesetztDateTime'),('VerordnungV2','Absetzungsgrund'),
 ('VerordnungV2','Id_Schein'),('VerordnungV2','Id_Medikament'),
 ('VerordnungV2','Id_Patient'),('VerordnungV2','IsDeleted'),
 ('Medikament','Id'),('Medikament','Artikelname'),('Medikament','Artikellangname'),
 ('MedikamentAtc','Id_Medikament'),('MedikamentAtc','AtcCode'),('MedikamentAtc','Bezeichnung'),
 ('Rechnung','Id'),('Rechnung','Id_Schein'),('Rechnung','RechnungsnummerPraefix'),
 ('Rechnung','Rechnungsnummer'),('Rechnung','RechnungsDatum'),('Rechnung','GesamtBetrag'),
 ('Rechnung','BetragBerechnet'),('Rechnung','Restbetrag'),('Rechnung','IsIgel'),
 ('Rechnung','IsStornoRechnung'),('Rechnung','StornoDatum'),('Rechnung','Id_Patient'),
 ('Eau','Id_MedDok'),('Eau','State'),('Eau','IkNr'),('Eau','MailingDateTime'),
 ('Eau','ResponseDateTime'),
 ('EpaEventLog','Id'),('EpaEventLog','EventStartDateTime'),('EpaEventLog','EventKind'),
 ('EpaEventLog','EventState'),('EpaEventLog','Id_EpaDocumentMeta'),('EpaEventLog','Id_Patient'),
 ('EpaDocumentMeta','Id'),('EpaDocumentMeta','DocumentUniqueId'),
 ('EpaDocumentMeta','DocumentCreationDateTime'),('EpaDocumentMeta','DocumentMetaJson'),
 ('EpaDocumentMeta','IsUpload'),
 ('PatientChipkarte','Id'),('PatientChipkarte','ChipkartenEinlesedatum'),
 ('PatientChipkarte','ChipkarteGueltigVon'),('PatientChipkarte','ChipkarteGueltigBis'),
 ('PatientChipkarte','VersichertenNr'),('PatientChipkarte','Versichertenart'),
 ('PatientChipkarte','IkNr'),('PatientChipkarte','KostentraegerIkNr'),
 ('PatientChipkarte','KassenName'),('PatientChipkarte','BesonderePersonengruppe'),
 ('PatientChipkarte','Statusergaenzung'),('PatientChipkarte','WopKennzeichen'),
 ('PatientChipkarte','VersichertenstatusRsa'),('PatientChipkarte','Id_Patient'),
 ('TodoItem','Id'),('TodoItem','Name'),('TodoItem','Description'),('TodoItem','Status'),
 ('TodoItem','Priority'),('TodoItem','CreatedPoint'),('TodoItem','StartDateTime'),
 ('TodoItem','DeadlineDateTime'),('TodoItem','DoneDateTime'),('TodoItem','Id_MedDok'),
 ('TodoItem','Id_Patient'),
 ('RezeptV2','Id'),('RezeptV2','ReferenceDateTime'),('RezeptV2','Ausstellungsdatum'),
 ('RezeptV2','Subtype'),('RezeptV2','BtmKennzeichen'),('RezeptV2','Id_Schein'),
 ('RezeptV2','IsSprechstundenbedarf'),('RezeptV2','IsHilfsmittel'),('RezeptV2','IsImpfstoff'),
 ('RezeptV2','IsNoctu'),('RezeptV2','IsUnfall'),('RezeptV2','IsArbeitsunfall'),
 ('RezeptV2','IsErsatzverordnung'),('RezeptV2','Id_MedDok'),('RezeptV2','Id_Patient'),
 ('RezeptInfo','Id'),('RezeptInfo','Id_Rezept'),('RezeptInfo','Pzn'),('RezeptInfo','Info'),
 ('RezeptInfo','IsAutIdem'),('RezeptInfo','IsFreitext'),('RezeptInfo','IsStrukturiert'),
 ('RezeptInfo','IsRezeptur'),('RezeptInfo','IsHilfsmittelgruppe'),('RezeptInfo','Rang'),
 ('RezeptInfoDruck','Id'),('RezeptInfoDruck','Id_RezeptInfo'),
 ('RezeptInfoDruck','Druckzeile'),('RezeptInfoDruck','Rang'),
 ('RezeptDiagnose','Id_Rezept'),('RezeptDiagnose','Icd'),('RezeptDiagnose','Beschreibung'),
 ('RezeptDiagnose','Sicherheit'),('RezeptDiagnose','Lokalisation'),
 ('MedDokAnhang','Id'),('MedDokAnhang','Id_MedDok'),('MedDokAnhang','FileName'),
 ('MedDokAnhang','Tag'),('MedDokAnhang','AnhangLength'),('MedDokAnhang','FsRowGuid'),
 ('MedDokAnhang','CreatedPoint'),('MedDokAnhang','AnhangData'),
 ('MedikationsplanItem','Id'),('MedikationsplanItem','IdPatient_Medikationsplan'),
 ('MedikationsplanItem','Id_Verordnung'),('MedikationsplanItem','Id_MedikationsplanFreitext'),
 ('MedikationsplanItem','MedikationsplanSortIndex'),('MedikationsplanItem','ItemTyp'),
 ('MedDokFormularVariable','Id_MedDok'),('MedDokFormularVariable','FormularVariablen'),
 ('MedDokFormularVariable','IstZwischenspeicherung')
) AS t(tab, col))
SELECT e.tab AS Tabelle, e.col AS FehlendeSpalte
FROM erwartet e
LEFT JOIN INFORMATION_SCHEMA.COLUMNS c
  ON c.TABLE_SCHEMA = 'dbo' AND c.TABLE_NAME = e.tab AND c.COLUMN_NAME = e.col
WHERE c.COLUMN_NAME IS NULL
ORDER BY e.tab, e.col;
```

## V2 — Schein: vollständige echte Spaltenliste

`Schein.IsPrivat` fehlt nachweislich — hier suchen wir die tatsächlichen
Abrechnungsweg-Spalten (Privat/IGeL/HZV) unter ihrem echten Namen.

```sql
SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'Schein'
ORDER BY ORDINAL_POSITION;
```

## V3 — Spaltenlisten der `SELECT *`-Tabellen

Für diese Tabellen kennen die Mapper das Schema nur defensiv:

```sql
SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME IN (
  'PatientCave','PatientDmp','HzvPatientTeilnahme','AbrechnungHybridDrg',
  'PatientBezugsperson','PatientBezugspersonKontakt',
  'PatientHeilmittelV2Verordnung','PatientHeilmittelV2VerordnungHeilmittel',
  'Medikationsplan','MedikationsplanFreitext')
ORDER BY TABLE_NAME, ORDINAL_POSITION;
```

## V4 — RowVersion auf den Delta-Tabellen

Das Inkrement (Delta-Load) setzt `rowversion` auf diesen Tabellen voraus.
Sollwert: alle 15 tauchen im Ergebnis auf; fehlende Tabellen = kein Delta möglich.

```sql
SELECT c.TABLE_NAME, c.COLUMN_NAME
FROM INFORMATION_SCHEMA.COLUMNS c
WHERE c.TABLE_SCHEMA = 'dbo' AND c.DATA_TYPE = 'timestamp'
  AND c.TABLE_NAME IN ('MedDok','Laborbogen','VerordnungV2','Schein','PatientConsent',
   'RezeptV2','PatientVitalparameterRecord','PatientCave','PatientKontakt',
   'ChronischeErkrankung','Rechnung','Medikationsplan','PatientChipkarte',
   'MedikationsplanItem','PatientHeilmittelV2Verordnung')
ORDER BY c.TABLE_NAME;
```

## V5 — Zeilenzahlen der Export-Tabellen (Mengengerüst)

```sql
SELECT t.name AS Tabelle, SUM(p.rows) AS Zeilen
FROM sys.tables t
JOIN sys.partitions p ON p.object_id = t.object_id AND p.index_id IN (0, 1)
WHERE t.name IN ('Patient','MedDok','MedDokKategorie','Schein','SchedulerAppointment',
 'Laborbogen','PatientVitalparameterRecord','PatientVitalparameterValue','Vitalparameter',
 'VerordnungV2','Medikament','MedikamentAtc','Rechnung','Eau','EpaEventLog',
 'EpaDocumentMeta','PatientChipkarte','TodoItem','RezeptV2','RezeptInfo','RezeptInfoDruck',
 'RezeptDiagnose','MedDokAnhang','Medikationsplan','MedikationsplanItem',
 'MedDokFormularVariable','PatientCave','PatientBezugsperson','PatientDmp',
 'HzvPatientTeilnahme','AbrechnungHybridDrg','PatientHeilmittelV2Verordnung')
GROUP BY t.name ORDER BY Zeilen DESC;
```

## V6 — Enum-Werte (nur Codes und Zählwerte, keine Personendaten)

```sql
SELECT 'Patient.Geschlecht' AS Feld, CAST(Geschlecht AS nvarchar(20)) AS Wert, COUNT(*) AS n
FROM dbo.Patient GROUP BY Geschlecht
UNION ALL
SELECT 'Schein.Scheinart', CAST(Scheinart AS nvarchar(20)), COUNT(*)
FROM dbo.Schein GROUP BY Scheinart
UNION ALL
SELECT 'Schein.Scheinuntergruppe', CAST(Scheinuntergruppe AS nvarchar(20)), COUNT(*)
FROM dbo.Schein GROUP BY Scheinuntergruppe
UNION ALL
SELECT 'VerordnungV2.ItemType', CAST(ItemType AS nvarchar(20)), COUNT(*)
FROM dbo.VerordnungV2 GROUP BY ItemType
UNION ALL
SELECT 'Eau.State', CAST(State AS nvarchar(20)), COUNT(*)
FROM dbo.Eau GROUP BY State
UNION ALL
SELECT 'Laborbogen.Grenzwertindikator', CAST(Grenzwertindikator AS nvarchar(20)), COUNT(*)
FROM dbo.Laborbogen GROUP BY Grenzwertindikator
UNION ALL
SELECT 'MedikationsplanItem.ItemTyp', CAST(ItemTyp AS nvarchar(20)), COUNT(*)
FROM dbo.MedikationsplanItem GROUP BY ItemTyp
ORDER BY Feld, Wert;
```

Zusätzlich das Quartalsformat (frei von Personenbezug):

```sql
SELECT DISTINCT TOP 20 Quartal, Abrechnungsquartal FROM dbo.Schein ORDER BY Quartal DESC;
```

## V7 — MedDok-Kategorien: Abdeckung der Ladeskripte

Der Export kennt: D, DD, DDA, DDAB, FDD, FD, A, V, FASA, AVA, B, PROC, I, TH,
THV, SONO, FIBRO, FBEUR, PROCT, COLO, GASTR, URIN, BRIEF, EAB, E, AU, ALTAU,
AFAU, KRANK, KHB, MDOK, L. Kategorien mit hohem `n`, die hier NICHT gelistet
sind, gehen aktuell nicht in den Export → als Befund melden.

```sql
SELECT k.Kuerzel, k.Name, COUNT(m.Id) AS n
FROM dbo.MedDokKategorie k
LEFT JOIN dbo.MedDok m ON m.Id_MedDokKategorie = k.Id
GROUP BY k.Kuerzel, k.Name
ORDER BY n DESC;
```

## V8 — Vitalparameter-Katalog (u. a. Blutdruck-Speicherung)

Klärt, ob RR systolisch/diastolisch als getrennte Parameter oder als ein
Wert gespeichert wird.

```sql
SELECT vp.Id, vp.Name, vp.DisplayName, vp.Masseinheit, COUNT(v.Id) AS Messwerte
FROM dbo.Vitalparameter vp
LEFT JOIN dbo.PatientVitalparameterValue v ON v.Id_Vitalparameter = vp.Id
GROUP BY vp.Id, vp.Name, vp.DisplayName, vp.Masseinheit
ORDER BY Messwerte DESC;
```

## V9 — Golden Record 3659: Mengengerüst je Domäne (nur Zählwerte)

Sollwerte dienen dem Abgleich mit `pvs/etl/validate_golden.py`.

```sql
SELECT 'MedDok' AS Domaene, COUNT(*) AS n FROM dbo.MedDok WHERE Id_Patient = 3659
UNION ALL SELECT 'Schein', COUNT(*) FROM dbo.Schein WHERE Id_Patient = 3659
UNION ALL SELECT 'Laborbogen', COUNT(*) FROM dbo.Laborbogen WHERE Id_Patient = 3659 AND IsAnforderung = 0
UNION ALL SELECT 'VerordnungV2', COUNT(*) FROM dbo.VerordnungV2 WHERE Id_Patient = 3659 AND IsDeleted = 0
UNION ALL SELECT 'RezeptV2', COUNT(*) FROM dbo.RezeptV2 WHERE Id_Patient = 3659
UNION ALL SELECT 'Termine', COUNT(*) FROM dbo.SchedulerAppointment WHERE Id_Patient = 3659
UNION ALL SELECT 'Vitalwerte', COUNT(*) FROM dbo.PatientVitalparameterRecord WHERE Id_Patient = 3659
UNION ALL SELECT 'Chipkarte', COUNT(*) FROM dbo.PatientChipkarte WHERE Id_Patient = 3659
UNION ALL SELECT 'Cave', COUNT(*) FROM dbo.PatientCave WHERE Id_Patient = 3659
UNION ALL SELECT 'Rechnung', COUNT(*) FROM dbo.Rechnung WHERE Id_Patient = 3659
UNION ALL SELECT 'Anhaenge', COUNT(*) FROM dbo.MedDokAnhang a JOIN dbo.MedDok m ON m.Id = a.Id_MedDok WHERE m.Id_Patient = 3659;
```

## V10 — eAU-Verknüpfung

Jede `Eau`-Zeile sollte an einem AU-MedDok hängen; Waisen = Befund.

```sql
SELECT COUNT(*) AS EauGesamt,
       SUM(CASE WHEN m.Id IS NULL THEN 1 ELSE 0 END) AS OhneMedDok
FROM dbo.Eau e LEFT JOIN dbo.MedDok m ON m.Id = e.Id_MedDok;
```

## V11 — Labor: JSON-Struktur und Anforderungs-Anteil

Prüft die Annahme `Details`-JSON mit `$.Ergebniswert` (Import filtert darauf).

```sql
SELECT IsAnforderung,
       COUNT(*) AS n,
       SUM(CASE WHEN JSON_VALUE(CAST(Details AS nvarchar(max)), '$.Ergebniswert')
                IS NOT NULL THEN 1 ELSE 0 END) AS MitErgebniswert
FROM dbo.Laborbogen GROUP BY IsAnforderung;
```

---

## Rückgabe

Die kompletten Ergebnistabellen (gern als Copy-Paste) zurück in die
Claude-Code-Session geben. Erwartete Befunde, auf die es besonders ankommt:

1. **V1/V2:** Welche erwarteten Spalten fehlen wirklich, und wie heißen die
   Abrechnungsweg-Felder am `Schein` tatsächlich?
2. **V6:** Die echten Enum-Werte von `Eau.State` (offener Punkt #7) und
   `VerordnungV2.ItemType` (Annahme: 1=strukturiert, 3=Freitext).
3. **V7:** MedDok-Kategorien mit hohem Volumen, die der Export noch nicht kennt.
4. **V8:** Wie der Blutdruck gespeichert ist (ein Parameter oder sys/dia getrennt).
5. **V4:** Ob alle 15 Delta-Tabellen eine RowVersion-Spalte haben.
