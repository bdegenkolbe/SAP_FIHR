# GREENBAY clinical — Bedienungsanleitung

Kurzreferenz für den Praxisbetrieb. Die Anwendung läuft lokal unter
`http://127.0.0.1:8710` (Start über Startmenü „GREENBAY clinical" oder
`Start.bat`). Alle Daten bleiben im Haus; die Analyse arbeitet auf
Pseudonymen — Klardaten nur über Break-Glass (protokolliert).

## 1. Anmeldung

Benutzername + Passwort. TOTP (Authenticator-Code) nur, wenn in den
Einstellungen `Anmeldung → MFA = required` gesetzt ist (Standard: aus).
Nach 5 Fehlversuchen sperrt das Konto 15 Minuten
(Sofort-Entsperrung: `tools/unlock_login.ps1`).

## 2. Patientenauswahl

Drei Suchfelder, kombinierbar (UND-verknüpft):

| Feld | Wirkung | Beispiel |
|---|---|---|
| Pseudonym / ICD / Freitext | Pseudonym, Diagnose-Code oder Begriff in Dokumenten (nicht-negiert) | `Reflux` |
| ICD-Filter | **Präfix**-Suche auf aktive Diagnosen | `I10` findet I10.90; `K7` findet K70–K77 |
| ATC-Filter | **Präfix**-Suche auf Medikation | `A10` = alle Antidiabetika |

Klick auf eine Zeile öffnet die 360°-Sicht. **„Als Kohorte analysieren →"**
übernimmt die aktuellen Filter in den Kohorten-Builder.

## 3. 360°-Patientensicht

Timeline (alle Ereignisse chronologisch), Diagnosen, Medikation, Labor
(mit Grenzwert-Markierung), Dokumente mit farbigen NLP-Annotationen
(grün = bestätigt, gelb = Verdacht, rot = verneint), CAVE-Hinweise.
**„Klardaten anfordern 🔓"** (Break-Glass): erfordert Begründung + erneute
Passworteingabe, wird unlöschbar auditiert.

## 4. Analyse / Kohorten-Builder

Ablauf: Kriteriumstyp wählen → Wert eintragen → **+ Kriterium** → **Kohorte
berechnen**. Ein getippter, noch nicht hinzugefügter Wert wird beim Berechnen
automatisch übernommen.

**Logik als Kette:** Merkmale stehen in einer Reihe; zwischen je zwei Merkmalen
sitzt die **Beziehung** — Klick darauf rolliert `und → oder → und ¬ → oder ¬`.
Ausgewertet wird von links nach rechts. **Klammern:** ein Merkmal per
Drag & Drop auf ein anderes ziehen → beide wandern in einen Kasten, der sich
wie ein Merkmal verhält (verschiebbar, negierbar ¬, beliebig schachtelbar);
Ziehen auf einen Kasten hängt das Merkmal dort an. Chart-Klicks (Therapie,
Begleitdiagnosen, Alter, Geschlecht) hängen das Merkmal mit „und" an die Kette
an — erneuter Klick entfernt es. Der Knopf **„? Hilfe & Beispiele"** zeigt
die Anleitung samt klickbarer Beispielabfragen.

| Kriterium | Wert | Zusatz | Beispiel |
|---|---|---|---|
| Diagnose (ICD) | Code-**Präfix** | – | `I10` findet auch I10.90 |
| Therapie (ATC) | Code-**Präfix** | – | `A10BA02` = Metformin |
| Laborwert | Kürzel/Name | Operator + Wert | `TSH` / `> 2,5` |
| Alter | von | bis | `50` / `79` |
| Geschlecht | m / w / d | – | `w` |
| Freitext | Begriff | – | `Sodbrennen` (nur nicht-negierte Erwähnungen) |
| Dokument-Konzept | Code/Begriff | `Verdacht` = inkl. unsichere | SNOMED-Konzept aus NLP-Annotation |
| Zeitraum | von (ISO) | bis (ISO) | `2021-01-01` / `2024-12-31` |

Beispielabfragen:

- **Alle Hypertoniker:** Diagnose (ICD) = `I10` → + Kriterium → Kohorte berechnen.
- **Diabetes Typ 2 unter Metformin:** `E11` (ICD) AND `A10BA02` (ATC).
- **Lebererkrankungen ab 50:** `K7` (ICD) AND Alter `50`–`150`.
- **HOMA-Verlauf einer Kohorte:** Kriterien setzen + rechts „Verlaufskurve:
  Labor-Code" = `HOMA` → Median je Quartal.

**Aggregatschutz:** Fallzahlen < 5 werden maskiert („<5").
**Forschungsexport:** lädt die Kohorte als pseudonymisiertes FHIR-Bundle
(JSON) herunter — für Auswertungen außerhalb nur nach Freigabe/Rechtsgrundlage.

## 5. Volltextsuche

Suche über alle Dokumente (FTS5). Negierte Befunde („kein Ikterus") sind
standardmäßig ausgeschlossen; die Provenienz (strukturiert/NLP/alle) steuert
die Einstellung `Analyse → Ableitungen`.

## 6. Verwaltung (nur mit Verwaltungsrechten)

- **ETL-Status & Store:** „⟳ Sync jetzt" (Inkrement), „Voll-Lauf" (alles),
  „Protokoll" (sync.log der letzten Läufe). Fortschrittsbalken läuft live;
  die Job-Tabelle zeigt Status, Statistik und Fehler je Lauf.
  Nächtlicher Sync: Task „GREENBAY clinical - Sync", 03:30 Uhr.
- **Benutzer & Rollen:** anlegen, Rollen zuweisen (Rechte nach
  `docs/BENUTZERVERWALTUNG.md`), deaktivieren.
- **Audit-Log:** append-only mit Hash-Kette; „Hash-Kette intakt" bestätigt
  die Unverändertheit.

## 7. Einstellungen (alle Konfiguration läuft hier)

- **Quellverbindung:** SQL-Server (Host/Instanz, DB, Login), „Verbindung
  testen" zeigt Version/Patientenzahl/Rechte. Passwort wird DPAPI-geschützt
  abgelegt, nie im Klartext.
- **Sync & Zeitplan:** Uhrzeit des Nachtlaufs, „Daten ab"-Stichtag
  (z. B. 2021-01-01) für den Load.
- **Datenschutz:** Modus (pseudonymize/anonymize), Freitext-De-ID,
  Dateinamen behalten, Gate-Politik (enforce/warn/off).
- **Dokument-Intelligence:** Annotation an/aus, Mindest-Konfidenz,
  Terminologieserver.
- **Analyse:** Ableitungs-Provenienz (structured/nlp/all).
- **Anmeldung:** MFA required/off. **Darstellung:** Theme, FHIR-Profil.

## 8. Wenn etwas klemmt

1. Verwaltung → **Protokoll** lesen (dort steht der echte Fehler).
2. Verbindungstest in den Einstellungen (Quell-DB erreichbar?).
3. Login gesperrt: `tools/unlock_login.ps1` (Rechtsklick → mit PowerShell).
4. Update einspielen: App schließen → `Setup.bat` erneut ausführen →
   `Start.bat`.
