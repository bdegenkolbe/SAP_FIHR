# Datenschema — In-Praxis-Betrieb

Ergänzung zu `CONCEPT.md`. Deckt ab: (1) revidierte Architektur (Tool läuft in der Praxis,
keine Klardaten-Ausleitung), (2) vollständiges Quell-Inventar mit Delta-Strategie,
(3) lokales Postgres-Schema als DDL (Benutzerverwaltung, Audit, ETL, Pseudonym-Vault),
(4) FHIR/openEHR-Persistenz, (5) gesicherter Storage.

---

## 1. Architektur-Revision (In-Praxis)

Das Tool ist **in der Praxis installiert**, Exporte erstellen **geschulte Praxismanager**.
Damit entfällt die Zonen-Trennung mit Datentransfer. Es bleibt ein Ein-Knoten-System im
Praxisnetz mit vier Bausteinen:

```mermaid
flowchart TB
    DB[(MSSQL PVS<br/>read-only Login)] --> ETL["ETL-Dienst<br/>Extract → Map → Annotate → Load"]
    ETL --> STORE[(Lokaler gesicherter Store<br/>PostgreSQL, verschlüsselt)]
    subgraph APP["Anwendung (im Praxisnetz)"]
        AUTH["Benutzerverwaltung + RBAC + MFA"]
        API["Analyse-API (FastAPI)"]
        UI["Analyse-UI (React)"]
        AUTH --> API --> UI
    end
    STORE --> API
    ETL -.Job-Steuerung.-> API
    API -->|jede Aktion| AUDIT[(Audit-Log, append-only)]
```

**Kernpunkte**
- Klardaten bleiben in der Praxis. Pseudonymisierung/Anonymisierung ist eine **Export-Option**
  (für Weitergabe/Auswertung), keine Zwangstransformation für den internen Store.
- Jeder Zugriff und jeder Export läuft über die Benutzerverwaltung und wird auditiert
  (Nachweispflicht §630f BGB / Art. 5 Abs. 2 DSGVO).
- Der Store ist verschlüsselt (Abschnitt 5); der Pseudonym-Vault ist separat geschützt.

---

## 2. Quell-Inventar (autoritativ, per Katalog ermittelt)

142 Tabellen mit `Id_Patient`. Delta-Fähigkeit aus den Change-Markern:

- **`RowVersion` vorhanden → `rowversion`-HWM** (bevorzugt, erfasst Inserts + Updates).
- **nur `CreatedPoint` → `createdpoint`-Append** (Insert-only-Annahme, kein Update-Delta).
- **keiner von beiden → `reconcile`/skip** (Voll-Abgleich oder ignorieren).
- `IsDeleted` vorhanden → Soft-Delete direkt mappen.

### 2.1 Export-relevant (Kern, priorisiert)

| Tabelle | Zeilen | Delta | Del | Blob | FHIR-Ziel |
|---|--:|---|:--:|:--:|---|
| `dbo.Laborbogen` | 2.196.907 | rowversion | – | JSON | Observation |
| `dbo.MedDok` | 1.109.575 | rowversion | – | XML | Condition / Observation / DocumentReference |
| `dbo.MedDokExtensionData` | 496.281 | – | – | KeyVal | **nicht exportiert** (BDT/xDT-Rohdaten, redundant) |
| `dbo.MedDokBdt` | 97.663 | – | – | BDT | (Fallback/Diagnose; nicht Kern) |
| `dbo.MedDokFormularVariable` | 59.047 | rowversion | – | JSON | Anreicherung (AU/Überweisung/Laborauftrag) |
| `dbo.MedDokAnhang` | 26.315 | – | – | Binär | DocumentReference.content (nur bei Bedarf) |
| `dbo.SchedulerAppointment` | 97.265 | createdpoint | ✓ | – | Appointment |
| `dbo.VerordnungV2` | 85.659 | rowversion | ✓ | – | MedicationRequest/Statement |
| `dbo.PatientChipkarte` | 55.791 | rowversion | – | – | Coverage (pseudonymisieren) |
| `dbo.Schein` | 53.019 | rowversion | – | – | Encounter / Claim |
| `dbo.PatientConsent` | 52.573 | rowversion | – | – | Consent |
| `dbo.LaborHeader` | 44.326 | createdpoint | – | – | DiagnosticReport (Kopf) |
| `dbo.RezeptV2` | 30.911 | rowversion | – | – | MedicationRequest |
| `dbo.PatientVitalparameterRecord` | 27.778 | rowversion | – | – | Observation (vital-signs) |
| `dbo.MedikamentVerordnungsmenge` | 26.972 | createdpoint | – | – | (Detail zu Verordnung) |
| `dbo.PatientCave` | 20.722 | rowversion | – | – | Flag / AllergyIntolerance |
| `dbo.EpaEventLog` | 19.880 | – | – | JSON | DocumentReference (ePA, optional) |
| `dbo.TodoItem` | 13.590 | reconcile* | – | – | Task (*kein RowVersion) |
| `dbo.EpaDocumentMeta` | 7.321 | – | – | JSON | (Detail zu ePA-Event) |
| `dbo.Eau` | 2.164 | – | – | Binär | eAU-Transport (an AU via Id_MedDok) |
| `dbo.PatientKontakt` | 18.760 | rowversion | – | – | Patient.telecom / RelatedPerson |
| `dbo.PatientMitbehandler` | 7.265 | createdpoint | – | – | CareTeam |
| `dbo.ChronischeErkrankung` | 4.577 | rowversion | – | – | Condition |
| `dbo.Rechnung` | 4.321 | rowversion | – | JSON | Invoice / Claim |
| `dbo.Medikationsplan` | 3.339 | rowversion | – | – | MedicationStatement (Liste) |
| `dbo.GeriatrieDok` | 3.155 | rowversion | – | XML | Composition / Observation |
| `dbo.PatientNfdm` | 2.726 | rowversion | – | – | Composition (Notfalldaten) |
| `dbo.PatientRezeptgebuehrenbefreiung` | 2.040 | rowversion | – | – | Coverage.extension |
| `dbo.PatientImpfstatus` | 1.316 | reconcile | – | – | Immunization (Status) |
| `dbo.KostenVoranschlag` | 1.129 | rowversion | – | – | Claim (Vorab) |
| `dbo.LaborAnforderung` | 965 | rowversion | – | – | ServiceRequest |
| `dbo.PatientHeilmittelV2Verordnung` | 441 | rowversion | – | – | ServiceRequest |
| `dbo.PatientNote` | 213 | createdpoint | – | – | Observation / Annotation |
| `dbo.PatientDisability` | 3 | rowversion | – | – | Condition / Observation |
| `dbo.PatientBeruflicheTaetigkeit` | 5 | createdpoint | – | – | Observation (social) |
| `dbo.PatientBezugsperson` | 3 | createdpoint | – | – | RelatedPerson |

Weitere strukturell vorhandene, aktuell leere Fachtabellen (bei Bedarf mitnehmen, sobald
befüllt): `PatientDiagnose` (rowversion), `PatientSchwangerschaft`, `PatientDmp`,
`EArztbrief`, `XArchivDocumentReference`, diverse Test-/Assessment-Tabellen
(`PatientPhq9Test` etc.).

### 2.2 Nicht exportieren (technisch/transient)

Ausschluss über Denylist-Muster in `tables.yaml`:
`*Temp`, `FehlerProtokoll`, `PresentPatient`, `BenutzerRecentPatient`, `DssProtokoll`,
`NotificationHistory`, `Dokumentenhistorie` (nur bei Bedarf), `Druckauftrag`, `*Queue`,
sämtliche 0-Zeilen-Integrations-/HZV-/EPA-Tabellen. `Audit.Patient` nur als optionale
Historienquelle.

### 2.3 Blob-Parser (Pflicht)

- `MedDok.Detail` (XML) — Parser **je `MedDokKategorie.Kuerzel`** (D=Diagnose bereits
  implementiert; Anamnese/Befund/Verlauf/… folgen).
- `Laborbogen.Details` (JSON) — einheitlich, implementiert.
- `MedDokFormularVariable.FormularVariablen` (JSON `{id,value}`) — nur klinische `_`/`Formular_*`-Felder lesen, PII (`Patient_*`/`Praxis_*`/`Arzt_*`) verwerfen.
- `MedDokExtensionData` (Key-Value BDT/xDT) — **nicht** exportiert; nur Fallback.
- `Rechnung`/`GeriatrieDok`/`EpaEventLog` — eigene Blob-Behandlung bei Aufnahme.

---

## 3. Lokales Schema — Benutzerverwaltung, Audit, ETL, Vault (PostgreSQL)

Voraussetzung: `pgcrypto` (Verschlüsselung), `pg_stat_statements` optional.
Rollenkonzept per RBAC; die technische DB-App-Rolle hat **kein** DELETE-Recht auf
`audit.*`.

### 3.1 Sicherheit / Benutzerverwaltung (`sec`)

```sql
CREATE SCHEMA sec;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE sec.app_user (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username      text NOT NULL UNIQUE,
  full_name     text NOT NULL,
  email         text UNIQUE,
  password_hash text NOT NULL,                 -- Argon2id
  mfa_secret    bytea,                          -- TOTP-Secret, pgp_sym_encrypt
  mfa_enabled   boolean NOT NULL DEFAULT false,
  status        text NOT NULL DEFAULT 'active'
                 CHECK (status IN ('active','locked','disabled')),
  failed_logins int NOT NULL DEFAULT 0,
  last_login_at timestamptz,
  password_changed_at timestamptz NOT NULL DEFAULT now(),
  created_at    timestamptz NOT NULL DEFAULT now(),
  created_by    uuid REFERENCES sec.app_user(id),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE sec.role (
  id   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text
);

CREATE TABLE sec.permission (
  id   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE
);

CREATE TABLE sec.role_permission (
  role_id uuid REFERENCES sec.role(id) ON DELETE CASCADE,
  perm_id uuid REFERENCES sec.permission(id) ON DELETE CASCADE,
  PRIMARY KEY (role_id, perm_id)
);

CREATE TABLE sec.user_role (
  user_id uuid REFERENCES sec.app_user(id) ON DELETE CASCADE,
  role_id uuid REFERENCES sec.role(id) ON DELETE CASCADE,
  PRIMARY KEY (user_id, role_id)
);

CREATE TABLE sec.session (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL REFERENCES sec.app_user(id),
  token_hash text NOT NULL,                     -- nur Hash speichern
  issued_at  timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  ip         inet,
  user_agent text,
  revoked_at timestamptz
);
```

**Rollen-/Rechte-Seed** (Vorschlag)

| Rolle | Rechte (permission.code) |
|---|---|
| `admin` | `user.manage`, `role.manage`, `audit.read`, `export.run`, `export.deidentify`, `data.read.clear`, `settings.manage` |
| `praxismanager` | `export.run`, `export.deidentify`, `data.read.clear` |
| `analyst` | `data.read.pseudo`, `query.run` |
| `auditor` | `audit.read`, `data.read.pseudo` |

Rechte-Katalog: `user.manage`, `role.manage`, `settings.manage`, `export.run`,
`export.deidentify`, `data.read.clear` (Klardaten), `data.read.pseudo` (nur
pseudonymisiert), `query.run`, `audit.read`.

### 3.2 Audit-Log (`audit`, append-only)

```sql
CREATE SCHEMA audit;

CREATE TABLE audit.event (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  ts          timestamptz NOT NULL DEFAULT now(),
  user_id     uuid REFERENCES sec.app_user(id),
  action      text NOT NULL,          -- login, logout, export.run, patient.view,
                                       -- query.run, deid.export, user.create, role.change
  object_type text,                    -- export_job | fhir_resource | app_user | query
  object_id   text,
  detail      jsonb,
  ip          inet,
  success     boolean NOT NULL DEFAULT true,
  prev_hash   bytea,                   -- optional: Hash-Chaining gegen Manipulation
  row_hash    bytea
);
-- App-Rolle: nur INSERT/SELECT; UPDATE/DELETE entzogen. Aufbewahrung gem. Löschkonzept.
```

### 3.3 ETL-Status & Export-Jobs (`etl`)

```sql
CREATE SCHEMA etl;

CREATE TABLE etl.watermark (
  source_table    text PRIMARY KEY,           -- 'dbo.Laborbogen'
  strategy        text NOT NULL,              -- rowversion | createdpoint | reconcile
  last_rowversion bytea,                       -- 8-Byte HWM
  last_created    timestamptz,
  last_run_at     timestamptz,
  rows_loaded     bigint
);

CREATE TABLE etl.export_job (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  started_by  uuid NOT NULL REFERENCES sec.app_user(id),
  started_at  timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz,
  mode        text NOT NULL,                  -- full | incremental | reconcile
  privacy     text NOT NULL,                  -- clear | pseudonymize | anonymize
  target      text NOT NULL,                  -- fhir | openehr
  status      text NOT NULL DEFAULT 'running',-- running | success | failed | partial
  scope       jsonb,                          -- Tabellen/Domänen, Zeitfenster
  stats       jsonb,                          -- {resources, patients, ...}
  error       text
);

CREATE TABLE etl.export_job_table (
  job_id            uuid REFERENCES etl.export_job(id) ON DELETE CASCADE,
  source_table      text,
  rows_read         bigint,
  resources_written bigint,
  status            text,
  PRIMARY KEY (job_id, source_table)
);
```

### 3.4 Pseudonym-Vault (`vault`, getrennt gesichert)

Nur mit Recht `export.deidentify`/`data.read.clear` zugreifbar. Klar-IDs verschlüsselt;
Schlüssel im OS-Keychain/HSM, nicht in der DB.

```sql
CREATE SCHEMA vault;

CREATE TABLE vault.patient_pseudonym (
  pseudonym        text PRIMARY KEY,          -- HMAC-SHA256(secret, Patient.Id), base32
  source_id_enc    bytea NOT NULL,            -- pgp_sym_encrypt(Patient.Id)
  source_nr_enc    bytea,                     -- pgp_sym_encrypt(PatientNr)
  date_shift_days  int NOT NULL,              -- konsistenter Offset je Patient
  created_at       timestamptz NOT NULL DEFAULT now()
);
```

---

## 4. FHIR-/openEHR-Persistenz

### 4.1 Option A — Postgres-JSONB FHIR-Store (`fhir`)

Schlank, volle Kontrolle, gut fürs MVP.

```sql
CREATE SCHEMA fhir;

CREATE TABLE fhir.resource (
  resource_type text NOT NULL,               -- Patient, Observation, Condition, ...
  id            text NOT NULL,               -- logische FHIR-Id (= Pseudonym-abgeleitet)
  version_id    int  NOT NULL DEFAULT 1,
  status        text NOT NULL DEFAULT 'active', -- active | deleted (Soft-Delete/Reconcile)
  last_updated  timestamptz NOT NULL DEFAULT now(),
  pseudonym     text,                        -- denormalisierter Patientenbezug (Filter)
  content       jsonb NOT NULL,              -- die FHIR-Ressource
  source_job    uuid REFERENCES etl.export_job(id),
  PRIMARY KEY (resource_type, id)
);
CREATE INDEX ix_fhir_pseudo   ON fhir.resource (pseudonym);
CREATE INDEX ix_fhir_updated  ON fhir.resource (resource_type, last_updated);
CREATE INDEX ix_fhir_content  ON fhir.resource USING gin (content jsonb_path_ops);

CREATE TABLE fhir.resource_history (
  resource_type text, id text, version_id int,
  changed_at timestamptz NOT NULL DEFAULT now(),
  operation  text,                           -- create | update | delete
  content    jsonb,
  job_id     uuid REFERENCES etl.export_job(id),
  PRIMARY KEY (resource_type, id, version_id)
);

CREATE TABLE fhir.reference (                -- Beziehungsauflösung für Graph-Abfragen
  src_type text, src_id text, field text,
  ref_type text, ref_id text,
  PRIMARY KEY (src_type, src_id, field, ref_type, ref_id)
);
```

**Upsert-Regel:** ID stabil aus `resource_type` + Quell-PK (bzw. Pseudonym) via uuid5 —
idempotent über wiederholte Läufe. Änderung → `version_id`++ und History-Eintrag.
Reconcile setzt fehlende Quell-PKs auf `status='deleted'`.

### 4.2 Option B — dedizierte Stores

- **Blaze** (FHIR, CQL) als Alternative zu 4.1, wenn native FHIR-Suche/CQL gewünscht.
- **EHRbase** (openEHR-CDR, AQL) für den openEHR-Pfad. Compositions gegen Templates
  (`OBSERVATION.laboratory_test_result`, `.blood_pressure`, `EVALUATION.problem_diagnosis`,
  `.medication_statement`).

Empfehlung: MVP mit 4.1, Blaze/EHRbase als spätere, konfigurierbare Ziele (`target` in
`export_job`).

### 4.3 NLP-Annotationen (`nlp`)

```sql
CREATE SCHEMA nlp;

CREATE TABLE nlp.annotation (
  id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  resource_type text NOT NULL,
  resource_id   text NOT NULL,
  pseudonym     text,
  span_start    int, span_end int,
  text_snippet  text,
  entity_type   text,                        -- CONDITION | DRUG | LAB | BODYSITE | ...
  code_system   text,                        -- ICD-10-GM | ATC | LOINC | SNOMED
  code          text,
  negated       boolean NOT NULL DEFAULT false,
  uncertain     boolean NOT NULL DEFAULT false,
  effective_at  timestamptz,
  FOREIGN KEY (resource_type, resource_id)
     REFERENCES fhir.resource(resource_type, id) ON DELETE CASCADE
);
CREATE INDEX ix_nlp_code  ON nlp.annotation (code_system, code, negated);
CREATE INDEX ix_nlp_pseudo ON nlp.annotation (pseudonym);
```

Für facettierte Volltextsuche zusätzlich Spiegelung nach OpenSearch (Index je Ressource +
Annotation), Postgres bleibt Source-of-Truth.

---

## 5. Gesicherter Storage

- **Verschlüsselung at rest:** Datenträger LUKS/BitLocker **plus** DB-seitig sensible
  Felder via `pgcrypto` (Vault, MFA-Secrets). Optional TDE (Enterprise-Postgres-Derivate).
- **Schlüsselverwaltung:** Master-Key im OS-Keychain/HSM/Vault, **nie** in der DB oder im Repo.
- **Zugriff:** DB nur lokal gebunden (`listen_addresses='localhost'`), App↔DB über
  Unix-Socket/TLS. Kein direkter Netzzugriff auf den Store.
- **Least Privilege:** getrennte DB-Rollen — `etl_writer` (schreibt `fhir`/`nlp`/`etl`),
  `api_reader` (liest, kein Schreibrecht auf `audit`), `vault_access` (nur mit App-Recht
  `data.read.clear`).
- **Backup:** verschlüsselte, versionierte Backups; Restore-Test dokumentiert; Aufbewahrung
  nach Löschkonzept.
- **Löschkonzept:** definierte Fristen je Datenart; harte Löschung inkl. Vault-Eintrag →
  Pseudonym wird unumkehrbar (De-facto-Anonymisierung).

---

## 6. Nächste Schritte für Claude Code

1. `tables.yaml` aus Abschnitt 2 generieren (Crawler + manuelle Mapping-Hints, Denylist).
2. Postgres-Migrationen (Alembic) aus Abschnitt 3–4 anlegen; RBAC-Seed einspielen.
3. Auth-Layer (Argon2id, TOTP-MFA, Session) + Permission-Guard in FastAPI.
4. ETL-Kern: rowversion-HWM-Loader für `Laborbogen`/`MedDok`/`VerordnungV2` (die 3 größten,
   rowversion-fähig) als erste Strecke; Golden-Record-Test gegen Patient 3659.
5. Blob-Parser-Registry (MedDok-XML je Kategorie).
6. Analyse-API + Timeline-View; danach NLP + OpenSearch.
