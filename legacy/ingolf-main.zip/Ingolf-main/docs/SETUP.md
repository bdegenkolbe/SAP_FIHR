# Installation & Betrieb ohne Adminrechte

Ziel: **Doppelklick-Installation** auf einem Windows-Arbeitsplatz **ohne Administrator­rechte**,
ohne Docker, ohne Dienste, ohne systemweite Änderungen. Alles landet im Benutzerprofil.

## 1. Warum das ohne Admin geht

- **Installationsort** `%LOCALAPPDATA%\GreenbayClinical` — im Benutzerprofil, kein Admin nötig.
- **Laufzeit** = *embeddable* Python (portabel, wird mitgeliefert/entpackt) — keine System­installation.
- **Datenbank** = SQLCipher (verschlüsselte SQLite-Datei) im Profil — kein Server, kein Dienst.
- **Quellzugriff** = `python-tds` (pure-Python-TDS) — kein ODBC-Treiber, keine DSN.
- **Autostart/Zeitplan** = **per-User** Scheduled Task (`schtasks /RU %USERNAME%`, ohne
  `/RL HIGHEST`) — läuft im Benutzerkontext, kein Admin.
- **Web-UI** = lokaler FastAPI/Uvicorn nur auf `127.0.0.1:<port>` — keine Firewallregel nötig.
- **Verschlüsselung** = App-seitig (SQLCipher) + Windows **DPAPI** (`CryptProtectData`,
  `CurrentUser`-Scope) für das Master-Secret — kein BitLocker/Adminrecht erforderlich.

## 2. Zwei Auslieferungsvarianten

### A) `Setup.bat` (leichtgewichtig, empfohlen für Start) — Self-Bootstrap
Reines Batch-Skript (liegt in `installer/Setup.bat`). **Nur diese eine Datei herunterladen
und doppelklicken** — alles Weitere passiert automatisch. Ablauf:
1. Prüft/erzeugt `%LOCALAPPDATA%\GreenbayClinical`.
2. **Beschafft den Anwendungscode selbst:** nutzt lokale Dateien, falls das Setup im
   Repo-/Paketordner liegt; sonst Download des Repo-Zips von GitHub via `curl`
   (in Windows 10/11 enthalten). Privates Repo: GitHub-Token in eine Datei
   **`setup.env` neben der Setup.bat** legen (Vorlage `installer/setup.env.example`,
   Zeile `GB_TOKEN=github_pat_…`) — alternativ klassisch `set GB_TOKEN=…`.
   Branch-Kandidaten: `GB_BRANCH` falls gesetzt, sonst `main` mit automatischem
   Fallback auf den Entwicklungsbranch.
3. **Beschafft die Python-Laufzeit selbst:** mitgeliefertes/vorhandenes Python, sonst
   Download des offiziellen *embeddable* Python von python.org (portabel, kein Admin)
   inkl. pip-Bootstrap.
4. Installiert Abhängigkeiten:
   - **online** (Zielrechner hat Internet): `pip install -r requirements.txt`
   - **offline-Fallback:** aus mitgeliefertem `wheels\`-Ordner (`pip --no-index --find-links`).
5. Führt die **stille Ersteinrichtung** aus (`installer/first_run.py`, keine
   Konsolenfragen): Master-Secret per DPAPI, Store-DB mit Rollen-Seed,
   Minimal-Config. **Alles Weitere passiert im Browser:** Owner-Konto + TOTP in
   der Ersteinrichtungs-Maske beim ersten Start; Quell-DB (Host/Login/Passwort,
   DPAPI-geschützt) inkl. Verbindungstest unter *Einstellungen →
   Quellverbindung*. (Konsolen-Wizard weiterhin verfügbar: `--interactive`.)
6. Registriert den **per-User** Scheduled Task (nächtlicher inkrementeller Export
   **in den lokalen Store**, `--db data\clinical.db`).
7. Legt **`Start.bat`** und eine **Startmenü-Verknüpfung** an (`…\Programs\GREENBAY clinical`).

**Starten nach der Installation:** Startmenü „GREENBAY clinical" oder
`%LOCALAPPDATA%\GreenbayClinical\Start.bat` — startet den lokalen Server
(`server/run.py`, nur 127.0.0.1:8710) und öffnet den Browser. Eine Kopie liegt als
`installer/Start.bat` im Repo.

### B) `Setup.exe` (signierbar, für gesperrte Umgebungen)
Single-File-Build via **PyInstaller** (`--onefile --noconsole`), der intern dasselbe wie
`Setup.bat` tut, aber ohne sichtbare Konsole und **signierbar** (Code-Signing-Zertifikat)
für AppLocker/WDAC-Umgebungen. Build-Rezept:
```bat
pip install pyinstaller
pyinstaller --onefile --noconsole --name Setup ^
  --add-data "app;app" --add-data "wheels;wheels" installer\bootstrap.py
signtool sign /fd SHA256 /a /tr http://timestamp.digicert.com /td SHA256 dist\Setup.exe
```

## 3. AppLocker / WDAC vorher prüfen (auf dem Zielrechner)

```powershell
Get-AppLockerPolicy -Effective -Xml                    # leer = keine AppLocker-Regeln
Get-Service AppIDSvc | Select Status,StartType         # Running = AppLocker aktiv
Get-CimInstance -Namespace root\Microsoft\Windows\DeviceGuard `
  -ClassName Win32_DeviceGuard |
  Select CodeIntegrityPolicyEnforcementStatus, UsermodeCodeIntegrityPolicyEnforcementStatus
# Werte je Feld: 0 = aus, 1 = Audit, 2 = erzwungen.
```

**Wichtige Unterscheidung bei WDAC/DeviceGuard:**
- `CodeIntegrityPolicyEnforcementStatus` = **Kernel-Mode** (KMCI/HVCI). Betrifft nur signierte
  **Kernel-Treiber**, ist auf modernen Windows mit Secure Boot/Speicherintegrität normal und
  **irrelevant** für User-Mode-Anwendungen. Ein Wert von 2 hier ist unkritisch.
- `UsermodeCodeIntegrityPolicyEnforcementStatus` = **User-Mode** (UMCI / Smart App Control).
  **Nur dieser Wert entscheidet**, ob unsere Anwendung (Python/.bat/.exe) blockiert würde.

Entscheidungsregel:
- **AppLocker leer + `UsermodeCodeIntegrity…` = 0:** Variante A (`Setup.bat`) genügt, **kein
  Signing nötig** — auch wenn der Kernel-Mode-Wert 2 ist. (Referenzrechner der Praxis:
  AppLocker leer, KMCI=2, **UMCI=0** → `Setup.bat` läuft ohne Zusatzmaßnahmen.)
- **`UsermodeCodeIntegrity…` = 1/2 oder AppLocker mit Regeln:** Variante B (signierte
  `Setup.exe`) **oder** einmalige IT-Freigabe des Ordners `%LOCALAPPDATA%\GreenbayClinical`.
- Rein kosmetisch: aus dem Internet geladene `.exe` kann eine einmalige **SmartScreen**-
  Reputationswarnung zeigen (kein Block); lokale/aus dem Firmennetz kopierte Pakete meist nicht.

## 4. Verzeichnislayout nach Installation

```
%LOCALAPPDATA%\GreenbayClinical\
├─ python\            embeddable Python-Runtime
├─ app\              Anwendungscode (agent/, reference/, ui/, server)
├─ data\             clinical.db (SQLCipher, verschlüsselt)
├─ config\           config.yaml (Verbindung, Policy, FHIR-Profil)
├─ secret\           master.bin (DPAPI-geschützt)
├─ logs\             ETL-/App-Logs
└─ GREENBAY clinical.lnk  (auch im Startmenü)
```

## 5. Erstbefüllung & Zeitplan

- **Erstlauf** (Full-Load) ist rechenintensiv (2,2 Mio. Laborbögen, 1,1 Mio. MedDok) →
  im Wizard optional als Hintergrundlauf mit Fortschrittsanzeige, batched, nachts fortsetzbar.
- **Danach** nächtlicher **inkrementeller** Lauf (rowversion-HWM) per User-Task.
- **Update der App** ohne Admin: neue `app\`-Dateien ersetzen, DB/Config/Secret bleiben.

## 6. Deinstallation

`installer\Uninstall.bat`: entfernt Task + Startmenü-Verknüpfung + Ordner. Da alles im
Benutzerprofil liegt, bleibt das System unberührt (kein Registry-/Programme-Eintrag).

Details der Laufzeit-Architektur (embedded statt Docker etc.) siehe `docs/DEPLOYMENT.md`.
