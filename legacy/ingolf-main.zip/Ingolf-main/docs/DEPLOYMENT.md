# Deployment ohne Adminrechte

Ergänzung/Revision zu `CONCEPT.md` und `SCHEMA.md`. Vorgabe: Installation und Betrieb
**vollständig im Nutzerkontext**, keine lokalen Administratorrechte, keine System-Dienste,
keine Treiberinstallation, keine Änderung von System-/Firewall-Einstellungen.

Das kippt vier bisherige Annahmen und ersetzt sie:

| Bisher (braucht Admin) | Ohne Admin stattdessen |
|---|---|
| Docker (Blaze / EHRbase / OpenSearch) | Embedded-Stores im Prozess (SQLite/SQLCipher, DuckDB, FTS5) |
| PostgreSQL-Server-Installation | SQLCipher (verschlüsseltes SQLite), Datei im Nutzerprofil |
| ODBC Driver 18 for SQL Server | Pure-Python-TDS (`pytds`), kein Treiber nötig |
| BitLocker/LUKS (Disk-Verschlüsselung) | App-Verschlüsselung (SQLCipher) + Windows-DPAPI für den Schlüssel |

---

## 1. Revidierter Tech-Stack (alles Userland)

| Anforderung | No-Admin-Wahl | Warum |
|---|---|---|
| Laufzeit | Gebündeltes Python (PyInstaller One-File **oder** portable venv) | Kein System-Python, kein Installer, entpacken + starten |
| Quell-DB-Zugriff | `pytds` (pure Python TDS) via SQLAlchemy-Dialekt | MSSQL ohne ODBC-Treiberinstallation |
| Lokaler Store (PHI) | **SQLCipher** (AES-256-verschlüsseltes SQLite), Datei in `%LOCALAPPDATA%` | Datei-basiert, kein Server, keine Adminrechte |
| Analytik | DuckDB (in-process) auf de-identifizierten Extrakten | Analytische Abfragen/Verläufe schnell, embedded |
| Volltext/Facetten | SQLite **FTS5** (eingebaut) | Ersetzt OpenSearch für Einzelpraxis, kein JVM/Dienst |
| Schlüsselschutz | Windows **DPAPI** (`CryptProtectData`, pro Nutzer) | Kein OS-Keychain-Admin, kein Master-Key im Klartext |
| API/UI | FastAPI + Uvicorn, gebunden an `127.0.0.1:<Highport>` | Kein Firewall-Eingriff, Browser ist vorhanden |
| Zeitsteuerung | Windows Task Scheduler **Nutzer-Task** oder In-App-Scheduler | Nutzer-Tasks brauchen kein Admin |

Konsequenz: **FHIR ist der voll-embedded Pfad.** Ein queryable openEHR-CDR (EHRbase) und
Blaze/OpenSearch bleiben optionale Server-Add-ons für den Fall, dass die IT Infrastruktur
bereitstellt (Abschnitt 7).

---

## 2. Installation & Packaging

- **Auslieferung:** signiertes One-File-Binary **oder** ZIP mit gebündeltem Interpreter.
  Installation = entpacken nach `%LOCALAPPDATA%\KlinikDatenplattform\` und starten.
- **Datenverzeichnis:** `%LOCALAPPDATA%\KlinikDatenplattform\data\` (Store, Logs, Config).
  Kein Schreiben nach `Program Files`, keine Registry-HKLM-Einträge (nur HKCU falls nötig).
- **Start:** Doppelklick startet den lokalen Dienst und öffnet den Standardbrowser auf
  `http://127.0.0.1:<port>`.

**Wichtiger Vorbehalt — Application Whitelisting:** Abgeschottete Praxen setzen oft
AppLocker/WDAC ein. Das ist eine IT-Richtlinie, kein lokales Adminrecht am Arbeitsplatz.
Gegenmittel: das Binary **code-signieren** (OV/EV-Zertifikat, herstellerseitig). Bei
aktivem Whitelisting genügt dann eine Publisher-Freigabe durch die IT — der Endnutzer
braucht weiterhin keine Adminrechte. Ohne Signatur kann SmartScreen/AppLocker den Start
blockieren. **Als Risiko früh mit der Praxis-IT klären.**

---

## 3. Gesicherter Storage ohne Admin

- **Verschlüsselung at rest:** SQLCipher verschlüsselt die **gesamte** DB-Datei (AES-256),
  unabhängig davon, ob die Platte verschlüsselt ist. PHI liegt nie im Klartext auf dem
  Datenträger.
- **Schlüssel:** zufälliger 256-bit-Key, mit **DPAPI** pro Windows-Nutzer verschlüsselt in
  `data\key.bin` abgelegt. Nur derselbe Windows-Account kann ihn entschlüsseln — kein
  Master-Key im Repo, keine Passphrase-Eingabe nötig. Non-Windows: OS-Keychain oder
  Argon2id-abgeleiteter Key aus App-Passphrase.
- **Zwei getrennte verschlüsselte Dateien:**
  - `store.db` — Betriebsdaten (Ressourcen, Nutzer, Audit, ETL-Status).
  - `vault.db` — Pseudonym-Zuordnung, separater Key, nur mit Recht `data.read.clear`
    entschlüsselt.
- **Netz:** Dienst bindet ausschließlich `127.0.0.1`. Keine eingehende Firewall-Regel nötig
  (die bräuchte Admin). Damit ist die Standardinstallation **Einzelarbeitsplatz**. Zugriff
  mehrerer Arbeitsplätze auf **eine** Instanz erfordert IT (Freigabe/Host) → Server-Modus,
  Abschnitt 7. Mehrere App-Nutzer an **einem** Arbeitsplatz (getrennte Logins) sind ohne
  Admin voll möglich.

---

## 4. MSSQL-Anbindung ohne ODBC

- Treiberfrei über `pytds` (reines Python-TDS), SQL-Auth gegen den read-only-Login des PVS.
  Kein „ODBC Driver 18" nötig.
- TLS: `pytds` unterstützt verschlüsselte Verbindungen; Zertifikatsprüfung konfigurierbar.
- Windows-Auth (NTLM) ist mit `pytds` eingeschränkt möglich; im Zweifel **SQL-Auth**
  mit dediziertem read-only-Konto (von der IT bereitgestellt) verwenden.
- Verbindungsdaten wie in `CONCEPT.md` §3, aber ohne `driver`-Feld; Secrets via DPAPI-
  geschützter Config statt ENV.

```yaml
# config/connection.example.yaml (No-Admin-Variante)
source:
  host: "PRAXIS-SQL01.local"
  port: 1433
  database: "EUGASTRO"
  auth: "sql"
  username: "svc_export_ro"          # read-only Login, von IT
  password_ref: "dpapi:src_db_pw"    # DPAPI-geschützt in data\secrets.bin
  encrypt: true
  trust_server_certificate: false
storage:
  dir: "%LOCALAPPDATA%/KlinikDatenplattform/data"
  cipher: "sqlcipher"
  key_ref: "dpapi:store_key"
```

---

## 5. Persistenz-Anpassung PostgreSQL → SQLite/SQLCipher

Die DDL aus `SCHEMA.md` bleibt inhaltlich gültig, wird aber auf SQLite übersetzt:

| Postgres | SQLite/SQLCipher |
|---|---|
| `CREATE SCHEMA sec/audit/etl/...` | Tabellen-Präfixe (`sec_`, `audit_`, `etl_`, `fhir_`, `nlp_`) oder `ATTACH` je Datei |
| `uuid DEFAULT gen_random_uuid()` | TEXT, UUID in der App (Python `uuid4`) erzeugt |
| `timestamptz` | TEXT (ISO-8601 UTC) oder INTEGER (Epoch) |
| `jsonb` + GIN | TEXT + JSON1 (`json_extract`); Filterfelder als **generierte Spalten** + B-Tree-Index |
| `pgcrypto` (Feldverschlüsselung) | ganze Datei via SQLCipher verschlüsselt; DPAPI für Key |
| `bytea` (rowversion HWM) | BLOB oder Hex-TEXT |
| append-only per Rechteentzug | BEFORE-UPDATE/DELETE-**Trigger** mit `RAISE(ABORT, …)` |

**Kern: FHIR-Ressource + Volltext (SQLite)**

```sql
CREATE TABLE fhir_resource (
  resource_type TEXT NOT NULL,
  id            TEXT NOT NULL,
  version_id    INTEGER NOT NULL DEFAULT 1,
  status        TEXT NOT NULL DEFAULT 'active',   -- active | deleted
  last_updated  TEXT NOT NULL,                    -- ISO-8601 UTC
  pseudonym     TEXT,                             -- denormalisiert für Filter
  content       TEXT NOT NULL,                    -- FHIR-JSON
  source_job    TEXT,
  PRIMARY KEY (resource_type, id)
);
CREATE INDEX ix_fhir_pseudo  ON fhir_resource (pseudonym);
CREATE INDEX ix_fhir_updated ON fhir_resource (resource_type, last_updated);

-- Beispiel: häufig gefilterte Codes als generierte Spalte indexieren
ALTER TABLE fhir_resource ADD COLUMN code0 TEXT
  GENERATED ALWAYS AS (json_extract(content,'$.code.coding[0].code')) VIRTUAL;
CREATE INDEX ix_fhir_code0 ON fhir_resource (resource_type, code0);

-- Volltext über Freitext/Annotations-Snippets
CREATE VIRTUAL TABLE fts_text USING fts5(
  resource_type, resource_id UNINDEXED, pseudonym UNINDEXED, snippet
);
```

**Audit append-only per Trigger**

```sql
CREATE TABLE audit_event (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL, user_id TEXT, action TEXT NOT NULL,
  object_type TEXT, object_id TEXT, detail TEXT, ip TEXT,
  success INTEGER NOT NULL DEFAULT 1, prev_hash BLOB, row_hash BLOB
);
CREATE TRIGGER audit_no_update BEFORE UPDATE ON audit_event
  BEGIN SELECT RAISE(ABORT,'audit append-only'); END;
CREATE TRIGGER audit_no_delete BEFORE DELETE ON audit_event
  BEGIN SELECT RAISE(ABORT,'audit append-only'); END;
```

Benutzerverwaltung (`sec_*`), ETL-Status (`etl_*`) und Vault (`vault_*`) werden 1:1 nach
diesem Muster übersetzt. Argon2id (Passwörter) und TOTP-MFA laufen rein in Python, kein
Admin nötig.

**Analytik:** DuckDB liest de-identifizierte Extrakte (View/Export aus `store.db`) für
schnelle Verläufe/Kohorten. Direkter DuckDB-Zugriff auf die SQLCipher-Datei ist nicht
möglich (Verschlüsselung); daher entweder Analytik über SQLite selbst (für eine Praxis
ausreichend) oder Export eines pseudonymisierten DuckDB-Files für schwere Auswertungen.

---

## 6. Zeitsteuerung ohne Admin

- Inkrementeller Load beim App-Start und/oder über einen **In-App-Scheduler** (APScheduler,
  läuft im Prozess).
- Optional automatischer Lauf via Windows Task Scheduler als **Nutzer-Task**
  (`schtasks /create /sc daily …` im Nutzerkontext) — kein Admin erforderlich.
- Kein Windows-Dienst (der bräuchte Admin).

---

## 7. openEHR / Server-Add-ons (optional, nur wo IT Infrastruktur stellt)

- **FHIR** ist im No-Admin-Setup vollständig abgedeckt (embedded).
- **openEHR-Compositions** können erzeugt und im lokalen Store abgelegt werden; ein
  **abfragbarer CDR (EHRbase, braucht Java+Postgres)** ist bewusst **nicht** Teil des
  No-Admin-Standards, sondern ein optionaler Server-Baustein.
- Ebenso **Blaze** (FHIR/CQL) und **OpenSearch** nur als optionale, IT-bereitgestellte
  Dienste. Der `target`-Schalter im `export_job` erlaubt es, dieselben Daten später dorthin
  zu spiegeln.

---

## 8. Auswirkungen auf die Roadmap

MVP bleibt wie in `CONCEPT.md §11`, mit diesen Ersetzungen:

1. Store = SQLCipher statt Postgres; Migrationsskripte in SQLite-DDL (Abschnitt 5).
2. Quellzugriff = `pytds` statt ODBC.
3. Auth/MFA/Audit = wie geplant, rein in Python.
4. ETL-Kern (rowversion-HWM für `Laborbogen`/`MedDok`/`VerordnungV2`) unverändert.
5. Analyse-UI = FastAPI+Uvicorn auf localhost, React-Static gebündelt.
6. Volltext/Annotation = FTS5 statt OpenSearch.
7. Packaging = signiertes One-File-Binary; Whitelisting-Freigabe früh mit IT klären.

---

## 9. Restrisiken (No-Admin-spezifisch)

- **Application Whitelisting** (AppLocker/WDAC): ohne Publisher-Freigabe evtl. Startblockade
  → Code-Signing + frühe IT-Abstimmung.
- **`pytds`-Reifegrad** vs. ODBC: Windows-Auth eingeschränkt → SQL-Auth-Konto einplanen.
- **Einzelarbeitsplatz per Default**: Mehrplatzzugriff auf eine Instanz braucht IT
  (Firewall/Host) → Server-Modus.
- **Backups ohne Admin**: verschlüsselte Backups ins Nutzerprofil oder auf freigegebenes
  Laufwerk; zentrale Backup-Strategie ggf. mit IT.
- **Performance großer Läufe** (`Laborbogen` 2,2 Mio.): SQLite skaliert für eine Praxis gut;
  Batching + WAL-Modus nutzen. Bei mehreren großen Praxen Server-Store erwägen.
