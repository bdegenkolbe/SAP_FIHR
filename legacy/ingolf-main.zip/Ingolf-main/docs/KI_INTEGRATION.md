# Konzept: KI-Integration in alle Sichten

**Ziel:** Jede Sicht der Plattform bekommt KI-Unterstützung — Arztbriefschreiben,
Transkription, OCR/Embeddings, Ontologie-Annotation, medizinische Fragen (RAG über
SOPs/AWMF-Leitlinien), Abfrage-Generierung im Analysetool, automatische Auswertungen.
**Die KI-Endpunkte werden von uns bereitgestellt** (on-premise oder eigene Cloud) —
die Plattform konsumiert sie über ein einziges, konfigurierbares Gateway.

Dieses Dokument ist die Bauanleitung für Claude Code (Stil wie `DOKUMENTE_ANNOTATION.md`):
Architektur → Fähigkeiten je Sicht → Datenschutz/Governance → Datenmodell →
Einstellungen → Umsetzungsstufen mit Definition of Done.

---

## 1. Grundsatzentscheidungen

1. **Ein Gateway, viele Fähigkeiten.** Alle KI-Aufrufe laufen über `server/ai/gateway.py`
   mit fünf Fähigkeits-Kanälen: `chat` (LLM, OpenAI-kompatibles `/v1/chat/completions`,
   inkl. Tool-/Function-Calling), `embed` (`/v1/embeddings`), `transcribe`
   (`/v1/audio/transcriptions`, Whisper-kompatibel), `ocr` (Vision-Chat oder dedizierter
   OCR-Endpunkt) und `code` (Code-Interpreter-Sandbox, §3.6). Je Kanal: Basis-URL,
   Modellname, API-Key (DPAPI-geschützt wie das DB-Passwort), Timeout. Damit sind
   vLLM/Ollama/llama.cpp on-prem genauso anschließbar wie ein eigener Cloud-Endpunkt —
   ohne Codeänderung.
2. **KI ist Assistenz, nie Autopilot.** Jede KI-Ausgabe ist ein *Entwurf* mit sichtbarer
   Kennzeichnung und Mensch-Bestätigung (Arzt validiert, dann erst Speichern). Keine
   autonome Diagnose/Therapieentscheidung → bewusst Dokumentations-/Rechercheassistenz
   (MDR-/AI-Act-Einstufung vor Produktivbetrieb prüfen, Ziel: kein Medizinprodukt).
3. **Datenschutz-Weiche gilt auch für KI.** Je Kanal ist konfiguriert, welche Datenklasse
   er empfangen darf (`clear` nur für als on-premise markierte Endpunkte, sonst maximal
   `pseudonym`). Das Assertion-Gate prüft ausgehende Prompts wie Exporte. Jeder Aufruf
   wird auditiert (wer, Zweck, Modell, Datenklasse, Prompt-Hash — nie der Klartext-Prompt
   im Audit).
4. **Provenance überall.** KI-erzeugte Inhalte tragen `…/ai-provenance` (Modell, Version,
   Prompt-Hash, Konfidenz, Prüfer) — analog zur bestehenden `nlp-provenance`. In der
   Analyse sind sie über den vorhandenen Provenienz-Schalter ein-/ausblendbar.
5. **Wiederverwenden statt neu bauen.** Die Annotations-Pipeline (`agent/annotate.py`)
   wurde bewusst mit austauschbarem Extraktor entworfen — der LLM-NER wird ein weiterer
   `TerminologyProvider`/Annotator, gleiche Ablage (Overlay + nlp_annotation), gleiche UI.

---

## 2. Architektur

```
                         Praxis (on-prem)                        von uns bereitgestellt
 ┌─────────────────────────────────────────────────────┐   ┌──────────────────────────┐
 │  UI (alle Sichten)                                   │   │  KI-Endpunkte             │
 │   └─ Assistenz-Panel (einheitl. Komponente, SSE)     │   │   chat  /v1/chat/…        │
 │  FastAPI                                             │   │   embed /v1/embeddings    │
 │   └─ /api/ai/* ── server/ai/gateway.py ──────────────┼──▶│   asr   /v1/audio/…       │
 │        │  Policy-Check (Datenklasse je Kanal)        │   │   ocr   vision-chat       │
 │        │  De-ID/Gate für ausgehende Prompts          │   │   code  Sandbox-Service   │
 │        │  Audit (Zweck, Modell, Prompt-Hash)         │   │    (1 Container/Session)  │
 │        │                                             │   └──────────────────────────┘
 │        ▼                                             │
 │  RAG-Index (Store): Leitlinien/SOPs + Embeddings     │
 │  FHIR-Store: Entwürfe mit ai-provenance              │
 └─────────────────────────────────────────────────────┘
```

- `server/ai/gateway.py` — HTTP-Client je Kanal, Retry/Timeout, Streaming (SSE an die UI),
  Mock-Provider für Tests (deterministische Antworten, keine Netzabhängigkeit).
- `server/ai/policy.py` — Datenklassen-Prüfung + Prompt-Gate + Audit vor jedem Aufruf.
- `server/ai/prompts.py` — versionierte Prompt-Vorlagen je Aufgabe (deutsch, mit
  Praxis-Kontextbausteinen); Version wandert in die Provenance.
- `server/ai/rag.py` — Ingest (PDF/HTML → Chunks → Embeddings), Hybrid-Retrieval
  (FTS5 + Vektor-Kosinus), Zitierpflicht (Antworten nur mit Quellenangaben).
- `server/ai/tasks.py` — die fachlichen Aufgaben (Brief, Zusammenfassung, Kohorte, …),
  jeweils: Kontext sammeln → Prompt bauen → Gateway → Ergebnis strukturieren.
- `server/ai/sandbox.py` — Code-Interpreter-Interface (§3.5): `RemoteSandbox`
  (Container-Service) / `LocalSandbox` (No-Admin-Fallback), Tool-Use-Schleife
  `execute_python`, Datei-Manifest, Artefakt-Einsammlung.

---

## 3. Fähigkeiten je Sicht

### 3.1 360°-Patientensicht
| Funktion | Ablauf | Ablage |
|---|---|---|
| **Arztbrief-Assistent** | Kontext = Timeline + aktive Diagnosen + Medikation + letzte Befunde → Entwurf (Anrede/Anamnese/Befunde/Epikrise/Procedere) → Editor mit Diff/Übernehmen | `Composition` mit `ai-provenance`, `status: preliminary` bis Arzt bestätigt (`final`) |
| **Patienten-Zusammenfassung** | „TL;DR" der Akte für den Praxisalltag (1 Absatz + Auffälligkeiten) | nur Anzeige, kein Speichern |
| **Transkription (Diktat/Ambient)** | Audio-Aufnahme im Browser → `transcribe`-Kanal → strukturierter Vorschlag (Anamnese/Befund/Prozedere getrennt) → Bestätigen | `Observation` (narrative Kategorie) mit `ai-provenance` |
| **Frage zur Akte** | Chat mit Patientenkontext (RAG über die Ressourcen DES Patienten) + Leitlinien-RAG; jede Antwort mit Quellen (Ressource/Leitlinien-Abschnitt) | nur Anzeige |

### 3.2 Dokumente (Dokument-Intelligence, Ausbau von `DOKUMENTE_ANNOTATION.md`)
- **KI-OCR:** `ocr`-Kanal als dritter Weg neben pypdf/Tesseract (Heuristik unverändert:
  erst nativer Text, dann Tesseract, dann Vision-Endpunkt für schwere Scans).
- **Embeddings:** jeder extrahierte Dokumenttext wird gechunkt (~500 Token, Overlap)
  und eingebettet → semantische Suche („ähnliche Befunde", „finde Dokumente über …")
  ergänzt die FTS5-Volltextsuche als Hybrid-Ranking.
- **LLM-Ontologie-Annotation:** LLM-NER (SNOMED/ICD/ATC/LOINC via Function-Calling,
  Validierung gegen `terminology.py`) ergänzt den Dictionary-Matcher; gleiche
  `Annotation`-Objekte, gleiche Negation/Kontext-Felder, `extractor: llm` in der
  Provenance. Konfidenz-Schwelle wie gehabt in den Einstellungen.

### 3.3 Analysetool
- **NL→Kohorte:** „alle Patientinnen über 60 mit Fettleber und HOMA > 3, ohne Metformin"
  → LLM erzeugt die vorhandene Kriterien-JSON (Function-Calling gegen das bestehende
  Schema `icd|atc|lab|age|gender|text|concept|period` + AND/OR). Die Kriterien werden
  als Tokens angezeigt (Nutzer sieht und korrigiert, bevor gerechnet wird) — die
  Berechnung bleibt der bestehende, deterministische SQL-Pfad inkl. Aggregatschutz.
- **NL→Auswertung:** „Erzeuge einen Qualitätsbericht Fettleber-Kohorte 2024" →
  Pipeline: Kohorte rechnen (deterministisch) → LLM verfasst den Berichtstext NUR aus
  den gelieferten Aggregaten (keine freien Zahlen; Zahlen werden nachvalidiert:
  jede Zahl im Text muss im Aggregat vorkommen) → Export als Markdown/PDF.
- **Erklär-Funktion:** Charts/KPIs auf Klick in Prosa erklären (nur Anzeige).

### 3.4 Wissensassistent (neue Sicht „Assistent")
- **RAG-Korpus:** Praxis-SOPs, hausinterne Standards, AWMF-Leitlinien (PDF-Import,
  versioniert wie Kataloge: Quelle, AWMF-Registernummer, Gültig-ab/-bis, Version).
  AWMF-PDFs werden manuell/skriptgestützt eingespielt (Lizenz-/Nutzungsbedingungen
  je Leitlinie beachten; keine automatische Massen-Spiegelung).
- **Antwortregeln:** immer mit Zitaten (Dokument + Abschnitt), „keine Quelle → keine
  Behauptung" (das Modell muss Nichtwissen erklären), Datum/Version der Leitlinie
  sichtbar, veraltete Leitlinien werden markiert.
- Optional mit Patientenbezug („gilt die Empfehlung für diesen Patienten?") — dann
  Patientenkontext + Leitlinien-RAG kombiniert, Rolle/Datenklasse vorausgesetzt.

### 3.5 Code Interpreter (Python-Sandbox pro Session, „wie in Claude")

Das LLM kann in Chat/Analyse-Kontexten Python-Skripte schreiben und **in einer
isolierten Sandbox pro Session** ausführen lassen (Tool-Use-Schleife über den
`chat`-Kanal: `execute_python` → Ergebnis/Fehler zurück ans Modell → Iteration).
Damit werden freie Auswertungen möglich, die das Kriterien-Schema übersteigen:
Überlebenszeit-Kurven, Regressionen, individuelle Diagramme, Excel-Exporte.

**Sitzungsmodell (wie in Claude):**
- Eine Sandbox je UI-Session, lazy erzeugt, mit **Arbeitsverzeichnis** (Dateien
  hochladen/erzeugen/herunterladen), **Zustand über Zellen hinweg** (Variablen bleiben),
  Idle-Timeout (Standard 15 min) und hartem Ressourcenlimit (CPU-Zeit je Zelle,
  RAM, Prozesszahl, Plattenquota). **Kein Netzwerkzugriff** aus der Sandbox.
- Vorinstalliert: pandas, numpy, matplotlib, openpyxl, scipy (Whitelist, versioniert).
- Artefakte (PNG/CSV/XLSX/HTML) werden eingesammelt, im Store abgelegt
  (`ai_artifact`) und in der UI inline gerendert — mit `ai-provenance` (Skript-Hash,
  Sandbox-Profil, Eingabedaten-Referenz), Skript einsehbar („Code anzeigen").

**Datenfluss (an die Weiche gekoppelt):** Die Sandbox bekommt NIE Direktzugriff auf
Store oder Quelle. Der Server stellt die Eingabedaten explizit bereit — als Dateien
im Arbeitsverzeichnis: Kohorten-Aggregate (JSON/CSV), pseudonymisierte Ressourcen-
Frames (flache CSV je Ressourcentyp) oder vom Nutzer hochgeladene Dateien. Was
hineingeht, entscheidet die Datenklassen-Policy des `code`-Kanals; der Transfer
läuft durchs Prompt-/Daten-Gate und wird auditiert (Datei-Manifest mit Hashes).
Ergebnisse, die in die Akte übernommen werden sollen, gehen den normalen
Entwurf-/Review-Weg (§4.5).

**Zwei Isolationsprofile** (Realität des No-Admin-Betriebs, `docs/DEPLOYMENT.md`):

| Profil | Isolation | Wo | Einsatz |
|---|---|---|---|
| **B — Container (Referenz)** | 1 Container pro Session (rootless Podman/Docker, `--network none`, read-only Image, tmpfs-Workdir, CPU/RAM-Limits, gern gVisor/Kata) hinter einer kleinen **Sandbox-Service-API** (`POST /sessions`, `POST /sessions/{id}/exec`, `GET/PUT /files`, `DELETE /sessions/{id}`) | auf dem von uns bereitgestellten Host (derselbe, der die KI-Endpunkte trägt) — im Praxisnetz oder als externer Endpunkt (dann Datenklasse max. `pseudonym`) | Standard, „alles wie in Claude" |
| **A — No-Admin-Fallback** | Subprozess je Session mit eigenem venv (embeddable Python), frischem Temp-Workdir, Windows-**Job-Object** (RAM-/CPU-/Prozesslimit, ohne Adminrechte), Import-Whitelist, kein Proxy/ENV → faktisch netzlos, harter Kill bei Timeout | direkt auf dem Praxis-PC | Einzelplatz ohne Server; schwächere Isolation ⇒ nur Datenklasse `pseudonym`/Aggregate, Funktionsumfang identisch |

Die Sandbox-Service-API ist bewusst trivial gehalten, damit Profil A und B hinter
demselben Interface liegen (`server/ai/sandbox.py`: `LocalSandbox` / `RemoteSandbox`).

**Entscheidung 07/2026: Profil B ist gesetzt und gebaut.** Der Service liegt unter
`sandbox-service/` (FastAPI + DockerRunner, Deployment per docker-compose auf dem
KI-Host, README dort); der Plattform-Client ist `server/ai/sandbox.RemoteSandbox`.
Tests (`tests/test_sandbox.py`) laufen über den protokollgleichen Subprozess-Runner
ohne Container; die Container-Eigenschaften (kein Netz, Limits) werden bei der
Abnahme auf dem KI-Host verifiziert.

**Einsatzorte:** Analysetool („Auswertung erzeugen" → LLM+Interpreter auf
Kohorten-Daten), Wissensassistent (Rechenfragen), Verwaltung (Ad-hoc-Reports).
In der 360°-Sicht nur auf explizit bereitgestellte Einzelakten-Frames.

### 3.6 Verwaltung & PVS-Sicht
- **Verwaltung:** KI-Nutzungsprotokoll (aus dem Audit), Endpunkt-Status/Latenz je Kanal
  („Verbindung testen" wie bei der Quell-DB), Token-/Kostenzähler je Monat.
- **PVS-Sicht (später, nach Kernel-M1):** Kodiervorschläge (EBM/GOÄ aus der
  Falldokumentation, Vorschlag → Arzt bestätigt), AU-/Überweisungstext-Vorschläge.

---

## 4. Datenschutz & Governance (verbindlich)

1. **Datenklassen je Kanal:** `ai_<kanal>_data_policy` = `clear | pseudonym | none`.
   `clear` ist nur wählbar, wenn der Endpunkt als on-premise deklariert ist
   (`ai_<kanal>_onprem = true`); sonst erzwingt das Gateway Pseudonymisierung des
   Kontexts (bestehende `privacy.text`/Pseudonym-Pipeline) oder verweigert.
2. **Prompt-Gate:** ausgehende Prompts laufen durch `gate.check` (gleiche Muster +
   Patientenidentifikatoren); Policy `enforce|warn|off` folgt der bestehenden
   Gate-Einstellung. Antworten, die in die Akte übernommen werden, laufen ebenfalls
   durchs Gate (Halluzinations-Schutz gegen erfundene Kontaktdaten/IDs).
3. **RBAC:** neue Rechte `ai.use` (Assistenz nutzen), `ai.draft.write` (Entwürfe in die
   Akte übernehmen — nur clinician/owner), `ai.admin` (Endpunkte/Modelle konfigurieren).
   Researcher/Analyst: nur Analyse-Funktionen (3.3) auf Pseudonymdaten.
4. **Audit:** jede KI-Interaktion append-only: Nutzer, Zweck (`task`), Kanal, Modell,
   Datenklasse, Prompt-/Antwort-Hash, Token, Dauer, übernommen ja/nein. Klartext-Prompts
   werden NICHT im Audit gespeichert (PHI); optional 24h-Debug-Puffer, verschlüsselt.
5. **Kennzeichnung:** UI zeigt KI-Inhalte immer mit Badge („KI-Entwurf — nicht geprüft" →
   nach Bestätigung „KI-unterstützt, geprüft von <Arzt> am <Datum>"). Der Prüfstatus
   steht in der `ai-provenance` (`reviewedBy`, `reviewedAt`).
6. **Verlässlichkeit:** Zitierpflicht im RAG; Zahlen-Nachvalidierung bei Auswertungen;
   Temperatur niedrig, deterministische Seeds wo verfügbar; Prompt-Versionen im Repo.

---

## 5. Datenmodell (Store-Erweiterung, Präfix ai_/rag_)

```sql
-- Wissenskorpus (Leitlinien/SOPs), versioniert wie ref_resource
CREATE TABLE rag_document (
  id TEXT PRIMARY KEY, title TEXT NOT NULL, source TEXT,     -- awmf | sop | praxis
  register_nr TEXT, version TEXT, valid_from TEXT, valid_to TEXT,
  file_sha256 TEXT, imported_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE rag_chunk (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  document_id TEXT REFERENCES rag_document(id) ON DELETE CASCADE,
  seq INTEGER, section TEXT, body TEXT NOT NULL,
  embedding BLOB                    -- float32[], Kosinus in SQL/NumPy; sqlite-vec optional
);
-- FTS5-Spiegel rag_fts(body, …) für Hybrid-Retrieval

-- Embeddings für Patientendokumente (semantische Suche)
CREATE TABLE ai_embedding (
  resource_type TEXT, resource_id TEXT, chunk_seq INTEGER,
  pseudonym TEXT, body TEXT, embedding BLOB,
  PRIMARY KEY (resource_type, resource_id, chunk_seq)
);

-- KI-Nutzungsprotokoll (ergänzend zum audit_event)
CREATE TABLE ai_call (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT DEFAULT (datetime('now')),
  user_id TEXT, task TEXT, channel TEXT, model TEXT, data_class TEXT,
  prompt_hash TEXT, response_hash TEXT, tokens_in INTEGER, tokens_out INTEGER,
  duration_ms INTEGER, accepted INTEGER
);

-- Code-Interpreter: Sessions + Artefakte (§3.5)
CREATE TABLE ai_sandbox_session (
  id TEXT PRIMARY KEY, user_id TEXT, profile TEXT,        -- container | local
  data_class TEXT, created_at TEXT DEFAULT (datetime('now')),
  last_used_at TEXT, closed_at TEXT,
  input_manifest TEXT                                     -- JSON: Dateien + SHA256
);
CREATE TABLE ai_artifact (
  id TEXT PRIMARY KEY, session_id TEXT REFERENCES ai_sandbox_session(id),
  user_id TEXT, name TEXT, content_type TEXT, size INTEGER,
  sha256 TEXT, script_hash TEXT, created_at TEXT DEFAULT (datetime('now')),
  content BLOB                                            -- PNG/CSV/XLSX/HTML
);
```

FHIR-seitig: Entwürfe als reguläre Ressourcen mit Extension
`urn:greenbay:clinical/ai-provenance` = `{model, promptVersion, promptHash,
confidence?, reviewedBy?, reviewedAt?}`; Status-Workflow `preliminary → final`.

---

## 6. Einstellungen (alles über die UI, wie gehabt)

Neue Karte **„KI-Endpunkte"** (Recht `ai.admin`), je Kanal chat/embed/transcribe/ocr/code:
`ai_<kanal>_url`, `ai_<kanal>_model`, `ai_<kanal>_onprem` (bool),
`ai_<kanal>_data_policy` (clear/pseudonym/none), API-Key über den DPAPI-Mechanismus
(`secret/ai_<kanal>.bin`, nie im Klartext zurück), „Verbindung testen"-Knopf je Kanal
(Roundtrip mit Mini-Prompt/1-Token-Embedding, zeigt Modell + Latenz).
Karte **„KI-Verhalten"**: Funktionen einzeln an/aus (Brief, Transkription, NL-Analyse,
Wissensassistent, LLM-Annotation, Code Interpreter), max. Kontextgröße, Temperatur,
RAG-Trefferzahl. Code-Interpreter-Block: Profil (`container`-Service-URL oder
`local`-Fallback), Limits (CPU-Sekunden/Zelle, RAM, Plattenquota, Idle-Timeout),
Paket-Whitelist.
Write-Through in `config.yaml` (`ai:`-Block) wie bei privacy/annotation, damit auch
Agent-Läufe (LLM-Annotation im Nachtlauf) dieselben Endpunkte nutzen.

---

## 7. Umsetzungsstufen (jede Stufe einzeln abnehmbar)

**Stufe 0 — Fundament** *(Voraussetzung für alles)*
Gateway + Policy + Audit + Einstellungen-Karte + Mock-Provider + „Verbindung testen".
DoD: Contract-Tests gegen Mock (alle 4 Kanäle), Policy blockt `clear` an nicht-on-prem,
Audit-Einträge mit Hashes, UI-Karte speichert/testet Endpunkte.

**Stufe 1 — Schreiben & Wissen** *(größter Praxisnutzen zuerst)*
Arztbrief-Assistent + Patienten-Zusammenfassung + Wissensassistent (RAG über
eingespielte SOPs/AWMF-PDFs, Ingest-Werkzeug + Kataloge-Sicht zeigt Korpus-Stand).
DoD: Brief-Entwurf aus Golden-Record 3659 fachlich plausibel (Arzt-Review), jede
RAG-Antwort zitiert, Entwurf-Workflow preliminary→final mit Badge, Gate-Test für Prompts.

**Stufe 2 — Hören & Sehen**
Transkription (Browser-Audio → strukturierter Eintrag) + KI-OCR als dritter
Extraktionsweg + Embeddings/semantische Suche über Dokumente.
DoD: Diktat-Roundtrip < 10 s für 1 min Audio (on-prem Whisper), OCR-Fallback greift
nur bei Scan-Heuristik, semantische Suche findet Paraphrasen (Testkorpus).

**Stufe 3 — Analysieren & Rechnen (inkl. Code Interpreter)**
NL→Kohorte (Function-Calling auf das Kriterien-Schema) + NL→Auswertung mit
Zahlen-Nachvalidierung + Erklär-Funktion + **Code Interpreter** (Sandbox-Interface
`LocalSandbox`/`RemoteSandbox`, Tool-Use-Schleife, Artefakt-Ablage, UI-Zellen im
Analysetool/Assistenten).
DoD: 20 Beispiel-Fragen → korrekte Kriterien-JSON (Testsuite); Bericht enthält keine
Zahl außerhalb der Aggregate; Aggregatschutz bleibt wirksam (n<5 nie im Text);
Sandbox: kein Netz (Verbindungsversuch schlägt in beiden Profilen fehl, Test),
Limits greifen (Endlosschleife wird nach CPU-Limit gekillt), Zustand bleibt über
Zellen erhalten, Artefakt-Roundtrip (Plot → Store → UI) mit Provenance.

**Stufe 4 — Annotieren & Kodieren**
LLM-Ontologie-Annotation (parallel zum Dictionary, A/B-vergleichbar über Provenance)
+ PVS-Kodiervorschläge (nach Kernel-M1).
DoD: LLM-Annotationen validieren gegen `terminology.py`, Overlay/Analyse unverändert
nutzbar, Vergleichsreport Dictionary vs. LLM je Testkorpus.

---

## 8. Risiken / offene Punkte

- **Halluzination** → Zitierpflicht, Zahlen-Nachvalidierung, Mensch-Bestätigung; Briefe
  nie ohne Review speicherbar.
- **Modellqualität on-prem** (deutsche Medizinsprache) → Kanäle getrennt konfigurierbar,
  damit z. B. Transkription lokal, Brief-LLM auf stärkerem Endpunkt laufen kann.
- **Latenz/Kosten** → Streaming in der UI, Token-Budget je Aufgabe, Nutzungsprotokoll.
- **Regulatorik** (MDR/AI-Act): Assistenz-Framing dokumentieren, Einstufung juristisch
  prüfen, bevor Funktionen über Dokumentation/Recherche hinausgehen.
- **AWMF-Inhalte**: Nutzungsrechte je Leitlinie prüfen (Einspielen ja, Weitergabe nein);
  Versionspflege wie Katalog-Lebenszyklus (CONCEPT.md 13.4).
- **Prompt-Injection über Dokumente** (RAG liest fremde Briefe/PDFs): Retrieval-Inhalte
  werden als Daten, nie als Instruktionen behandelt (Prompt-Härtung + Tests).
- **Sandbox-Ausbruch/Ressourcenmissbrauch (Code Interpreter):** Profil B ist die
  Referenz (Container, kein Netz, read-only Image); Profil A (No-Admin-Subprozess)
  ist bewusst schwächer isoliert → dort nur Pseudonym-/Aggregatdaten, Import-Whitelist,
  Job-Object-Limits, und das LLM-generierte Skript ist immer einsehbar. Die Sandbox
  hat nie Credentials oder Store-Zugriff — sie sieht nur die explizit hineingegebenen
  Dateien.
