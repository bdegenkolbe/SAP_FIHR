# 30 — Migration EUGASTRO → Kernel (M0–M4)

## Prinzip

Die Migration ist der vorhandene Collector (`agent/`) mit neuem Ziel: statt
FHIR-Bundle-Dateien schreibt sie **Events in den Kernel-Store**. Extraktion,
Blob-Parser und FHIR-Mapper werden importiert, nicht kopiert.

```
agent.dbsource.Source ─┐
agent.meddok.parse_detail ─┼→ pvs.etl.transform_events → pvs.store.append_event
agent.mappers (FHIR)  ─┘         │
                                  └→ pvs.etl.build_fall (Schein → Fall)
```

## Stufen

| Stufe | Inhalt | Gate |
|---|---|---|
| M0 | Privacy `off` für on-prem-Kernel (Config-Flag `privacy.mode: off`, nur wenn `target.zone: praxis`). Export-Pfade unverändert durch Privacy+Assertion. | Code-Review Gate-Logik |
| M1 | Golden Records 3659 + 76824 vollständig, `validate-golden` grün | 100 % Checkliste unten |
| M2 | Full-Load alle Patienten + Delta (RowVersion-HWM, `MIN_ACTIVE_ROWVERSION`), Reconcile-Lauf wöchentlich (Deletes) | Zähler-Abgleich Quelle↔Kernel je Tabelle, Abweichung erklärt |
| M3 | Führungswechsel Doku; Rückspiel Abrechnungsdaten nach medatixx (GDT/BDT oder manuell) | 2 Wochen fehlerfreier Parallelbetrieb |
| M4 | Rückspiel entfällt je Abrechnungspfad (GOÄ → Stufe 3, KVDT → Stufe 5 Zielbild) | — |

## Idempotenz & Delta

- `(source='migration:eugastro', source_ref='<Tabelle>:<PK>[:<RowVersion>]')`
- RowVersion-Änderung ⇒ neues Event mit `supersedes` auf Vorgänger-Event
  (Lookup über `source_ref`-Präfix `<Tabelle>:<PK>`).
- Tabellen ohne RowVersion (TodoItem, Medikationsplan mit PK=Id_Patient):
  Full-Reconcile je Lauf, Vergleich über Inhalts-Hash.
- PATID-Plausibilitätscheck (bekannte Datenanomalie, CONCEPT §1.5): bei Labor-
  Import PatientNr im JSON gegen erwartete Patienten-ID prüfen; Mismatch ⇒
  Event in Quarantäne-Tabelle, kein Kernel-Write.

## Golden-Record-Checkliste #76824 (Soll aus medatixx, Stand 14.07.2026)

Fixiert in `pvs/etl/validate_golden.py`. Quelle: sieben medatixx-Screens.

**Stammdaten/Kontext**
- Patient *24.07.1976, männlich, Privat (Barmenia), Hausarzt Dr. med. Sowa Leipzig
- CAVE-Flag vorhanden, Text beginnt „Bitte vom Labor“
- Fall: Privatschein 24.05.2026, Behandler IS, MVZ eugastro

**Diagnosen (L&D)**
- I10.9- G „Essentielle Hypertonie, nicht näher bezeichnet“ (24.05.2026)
- K76.0 G „Steatosis hepatis a.n.k. neu: MASLD“ (24.05.2026)
- Anzahl Diagnosen im Schein-Kontext: 2

**Vitalparameter (3 Zeitpunkte)**
- 14.07.2026 17:14 — Größe 184, Gewicht 91, BMI 26,9
- 18.05.2022 07:47 — Gewicht 95, BMI 28,1, RR 144/101, Puls 73
- 14.08.2020 07:39 — Gewicht 91, BMI 26,9, RR 136/91, Puls 77

**Medikation (Verordnungsübersicht + Medikationsplan)**
- DM: MOUNJARO 7.5MG KWIKPEN (Tirzepatid 7,5 mg/Dosis, Injekt, 1× Woche), 24.05.2026
- DM: CANDESARTAN 1A 8MG TAB N3 100 St, 1-0-0, reicht bis 01.09.2026
- LM: Mounjaro 5 mg/0,5 Fertigpen 4 Stck., „nach plan“, 05.02.2026
- LM: FLUTICASON CIPLA 250UG 120 DOS N2, 1-0-1, 29.03.2022
- Medikationsplan: genau 2 Dauermedikations-Items, 0 Bedarfsmedikation

**Labor (Kumulativ, Spalte 18.12.2025)**
- LYMP% 33, NEUT% 55, MONO% 8,3, EOS% 1,70, BASO% 0,90
- QUICK 101, INR 1,00, PTT 31
- BZG 5,9 (Indikator +), CHOL 5,47 (+), LDL 3,71, HDL 1,23
- Grenzwertindikatoren aus `Grenzwertindikator`/JSON übernehmen, nicht neu berechnen

**Timeline (Dokumentation, Auszug obere Einträge)**
- 14.07.2026 N „g+c im Herbst planen“; VP-Eintrag 17:14
- 24.05.2026 D I10.9-, RP Mounjaro 7.5, RP Candesartan, D K76.0, PS Privatschein
- 27.02.2026 2× MDOK Kostenzusage; 26.02. N „Rezept an Pat. geschickt“;
  05.02. N + RP Mounjaro 5 mg

Validator prüft Existenz, Werte, Datumszuordnung und Event-Reihenfolge; Toleranz
nur bei Formatierung (Dezimalkomma, Whitespace), nie beim Wert.

## Definition of Done

- [ ] `migrate --patient 76824` schreibt alle Domänen als Events, idempotent (2. Lauf: 0 neue Events)
- [ ] `validate-golden` 100 % für 3659 und 76824
- [ ] Full-Load-Mengengerüst dokumentiert (Zeilen je Tabelle Quelle vs. Events)
- [ ] Delta-Lauf nach gezielter Quelländerung erzeugt genau 1 supersedes-Event
- [ ] Quarantäne-Pfad (PATID-Mismatch) getestet
