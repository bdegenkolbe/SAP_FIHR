# 60 — TI-Adapter (Stufe 4 des Zielbilds)

Kein Eigenbau von Konnektor-Logik: Anbindung über **TIaaS/TI-Gateway** eines
Partners (RISE, Arvato, secunet — Auswahlkriterien: HSM-basierte SMC-B/HBA-
Verwaltung, REST-Fassade, Mandantenfähigkeit, Preis je Arbeitsplatz).

| Fachanwendung | Schnittstelle | Kernel-Ankopplung | Verfahren |
|---|---|---|---|
| VSDM (eGK-Stammdaten) | Gateway-REST | Check-in-Schritt: Coverage-Update + FK 4109 | Bestandteil PVS-Betrieb |
| eAU | KIM + KBV_PR_EAU (FHIR) | `au.ausgestellt`-Event ⇒ eAU-Bundle ⇒ KIM-Versand; Status zurück in Task (Quelle heute: `dbo.Eau.State`) | gematik-Bestätigung |
| eRezept | Fachdienst, KBV_PR_ERP (FHIR) | `medikation.verordnet` ⇒ ERP-Bundle, Signatur via HBA (Komfortsignatur) | gematik-Bestätigung |
| ePA | MHD/FHIR-Dokumenten-API | `brief.erstellt`/Befunde ⇒ Upload; EpaEventLog-Migration liefert Historie | gematik-Bestätigung |
| KIM (eArztbrief u. a.) | KIM-Clientmodul via Gateway | Communication-Events | — |

Reihenfolge: VSDM → eAU → eRezept → ePA (aufsteigender Signatur-/Workflow-Aufwand).
Alle Payloads sind FHIR — Mapper sind Projektionen aus dem Kernel, keine neuen
Datenmodelle. Vorarbeit jetzt schon möglich: KBV-Profile (eAU, ERP) als
Validierungs-Fixtures in Tests aufnehmen.

## Definition of Done (Spec-Ebene, vor Implementierung)

- [ ] TIaaS-Partner ausgewählt, Sandbox-Zugang vorhanden
- [ ] eAU-Bundle aus Kernel-Event gegen KBV-Profil validiert (offline)
- [ ] Signatur-Konzept (HBA/SMC-B, Komfortsignatur) dokumentiert
