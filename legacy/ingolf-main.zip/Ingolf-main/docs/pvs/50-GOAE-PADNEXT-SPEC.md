# 50 — GOÄ-Abrechnung + PADneXt-Export (Privatpfad)

## Zweck

Erster **nativer** Abrechnungspfad des PVS — zulassungsfrei. Deckt Privat- und
IGeL-Fälle ab (Golden Record #76824 ist genau dieser Fall: Privat-Barmenia,
Rechnung 15.04.2026 in der Timeline, `dbo.Rechnung` mit IsIgel-Flag vorhanden).

## Modell

```
GoaePosition
  ziffer          GOÄ-Nr. (inkl. Analogziffern "A…")
  text            Leistungstext
  datum
  faktor          Decimal (Regelsätze 1.0/1.8/2.3/… je Leistungsart; Schwellen-
                  überschreitung ⇒ begruendung pflicht)
  begruendung     optional, Pflicht bei Faktor > Schwellwert
  betrag_einfach  aus GOÄ-Punktzahl × Punktwert (Punktwert als Konstante mit
                  Versionsdatum in config/goae.yaml)   # VERIFY aktueller Punktwert
  anzahl

GoaeRechnung
  fall_id, patient (Klardaten — on-prem), rechnungsnr (Nummernkreis je
  Betriebsstätte, Präfix wie Quelle `RechnungsnummerPraefix`), datum,
  positionen[], zwischensumme, auslagen[], gesamt, status
  (ENTWURF|GESTELLT|BEZAHLT|STORNIERT — Storno erzeugt supersedes-Event)
```

Regelprüfung Minimum: Ausschlüsse/Neben­einander­berechnung als deklarative
Regeln in `config/goae-regeln.yaml` (analog KVDT-Registry-Prinzip), nicht
hartkodiert.

## Ausgaben

1. **PDF-Rechnung** — Layout GREENBAY-CI (ui/design/tokens.css), Pflichtangaben
   §12 GOÄ (Ziffer, Text, Faktor, Begründung, Betrag, Diagnosebezug optional).
2. **PADneXt** — XML nach PAD-Standard (padx-Paket: `auftrag.pad` +
   Rechnungsdatei(en), ZIP-Container). Für Factoring/PVS-Verrechnungsstellen.
   `# VERIFY: PADneXt-Version + XSD von PADline beziehen, Schema-Validierung
   in Test aufnehmen.` Skeleton in `pvs/goae/padnext.py`.

## Migration

Bestandsrechnungen aus `dbo.Rechnung` (Q_RECHNUNG verifiziert) werden als
`rechnung.gestellt`-Events importiert — Nummernkreis-Fortführung ab
MAX(Rechnungsnummer) je Präfix.

## Definition of Done

- [ ] GOÄ-Rechnung für einen synthetischen Privatfall: PDF + padx erzeugt
- [ ] padx validiert gegen offizielle XSD
- [ ] Nummernkreis-Fortführung aus Migration getestet
- [ ] Faktor-Schwellen-Logik mit Begründungspflicht getestet
