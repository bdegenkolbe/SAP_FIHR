# 70 — PVS-Sicht (Modul neben Patientensicht & Analysetool)

## Einordnung

Die Plattform hat drei Lese-Module (Patientenauswahl, 360°-Patientensicht,
Versorgungsanalyse). Die **PVS-Sicht** ist das vierte Modul und der erste
**Schreibpfad**: Karteikarte mit Befehlszeilen-Erfassung, Fall/Schein-Panel und
GOÄ-Leistungserfassung. Sie schreibt Events in den Kernel
(docs/pvs/10-KERNEL-SPEC.md) — im Mockup simuliert ein In-Memory-Event-Log
exakt dieses Verhalten (append-only, source `ui`).

Auslieferung als **eine selbständige HTML-Datei**
(`ui/mockups/pvssicht.html`, Tokens inline wie bei den Bestandsmockups) —
keine Änderung an index/patientensicht/analysetool nötig, da der Plattform-
Stand in der Praxis weiterentwickelt ist. Integration = ein Nav-Link.

## Layout (3 Zonen)

```
┌──────────────────────────────────────────────────────────────┐
│ Topbar: Logo · Modulnav (…· PVS-Sicht) · Benutzer            │
├──────────────────────────────────────────────────────────────┤
│ Patientenkopf: Name · geb. · # · CAVE-Band · Fall-Chip       │
├───────────────────────────────┬──────────────────────────────┤
│ KARTEIKARTE (Timeline)        │ SEITENPANEL                  │
│  Befehlszeile (Kürzel-Logik)  │  Fall/Schein (Q, Art, Status)│
│  Einträge chronologisch,      │  Leistungen GOÄ (live Summe) │
│  Typ-Chips wie medatixx:      │  Medikationsplan (DM/BM)     │
│  N D RP VP L BEF B            │  Diagnosen (Fallkontext)     │
├───────────────────────────────┴──────────────────────────────┤
│ Statusleiste: Kernel-Events · Fallstatus · GOÄ-Summe         │
└──────────────────────────────────────────────────────────────┘
```

## Befehlszeile (Kürzel-Erfassung, medatixx-kompatible Mechanik)

| Kürzel | Wirkung | Kernel-Event |
|---|---|---|
| `n <Text>` | Notiz | notiz.erfasst |
| `d <ICD> <G/V/Z/A> <Text>` | Diagnose (Fallkontext) | diagnose.dokumentiert |
| `rp <Präparat> <Dosierung>` | Verordnung → Medikationsplan | medikation.verordnet |
| `vp <Größe> <Gewicht> [RRsys/RRdia] [Puls]` | Vitalwerte (BMI berechnet) | vitalwert.erfasst |
| `l <GOÄ-Ziffer> [Faktor]` | Leistung → Fall-Panel, Summe | leistung.erfasst |
| `b <Text>` | Befund | befund.dokumentiert |

Jede Erfassung erzeugt sichtbar ein Event (Zähler in der Statusleiste) und
einen Timeline-Eintrag — dieselbe Semantik wie `KernelStore.append_event`.

## Verbindliche Regeln

- Nur synthetische Daten im Mockup.
- Design-Tokens unverändert aus tokens.css (inline eingebettet).
- Typ-Chips farblich an medatixx-Konvention angelehnt (N blau, D orange,
  RP rot, VP grau, L grün) — Wiedererkennung für das Praxisteam.
- Keine externen Abhängigkeiten außer dem Font-Import.

## Definition of Done

- [ ] Datei öffnet standalone, alle Kürzel funktionieren, GOÄ-Summe live
- [ ] Nav-Link in bestehendem index einhängbar (dokumentiert in INTEGRATION.md)
- [ ] Nächste Ausbaustufe: Befehlszeile gegen echten Kernel (FastAPI-Endpoint
      `POST /events`) statt In-Memory — API-Form identisch zu Event.row()
