# PVS-Bauplan — Arbeitsanweisung für Claude Code

**Kontext:** Erweiterung der Klinik-Datenplattform zum FHIR/openEHR-nativen PVS
(siehe `PVS-ZIELBILD.md`). Dieses Verzeichnis (`docs/pvs/`) enthält die Specs,
`pvs/` die Implementierung. Die Migrations-Engine baut auf `agent/` auf
(dbsource, privacy, meddok, mappers) — **nichts davon duplizieren**, importieren.

## Modulübersicht und Reihenfolge

| # | Modul | Spec | Code | Status |
|---|---|---|---|---|
| 1 | Klinischer Kernel (Ereignisstrom + FHIR-Store) | `10-KERNEL-SPEC.md` | `pvs/model/events.py`, `pvs/store/` | Skeleton lauffähig |
| 2 | Fall/Schein-Aggregat + KVDT-Feldmapping | `20-FALL-SCHEIN-SPEC.md` | `pvs/model/fall.py`, `pvs/etl/build_fall.py` | Skeleton lauffähig |
| 3 | Migration EUGASTRO → Kernel (M0–M2) | `30-MIGRATION-SPEC.md` | `pvs/etl/migrate.py`, `transform_events.py`, `validate_golden.py` | Skeleton lauffähig |
| 4 | KVDT/ADT-Serializer + XPM | `40-KVDT-SERIALIZER-SPEC.md` | `pvs/kvdt/` | Encoder fertig, Satzdefinitionen zu verifizieren |
| 5 | GOÄ + PADneXt (Privatabrechnung) | `50-GOAE-PADNEXT-SPEC.md` | `pvs/goae/` | Skeleton |
| 6 | TI-Adapter (VSDM, eAU, eRezept, ePA) | `60-TI-ADAPTER-SPEC.md` | — | Spec only |

## Arbeitsregeln

1. **Spec zuerst lesen**, dann Code. Jede Spec hat einen Abschnitt
   „Definition of Done" — der ist verbindlich.
2. **Verifizierte SQL** nur aus `agent/export.py` übernehmen (dort gegen die
   reale DB geprüft). Neue Queries erst nach Schema-Check (`docs/SCHEMA.md`,
   Fallstricke in `docs/CONCEPT.md` §1.5).
3. **Kein Klardaten-Leak:** Der Kernel läuft on-prem, Privacy-Modus `off` ist
   dort zulässig (M0). Jeder Export-Pfad nach außen läuft weiter durch
   `agent/privacy.py` + Assertion-Gate.
4. **Offene Verifikationspunkte** sind im Code mit `# VERIFY:` markiert —
   insbesondere KVDT-Feldkennungen gegen die aktuelle KBV-Satzbeschreibung
   (Zugang via KBV-ITA-Registrierung) und PADneXt-XSD. Nicht raten, prüfen.
5. Tests ohne DB: `python -m pytest tests/ -q`. Migrationsläufe nur mit
   `config/pvs.yaml` gegen die Quell-DB (read-only Login).

## CLI

```bash
python -m pvs.cli init-store   --db ./out/pvs.db                      # Kernel-DB anlegen
python -m pvs.cli migrate      --config config/pvs.yaml --patient 76824
python -m pvs.cli migrate      --config config/pvs.yaml --mode full
python -m pvs.cli migrate      --config config/pvs.yaml --mode incremental
python -m pvs.cli validate-golden --db ./out/pvs.db --patient 76824
python -m pvs.cli kvdt-dry-run --db ./out/pvs.db --quartal 2/2026     # ADT-Datei ohne Zulassung, für XPM-Test
python -m pvs.cli goae-invoice --db ./out/pvs.db --fall <id>          # GOÄ-Rechnung + PADneXt
```

## Golden Records

- Patient **3659** (verifizierter Referenzfall der Plattform)
- Patient **#76824** (Degenkolbe — Sollwerte aus medatixx-Screens vom 14.07.2026,
  fixiert in `pvs/etl/validate_golden.py`)

Abnahme M1 = beide Golden Records bestehen `validate-golden` zu 100 %.
