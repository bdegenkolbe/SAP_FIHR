# 40 — KVDT/ADT-Serializer + XPM-Teststrecke

## Zweck

Projektion Fall-Aggregate → ADT-Quartalsdatei (KVDT). Ziel der ersten Ausbaustufe
ist **nicht** die Einreichung, sondern die grüne Prüfung im **KBV-Prüfmodul (XPM)**
— der objektive Nachweis, dass der Kernel abrechnungsfähig ist, lange vor der
Zulassung.

## xDT-Grundsyntax (implementiert in `pvs/kvdt/encoder.py`)

Jede Zeile: `LLL` (3-stellige Gesamtlänge inkl. CR/LF) + `FFFF` (Feldkennung) +
Inhalt + CR/LF. Länge = 3 + 4 + len(inhalt) + 2. Zeichensatz gemäß
Satzbeschreibung (ISO 8859-15 üblich). `# VERIFY: Zeichensatz + Feldlängenregeln
der aktuellen KVDT-Version.`

Sätze beginnen mit FK 8000 (Satzart) und enden implizit mit dem nächsten
8000/Dateiende; Paket-/Container-Sätze (con0/adt0/adt9/con9) tragen Zähl- und
Prüfsummenfelder. `# VERIFY: Pflichtfelder der Rahmen-Sätze.`

## Architektur

```
Fall-Aggregate (Kernel) → kvdt/satzarten.py (deklaratives Satz-Registry)
                        → kvdt/serializer.py (Registry-getrieben, keine Hardcodes)
                        → out/adt/<BSNR>_<QJJJJ>.con
                        → XPM (extern, KBV) → Fehlerprotokoll → Regelwerk-Backlog
```

`satzarten.py` ist ein **deklaratives Registry** (Feldreihenfolge, Pflicht/Kann,
Wiederholungen, Bedingungen). Claude Code füllt es aus der offiziellen
Satzbeschreibung (KBV-ITA-Zugang); der Serializer bleibt unverändert.

## Teststrecke

1. `kvdt-dry-run` erzeugt Datei aus Kernel-Daten (nur GKV-Fälle; #76824 ist
   PRIVAT ⇒ leerer Lauf ist korrekt — Testdaten: synthetische GKV-Fälle in
   `tests/fixtures/`).
2. XPM lokal ausführen (Kommandozeilen-Prüfmodul der KBV, quartalsweise
   aktualisiert). Jeden Fehlercode als Regel in `pvs/kvdt/rules.py` nachziehen.
3. Erst wenn XPM grün + Regelwerk stabil: Zulassungsverfahren planen (Zielbild
   Stufe 5).

## Definition of Done

- [ ] Encoder: Längen-/Zeichensatzkorrekt, Roundtrip-Test (parse eigener Ausgabe)
- [ ] Registry: Satzarten con0/besa/adt0/0101/0102/adt9/con9 vollständig aus
      offizieller Satzbeschreibung übernommen (alle VERIFY aufgelöst)
- [ ] Dry-Run-Datei besteht XPM ohne Struktur-Fehler (Inhaltsfehler → Backlog)
