# PVS-Zielbild: FHIR/openEHR-natives Praxissystem (Arbeitstitel: GREENBAY PVS)

**Ausgangslage:** Klinik-Datenplattform (EUGASTRO/medatixx → FHIR R4/openEHR) mit
kartierter Datenlandkarte (126 patientenbezogene Tabellen, MedDok-Blob-Parser,
RowVersion-Delta, Pseudonymisierung). Diese Pipeline ist zugleich die Migrations-Engine
für den PVS-Neubau.

**These:** Der Neubau ist machbar, wenn er als **Strangler-Pattern** angelegt wird —
das neue System übernimmt die klinische Dokumentation zuerst, Abrechnung und TI
schrittweise. Big-Bang-Ersatz eines KV-abrechnenden PVS ist ein 24–36-Monats-Projekt
mit Dauer-Zertifizierungsbetrieb; der gestufte Weg liefert nach 6–9 Monaten produktiven
Nutzen.

---

## 1. Formale Abbildung des Versorgungsprozesses

Der ambulante Versorgungsprozess wird auf drei Ebenen modelliert:

- **Prozessebene** (BPMN-artig): Phasen, Zustände, Übergänge, Akteure
- **Informationsebene**: FHIR-R4-Ressourcen (Austausch + Persistenz) und
  openEHR-Archetypen (klinische Modellierungsdisziplin)
- **Regulatorik-Ebene**: welche deutschen Artefakte (KVDT-Felder, Muster,
  TI-Fachdienste) an welchem Prozessschritt hängen

### 1.0 Prozessübersicht

```mermaid
flowchart LR
    A[Kontakt/Termin] --> B[Aufnahme/Check-in]
    B --> C[Klinischer Kontakt<br/>Anamnese·Diagnostik·Diagnose]
    C --> D[Therapie/Verordnung]
    C --> E[Leistungserfassung]
    D --> E
    E --> F[Abschluss/Doku]
    F --> G[Abrechnung<br/>KVDT-Quartal / GOÄ-Rechnung]
    F --> H[Recall/DMP/Nachsorge]
    H --> A
```

Zentrale Invariante: **Jede klinische Handlung erzeugt genau ein Ereignis im
Ereignisstrom des Patienten** (append-only, versioniert). Das entspricht 1:1 der
medatixx-`MedDok`-Philosophie (Karteikarten-Timeline, Bild 1) — und ist der Grund,
warum die Migration strukturell sauber geht.

### 1.1 Phase: Kontakt & Terminierung

| Aspekt | Modell |
|---|---|
| FHIR | `Appointment`, `Schedule`, `Slot`, `Patient` |
| openEHR | (kein klinischer Inhalt — Administrationsdomäne bleibt FHIR-only) |
| Quelle EUGASTRO | `SchedulerAppointment`, `Patient` |
| DE-Spezifika | Terminservicestelle-Codes (TSS), Videosprechstunde |

### 1.2 Phase: Aufnahme / Check-in / Fall

| Aspekt | Modell |
|---|---|
| FHIR | `Encounter` (Fall), `Coverage` (Versicherung), `Account`, `Consent` |
| Quelle | `Schein` (→ Encounter + Account), `PatientChipkarte` (→ Coverage), `PatientConsent` |
| DE-Spezifika | **Schein** = zentrales deutsches Konstrukt. Modellierung: `Encounter` mit Extension `schein-typ` (Original-/Überweisungs-/Notfall-/Privatschein) + `Account` je Quartal. VSDM-Stammdatenabgleich (eGK) beim Check-in → TI. Kostenträger via `Coverage.payor` mit IK-Nummer. |
| KVDT | Scheinuntergruppe (4239), Abrechnungsgebiet, Kostenträger (4104ff), Versichertendaten aus VSDM |

Der Schein ist **die** Brücke zwischen klinischer und Abrechnungswelt. Empfehlung:
eigenes internes Aggregat `Fall` (Quartal × Kostenträger × Behandler), das nach FHIR
als `Encounter`+`Account` projiziert wird und nach KVDT als Schein serialisiert.

### 1.3 Phase: Klinischer Kontakt

| Aspekt | Modell |
|---|---|
| FHIR | `Observation` (Vitalwerte, Labor, Anamnese-Items), `Condition` (Diagnosen), `DiagnosticReport` (Laborbericht, Sono, Endoskopie), `DocumentReference` (Briefe, Scans), `AllergyIntolerance`, `Flag` (CAVE) |
| openEHR | `OBSERVATION.blood_pressure`, `.body_weight`, `.laboratory_test_result`, `EVALUATION.problem_diagnosis`, `.adverse_reaction_risk`; Compositions je Kontakt |
| Quelle | `PatientVitalparameter*`, `Laborbogen`+`LaborHeader` (JSON), `MedDok` Kategorien D/BEF/Anamn/Sono/Prokto/Fibroscan (XML-Parser vorhanden), `PatientCave`, `ChronischeErkrankung` |
| DE-Spezifika | ICD-10-GM + **Diagnosesicherheit** G/V/Z/A (KVDT-Feld 6003/6001-Zusatz; FHIR: `condition-ver-status` + de-basis Extension), Seitenlokalisation L/R/B. Labor-Eingang via **LDT 3** (Laborgeräte/-gemeinschaften), Geräte via **GDT** (Sono, Endoskopie — für eugastro zentral). |
| KVDT | 6001 (ICD), 6003 (Sicherheit), 6004 (Lokalisation), Dauerdiagnosen-Kennzeichnung |

### 1.4 Phase: Therapie & Verordnung

| Aspekt | Modell |
|---|---|
| FHIR | `MedicationRequest` (Rezept), `MedicationStatement` (Medikationsplan/Dauermedikation), `ServiceRequest` (Überweisung, Heilmittel, Laborauftrag), `Task` (eAU-Workflow) |
| openEHR | `INSTRUCTION.medication_order`, `ACTION.medication` |
| Quelle | `VerordnungV2`+`Medikament*` (PZN/ATC/Wirkstoff — Bild 5/6 zeigen DM/LM-Status sauber strukturiert), `Medikationsplan*` (→ BMP!), `RezeptV2`+`RezeptInfo`, `PatientHeilmittelV2Verordnung`, `MedDok` AU-Kategorien + `MedDokFormularVariable` (JSON-Formularfelder) |
| DE-Spezifika | **eRezept** (gematik-Fachdienst, KBV_PR_ERP-Profile — FHIR-nativ!), **BMP** (Bundeseinheitlicher Medikationsplan, druckbar + eMP), **eAU** via KIM (KBV_PR_EAU — ebenfalls FHIR), Muster 6/10 (Überweisung), Muster 13 (Heilmittel mit Diagnosegruppe/Leitsymptomatik), Muster 16 (Papierrezept-Fallback), AMTS-Prüfung (ABDA-Datenbank-Lizenz nötig) |
| KVDT | verordnete Leistungen sind nicht KVDT-relevant, aber AU-Zeiten (Feld 3110er-Block) |

Wichtig: eRezept und eAU sind **bereits FHIR-R4-Profile der KBV/gematik**. Ein
FHIR-nativer Kernel erzeugt diese Objekte ohne Impedanz — das ist der strukturelle
Vorteil gegenüber jedem xDT-Altsystem.

### 1.5 Phase: Leistungserfassung & Abrechnung

| Aspekt | Modell |
|---|---|
| FHIR | `ChargeItem` (Einzelleistung), `Claim`/`Invoice` (Rechnung), `Account` (Sammler je Fall) |
| Quelle | Leistungen in `Schein`-Kontext + `MedDokExtensionData` (Feldkennung 8402 etc. als Fallback), `Rechnung`, `Eau` |
| DE-Spezifika GKV | **EBM-Katalog** (quartalsweise, KBV), Regelwerk (Ausschlüsse, Zeitprofile, Budgets, RLV), **KVDT/ADT-Quartalsdatei** durchs **KBV-Prüfmodul (XPM)**, Übermittlung via KV-Connect/1-Click |
| DE-Spezifika PKV | **GOÄ** (Faktor, Begründungen, Analogziffern), Rechnung als PDF + **PADneXt**-Export an PVS/Factoring (z. B. PVS holding) — **keine Zulassung erforderlich** |

Modellentscheidung: `ChargeItem` je erbrachter Leistung mit `code` aus EBM- bzw.
GOÄ-CodeSystem, Regelprüfung als eigener Service über dem Ereignisstrom. Der
KVDT-Serializer ist dann eine **Projektion**: Fall-Aggregat + ChargeItems + Conditions
→ ADT-Satzarten (0101/0102, 0201, 0204 …). Testbar gegen das öffentlich verfügbare
KBV-Prüfmodul, lange bevor eine Zulassung beantragt wird.

### 1.6 Phase: Abschluss, Kommunikation, Nachsorge

| Aspekt | Modell |
|---|---|
| FHIR | `Composition` (Arztbrief/Epikrise), `Communication` (KIM-Nachrichten), `Task` (Recall, ToDo), `CarePlan` (DMP) |
| Quelle | `MedDok` BRIEF/EAB/Epikrise, `TodoItem`, Recall-Tabellen |
| DE-Spezifika | **eArztbrief** via KIM, **ePA für alle** (Dokumenten-Upload MHD/FHIR, seit 2025 verpflichtend), eDMP (KBV-zertifizierungspflichtig, XML-Sätze je Programm) |

---

## 2. Zielarchitektur

```mermaid
flowchart TB
    subgraph KERNEL["Klinischer Kernel (FHIR-nativ)"]
        ES[(Ereignisstrom<br/>append-only, versioniert)]
        FS[(FHIR-Store<br/>Postgres/JSONB oder Medplum/Blaze)]
        AQ[openEHR-Projektion<br/>EHRbase optional]
        ES --> FS
        ES --> AQ
    end
    subgraph DOMAIN["Fachdienste"]
        FALL["Fall/Schein-Aggregat"]
        REGEL["EBM/GOÄ-Regelwerk"]
        FORM["Formular-Engine<br/>Muster + BMP + PDF"]
        TERM["Terminplanung"]
    end
    subgraph EDGE["Schnittstellen"]
        KVDT["KVDT/ADT-Serializer<br/>+ KBV-Prüfmodul XPM"]
        PAD["GOÄ-Rechnung + PADneXt"]
        TI["TI-Adapter (TIaaS/TI-Gateway)<br/>VSDM · eRezept · eAU/KIM · ePA"]
        GDT["GDT/LDT3-Adapter<br/>Sono · Endoskopie · Labor"]
    end
    MIG["Migrations-Engine<br/>= vorhandener Collector-Agent"] --> ES
    KERNEL --> DOMAIN --> EDGE
```

**Entscheidungen:**

1. **FHIR R4 als Persistenz- und API-Modell**, nicht nur als Exportformat. Begründung:
   eRezept, eAU, ePA, ISiK sind FHIR — der Kernel spricht die Zielsprache der TI nativ.
   Kandidaten: Medplum (Open Source, Auth/Subscriptions/React-Komponenten out of the
   box), Blaze (CQL-stark, read-optimiert), HAPI, oder eigenes Postgres/JSONB wie im
   Plattform-Konzept §7. Für ein PVS mit Write-Path ist **Medplum** der stärkste
   Startpunkt; Blaze bleibt Analyse-Store.
2. **openEHR als Modellierungsdisziplin, nicht als Pflicht-Runtime.** Archetypen/Templates
   definieren die klinischen Inhalte (was ist eine Blutdruckmessung, eine Diagnose),
   EHRbase läuft als optionale Projektion für AQL/Forschung — exakt wie im
   Plattform-Konzept bereits angelegt. Kein Dogmenstreit: FHIR ist Austausch/Betrieb,
   openEHR ist semantische Tiefe.
3. **Deutsche Konstrukte als eigene Aggregate** (Fall/Schein, Formular, Abrechnungslauf)
   mit Projektionen nach FHIR und KVDT — nicht als FHIR-Extension-Gestrüpp.
4. **Ereignisstrom append-only** — erfüllt nebenbei die Dokumentationspflicht
   (§630f BGB, Änderungsnachvollziehbarkeit) und ersetzt das Audit-Schema der Quelle.

---

## 3. Migration aus dem Altsystem (direkt, gestuft)

Die vorhandene Pipeline (dbsource → mappers → export) **ist** die Migrations-Engine.
Erweiterungen:

| Stufe | Inhalt | Aufwand |
|---|---|---|
| M0 | Privacy-Modus `off` ergänzen für Praxis-interne 1:1-Migration (Klardaten bleiben on-prem — zulässig, da kein Zonenwechsel). Assertion-Gate bleibt für Exportpfade aktiv. | klein (Config existiert schon) |
| M1 | **Golden-Record-Validierung**: Patient 3659 + eigene Akte #76824 vollständig migrieren, Feld-für-Feld-Abgleich gegen medatixx-UI (Bilder 1–7 als Referenz: Timeline, L&D, Vitalparameter, Verordnungsübersicht, Medikationsplan, Laborkumulativ). Abnahmekriterium: 100 % der sichtbaren UI-Inhalte im neuen System reproduzierbar. | 2–3 Wochen |
| M2 | Voll-Migration read-only + **Parallelbetrieb**: neues System zeigt, medatixx führt. Delta-Sync via RowVersion alle n Minuten (Mechanik vorhanden). | 4–6 Wochen |
| M3 | **Führungswechsel Dokumentation**: neues System erfasst, kritische Objekte (Diagnosen, Leistungen) werden für die Abrechnung nach medatixx zurückgespielt — pragmatisch via GDT/BDT-Import oder MFA-Doppelerfassung der reinen Abrechnungsziffern. medatixx = Abrechnungs-/TI-Terminal. | Strangler-Kern |
| M4 | Rückspielung entfällt schrittweise, sobald native Abrechnung (erst GOÄ, dann KVDT) und TI-Anbindung stehen. | — |

Bekannte Fallstricke aus dem Plattform-Konzept gelten weiter (TodoItem ohne RowVersion,
Eau nur über Id_MedDok, PATID-Anomalie → Plausibilitätscheck ist im Migrationslauf
Pflicht, nicht Option).

---

## 4. Regulatorik-Gap-Liste (ehrlich)

| Baustein | Pflicht für | Verfahren | Einschätzung |
|---|---|---|---|
| KVDT/ADT + KBV-Prüfmodul | KV-Abrechnung | KBV-Zulassung als PVS-Hersteller (ITA-Registrierung, Zulassungsverfahren je Anwendung), danach **Quartalsupdate-Pflicht dauerhaft** (EBM, SDKT, ICD/OPS, XPM) | technisch beherrschbar, organisatorisch ein Dauerbetrieb — die eigentliche Eintrittsbarriere |
| Blankoformularbedruckung | Muster-Druck | eigene KBV-Zertifizierung | mittel |
| eDMP | DMP-Teilnahme | KBV-Zertifizierung je Programm | verschiebbar (Stufe 5+) |
| LDT 3 | Laborkommunikation | KBV-Zulassung | für eugastro früh nötig (Laborvolumen) |
| GDT | Gerätekopplung | de-facto-Standard, keine Zulassung | klein, früh machen (Sono/Endoskopie) |
| TI-Basis (VSDM) | GKV-Betrieb | via TIaaS/TI-Gateway-Partner (RISE, Arvato, secunet) statt Eigenbau | Partnerintegration, Wochen nicht Jahre |
| eRezept, eAU/KIM, ePA | GKV-Pflichtanwendungen | gematik-**Bestätigungsverfahren** je Fachanwendung für den Hersteller | FHIR-nativ deutlich leichter; dennoch je Anwendung Monate |
| GOÄ + PADneXt | Privatabrechnung | **keine Zulassung** | sofort adressierbar — der Keil |
| DSGVO/§630f, MDR-Abgrenzung | immer | DSFA, Löschkonzept; PVS i. d. R. kein Medizinprodukt, aber Entscheidungsunterstützung (AMTS, Recall-Logik) sauber abgrenzen | mit hAIppokrates-Erfahrung vorhanden |

---

## 5. Stufenplan

| Stufe | Ergebnis | Abrechnung | TI | Zeithorizont |
|---|---|---|---|---|
| 0 (läuft) | Datenplattform read-only, FHIR-Export, Analyse-UI | medatixx | medatixx | — |
| 1 | Klinischer Kernel + Migration M1/M2, 360°-Sicht produktiv im Parallelbetrieb | medatixx | medatixx | 3 Monate |
| 2 | Führende Dokumentation im neuen System (Diagnosen, Vitalwerte, Verlauf, Briefe), GDT-Gerätekopplung, Formulardruck | medatixx (Rückspiel) | medatixx | +3 Monate |
| 3 | **Privat-PVS komplett**: GOÄ, Rechnung, PADneXt, BMP-Druck | GOÄ nativ, GKV via medatixx | medatixx | +3 Monate |
| 4 | TI-Anbindung via TIaaS: VSDM, eAU, eRezept, ePA (Bestätigungsverfahren) | wie 3 | nativ | +6–9 Monate |
| 5 | KVDT-Serializer + XPM-grün + KBV-Zulassung → medatixx abschaltbar | voll nativ | nativ | +6–12 Monate |

Stufe 3 ist ein eigenständig verkaufbares Produkt (Privatpraxen/Selbstzahler-MVZ,
kein Zulassungs-Overhead) und finanziert den Weg zu Stufe 5.

---

## 6. Nächste konkrete Schritte

1. Golden-Record M1 definieren: Abnahme-Checkliste aus den sieben medatixx-Screens
   ableiten (Timeline-Einträge, L&D, Vitalparameter-Historie, Verordnungsstatus DM/LM,
   Medikationsplan, Laborkumulativ mit Grenzwertindikatoren).
2. Kernel-Entscheidung: Medplum-PoC vs. Eigenbau Postgres/JSONB (2-Wochen-Spike,
   Kriterien: Write-Path, Versionierung, Subscriptions, Auth, DE-Profile).
3. Fall/Schein-Aggregat spezifizieren (Quartal × Kostenträger × Behandler) inkl.
   KVDT-Feldmapping als Tabelle — Grundlage für den späteren Serializer.
4. KBV-ITA-Registrierung als Softwarehaus prüfen (Zugang zu Satzbeschreibungen,
   Prüfmodulen, Testdaten) — kostet nichts außer Formalie, öffnet alle Spezifikationen.
5. TIaaS-Partnergespräch (RISE/Arvato) für Stufe-4-Planung.
