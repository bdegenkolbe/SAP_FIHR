# 10 — Klinischer Kernel: Ereignisstrom + FHIR-Persistenz

## Zweck

Der Kernel ist die führende Dokumentation des PVS. Er besteht aus zwei Schichten:

1. **Ereignisstrom** (`events`) — append-only, versioniert, unveränderlich.
   Jede klinische oder administrative Handlung ist genau ein Event.
   Erfüllt §630f BGB (Änderungen erkennbar, Ursprungsinhalt erhalten).
2. **Ressourcen-Store** (`resources`) — materialisierte FHIR-R4-Ressourcen als
   JSON, aktuelle Version je (type, id), Historie über den Ereignisstrom
   rekonstruierbar.

Entwicklungs-DB ist **SQLite** (No-Admin, wie Plattform-Deployment mit
SQLCipher-Option); Produktionspfad **PostgreSQL/JSONB** — das DDL in
`pvs/store/schema.sql` ist in beiden Dialekten lauffähig gehalten
(keine dialektspezifischen Typen außer dokumentierten Stellen).

## Ereignismodell

```
Event
  event_id        UUID v4
  seq             monoton steigende Sequenz (Store-vergeben)
  occurred_at     fachlicher Zeitpunkt (ReferenceDateTime der Quelle)
  recorded_at     technischer Zeitpunkt (Schreibzeitpunkt)
  patient_id      interne Patienten-ID (Kernel)
  fall_id         optional: Fall-Aggregat (siehe 20-FALL-SCHEIN-SPEC)
  actor           Behandler/Benutzer-Kürzel (Quelle: LE/BE, z. B. "IS")
  event_type      kontrolliertes Vokabular (unten)
  resource_type   FHIR-Ressourcentyp des Payloads
  resource_id     stabile Ressourcen-ID
  payload         FHIR-JSON (kanonisch serialisiert)
  source          Herkunft: "migration:eugastro" | "ui" | "ti:..." | "gdt" | "ldt"
  source_ref      Quell-PK (z. B. MedDok.Id) für Idempotenz + Rückverfolgung
  supersedes      event_id des Vorgängers bei Korrektur (Storno-Prinzip)
  hash            SHA-256 über (payload, patient_id, occurred_at) — Integritätskette
```

### event_type-Vokabular (v1)

| event_type | resource_type | Quelle (Migration) |
|---|---|---|
| `diagnose.dokumentiert` | Condition | MedDok D/DD/… |
| `befund.dokumentiert` | Observation/DiagnosticReport | MedDok BEF/SONO/FIBRO/… |
| `anamnese.dokumentiert` | Observation | MedDok A/FASA |
| `verlauf.dokumentiert` | Observation (narrative) | MedDok V |
| `vitalwert.erfasst` | Observation (vital-signs) | PatientVitalparameter* |
| `labor.ergebnis` | Observation + DiagnosticReport | Laborbogen/LaborHeader |
| `medikation.verordnet` | MedicationRequest | RezeptV2/RezeptInfo |
| `medikation.status` | MedicationStatement | VerordnungV2 (DM/LM), Medikationsplan |
| `heilmittel.verordnet` | ServiceRequest | PatientHeilmittelV2Verordnung |
| `au.ausgestellt` | DocumentReference (+Task eAU) | MedDok AU + Eau |
| `brief.erstellt` | Composition | MedDok BRIEF/EAB/E |
| `cave.gesetzt` | Flag / AllergyIntolerance | PatientCave |
| `notiz.erfasst` | Communication | MedDok N |
| `termin.geplant` | Appointment | SchedulerAppointment |
| `fall.eroeffnet` / `fall.geschlossen` | Encounter/Account | Schein |
| `leistung.erfasst` | ChargeItem | Leistungsdaten/8402-Fallback |
| `rechnung.gestellt` | Invoice | Rechnung |
| `consent.erfasst` | Consent | PatientConsent |
| `patient.angelegt` / `patient.geaendert` | Patient | Patient |

Erweiterung nur additiv; Typen nie umdeuten.

## Regeln

- **Idempotenz:** `(source, source_ref)` ist unique. Re-Runs der Migration
  erzeugen keine Duplikate; geänderte Quelldaten (RowVersion↑) erzeugen ein
  neues Event mit `supersedes` auf das alte.
- **Korrekturen:** niemals UPDATE auf `events`. Korrektur = neues Event mit
  `supersedes`; der Ressourcen-Store zeigt immer den letzten Stand.
- **Löschen:** fachliches Löschen = Event `*.storniert` mit leerem Payload-Kern
  + `supersedes`; physisches Löschen nur per dokumentiertem Löschkonzept-Job.
- **Timeline:** Patientenakte = `SELECT … WHERE patient_id=? ORDER BY occurred_at`
  — entspricht exakt der medatixx-Karteikarte (Referenz: Screen „Dokumentation").
- **IDs:** Ressourcen-IDs sind `"{typ}-eug-{quell_pk}"` für migrierte Objekte
  (stabil, kollisionfrei), UUID für native Objekte.

## Definition of Done

- [ ] `init-store` legt Schema an, `append_event` erzwingt Idempotenz + Hashkette
- [ ] Timeline-Query liefert für #76824 dieselbe Eintragsfolge wie medatixx-Screen 1
- [ ] Korrektur-/Storno-Pfad getestet (supersedes)
- [ ] Postgres-Lauf mit identischem Schema dokumentiert
