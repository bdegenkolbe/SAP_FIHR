# 20 — Fall/Schein-Aggregat + KVDT-Feldmapping

## Zweck

Der **Fall** ist das deutsche Abrechnungsaggregat: Klammer um alle abrechnungs-
relevanten Ereignisse eines Patienten je **Quartal × Kostenträgerkontext ×
Betriebsstätte**. Er ist ein eigenes Kernel-Aggregat mit zwei Projektionen:

- **FHIR:** `Encounter` (Behandlungskontext) + `Account` (Sammler) + `Coverage`
- **KVDT:** ein ADT-Schein (Satzart 0101/0102/0103/0104) je Fall
- **GOÄ:** Rechnungsgrundlage (Privatfall)

## Aggregat

```
Fall
  fall_id            UUID
  patient_id
  quartal            "Q/JJJJ"  (aus Schein.Quartal / Abrechnungsquartal)
  fall_art           enum: KURATIV | UEBERWEISUNG | BELEG | NOTFALL | PRIVAT | IGEL | HZV
  schein_untergruppe KVDT-Code (VERIFY gegen Satzbeschreibung), Quelle Schein.Scheinuntergruppe
  kostentraeger      { ik, name, versichertenart, wop, ktab }        # GKV
  privat             { versicherung, tarif }                          # PKV (z. B. Barmenia)
  betriebsstaette    { bsnr, nbsnr? }
  behandler          [ { lanr, kuerzel } ]                            # z. B. IS = Prof. Schiefke
  ueberweisung       { von_bsnr, von_lanr, an, auftrag, diagnose_verdacht, zielauftrag }
  gueltig_von / bis
  status             enum: OFFEN | ABGESCHLOSSEN | ABGERECHNET | STORNIERT
  positionen         [ ChargeItem-Refs ]     # Leistungen (EBM-GNR bzw. GOÄ-Ziffer)
  diagnosen          [ Condition-Refs ]      # Behandlungsdiagnosen des Falls
```

**Quelle Migration:** `dbo.Schein` (Spaltenliste verifiziert in `agent/export.py`
Q_SCHEIN: Scheinart, Scheinuntergruppe, Quartal, Abrechnungsquartal, KassenName,
Iknr, IsPrivat, IsIgel, RechnungsTyp, HzvVertragKennung, Ueberweisung*, …).

### Ableitung fall_art

| Bedingung (Schein) | fall_art |
|---|---|
| IsPrivat=1, IsIgel=0 | PRIVAT |
| IsIgel=1 | IGEL |
| HzvVertragKennung gesetzt | HZV |
| UeberweisungVon gesetzt | UEBERWEISUNG |
| IsStationaer=1 | BELEG |
| sonst | KURATIV |

## KVDT-Feldmapping (ADT)

Notation: Kernel-Feld → KVDT-Feldkennung (FK). Alle FK-Nummern sind gegen die
**aktuelle KVDT-Satzbeschreibung der KBV** zu verifizieren (`# VERIFY`), Zugang
über KBV-ITA. Die Struktur (welches Datum wohin) ist verbindlich, die Nummern
sind Arbeitsstand nach bekannter xDT-Systematik.

### Satzaufbau je Fall

```
con0 (Container-Beginn)
 └─ besa (Betriebsstätten-Stammdaten, 1× je Datei)
 └─ adt0 (ADT-Paket-Header: Quartal, Abrechnungs-BSNR, PVS-Kennung/Prüfnr.)
     └─ 010x je Fall:                                  # Satzart aus fall_art
         Patientenblock  → 3000 PatientNr, 3101 Name, 3102 Vorname,
                           3103 Geburtsdatum (TTMMJJJJ), 3110 Geschlecht,
                           3105/3119 Versichertennr./Versicherten-ID (eGK)   # VERIFY
                           3107 Straße, 3112 PLZ, 3113 Ort                   # VERIFY
         Versicherung    → 4104 Kostenträger-IK, 4106 KTAB, 4108 Zulassungsnr.?,
                           4109 letzter Einlesetag eGK, 4110 gültig bis,
                           4131 Besondere Personengruppe, 4132 DMP-Kennz.    # VERIFY
         Schein          → 4101 Quartal (JJJJQ), 4102 Ausstellungsdatum,
                           4121 Gebührenordnung, 4122 Abrechnungsgebiet,
                           4239 Scheinuntergruppe
         Überweisung     → 4205 Auftrag, 4207 Diagnose/Verdacht,
                           4218 überweisende BSNR, 4242 überweisende LANR    # VERIFY
         je Leistung     → 5000 Leistungstag, 5001 GNR (EBM),
                           5005 Multiplikator, 5006 Uhrzeit,
                           5098 BSNR, 5099 LANR (erbringender Arzt)
         je Diagnose     → 6001 ICD-10-GM, 6003 Sicherheit (G/V/Z/A),
                           6004 Lokalisation (L/R/B),
                           6006 Ausnahmetatbestand                            # VERIFY
 └─ adt9 / con9 (Paket-/Container-Ende mit Satzzählern)
```

### Kernel → KVDT Zuordnungstabelle

| Kernel | FK | Bemerkung |
|---|---|---|
| Patient.PatientNr | 3000 | aus Quelle unverändert |
| Patient.Name/Vorname | 3101/3102 | |
| Geburtsdatum | 3103 | Quelle liefert Jahr/Monat/Tag getrennt → zusammensetzen |
| Geschlecht | 3110 | Quelle: 2=m (Mapping-Tabelle in `fall.py`) |
| Coverage.ik | 4104 | Schein.Iknr |
| Fall.quartal | 4101 | Format JJJJQ |
| Fall.schein_untergruppe | 4239 | 1:1 aus Schein.Scheinuntergruppe, VERIFY Codeliste |
| Fall.diagnosen[].icd | 6001 | inkl. `-`-Suffix wie dokumentiert (I10.9-) |
| Fall.diagnosen[].sicherheit | 6003 | G/V/Z/A (identisch zu FHIR-Mapping in mappers.py) |
| ChargeItem.gnr | 5001 | EBM; GOÄ-Fälle erzeugen **keinen** ADT-Satz |
| ChargeItem.datum | 5000 | |
| Behandler.lanr / Betriebsstätte.bsnr | 5099 / 5098 | je Leistung |

### Invarianten (Regelwerk-Minimum vor XPM)

1. Jeder Fall hat ≥1 Behandlungsdiagnose mit Sicherheit G oder Z, sonst Warnung.
2. Jede Leistung liegt im Fall-Quartal.
3. PRIVAT/IGEL-Fälle erzeugen keinen KVDT-Output (→ GOÄ-Pfad).
4. LANR/BSNR 9-stellig; Pseudo-LANR-Regeln beachten.       # VERIFY
5. ICD nur aus gültigem ICD-10-GM-Jahreskatalog des Abrechnungsjahres.

## Definition of Done

- [ ] `build_fall.py` erzeugt aus Q_SCHEIN-Zeilen Fall-Aggregate inkl. fall_art
- [ ] Golden Record #76824: 1 Fall „P 24.05.2026 – IS", fall_art=PRIVAT,
      Versicherung Barmenia, Behandler IS — validiert
- [ ] FHIR-Projektion Encounter+Account+Coverage rundläuft durch fhir.resources
- [ ] KVDT-Zuordnungstabelle vollständig gegen KBV-Satzbeschreibung verifiziert
      (alle `# VERIFY` aufgelöst) — Voraussetzung für 40-KVDT-SERIALIZER
