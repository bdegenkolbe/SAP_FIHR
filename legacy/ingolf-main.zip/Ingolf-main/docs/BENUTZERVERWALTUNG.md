# Benutzerverwaltung, Rollen & Datenschutz-Weiche

Dieses Dokument spezifiziert **wer was sieht** — insbesondere die zentrale Weiche
zwischen **Klardaten** (praxisinterne Versorgung, Verantwortlicher i.S. DSGVO) und
**Pseudonymdaten** (Analyse/Forschung). Diese Weiche ist kein Nebenaspekt, sondern das
sicherheitskritische Herzstück der Anwendung.

## 1. Grundprinzip: zwei Datenmodi, eine Datenbasis

Der Export erzeugt Ressourcen in einem von drei Modi (`privacy.mode`):

| Modus | Inhalt | Zweck | wer |
|---|---|---|---|
| `off` (Klar) | Klarnamen, KVNR, Adresse, volle Daten | Behandlung/Versorgung | Behandler, MFA (Praxis) |
| `pseudonymize` | HMAC-Pseudonym, Date-Shift, KVNR gehasht, Freitext-De-ID | Interne Auswertung/QM | Auswerter |
| `anonymize` | wie pseudo + Generalisierung (nur Geburtsjahr) | Forschung/Weitergabe | Externe/Projekte |

**Regel:** Der Modus ist an die **Rolle** und den **Zweck** gebunden, nicht frei wählbar.
Die UI zeigt den aktiven Modus dauerhaft als Badge (rot = Klar, grün = Pseudonym). Ein
Wechsel in den Klarmodus ist ein protokollierter, rollen­geschützter Vorgang (Abschnitt 5).

## 2. Rollen

| Rolle | Beschreibung | Default-Modus |
|---|---|---|
| `owner` | Praxisinhaber/Verantwortlicher; verwaltet Nutzer, Schlüssel, Re-ID | Klar |
| `clinician` | Ärztin/Arzt in der Versorgung | Klar |
| `mfa` | Medizinische Fachangestellte | Klar (eingeschränkt) |
| `analyst` | Interne Auswertung/QM ohne Behandlungsbezug | Pseudonym |
| `researcher` | Projekt-/Studienauswertung | Anonym |
| `auditor` | liest nur Audit-Log, keine Klinikdaten | – |
| `admin_tech` | technischer Betrieb (ETL, Backup); **keine** Klinikdaten im Klartext | – |

Rollen sind kombinierbar über Rollen­zuweisung (`sec.benutzer_rolle`), Rechte sind additiv
mit Ausnahme der Klardaten-Sperre (deny gewinnt immer).

## 3. Rechtematrix

| Fähigkeit | owner | clinician | mfa | analyst | researcher | auditor | admin_tech |
|---|:--:|:--:|:--:|:--:|:--:|:--:|:--:|
| Patient suchen (Klar) | ✓ | ✓ | ✓ | – | – | – | – |
| Patient suchen (Pseudonym) | ✓ | ✓ | ✓ | ✓ | ✓ | – | – |
| 360°-Sicht Klardaten | ✓ | ✓ | ○ | – | – | – | – |
| 360°-Sicht pseudonym | ✓ | ✓ | ✓ | ✓ | ✓ | – | – |
| Freitext/Dokumente lesen | ✓ | ✓ | ○ | ○¹ | –¹ | – | – |
| Analysetool / Kohorten | ✓ | ✓ | – | ✓ | ✓ | – | – |
| Forschungsexport | ✓ | – | – | ○ | ✓ | – | – |
| Re-Identifikation (Break-Glass) | ✓ | ○² | – | – | – | – | – |
| Benutzer-/Rollenverwaltung | ✓ | – | – | – | – | – | – |
| Schlüssel/Secret verwalten | ✓ | – | – | – | – | – | – |
| ETL/Backup/Betrieb | ○ | – | – | – | – | – | ✓ |
| Audit-Log einsehen | ✓ | – | – | – | – | ✓ | – |

○ = eingeschränkt/konfigurierbar · ¹ Freitext im Pseudonymmodus nur de-identifiziert ·
² nur wenn `owner` es der Rolle freigibt.

## 4. Authentifizierungs-Flows (No-Admin, ohne Mailserver)

- **First-Run-Bootstrap:** Beim ersten Start existiert kein Nutzer. Der Setup-Wizard legt
  genau einen `owner` an (Benutzername + starkes Passwort, Argon2id) und **erzwingt sofortiges
  TOTP-Enrollment** (QR im Fenster, kein Mailversand nötig). Recovery-Codes werden einmalig
  angezeigt und müssen bestätigt werden.
- **Login:** Passwort (Argon2id) + TOTP (RFC 6238). Rate-Limit + temporäre Sperre nach
  Fehlversuchen (`sec.login_versuch`).
- **Passwort-Reset ohne Admin/Mail:** über Recovery-Code; alternativ setzt der `owner` ein
  Reset-Ticket. Kein E-Mail-Weg erforderlich (Einzelplatz-tauglich).
- **Sessions:** kurzlebiges Token im Speicher, Idle-Timeout, Re-Auth vor sensiblen Aktionen
  (Break-Glass, Nutzerverwaltung, Schlüsselwechsel).
- **MFA-Pflicht:** über die Einstellungen steuerbar (`auth_mfa`). **Standard: aus** —
  Einzelplatz in der Praxis, physisch gesichert; Login/Break-Glass dann nur mit
  Passwort. Für Mehrplatz-/exponierte Installationen auf `required` stellen
  (gilt dann für alle Konten; TOTP-Secrets werden bei der Kontoanlage immer
  erzeugt und aufbewahrt, Einschalten wirkt sofort ohne Neu-Einrichtung).

## 5. Re-Identifikation / Break-Glass (kontrollierter Klartext-Zugriff)

Der Re-ID-Vault (`vault`-Schema, separat verschlüsselt) hält die Zuordnung Pseudonym ↔ echte
ID. Rückauflösung ist ein expliziter Vorgang:

1. Nutzer mit Recht `reid` klickt in der pseudonymen Sicht „Klardaten anfordern".
2. **Re-Auth** (Passwort + TOTP) + **Begründung** (Pflichtfeld, Zweckbindung).
3. Vault löst nur den angefragten Datensatz auf, zeitlich begrenzt.
4. **Append-only-Audit** (`audit`-Schema): wer, wann, welches Pseudonym, Begründung, Dauer.
5. Optional 4-Augen-Prinzip: `owner` muss zweite Freigabe erteilen (konfigurierbar).

Das Break-Glass ist in der UI als roter Vorgang gekennzeichnet (siehe Mockup Patientensicht,
Button „Klardaten anfordern 🔓").

## 6. Audit (nachweispflichtig)

Jede sicherheitsrelevante Aktion (Login, fehlgeschlagener Login, Moduswechsel, Re-ID,
Export, Nutzer-/Rechteänderung, Schlüsselwechsel) wird append-only protokolliert
(`audit.eintrag`, Hash-Verkettung gegen nachträgliche Manipulation). `auditor` liest, niemand
ändert/löscht.

## 7. Verbindung zum Datenmodell

Setzt auf das bereits in `docs/SCHEMA.md` definierte `sec`- und `audit`-Schema auf
(Argon2id-Hash, TOTP-Secret verschlüsselt, Rollen, append-only-Log). Dieses Dokument
definiert die **Semantik/Policy**, SCHEMA.md die **Tabellen**.
