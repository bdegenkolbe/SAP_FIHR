# Klinische Datenplattform — Export (FHIR/openEHR) + Analyse

**Zweck:** Read-only-Anbindung an ein Praxisverwaltungssystem (MSSQL), inkrementeller
Voll-Export aller Patientendaten in eine lokale Datenbank, Transformation nach FHIR R4
bzw. openEHR, verpflichtende Pseudonymisierung/Anonymisierung am Quell-Rand, plus eine
Analyseoberfläche mit intelligenter Volltextannotation.

Dieses Dokument ist die Arbeitsgrundlage für die Entwicklung in Claude Code. Es enthält
die konkrete Datenlandkarte des vorliegenden Systems (EUGASTRO, gastroenterologisches PVS),
die Zielarchitektur und einen umsetzbaren Bauplan.

---

## 0. Datenschutz-Rahmen (verbindlich, nicht optional)

Ein Voll-Export aller Patienten einer Arztpraxis ist eine Verarbeitung besonderer
Kategorien personenbezogener Daten (Art. 9 DSGVO). Vor produktivem Einsatz zu klären:
Rechtsgrundlage (Behandlungsvertrag, Einwilligung, Forschungsprivileg §27 BDSG, o. Ä.),
Auftragsverarbeitung ggü. dem PVS-Betreiber, Rolle als Verantwortlicher, sowie ein
dokumentiertes Löschkonzept. Die Architektur setzt das technisch um durch:

- **Pseudonymisierung/Anonymisierung am Quell-Rand** — nur transformierte Daten verlassen
  das Praxisnetz.
- **Getrennte, verschlüsselte Re-Identifikationstabelle** — verbleibt on-prem, niemals in
  der Analyse-DB.
- **Read-only-Zugriff** auf die Quelle (dedizierter Login oder Read-Replica).

Das ist kein juristischer Rat, sondern die technische Leitplanke des Systems.

---

## 1. Datenlandkarte Quellsystem (dbo-Schema, EUGASTRO)

984 Tabellen in den Schemata `Audit` und `dbo`. Arbeitsschema ist `dbo`.
Zentrale Entität ist `dbo.Patient` (PK `Id`), auf die **126 Tabellen** per `Id_Patient`
verweisen. Das ist der Ausgangspunkt jeder patientenzentrierten Extraktion.

### 1.1 Kernentität

| Tabelle | PK | Wichtige Felder | Bedeutung |
|---|---|---|---|
| `dbo.Patient` | `Id` | `PatientNr`, `Geschlecht` (2=m), Geburtsdatum, Adresse, `IsPrivat`, `PatientSeit` | Stammdaten, 63 Spalten |

### 1.2 Domänen → Tabellen (FHIR-Zielressource)

| Domäne | Quelltabelle(n) | Blob/Format | FHIR-Ziel |
|---|---|---|---|
| Diagnosen | `MedDok` + `MedDokKategorie` (Kuerzel='D') | `Detail` = XML `<MedDokDiagnose>` (Icd, IcdBeschreibung, Sicherheit G/Z) | `Condition` |
| Weitere Dokumentation | `MedDok` + `MedDokKategorie` (andere Kuerzel) | `Detail` = XML/Text je Kategorie | `Observation`/`ClinicalImpression`/`DocumentReference` |
| Labor | `Laborbogen` + `LaborHeader`, `LaborAnforderung` | `Details` = **sauberes JSON** (Ergebniswert, Einheit, NormalwertText, TestIdent, Testbezeichnung, GrenzwertIndikator, TestbezogeneHinweise) | `Observation` + `DiagnosticReport` (1 Report je `LaborHeader`) |
| Vitalwerte | `PatientVitalparameterRecord` + `PatientVitalparameterValue` + `Vitalparameter` | relational | `Observation` (vital-signs) |
| Medikation/Verordnung | `VerordnungV2` + `Medikament` + `MedikamentAtc` + `MedikamentWirkstoff` + `MedikamentVerordnungsmenge` | relational; `ItemType` 1=strukturiert (PZN/ATC), 3=Freitext | `MedicationStatement`/`MedicationRequest` |
| Medikationsplan | `Medikationsplan` + `MedikationsplanItem` | relational (Verweis auf `VerordnungV2`) | `MedicationStatement` (Liste) |
| Rezepte | `RezeptV2` + `RezeptInfo` (+`RezeptInfoDruck`) + `RezeptDiagnose` | relational; `Info` = Präparat+Dosierschema, `Pzn`, `IsAutIdem` | `MedicationRequest` (je Verordnungszeile, `groupIdentifier` je Rezept) |
| CAVE/Warnhinweise | `PatientCave` | `DescriptionText`, `IntoleranceText` (meist NULL) | `Flag` (bzw. `AllergyIntolerance`, **nur wenn** `IntoleranceText` gesetzt) |
| Impfstatus | `PatientImpfstatus` | Statuscode | `Immunization` (nur wenn Einzelimpfungen dokumentiert) |
| Einwilligungen | `PatientConsent` | relational | `Consent` |
| Kontaktdaten | `PatientKontakt` | relational | `Patient.telecom`/`RelatedPerson` |
| Mitbehandler | `PatientMitbehandler` | relational | `CareTeam`/`PractitionerRole` |
| eGK | `PatientChipkarte` | relational (**sensibel: Versichertennr.**) | `Coverage` (pseudonymisiert) |
| Termine | `SchedulerAppointment` | relational | `Appointment` |
| Abrechnung/Fall | `Schein` | relational | `Encounter`/`Claim` |
| Rechnung | `Rechnung`, `Eau` | relational | `Invoice`/`Claim` |
| Chronische Erkr. | `ChronischeErkrankung` | relational | `Condition` |
| Arbeitsunfähigkeit | `MedDok` (AU/ALTAU/AFAU, `<meddokformular>`) + `MedDokFormularVariable` + `Eau` | XML + JSON-Formularfelder + Transport | `DocumentReference` (eAU) |
| Arztbriefe/Epikrisen | `MedDok` (BRIEF/EAB/E) | `Detail` = `<MedDokFreitext>` | `Composition` |
| Heilmittel | `PatientHeilmittelV2Verordnung` (+`…Heilmittel`) | relational (ICD, DiagnoseGruppe, Leitsymptomatik, Positionen) | `ServiceRequest` |
| ToDo/Aufgaben | `TodoItem` | relational (Status/Priority/Deadline) | `Task` |
| ePA-Austausch | `EpaEventLog` + `EpaDocumentMeta` | relational + JSON (`DocumentMetaJson`) | `DocumentReference` (optional) |
| Formularvariablen | `MedDokFormularVariable` | JSON-Array `{id,value}` | Anreicherung (AU/Überweisung/Laborauftrag), **kein** eigener Ressourcentyp |
| BDT/xDT-Rohdaten | `MedDokExtensionData` | Key-Value (Feldkennung→Wert) | **nicht exportiert** (redundant/Fallback) |
| Datei-Anhänge | `MedDokAnhang` | `varbinary` + FileName/Länge | `DocumentReference` (Metadaten; `--embed-anhaenge` → base64) |
| NFDM/Geriatrie | `PatientNfdm`, `GeriatrieDok` | XML/relational | `Composition`/`Observation` |

### 1.3 Blob-Spalten (Sonderbehandlung im Mapping)

- **`MedDok.Detail`** — XML. Je nach `MedDokKategorie.Kuerzel` unterschiedliches Schema
  (Diagnose, Anamnese, Befund, Verlauf …). Pro Kategorie ein eigener Parser.
- **`Laborbogen.Details`** — JSON, einheitlich, gut parsebar. Enthält Freitext in
  `TestbezogeneHinweise` (Kandidat für NLP-Annotation).
- **`PatientCave.DescriptionText` / `DescriptionHtml`** — Freitext/HTML.
- **`MedDokFormularVariable.FormularVariablen`** — JSON-Array `{id,value}` strukturierter
  Formularfelder (AU: `_ArbeitsunfaehigSeit`/`_VoraussichtlichArbeitsunfaehigBis`/`_Diagnose`
  mit ICD/`_IsEau`; Laborauftrag: `_ID01.._ID61`/`_Auftrag`; Überweisung). **Enthält PII**
  (`Patient_*`, `Praxis_Stempel`, `Arzt_*`) — beim Parsen werden **nur** klinische Felder
  (`_`-Präfix, `Formular_*`) gelesen, PII-Präfixe verworfen.
- **`MedDokExtensionData`** — Key-Value-Store roher BDT/xDT-Feldkennungen (z. B. 8402
  Leistungskennzeichen, 6200 Datum). Redundant zu geparstem Labor/Leistung → **nicht** als
  eigener Ressourcentyp exportiert; nur diagnostische Fallback-Quelle.
- Diverse `*Dok`-Tabellen mit narrativen Textfeldern → NLP-Pipeline (Abschnitt 8).

### 1.4 Change-Tracking-Spalten (Basis für Incremental Load)

Praktisch alle Bewegungsdatentabellen tragen:

- **`RowVersion`** — Typ `timestamp`/`rowversion` (8 Byte, monoton, DB-weit eindeutig).
  **Primärer Delta-Marker.** Inkrementiert bei jedem UPDATE/INSERT automatisch.
- `CreatedPoint` (datetime2), `CreatedBy`, `CreatedAt` — Anlagezeitpunkt/-quelle.
- Teilweise `_lastModifiedDate` auf Kopftabellen (unzuverlässig für „letzte Buchung", nicht als alleinigen Marker verwenden).

Zusätzlich existiert ein **`Audit`-Schema** — potenzielle Historienquelle, aber
versionsabhängig und nicht als primäre Delta-Quelle verlässlich.

### 1.5 Bekannte Fallstricke (aus der Analyse)

- Spaltennamen weichen von Vermutungen ab: `Vitalparameter` nutzt `Name`/`DisplayName`/
  `Masseinheit` (nicht Bezeichnung/Einheit); `PatientVitalparameterRecord` nutzt `Datum`
  (nicht ReferenceDateTime); `Medikationsplan` hat keine `Datum`-Spalte (nur `CreatedPoint`/`Version`).
- `Eau` hat kein `Id_Schein` (und kein `Id_Patient` — Verknüpfung nur über `Id_MedDok`).
- `TodoItem` hat **keine** `RowVersion`-Spalte → kann nicht per Rowversion-Delta laufen
  (voller Reconcile über `Id_Patient`); `Medikationsplan`-PK ist `Id_Patient` (kein `Id`).
- Datenanomalie beobachtet: In einer Laborsitzung stand in der `PATID`-Zeile eine
  fremde Kennung statt der PatientNr — **Zuordnungsprüfung beim Import einbauen**
  (Plausibilitätscheck PatientNr ↔ erwartete ID).
- Collection-Endpunkte im Quell-API liefern teils nur Link-Stubs; hier gilt: direkt gegen
  die Tabellen arbeiten, nicht gegen abstrahierte Views.

### 1.6 Discovery ist noch nicht vollständig

Kartiert sind die ~20 wichtigsten der 126 FK-Tabellen. **Schritt 1 der Entwicklung** ist
ein automatischer Schema-Crawler (Abschnitt 4.1), der alle 126 Tabellen, ihre Spalten,
FK-Beziehungen, Blob-Spalten und Change-Marker in eine Mapping-Registry schreibt. Diese
Registry (YAML) wird die eigentliche, gepflegte „Datenlandkarte" und steuert den Export
konfigurativ statt hartkodiert.

---

## 2. Zielarchitektur

Drei physisch/logisch getrennte Zonen. Klardaten bleiben links.

```mermaid
flowchart LR
    subgraph SRC["Praxisnetz (on-prem, Klardaten)"]
        DB[(MSSQL PVS<br/>read-only Login)]
        AGENT["Collector-Agent<br/>Extract + Pseudonymize"]
        MAP[(Re-ID-Vault<br/>verschlüsselt, verbleibt on-prem)]
        DB --> AGENT
        AGENT <--> MAP
    end
    subgraph XFER["Transfer (nur pseudonymisierte Daten)"]
        PKG["Delta-Paket<br/>FHIR/openEHR, signiert"]
    end
    subgraph ANALYSE["Analysezone (lokal/sovereign)"]
        STORE[(FHIR-Store: Blaze<br/>oder openEHR: EHRbase)]
        IDX[(Such-/Annotationsindex<br/>OpenSearch)]
        API["Analyse-API (FastAPI)"]
        UI["Analyse-UI (React)"]
        STORE --> API
        IDX --> API
        API --> UI
    end
    AGENT --> PKG --> STORE
    AGENT -->|Textblobs annotiert| PKG --> IDX
```

**Kernentscheidung:** Extraktion **und** Pseudonymisierung laufen im selben Agent im
Praxisnetz. Nur pseudonymisierte, bereits nach FHIR/openEHR transformierte Deltas verlassen
die Zone. Der Re-ID-Vault (Pseudonym ↔ echte ID) bleibt verschlüsselt on-prem und ist für
die Analysezone nie erreichbar.

---

## 3. Verbindungskonfiguration (nutzerkonfigurierbar)

- Verbindung als YAML-Profil, Secrets getrennt (ENV/OS-Keychain/Vault), **nie** im Klartext
  im Repo.
- Treiber: `pyodbc` + ODBC Driver 18 for SQL Server, TLS erzwungen (`Encrypt=yes`).
- Read-only-Login mit `db_datareader`; kein DDL, kein Schreibrecht.
- Verbindungstest + Rechte-Check + Schema-Kompatibilitätsprüfung beim ersten Lauf.

```yaml
# config/connection.example.yaml
source:
  driver: "ODBC Driver 18 for SQL Server"
  host: "PRAXIS-SQL01.local"
  port: 1433
  database: "EUGASTRO"
  auth: "sql"                 # oder "windows"
  username_env: "SRC_DB_USER" # Wert kommt aus ENV/Keychain
  password_env: "SRC_DB_PW"
  encrypt: true
  trust_server_certificate: false
  application_intent: "ReadOnly"
privacy:
  mode: "pseudonymize"        # off | pseudonymize | anonymize
  reid_vault: "file:///secure/reid.sqlite.enc"  # bleibt on-prem
  hmac_key_env: "PSEUDO_HMAC_KEY"
  date_shift: true            # konsistenter Offset je Patient
  free_text_deid: true
target:
  kind: "fhir-blaze"          # fhir-blaze | openehr-ehrbase | postgres-jsonb
  url: "http://localhost:8080/fhir"
load:
  batch_size: 500
  tables_registry: "config/tables.yaml"
```

---

## 4. Extraktion & Incremental Load

### 4.1 Schema-Crawler (einmalig + bei Schemaänderung)
Liest `INFORMATION_SCHEMA` + `sys.foreign_keys` + `sys.columns`, erkennt pro Tabelle:
PK, FK auf `Patient`, `rowversion`-Spalte, Blob-Spalten (XML/JSON/Text). Ergebnis →
`config/tables.yaml` (die pflegbare Datenlandkarte). Manuelle Mapping-Hints (welche
FHIR-Ressource, welcher Blob-Parser) werden dort ergänzt.

### 4.2 Delta-Strategie (Priorität von oben)
1. **SQL Server Change Tracking (CT)** — sauberste Lösung, falls auf der Quelle aktivierbar
   (`ALTER DATABASE … SET CHANGE_TRACKING = ON`). Auf produktiven PVS oft nicht erlaubt.
2. **rowversion-High-Watermark (Default)** — je Tabelle den `MAX(RowVersion)` des letzten
   Laufs speichern; nächster Lauf zieht `WHERE RowVersion > @last`. Grenze über
   `MIN_ACTIVE_ROWVERSION()` respektieren, um offene Transaktionen nicht zu verpassen.
3. **`CreatedPoint`-Fallback** — nur für reine Insert-only-Tabellen ohne rowversion.

Watermarks liegen in der lokalen Load-State-Tabelle (`etl_state`), nicht in der Quelle.
Erststart = Full Load; danach nur Deltas.

### 4.3 Löschungen
rowversion erkennt keine physischen Deletes. Optionen: (a) periodischer Key-Abgleich
(Set-Differenz PK-Liste Quelle vs. Ziel) im „Full-Reconcile"-Lauf, (b) Soft-Delete-Flags
der Quelle mappen (z. B. `IsDeleted` in `VerordnungV2`). Reconcile z. B. wöchentlich.

### 4.4 Ablauf je Lauf
Extract (batched) → Pseudonymize (in-memory) → Map (FHIR/openEHR) → Annotate (Text) →
Load (idempotent, upsert per Ressourcen-ID) → Watermark commit. Fehlertolerant: pro
Tabelle/Batch transaktional, Wiederaufsetzpunkt über `etl_state`.

---

## 5. Pseudonymisierung / Anonymisierung (am Quell-Rand)

Modus über Config: `off` (nur intern/on-prem zulässig), `pseudonymize`, `anonymize`.

### 5.1 Direkte Identifikatoren
Name, Adresse, Geburtsdatum(tag), PatientNr, Versichertennummer, Chipkarten-IDs,
Telefon/E-Mail, Namen von Behandlern in Freitext.
- **Pseudonymisieren:** stabiler Pseudonym = `HMAC-SHA256(secret, echte_ID)` → gleiche
  Person immer gleicher Pseudonym, aber ohne Schlüssel nicht umkehrbar. Re-ID-Vault hält
  `pseudonym → echte_ID` verschlüsselt on-prem.
- **Anonymisieren:** Identifikatoren entfernen, kein Vault, keine Umkehrbarkeit.

### 5.2 Quasi-Identifikatoren (Re-Identifikationsrisiko)
- Datum: **konsistentes Date-Shifting** je Patient (zufälliger Offset ±N Tage, pro Person
  fix) — erhält Intervalle/Verläufe, verschleiert absolute Termine. Alternativ nur
  Jahr/Alter.
- Alter: Banding (5-Jahres-Gruppen) im Anonymisierungsmodus.
- PLZ: auf 3 Stellen kürzen.
- Seltene Kombinationen (Diagnose+Ort+Alter): optional k-Anonymität/Generalisierung.

### 5.3 Freitext-De-Identifikation
NER-basierte Erkennung + Maskierung von Personennamen, Orten, Daten, Kontaktdaten in
`MedDok.Detail`, `TestbezogeneHinweise`, `PatientCave.*`. Ersatz durch typisierte Platzhalter
(`[PERSON]`, `[DATUM]`). Läuft **vor** dem Transfer.

### 5.4 Design-Garantie
Der Agent schreibt ausgehend ausschließlich pseudonymisierte Objekte. Ein Assertion-Gate
vor dem Load prüft schematisch, dass keine Klartext-Identifikatoren (Regex/Feldliste)
im ausgehenden Paket sind. Verstoß = Abbruch.

---

## 6. Mapping MSSQL → FHIR R4 / openEHR

- **FHIR R4** (empfohlener Primärpfad): pro Domäne ein Mapper (siehe Tabelle 1.2).
  Bibliothek `fhir.resources` (pydantic, validiert). Kodiersysteme: ICD-10-GM
  (`http://fhir.de/CodeSystem/bfarm/icd-10-gm`), ATC (`…/bfarm/atc`), PZN (`…/ifa/pzn`),
  LOINC für Labor/Vitalwerte, UCUM für Einheiten. Ausgabe als `Bundle` (collection) oder
  direkt als Ressourcen in den FHIR-Store.
- **openEHR** (optionaler Parallelpfad): Compositions gegen Archetypen/Templates
  (z. B. `openEHR-EHR-OBSERVATION.laboratory_test_result`, `.blood_pressure`,
  `EVALUATION.problem_diagnosis`, `.medication_statement`). Ziel-CDR: **EHRbase**.
- Mapping-Regeln datengetrieben aus `config/tables.yaml` + Blob-Parser je `MedDokKategorie`.
- Diagnosesicherheit KBV: `G`→confirmed, `Z`→differential/„Zustand nach", `V`→provisional,
  `A`→refuted (wie im bestehenden Export).

Der bereits gebaute Einzel-Patient-Export (`build_bundle.py`) ist die Referenz-Implementierung
für die Mapper und wird zum Multi-Patient-Batch verallgemeinert.

---

## 7. Lokale Zieldatenbank / „vollständige Patientendatensicht"

Empfehlung nach Aufwand/Nutzen:

- **Primär: Blaze FHIR-Store** (Open Source, deutschsprachiger Ursprung, CQL-fähig, sehr
  schnell, Docker). Native FHIR-Suche + Analytics.
- **Alternative/ergänzend: EHRbase** (Open-Source-openEHR-CDR) für den openEHR-Pfad, AQL-Abfragen.
- **Minimal/eigenständig: PostgreSQL mit JSONB** — FHIR-Ressourcen als JSONB, GIN-Indizes,
  plus materialisierte Sichten für die Patienten-Timeline. Volle Kontrolle, wenig Ballast,
  gut für MVP.

**Patientendatensicht:** eine materialisierte, chronologisch sortierte Event-Sicht je
Pseudonym (Diagnosen, Labor, Vitalwerte, Medikation, Termine, Abrechnung) — die Grundlage
für Verläufe in der UI. Bei Blaze via FHIR `$everything`/CQL, bei Postgres via View.

---

## 8. Textannotation & intelligente Suche

Ziel: Freitext- und Blob-Inhalte durchsuchbar und filterbar machen.

- **Pipeline (Python):** spaCy (deutsches Modell) + medizinische Erweiterung
  (medspaCy-Muster / GERNERMED-Ansatz) für klinische Entitäten.
- **Negations-/Unsicherheitserkennung** (dt. NegEx-Variante) — essenziell: „kein Hinweis
  auf Zöliakie", „Z. n. H.p.-Eradikation", „unauffällig" dürfen nicht als positive Befunde
  indexiert werden.
- **Terminologie-Verknüpfung:** erkannte Begriffe gegen ICD-10-GM, ATC, LOINC, perspektivisch
  SNOMED CT mappen → strukturierte Annotation am Textknoten.
- **Ablage:** Annotationen als FHIR-Extensions bzw. als `Observation`/`Condition`-Verweise,
  zusätzlich denormalisiert in **OpenSearch** für facettierte Volltextsuche
  (Filter: Entitätstyp, Code, Negation, Zeitraum, Pseudonym).
- **Suchbeispiele:** „alle Patienten mit HOMA-Index > 3 und dokumentierter Fettleber",
  „Freitext erwähnt ‚Insulinresistenz' nicht-negiert", „Verordnungen ATC A10 im Verlauf".

---

## 9. Analyseoberfläche

- **Backend:** FastAPI. Endpunkte für Kohorten-Query, Patienten-Timeline, Volltext/Facetten,
  Aggregationen. Für FHIR-Analytik: CQL (Blaze) oder **Pathling**/SQL-on-FHIR
  (ViewDefinition) für tabellarische Auswertungen.
- **Frontend:** React. Kernviews:
  1. **Kohorten-Explorer** — Filter über Codes/Werte/Text, Ergebnis als Liste von Pseudonymen.
  2. **Patienten-Timeline** — chronologischer Verlauf aller Ereignisse, Wertverläufe als
     Charts (z. B. Labortrend HOMA/Leberwerte über Zeit).
  3. **Volltextsuche** — facettiert, mit hervorgehobenen, annotierten Treffern.
  4. **Ad-hoc-Query** — gespeicherte CQL/AQL/SQL-Abfragen.
- Verläufe nutzen die date-shift-erhaltene Intervallstruktur; absolute Daten bleiben
  pseudonymisiert.

---

## 10. Tech-Stack & Repo-Struktur (für Claude Code)

**Stack:** Python 3.11+, pyodbc/SQLAlchemy, `fhir.resources`, spaCy + medizinische Muster,
FastAPI, React (Vite), Docker Compose (Blaze/EHRbase/OpenSearch/Postgres), typer (CLI),
pydantic-settings (Config), Alembic (lokale Metadaten-DB).

```
klinik-datenplattform/
├── config/
│   ├── connection.example.yaml
│   └── tables.yaml                 # generierte + gepflegte Datenlandkarte
├── agent/                          # läuft on-prem
│   ├── discovery/                  # Schema-Crawler → tables.yaml
│   ├── extract/                    # Incremental Load (rowversion/CT)
│   ├── privacy/                    # Pseudonym, Date-Shift, Freitext-DeID, Assertion-Gate
│   ├── mapping/
│   │   ├── fhir/                   # je Domäne ein Mapper (aus build_bundle.py generalisiert)
│   │   ├── openehr/                # Compositions/Templates
│   │   └── blob_parsers/           # MedDok-XML je Kategorie, Laborbogen-JSON
│   ├── annotate/                   # NLP-Pipeline (NER, Negation, Terminologie-Linking)
│   └── load/                       # Upsert in Ziel-Store + etl_state
├── analysis/
│   ├── api/                        # FastAPI
│   └── ui/                         # React
├── deploy/
│   └── docker-compose.yml          # Blaze/EHRbase/OpenSearch/Postgres
├── tests/                          # Mapper-Tests gegen bekannte Referenzfälle
└── CONCEPT.md                      # dieses Dokument
```

**Referenzfall für Tests:** Patient 3659 (bereits verifizierter Einzel-Export) dient als
Golden-Record-Testfall für die Mapper — Ergebnis muss reproduzierbar dem geprüften Bundle
entsprechen.

---

## 11. Roadmap

**MVP (belastbarer Kern)**
1. Verbindungskonfig + Verbindungs-/Rechte-Test.
2. Schema-Crawler → `tables.yaml`.
3. Full Load der Kern-Domänen (Patient, Diagnosen, Labor, Vitalwerte, Medikation) nach
   Postgres-JSONB.
4. Pseudonymisierung + Date-Shift + Assertion-Gate.
5. FHIR-Mapper (aus `build_bundle.py` generalisiert), Golden-Record-Test.
6. Minimale Patienten-Timeline-View.

**Ausbau 1**
7. Incremental Load über rowversion + `etl_state`.
8. Restliche Domänen (Termine, Abrechnung, Consent, Impf, CAVE …).
9. Blaze als FHIR-Store, Kohorten-Explorer.

**Ausbau 2**
10. NLP-Annotation + OpenSearch + facettierte Suche.
11. openEHR-Pfad (EHRbase) parallel.
12. Delete-Reconcile, Anonymisierungsmodus, k-Anonymität.

---

## 12. Offene Punkte / Risiken

- **CT auf Quelle aktivierbar?** Wenn nein, rowversion-Pfad (Default) — Deletes brauchen Reconcile.
- **XML-Vielfalt in `MedDok.Detail`** — Parser je `MedDokKategorie` nötig; Kategorien erst
  vollständig katalogisieren.
- **Datenqualität** — PATID-Anomalie zeigt: Plausibilitätschecks beim Import Pflicht.
- **Terminologie-Lizenzen** — SNOMED CT braucht Lizenz (NHS/DE über BfArM); ICD-10-GM/ATC/LOINC frei nutzbar.
- **Last auf Produktivsystem** — Extraktion gegen Read-Replica oder in Randzeiten; Batch-Größen begrenzen.
- **Rechtsgrundlage & AV-Vertrag** — vor Produktivbetrieb klären (Abschnitt 0).

---

## 13. Ergänzungen: Oberfläche, Kataloge, Verwaltung, Betrieb, Governance

Dieser Abschnitt schließt die zuvor nur angerissenen Konzeptteile und verweist auf die
zugehörigen Detaildokumente und die klickbaren Mockups.

### 13.1 Oberfläche (Mockups + Spezifikation)
Interaktive Prototypen unter `ui/mockups/` (`index.html` als Launcher): **Patientenauswahl**,
**360°-Patientensicht**, **Versorgungsanalyse**. Design-System (GREENBAY-CI, Tokens,
Komponenten, Dark-Mode-Variante, Barrierefreiheit) in `ui/design/tokens.css`. Screens,
Zustände und die FHIR-Profil-Umschaltung sind in `docs/UI_SPEC.md` spezifiziert.

### 13.2 Datenschutz-Weiche (Klar vs. Pseudonym) — konzeptioneller Fork
Die Anwendung trennt strikt **Versorgung (Klardaten)** und **Analyse (Pseudonym/Anonym)**.
Der Modus ist an Rolle und Zweck gebunden, dauerhaft als Badge sichtbar, und ein Wechsel in
den Klarmodus ist ein protokollierter, rollen­geschützter Vorgang. Rollen, vollständige
Rechtematrix, Auth-Flows (First-Run-Bootstrap, TOTP, Reset ohne Mail) und **Break-Glass/Re-ID**
sind in `docs/BENUTZERVERWALTUNG.md` definiert (setzt auf `sec`/`audit`/`vault` aus SCHEMA.md auf).

### 13.3 FHIR-Profil (R4 · MII-KDS · KBV)
Zielprofil in den Einstellungen wählbar; wirkt auf `meta.profile` und optionale Profil­validierung.
Der Mapping-Kern bleibt unverändert, ein Profil-Layer ergänzt Pflichtfelder/Slicing.
Doppelausleitung (z. B. R4 **und** MII) möglich. Default heute: bare R4 (implementiert).

### 13.4 Katalog-Lebenszyklus
Interne Kataloge werden aus der Quelle exportiert (`reference/` → ObservationDefinition,
Medication, ChargeItemDefinition, CodeSystem). **Externe Register** (LOINC, ICD-10-GM, ATC,
GOÄ/EBM) liegen nicht in der Quell-DB und werden als lizenzierte/freie Terminologie separat
eingespielt und **versioniert** (Gültig-ab/-bis, Quelle, Version). Die UI nutzt die Kataloge
zur Auflösung (ATC/PZN-Namen, geschlechtsspezifische Referenzbereiche) und zeigt den
Katalog-/Versionsstand im Bereich „Kataloge". Aktualisierung: manuell oder terminiert;
Änderungen verändern **keine** historischen Messwerte (nur Anzeige/Interpretation).

### 13.5 Verwaltungssichten & Praxis-Stammdaten
Neben Patientendaten braucht die Plattform **Praxis-Stammdaten** (keine PHY):
`Betriebsstaette` (Standorte/BSNR), `Benutzer`/`BenutzerKuerzel` (Behandler/LANR),
Kostenträger/Kassen (denormalisiert an Schein/Chipkarte). Diese fließen als FHIR
`Organization`/`Practitioner`/`PractitionerRole`/`Location` bzw. als auflösbare Referenzen ein
und speisen die Verwaltungssichten (Abrechnungs-/Fallübersicht, Termine, Versicherung).
Administrative Patienten-Ressourcen (Encounter, Claim, Invoice, Coverage, Appointment) sind
bereits gemappt; die Verwaltungssicht aggregiert sie.

### 13.6 Schlüssel-Management
- **Master-Secret** (HMAC-Pseudonymisierung + Vault-Verschlüsselung) wird beim First-Run
  erzeugt und per **Windows DPAPI (CurrentUser)** gebunden abgelegt (`secret/master.bin`),
  nie im Klartext in der Config.
- **Re-ID-Vault** getrennt verschlüsselt; Zugriff nur über Break-Glass.
- **Rotation:** Secret-Wechsel durch `owner` mit Re-Pseudonymisierung (Mapping-Migration über
  Vault); dokumentierter, protokollierter Vorgang.

### 13.7 Betrieb (Einzelplatz)
- **Erstlast:** Full-Load ist rechenintensiv (2,2 Mio. Laborbögen, 1,1 Mio. MedDok) →
  batched, fortsetzbar, Fortschrittsanzeige; danach nächtlicher Inkrement (rowversion-HWM).
- **Monitoring ohne Mailserver:** ETL-Status/Fehler in der UI (Bereich Verwaltung) + Logdatei;
  optional Desktop-Benachrichtigung. Kein SMTP nötig.
- **Backup/Restore:** verschlüsselte DB-Datei + Vault sichern (Nutzer-initiiert oder Task);
  Restore-Prozedur dokumentiert. **Update** der App ohne Admin (Dateiaustausch, Daten bleiben).
- Installation/No-Admin/Setup.exe/.bat: `docs/SETUP.md` + `installer/`.

### 13.8 openEHR-Entscheidung
**FHIR R4 ist primär** (Interoperabilität, Profile, Tooling). **openEHR** bleibt als optionale
zweite Ausleitung (`--openehr`, aktuell Composition-Vorstufe) für archetyp-basierte
Detailmodellierung — kein Blocker für v1, aktivierbar wenn ein openEHR-Repository angebunden wird.

---

## 14. Erweiterung: Dokument-Intelligence-Layer (Anzeige · Annotation · Analyse)

Gespeicherte Dokumente (MedDokAnhang-Scans, Fremdbriefe, docx/pdf) werden lesbar, mit
SNOMED CT (primär) sowie ICD-10-GM/LOINC/ATC kodiert und für die Analyse nutzbar gemacht.
Vollständige Bauanleitung: `docs/DOKUMENTE_ANNOTATION.md`. Module (Gerüst, verifiziert):
`agent/documents.py` (Typ per Magic-Bytes, Text, OCR-Hook), `agent/annotate.py`
(NER/Negation/Kontext, FHIR-Overlay + abgeleitete Condition/Observation),
`reference/terminology.py` (lokaler Katalog-Matcher + FHIR-Terminologieserver),
`agent/extract_anhaenge.py` (lokaler BLOB→Datei-Extraktor). UI: Tab „Dokumente" +
`ui/mockups/dokumentsicht.html` (Viewer mit Highlight); Analysetool-Kriterium
„Dokument-Konzept (SNOMED)". Klardaten/OCR/NLP laufen lokal in der Praxis; SNOMED-Lizenz
(BfArM/MLDS) vor Produktivbindung final prüfen.

---

## 15. Erweiterung: KI-Integration in alle Sichten

Arztbrief-Assistent, Transkription, KI-OCR/Embeddings, LLM-Ontologie-Annotation,
Wissensassistent (RAG über SOPs/AWMF-Leitlinien mit Zitierpflicht), NL→Kohorte und
NL→Auswertung im Analysetool sowie ein **Code Interpreter** (isolierte Python-Sandbox
je Session — Container-Profil auf bereitgestelltem Host, No-Admin-Fallback lokal).
Alle Aufrufe laufen über ein konfigurierbares Gateway
(fünf Kanäle: chat/embed/transcribe/ocr/code, Endpunkte werden von uns bereitgestellt),
mit Datenklassen-Policy je Kanal, Prompt-Gate, append-only-Audit und ai-provenance
an jedem Entwurf (Mensch bestätigt, nie Autopilot). Vollständige Bauanleitung mit
Umsetzungsstufen 0–4: `docs/KI_INTEGRATION.md`.
