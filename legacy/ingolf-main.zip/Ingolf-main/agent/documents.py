#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Textgewinnung aus Praxis-Anhaengen (MedDokAnhang) und Freitext-Dokumenten.

Verantwortlich fuer Schritt 1-2 des Dokument-Intelligence-Layers:
  (1) Dateityp zuverlaessig bestimmen -- per MAGIC BYTES, nicht per Dateiendung,
      weil in EUGASTRO viele FileName-Werte KEINE echte Endung haben (dort steht
      ein Zeitstempel wie '..._2024_09_03_25'). Endung ist bestenfalls ein Hinweis.
  (2) Volltext extrahieren: docx (Haupttyp, ~21.800 Stk), pdf (~1.760, teils Scan),
      rtf/txt; Bilder und Scan-PDFs ueber einen OCR-Hook.

Alle Abhaengigkeiten sind optional und werden defensiv importiert. Fehlt ein Parser,
liefert die Funktion (typ, "") zurueck statt zu crashen -- die Pipeline degradiert
sauber (Dokument wird angezeigt/gespeichert, aber nicht annotiert).
"""
from __future__ import annotations
from dataclasses import dataclass


# ---------------------------------------------------------------------------
# (1) Typ-Erkennung per Magic Bytes
# ---------------------------------------------------------------------------
def detect_type(data: bytes, filename: str | None = None) -> str:
    """Bestimmt den Dokumenttyp aus den ersten Bytes. Rueckgabe:
    'pdf' | 'docx' | 'doc' | 'rtf' | 'jpg' | 'png' | 'tiff' | 'gif' | 'txt' | 'empty' | 'unknown'.
    filename wird nur als schwacher Tie-Breaker genutzt."""
    if not data:
        return "empty"
    head = data[:16]
    if head[:5] == b"%PDF-":
        return "pdf"
    if head[:4] == b"PK\x03\x04":
        # ZIP-Container -> OOXML? docx erkennt man am [Content_Types].xml/word/
        low = data[:4000]
        if b"word/" in low or b"wordprocessingml" in low:
            return "docx"
        if b"ppt/" in low:
            return "pptx"
        if b"xl/" in low:
            return "xlsx"
        return "zip"
    if head[:5] == b"{\\rtf" or head[:4] == b"{\\rt":
        return "rtf"
    if head[:4] == b"\xD0\xCF\x11\xE0":          # OLE2 -> altes .doc
        return "doc"
    if head[:3] == b"\xFF\xD8\xFF":
        return "jpg"
    if head[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if head[:4] in (b"II*\x00", b"MM\x00*"):
        return "tiff"
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    # Text? (druckbare Bytes / UTF-8-dekodierbar)
    try:
        data[:512].decode("utf-8"); return "txt"
    except Exception:
        pass
    if filename and "." in filename:
        ext = filename.rsplit(".", 1)[-1].lower()
        if ext in ("pdf", "docx", "doc", "rtf", "txt", "jpg", "jpeg", "png", "tif", "tiff", "gif"):
            return "jpg" if ext == "jpeg" else ("tiff" if ext == "tif" else ext)
    return "unknown"


MIME = {"pdf": "application/pdf", "jpg": "image/jpeg", "png": "image/png",
        "tiff": "image/tiff", "gif": "image/gif", "doc": "application/msword",
        "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "rtf": "application/rtf", "txt": "text/plain", "empty": "application/octet-stream",
        "unknown": "application/octet-stream"}


# ---------------------------------------------------------------------------
# (2) Textextraktion
# ---------------------------------------------------------------------------
@dataclass
class ExtractResult:
    doctype: str
    text: str
    ocr_used: bool = False
    pages: int | None = None
    note: str = ""


def extract_text(data: bytes, filename: str | None = None,
                 ocr: bool = True, ocr_lang: str = "deu") -> ExtractResult:
    """Extrahiert Volltext. Waehlt den Parser anhand von detect_type()."""
    t = detect_type(data, filename)
    if t == "pdf":
        return _pdf(data, ocr, ocr_lang)
    if t == "docx":
        return ExtractResult(t, _docx(data))
    if t == "rtf":
        return ExtractResult(t, _rtf(data))
    if t == "txt":
        return ExtractResult(t, data.decode("utf-8", "replace"))
    if t in ("jpg", "png", "tiff", "gif"):
        txt = _ocr_image(data, ocr_lang) if ocr else ""
        return ExtractResult(t, txt, ocr_used=bool(txt))
    if t == "doc":
        return ExtractResult(t, _doc_legacy(data), note="altes .doc -> nur mit antiword/textract")
    if t == "empty":
        return ExtractResult(t, "", note="leerer Anhang (Platzhalter)")
    return ExtractResult(t, "", note="kein Parser fuer diesen Typ")


def _docx(data: bytes) -> str:
    try:
        import io, docx  # python-docx
        d = docx.Document(io.BytesIO(data))
        parts = [p.text for p in d.paragraphs]
        for tbl in d.tables:
            for row in tbl.rows:
                parts.append("\t".join(c.text for c in row.cells))
        return "\n".join(x for x in parts if x).strip()
    except Exception:
        # Fallback: XML aus dem ZIP direkt strippen
        try:
            import io, zipfile, re
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                xml = z.read("word/document.xml").decode("utf-8", "replace")
            xml = re.sub(r"</w:p>", "\n", xml)
            return re.sub(r"<[^>]+>", "", xml).strip()
        except Exception:
            return ""


def _rtf(data: bytes) -> str:
    txt = data.decode("latin-1", "replace")
    try:
        from striprtf.striprtf import rtf_to_text
        return rtf_to_text(txt).strip()
    except Exception:
        import re
        txt = re.sub(r"\\[a-z]+-?\d* ?", " ", txt)
        txt = re.sub(r"[{}]", " ", txt)
        return re.sub(r"\s+", " ", txt).strip()


def _pdf(data: bytes, ocr: bool, ocr_lang: str) -> ExtractResult:
    text, pages = "", None
    try:
        import io
        from pypdf import PdfReader
        r = PdfReader(io.BytesIO(data))
        pages = len(r.pages)
        text = "\n".join((p.extract_text() or "") for p in r.pages).strip()
    except Exception:
        try:
            from pdfminer.high_level import extract_text as pm
            import io
            text = (pm(io.BytesIO(data)) or "").strip()
        except Exception:
            text = ""
    # Scan-Heuristik: kaum Text trotz Seiten -> OCR
    if ocr and (len(text) < 40):
        otext = _ocr_pdf(data, ocr_lang)
        if otext:
            return ExtractResult("pdf", otext, ocr_used=True, pages=pages,
                                 note="Text via OCR (vermutlich Scan)")
    return ExtractResult("pdf", text, pages=pages)


def _ocr_pdf(data: bytes, lang: str) -> str:
    """Rasterisiert PDF-Seiten und OCR't sie. Braucht pdf2image+pytesseract+tesseract."""
    try:
        from pdf2image import convert_from_bytes
        import pytesseract
        imgs = convert_from_bytes(data, dpi=200)
        return "\n".join(pytesseract.image_to_string(im, lang=lang) for im in imgs).strip()
    except Exception:
        return ""


def _ocr_image(data: bytes, lang: str) -> str:
    try:
        import io, pytesseract
        from PIL import Image
        return pytesseract.image_to_string(Image.open(io.BytesIO(data)), lang=lang).strip()
    except Exception:
        return ""


def _doc_legacy(data: bytes) -> str:
    try:
        import textract, tempfile, os
        with tempfile.NamedTemporaryFile(suffix=".doc", delete=False) as f:
            f.write(data); path = f.name
        try:
            return textract.process(path).decode("utf-8", "replace").strip()
        finally:
            os.unlink(path)
    except Exception:
        return ""
