# -*- coding: utf-8 -*-
"""openEHR-Pfad (pragmatisch).

Erzeugt ein template-fertiges Zwischenformat je Patient: Compositions mit
Archetyp-Knoten fuer Diagnosen (EVALUATION.problem_diagnosis) und Laborwerte
(OBSERVATION.laboratory_test_result). Die Serialisierung nach openEHR-Canonical
oder Flat-JSON erfolgt beim Import in den CDR (EHRbase) ueber ein Operational
Template (OPT) — dieses Modul liefert die dafuer noetige strukturierte Vorstufe.
"""
from __future__ import annotations
from meddok import parse_detail


def build_compositions(pid, pseudonym, med_rows, labor_rows, privacy):
    comps = []

    # 1) Diagnosen
    diag = []
    for r in med_rows:
        if r.get("Kuerzel") not in ("D", "DD", "DDA", "DDAB", "FDD", "FD"):
            continue
        det = parse_detail(r.get("Detail"))
        if det.get("kind") != "diagnose" or not det.get("icd"):
            continue
        diag.append({
            "archetype_node_id": "openEHR-EHR-EVALUATION.problem_diagnosis.v1",
            "problem_diagnosis_name": det.get("text"),
            "problem_diagnosis_code": {"terminology": "ICD-10-GM", "code": det["icd"]},
            "diagnostic_certainty": det.get("sicherheit"),
            "date_clinically_recognised": privacy.shift(pid, r.get("ReferenceDateTime")),
        })
    if diag:
        comps.append({
            "composition": "openEHR-EHR-COMPOSITION.problem_list.v1",
            "subject": pseudonym, "content": diag,
        })

    # 2) Laborwerte
    import json
    labs = []
    for r in labor_rows:
        try:
            d = json.loads(r["Details"]) if r.get("Details") else {}
        except (ValueError, TypeError):
            continue
        if d.get("Ergebniswert") is None:
            continue
        labs.append({
            "archetype_node_id": "openEHR-EHR-OBSERVATION.laboratory_test_result.v1",
            "analyte_name": d.get("Testbezeichnung") or r.get("Kuerzel"),
            "analyte_code": r.get("Kuerzel"),
            "result_value": d.get("Ergebniswert"),
            "result_unit": d.get("Einheit"),
            "reference_range": d.get("NormalwertText"),
            "time": privacy.shift(pid, r.get("Datum")),
        })
    if labs:
        comps.append({
            "composition": "openEHR-EHR-COMPOSITION.report_result.v1",
            "subject": pseudonym, "content": labs,
        })

    return comps
