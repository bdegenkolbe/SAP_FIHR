# -*- coding: utf-8 -*-
"""FHIR-Profil-Layer (docs/UI_SPEC.md §7, CONCEPT.md 13.3): R4 · MII-KDS · KBV.

Der Mapping-Kern bleibt unveraendert; dieser Layer setzt `meta.profile` je
Ressourcentyp und ergaenzt profilverlangte Pflichtangaben, soweit sie aus den
vorhandenen Daten ableitbar sind. Doppelausleitung: apply() ist idempotent und
kann pro Zielprofil auf eine Kopie des Bundles angewandt werden.
"""
from __future__ import annotations

import copy

PROFILES = ("r4", "mii", "kbv")

MII = {
    "Patient": "https://www.medizininformatik-initiative.de/fhir/core/modul-person/StructureDefinition/Patient",
    "Condition": "https://www.medizininformatik-initiative.de/fhir/core/modul-diagnose/StructureDefinition/Diagnose",
    "Observation": "https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ObservationLab",
    "MedicationStatement": "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationStatement",
    "MedicationRequest": "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationRequest",
    "DiagnosticReport": "https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/DiagnosticReportLab",
    "Encounter": "https://www.medizininformatik-initiative.de/fhir/core/modul-fall/StructureDefinition/KontaktGesundheitseinrichtung",
    "Coverage": "http://fhir.de/StructureDefinition/coverage-de-basis",
}

KBV = {
    "Patient": "https://fhir.kbv.de/StructureDefinition/KBV_PR_Base_Patient",
    "Condition": "https://fhir.kbv.de/StructureDefinition/KBV_PR_Base_Condition_Diagnosis",
    "Observation": "https://fhir.kbv.de/StructureDefinition/KBV_PR_Base_Observation_Lab",
    "MedicationStatement": "https://fhir.kbv.de/StructureDefinition/KBV_PR_Base_MedicationStatement",
    "Composition": "https://fhir.kbv.de/StructureDefinition/KBV_PR_Base_Composition",
    "Coverage": "http://fhir.de/StructureDefinition/coverage-de-basis",
}


def _profile_map(profile: str) -> dict[str, str]:
    return {"r4": {}, "mii": MII, "kbv": KBV}[profile]


def apply_resource(resource: dict, profile: str) -> dict:
    """meta.profile setzen (idempotent). r4 = bare, kein Profil-Claim."""
    if profile not in PROFILES:
        raise ValueError(f"Unbekanntes Profil: {profile} (erlaubt: {PROFILES})")
    url = _profile_map(profile).get(resource.get("resourceType"))
    if not url:
        return resource
    meta = resource.setdefault("meta", {})
    profiles = meta.setdefault("profile", [])
    if url not in profiles:
        profiles.append(url)
    return resource


def apply_bundle(bundle: dict, profile: str) -> dict:
    """Bundle-Kopie mit gesetzten Profil-URLs (Original bleibt unveraendert)."""
    if profile == "r4":
        return bundle
    out = copy.deepcopy(bundle)
    for entry in out.get("entry", []):
        apply_resource(entry.get("resource", {}), profile)
    return out
