# -*- coding: utf-8 -*-
"""Assertion-Gate (CONCEPT.md 5.4): letzte Pruefung vor dem Schreiben des Exports.

Der Agent gibt im Pseudonymisierungs-/Anonymisierungsmodus keine
Klartext-Identifikatoren aus. Dieses Gate prueft jedes ausgehende Bundle
wertbasiert (bekannte Identifikatoren des Patienten aus der Quellzeile) und
musterbasiert (KVNR, E-Mail, Telefon).

Konfigurierbar fuer den In-Praxis-Betrieb (privacy-Config, s. Privacy-Klasse):
- gate: "enforce" (Verstoss = Abbruch) | "warn" (nur Warnung) | "off"
- Das Gate prueft nur, was die De-ID verspricht: ist free_text_deid abgeschaltet,
  werden narrative Felder/Titel nicht geprueft; ist keep_filenames aktiv, sind
  Anhang-Dateinamen ausgenommen. Strukturfelder bleiben immer geschuetzt.
- Bei mode=off (Klardaten, interner Praxis-Store) ist das Gate inaktiv.
"""
from __future__ import annotations

import re
import sys
from typing import Any, Iterator

# Musterbasierte Checks (unabhaengig vom konkreten Patienten)
_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("Versichertennummer (KVNR)", re.compile(r"\b[A-Z]\d{9}\b")),
    ("E-Mail-Adresse", re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]{2,}\b")),
    ("Telefonnummer", re.compile(r"(?<!\d)(?:\+49[\d /()-]{7,}\d|0\d{3,4}[ /-]\d{5,})(?!\d)")),
]

# Quellspalten, deren Werte im Ausgang niemals auftauchen duerfen
_IDENTIFIER_COLUMNS = ("Name", "Vorname", "Geburtsname", "Strasse", "Wohnort",
                       "PatientNr", "VersichertenNr")

# Feldnamen mit narrativem Inhalt/Titeln: nur geprueft, wenn free_text_deid aktiv
_NARRATIVE_KEYS = {"valueString", "conclusion", "description", "text", "div",
                   "data", "title", "display", "shortinfo", "info"}


class GateViolation(Exception):
    pass


def _strings(obj: Any, path: str = "$") -> Iterator[tuple[str, str]]:
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from _strings(v, f"{path}.{k}")
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            yield from _strings(v, f"{path}[{i}]")
    elif isinstance(obj, str):
        yield path, obj


def _identifier_patterns(patient_row: dict | None) -> list[tuple[str, re.Pattern]]:
    out = []
    for col in _IDENTIFIER_COLUMNS:
        value = (patient_row or {}).get(col)
        if value is None:
            continue
        value = str(value).strip()
        if len(value) < 3:      # zu kurz fuer verlaesslichen Match (z.B. Hausnummern)
            continue
        # Kein \b: Unterstriche zaehlen als Wortzeichen und wuerden Treffer in
        # Dateinamen ("Sono_Nachname_2024.pdf") verfehlen. Grenze = kein Alnum.
        boundary_l = r"(?<![A-Za-z0-9ÄÖÜäöüß])"
        boundary_r = r"(?![A-Za-z0-9ÄÖÜäöüß])"
        out.append((f"Quellwert {col}",
                    re.compile(boundary_l + re.escape(value) + boundary_r, re.IGNORECASE)))
    return out


def _exempt(path: str, free_text_deid: bool, keep_filenames: bool) -> bool:
    last_key = path.rsplit(".", 1)[-1]
    if keep_filenames and path.endswith("attachment.title"):
        return True
    if not free_text_deid and last_key in _NARRATIVE_KEYS:
        return True
    return False


def check(objects: Any, patient_row: dict | None = None,
          free_text_deid: bool = True, keep_filenames: bool = False) -> list[str]:
    """Liefert Liste der Verstoesse (leer = sauber)."""
    checks = _PATTERNS + _identifier_patterns(patient_row)
    violations = []
    for path, text in _strings(objects):
        if _exempt(path, free_text_deid, keep_filenames):
            continue
        for label, pattern in checks:
            if pattern.search(text):
                violations.append(f"{label} im Klartext: {path}")
    return violations


def assert_clean(objects: Any, patient_row: dict | None, privacy: Any) -> None:
    """Vor dem Schreiben aufrufen. `privacy` ist eine Privacy-Instanz oder ein
    Modus-String (dann Default-Policy: enforce, alle Schichten aktiv)."""
    if isinstance(privacy, str):
        mode, policy, free_text_deid, keep_filenames = privacy, "enforce", True, False
    else:
        mode = privacy.mode
        policy = getattr(privacy, "gate", "enforce")
        free_text_deid = getattr(privacy, "free_text_deid", True)
        keep_filenames = getattr(privacy, "keep_filenames", False)

    if mode == "off" or policy == "off":
        return  # Klardaten nur intern bzw. Gate explizit deaktiviert
    violations = check(objects, patient_row,
                       free_text_deid=free_text_deid, keep_filenames=keep_filenames)
    if not violations:
        return
    preview = "\n  - ".join(violations[:20])
    if policy == "warn":
        sys.stderr.write(f"[GATE-WARNUNG] {len(violations)} potenzielle "
                         f"Klartext-Funde (Export laeuft weiter):\n  - {preview}\n")
        return
    raise GateViolation(
        f"Assertion-Gate: {len(violations)} Verstoss/Verstoesse - "
        f"Export abgebrochen:\n  - {preview}"
    )
