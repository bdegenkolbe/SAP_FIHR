# -*- coding: utf-8 -*-
"""FHIR-R4-Mapper je Domaene.

Jede Funktion nimmt einen ExportContext + bereits geladene Quellzeilen (list[dict])
und liefert eine Liste von Bundle-Entries {"fullUrl", "resource"}.
Datumswerte laufen durch ctx.d() (Date-Shift bei Pseudonymisierung).
"""
from __future__ import annotations
import datetime as _date_mod
import uuid as _uuid


def _today() -> str:
    """Heutiges Datum (ISO) fuer Status-Ableitungen (z. B. ReichtBis abgelaufen)."""
    return _date_mod.date.today().isoformat()
from meddok import (parse_detail, strip_html, parse_formularvariablen,
                    formular_datum, formular_diagnosen)

# --- Kodier-Systeme --------------------------------------------------------
SYS_ICD = "http://fhir.de/CodeSystem/bfarm/icd-10-gm"
SYS_ATC = "http://fhir.de/CodeSystem/bfarm/atc"
SYS_PZN = "http://fhir.de/CodeSystem/ifa/pzn"
SYS_LOINC = "http://loinc.org"
SYS_OBSCAT = "http://terminology.hl7.org/CodeSystem/observation-category"
SYS_EBM = "http://fhir.de/CodeSystem/kbv/ebm"      # sofern verfuegbar
SYS_LOCAL = "https://eugastro.local"

# Geschlecht (systemspezifisch! in dieser DB: 2=maennlich, 1=weiblich) -----
GENDER = {1: "female", 2: "male", 3: "other", 4: "other", 0: "unknown"}

# eAU-Uebertragungsstatus (Eau.State, inhaltlich belegt: Gutachten 2.1) ------
EAU_STATE = {0: "neu", 1: "versendet-wartet-quittung", 3: "zwischenstatus-fehler",
             5: "storniert", 6: "versendet-antwort-laeuft", 7: "abgeschlossen"}

# KBV-Diagnosesicherheit -> FHIR clinical/verification ----------------------
SICH = {
    "G": ("active", "confirmed"),
    "V": ("active", "provisional"),
    "Z": ("active", "differential"),   # "Zustand nach" / Verdacht
    "A": ("inactive", "refuted"),
}

# LOINC fuer haeufige Labor-Analyte (best effort; Rest: lokaler Code) -------
LAB_LOINC = {
    "LEUK": "6690-2", "ERY": "789-8", "HB": "718-7", "HCT": "4544-3", "MCV": "787-2",
    "MCH": "785-6", "MCHC": "786-4", "THRO": "777-3", "KREA": "2160-0", "HST": "3094-0",
    "GOT": "1920-8", "GPT": "1742-6", "GGT": "2324-2", "AP": "6768-6", "LDH": "2532-0",
    "CHOL": "2093-3", "HDL": "2085-9", "LDL": "2089-1", "TRI": "2571-8", "BZG": "2345-7",
    "TSH": "3016-3", "CRP": "1988-5", "FERR": "2276-4", "HBA1C": "4548-4", "GFR": "48642-3",
    "INR": "6301-6", "QUICK": "5894-1", "VD25": "1989-3", "VB12": "2132-9", "FOL": "2284-8",
}

# Narrative Kategorien -> FHIR-Abbildung ------------------------------------
NARRATIVE = {
    "A": ("Anamnese", "exam"), "V": ("Aktuelle Anamnese und Verlauf", "exam"),
    "FASA": ("Familien-/Sozialanamnese", "social-history"),
    "AVA": ("Allgemeine/Vegetative Anamnese", "exam"),
    "B": ("Klinischer Erstbefund", "exam"),
    "PROC": ("Prozedere", "therapy"), "I": ("Fragestellung", "exam"),
    "TH": ("Therapie", "therapy"), "THV": ("Therapieverlauf", "therapy"),
}
# Fachliche Befunde (Endoskopie/Sono/Fibroscan) -> DiagnosticReport ---------
FINDINGS = {
    "SONO": "Abdomensonographie", "FIBRO": "Fibroscan", "FBEUR": "Fibroscan-Beurteilung",
    "PROCT": "Proktoskopie", "COLO": "Koloskopie", "GASTR": "Gastroskopie", "URIN": "Urinstix",
}
# Arztbriefe / Epikrisen -> Composition -------------------------------------
LETTERS = {"BRIEF": "Arztbrief", "EAB": "eArztbrief", "E": "Epikrise"}
# AU-Bescheinigungen -> DocumentReference (eAU) -----------------------------
AU_CATS = {"AU": "Arbeitsunfaehigkeitsbescheinigung", "ALTAU": "AU (Altbestand)",
           "AFAU": "AU-Fortbestehen (Kassenbericht)"}
# Sonstige Dokumente -> DocumentReference -----------------------------------
DOCS = {"KRANK": "Krankenhauseinweisung", "KHB": "Verordnung Krankenhausbehandlung",
        "MDOK": "Archivdokument"}


class ExportContext:
    def __init__(self, pid, pseudonym, subject_ref, privacy):
        self.pid = pid
        self.pseudonym = pseudonym
        self.subject = {"reference": subject_ref}
        self.privacy = privacy

    def uid(self, *parts) -> str:
        key = "eugastro-" + self.pseudonym + "-" + "-".join(str(p) for p in parts)
        return "urn:uuid:" + str(_uuid.uuid5(_uuid.NAMESPACE_DNS, key))

    def d(self, iso):
        return self.privacy.shift(self.pid, iso)

    def txt(self, s):
        return self.privacy.text(self.pid, s)

    def hash_id(self, value, label="id"):
        return self.privacy.hash_id(value, label)


def _entry(ctx, res, *idparts):
    u = ctx.uid(*idparts)
    res["id"] = u.split(":")[-1]
    return {"fullUrl": u, "resource": res}


# ===========================================================================
# 1) Patient
# ===========================================================================
def map_patient(ctx, row: dict) -> dict:
    y, m, dd = row.get("Geburtsjahr"), row.get("Geburtsmonat"), row.get("Geburtstag")
    birth = None
    if y:
        birth = f"{int(y):04d}"
        if m and dd:
            birth = f"{int(y):04d}-{int(m):02d}-{int(dd):02d}"
    res = {
        "resourceType": "Patient",
        "identifier": [{"system": f"{SYS_LOCAL}/patient-nr", "value": str(row.get("PatientNr"))}],
        "active": row.get("VerstorbenAm") is None,
        "name": [{"use": "official", "family": row.get("Name"),
                  "given": [g for g in [row.get("Vorname")] if g],
                  "prefix": [row["Titel"]] if row.get("Titel") else None}],
        "gender": GENDER.get(row.get("Geschlecht"), "unknown"),
        "birthDate": birth,
    }
    strasse = " ".join(x for x in [row.get("Strasse"), row.get("Hausnummer")] if x)
    if strasse or row.get("Wohnort"):
        res["address"] = [{"use": "home", "type": "physical",
                           "line": [strasse] if strasse else None,
                           "city": row.get("Wohnort"), "postalCode": row.get("Postleitzahl"),
                           "country": row.get("Laenderkennzeichen") or "DE"}]
    if row.get("VerstorbenAm"):
        res["deceasedDateTime"] = ctx.d(row["VerstorbenAm"])
    # None-Felder aufraeumen
    _clean(res)
    ctx.privacy.redact_patient(res, ctx.pid)
    res["id"] = ctx.pseudonym
    return res


# ===========================================================================
# 2) Diagnosen -> Condition (Kategorien D/DD/DDA/DDAB/FDD/FD)
# ===========================================================================
def map_conditions(ctx, rows: list[dict]) -> list[dict]:
    out = []
    for r in rows:
        det = parse_detail(r.get("Detail"), r.get("Kuerzel"))
        if det.get("kind") != "diagnose" or not det.get("icd"):
            continue
        cs, vs = SICH.get(det.get("sicherheit", ""), ("active", "unconfirmed"))
        kuerzel = r.get("Kuerzel")
        # Dauerdiagnose behandlungsrelevant -> problem-list; Akut -> encounter-diagnosis
        cat = "problem-list-item" if kuerzel in ("DD", "DDA", "FDD", "FD") else "encounter-diagnosis"
        if kuerzel == "DDAB":
            cs = "inactive"
        res = {
            "resourceType": "Condition",
            "clinicalStatus": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/condition-clinical", "code": cs}]},
            "verificationStatus": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/condition-ver-status", "code": vs}]},
            "category": [{"coding": [{"system": "http://terminology.hl7.org/CodeSystem/condition-category", "code": cat}]}],
            "code": {"coding": [{"system": SYS_ICD, "code": det["icd"], "display": det.get("text")}],
                     "text": det.get("text")},
            "subject": ctx.subject,
            "recordedDate": ctx.d(r.get("ReferenceDateTime")),
            "note": [{"text": f"Diagnosesicherheit (KBV): {det.get('sicherheit')}"}],
        }
        if r.get("Id_Schein"):
            res["encounter"] = {"reference": ctx.uid("enc", r["Id_Schein"])}
        _clean(res)
        out.append(_entry(ctx, res, "cond", r["Id"]))
    return out


# ===========================================================================
# 3) Besuche/Faelle -> Encounter + Ueberweisung(en) -> ServiceRequest + Claim
# ===========================================================================
def map_scheine(ctx, scheine: list[dict], leistungen_by_schein: dict) -> list[dict]:
    out = []
    for s in scheine:
        sid = s["Id"]
        start = ctx.d(s.get("AusstellungsDateTime") or s.get("ScheinGueltigVon"))
        enc = {
            "resourceType": "Encounter",
            "status": "finished",
            "class": {"system": "http://terminology.hl7.org/CodeSystem/v3-ActCode",
                      "code": "IMP" if s.get("IsStationaer") else "AMB"},
            "type": [{"coding": [{"system": f"{SYS_LOCAL}/scheinart", "code": str(s.get("Scheinart")),
                                  "display": s.get("Scheinuntergruppe")}]}],
            "subject": ctx.subject,
            "period": {"start": start},
        }
        if s.get("DiagnoseVerdacht"):
            enc["reasonCode"] = [{"text": ctx.txt(s["DiagnoseVerdacht"])}]
        # Eingehende Ueberweisung (Ueberweisungsfall)
        if s.get("UeberweisungVon"):
            enc.setdefault("extension", []).append(
                {"url": f"{SYS_LOCAL}/ueberweisung-von", "valueString": ctx.txt(s["UeberweisungVon"])})
        _clean(enc)
        out.append(_entry(ctx, enc, "enc", sid))

        # Weiterueberweisung / Zielauftrag -> ServiceRequest (ausgehend)
        if s.get("UeberweisungAn") or s.get("WeiterbehandelnderArzt") or s.get("IsZielauftrag"):
            sr = {
                "resourceType": "ServiceRequest",
                "status": "completed",
                "intent": "order",
                "category": [{"coding": [{"system": "http://snomed.info/sct", "code": "3457005",
                                          "display": "Patient referral"}]}],
                "subject": ctx.subject,
                "encounter": {"reference": ctx.uid("enc", sid)},
                "authoredOn": start,
                "code": {"text": ctx.txt(s.get("Auftrag") or "Ueberweisung")},
            }
            ziel = s.get("UeberweisungAn") or s.get("WeiterbehandelnderArzt")
            if ziel:
                sr["performer"] = [{"display": ctx.txt(ziel)}]
            if s.get("LanrUeberweiser") or s.get("BsnrUeberweiser"):
                sr["requester"] = {"identifier": {"system": f"{SYS_LOCAL}/lanr",
                                                  "value": s.get("LanrUeberweiser")}}
            _clean(sr)
            out.append(_entry(ctx, sr, "referral", sid))

        # GKV-/Privat-Abrechnung -> Claim (Leistungen dieses Scheins)
        items = leistungen_by_schein.get(sid, [])
        if items:
            # Abrechnungsweg: primaer Schein.AbrechnungsArt (Gutachten 1.1:
            # 1=GKV, 2=Privat/IGeL - IsIgel trennt, 3=BG/Unfall). Fallback fuer
            # andere Installationen ohne AbrechnungsArt: alte Kennzeichen.
            art = s.get("AbrechnungsArt")
            if art == 2:
                subtype = "IGeL" if s.get("IsIgel") else "Privat"
            elif art == 3:
                subtype = "BG/Unfall"
            elif art == 1:
                subtype = "GKV"
            elif s.get("IsIgel"):
                subtype = "IGeL"
            elif s.get("IsPrivat") or s.get("RechnungsTyp"):
                subtype = "Privat"
            elif s.get("HzvVertragKennung"):
                subtype = "HZV/Selektivvertrag"
            else:
                subtype = "GKV"
            claim = {
                "resourceType": "Claim",
                "status": "active",
                "type": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/claim-type",
                                     "code": "professional"}]},
                "subType": {"coding": [{"system": f"{SYS_LOCAL}/abrechnungsweg", "code": subtype}]},
                "use": "claim",
                "patient": ctx.subject,
                "created": start,
                "billablePeriod": {"start": ctx.d(s.get("Quartal"))},
                "insurance": [{"sequence": 1, "focal": True,
                               "coverage": {"display": s.get("KassenName") or subtype}}],
                "item": [],
            }
            if s.get("HzvVertragKennung") or s.get("HonorarAnlageId"):
                claim.setdefault("extension", []).append(
                    {"url": f"{SYS_LOCAL}/vertragskennung",
                     "valueString": str(s.get("HonorarAnlageId") or s.get("HzvVertragKennung"))})
            for i, L in enumerate(items, 1):
                claim["item"].append({
                    "sequence": i,
                    "productOrService": {"coding": [{"system": SYS_EBM, "code": L["ziffer"]}],
                                         "text": L["ziffer"]},
                    "quantity": {"value": _num(L.get("multiplikator"), 1)},
                    "servicedDate": ctx.d(L.get("date")),
                })
            _clean(claim)
            out.append(_entry(ctx, claim, "claim", sid))
    return out


# ===========================================================================
# 4) Termine -> Appointment
# ===========================================================================
def map_appointments(ctx, rows: list[dict]) -> list[dict]:
    out = []
    for r in rows:
        if r.get("IsMarkedAsCancelled") or r.get("IsDeleted"):
            status = "cancelled"
        elif r.get("AppointmentKept"):
            status = "fulfilled"
        else:
            status = "booked"
        res = {
            "resourceType": "Appointment",
            "status": status,
            "description": r.get("Subject"),
            "start": ctx.d(r.get("StartDateTime")),
            "end": ctx.d(r.get("EndDateTime")),
            "comment": ctx.txt(r.get("BesuchsgrundText") or r.get("Info")),
            "participant": [{"actor": ctx.subject, "status": "accepted"}],
        }
        _clean(res)
        out.append(_entry(ctx, res, "appt", r["Id"]))
    return out


# ===========================================================================
# 5) Narrative (Anamnese/Befund/Verlauf/Epikrise/...) -> Observation
# ===========================================================================
def map_narrative(ctx, rows: list[dict]) -> list[dict]:
    out = []
    for r in rows:
        k = r.get("Kuerzel")
        disp, cat = NARRATIVE.get(k, (k, "exam"))
        det = parse_detail(r.get("Detail"), k)
        text = ctx.txt(det.get("text"))
        if not text:
            continue
        res = {
            "resourceType": "Observation",
            "status": "final",
            "category": [{"coding": [{"system": SYS_OBSCAT, "code": cat}]}],
            "code": {"coding": [{"system": f"{SYS_LOCAL}/meddok", "code": k, "display": disp}], "text": disp},
            "subject": ctx.subject,
            "effectiveDateTime": ctx.d(r.get("ReferenceDateTime")),
            "valueString": text,
        }
        if r.get("Id_Schein"):
            res["encounter"] = {"reference": ctx.uid("enc", r["Id_Schein"])}
        _clean(res)
        out.append(_entry(ctx, res, "narr", r["Id"]))
    return out


# ===========================================================================
# 6) Fachbefunde (Endoskopie/Sono/Fibroscan) -> DiagnosticReport
# ===========================================================================
def map_findings(ctx, rows: list[dict]) -> list[dict]:
    out = []
    for r in rows:
        k = r.get("Kuerzel")
        det = parse_detail(r.get("Detail"), k)
        text = ctx.txt(det.get("text"))
        res = {
            "resourceType": "DiagnosticReport",
            "status": "final",
            "category": [{"coding": [{"system": f"{SYS_LOCAL}/befundtyp", "code": k}]}],
            "code": {"text": FINDINGS.get(k, k)},
            "subject": ctx.subject,
            "effectiveDateTime": ctx.d(r.get("ReferenceDateTime")),
            "conclusion": text,
        }
        if r.get("Id_Schein"):
            res["encounter"] = {"reference": ctx.uid("enc", r["Id_Schein"])}
        _clean(res)
        out.append(_entry(ctx, res, "find", r["Id"]))
    return out


# ===========================================================================
# 7) Dokumente -> DocumentReference
# ===========================================================================
def map_documents(ctx, rows: list[dict]) -> list[dict]:
    import base64
    out = []
    for r in rows:
        k = r.get("Kuerzel")
        det = parse_detail(r.get("Detail"), k)
        text = ctx.txt(det.get("text"))
        # Volltext bleibt vollstaendig erhalten (base64 im Attachment); die
        # description ist nur die Kurzfassung fuer Listenansichten.
        attachment = {"contentType": "text/plain; charset=utf-8", "title": DOCS.get(k, k)}
        if text:
            attachment["data"] = base64.b64encode(text.encode("utf-8")).decode("ascii")
        res = {
            "resourceType": "DocumentReference",
            "status": "current",
            "type": {"coding": [{"system": f"{SYS_LOCAL}/dokumenttyp", "code": k}],
                     "text": DOCS.get(k, k)},
            "subject": ctx.subject,
            "date": ctx.d(r.get("ReferenceDateTime")),
            "content": [{"attachment": attachment}],
            "description": text[:280] if text else None,
        }
        _clean(res)
        out.append(_entry(ctx, res, "doc", r["Id"]))
    return out


# ===========================================================================
# 7b) Arztbriefe / Epikrisen -> Composition (voller Text)
# ===========================================================================
def map_arztbriefe(ctx, rows: list[dict]) -> list[dict]:
    out = []
    for r in rows:
        k = r.get("Kuerzel")
        det = parse_detail(r.get("Detail"), k)
        text = ctx.txt(det.get("text"))
        if not text:
            continue
        res = {
            "resourceType": "Composition",
            "status": "final",
            "type": {"coding": [{"system": "http://loinc.org",
                                 "code": "11488-4" if k != "E" else "11490-0",
                                 "display": LETTERS.get(k, k)}], "text": LETTERS.get(k, k)},
            "subject": ctx.subject,
            "date": ctx.d(r.get("ReferenceDateTime")),
            "title": LETTERS.get(k, k),
            "section": [{"title": LETTERS.get(k, k),
                         "text": {"status": "generated", "div": f"<div xmlns=\"http://www.w3.org/1999/xhtml\">{text}</div>"}}],
        }
        if r.get("Id_Schein"):
            res["encounter"] = {"reference": ctx.uid("enc", r["Id_Schein"])}
        _clean(res)
        out.append(_entry(ctx, res, "letter", r["Id"]))
    return out


# ===========================================================================
# 7c) Arbeitsunfaehigkeit (eAU) -> DocumentReference + geparste AU-Eckdaten
#     MedDok AU/ALTAU/AFAU (<meddokformular> shortinfo) + optional Eau-Status.
# ===========================================================================
def map_au(ctx, rows: list[dict], eau_by_meddok: dict | None = None,
           fv_by_meddok: dict | None = None) -> list[dict]:
    import re
    eau_by_meddok = eau_by_meddok or {}
    fv_by_meddok = fv_by_meddok or {}
    out = []
    for r in rows:
        k = r.get("Kuerzel")
        det = parse_detail(r.get("Detail"), k)
        raw = det.get("shortinfo") or det.get("text") or ""   # Rohtext fuer Extraktion
        info = ctx.txt(raw)                                     # de-identifiziert fuer Description
        seit = None
        # 1) Strukturierte Formularvariablen bevorzugen
        fv = fv_by_meddok.get(r.get("Id"))
        if fv:
            au = au_from_formularvariablen(ctx, fv)
            bis, seit, folge, icds = au["bis"], au["seit"], au["folge"], au["icds"]
            is_eau = au["is_eau"]
        else:
            # 2) Fallback: aus ROH-shortinfo extrahieren (vor De-ID)
            bis, is_eau = None, False
            m = re.search(r"bis\s+(\d{1,2}\.\d{1,2}\.\d{2,4})", raw)
            if m:
                try:
                    d, mo, y = m.group(1).split(".")
                    y = ("20" + y) if len(y) == 2 else y
                    bis = ctx.d(f"{int(y):04d}-{int(mo):02d}-{int(d):02d}")
                except ValueError:
                    pass
            icds = re.findall(r"[A-Z]\d{2}(?:\.\d{1,2})?", raw)
            folge = bool(re.search(r"Folge", raw, re.I))
        res = {
            "resourceType": "DocumentReference",
            "status": "current",
            "type": {"coding": [{"system": f"{SYS_LOCAL}/dokumenttyp", "code": "eAU"}],
                     "text": AU_CATS.get(k, "Arbeitsunfaehigkeitsbescheinigung")},
            "category": [{"text": "Folgebescheinigung" if folge else "Erstbescheinigung"}],
            "subject": ctx.subject,
            "date": ctx.d(r.get("ReferenceDateTime")),
            "description": info,
            "content": [{"attachment": {"contentType": "text/plain", "title": "eAU"}}],
        }
        start = seit or ctx.d(r.get("ReferenceDateTime"))
        if bis or start:
            res["context"] = {"period": {"start": start, "end": bis}}
        if icds:
            res.setdefault("extension", []).append(
                {"url": f"{SYS_LOCAL}/au-diagnosen", "valueString": ",".join(sorted(set(icds)))})
        if is_eau:
            res.setdefault("extension", []).append(
                {"url": f"{SYS_LOCAL}/is-eau", "valueBoolean": True})
        # Uebertragungsstatus aus Eau (Enum belegt, Gutachten 2.1)
        eau = eau_by_meddok.get(r.get("Id"))
        if eau:
            state = eau.get("State")
            res.setdefault("extension", []).append(
                {"url": f"{SYS_LOCAL}/eau-status",
                 "valueString": EAU_STATE.get(state, str(state))})
            if eau.get("IkNr"):
                res.setdefault("extension", []).append(
                    {"url": f"{SYS_LOCAL}/eau-kasse-iknr", "valueString": eau["IkNr"]})
        _clean(res)
        out.append(_entry(ctx, res, "au", r["Id"]))
    return out


# ===========================================================================
# 7d) ePA-Austausch -> DocumentReference (EpaEventLog + EpaDocumentMeta)
#     Optional (config). Bildet ab, welche Dokumente wann mit der ePA
#     ausgetauscht wurden (Richtung via IsUpload). Klinischer Inhalt selbst
#     wird bereits aus den Quelltabellen (Labor/MedDok/...) exportiert.
# ===========================================================================
def map_epa(ctx, rows: list[dict]) -> list[dict]:
    import json
    out = []
    for r in rows:
        meta = {}
        if r.get("DocumentMetaJson"):
            try:
                meta = json.loads(r["DocumentMetaJson"])
            except (ValueError, TypeError):
                meta = {}
        # ePA-Dokumenttitel koennen Namen tragen -> immer de-identifizieren
        title = ctx.txt(meta.get("title") or meta.get("Title")
                        or meta.get("typeDisplay")) or "ePA-Dokument"
        res = {
            "resourceType": "DocumentReference",
            "status": "current",
            "docStatus": "final",
            "type": {"text": title},
            "category": [{"text": "ePA-Upload" if r.get("IsUpload") else "ePA-Download"}],
            "subject": ctx.subject,
            "date": ctx.d(r.get("EventStartDateTime") or r.get("DocumentCreationDateTime")),
            "identifier": [{"system": f"{SYS_LOCAL}/epa-doc", "value": str(r.get("DocumentUniqueId"))}]
                          if r.get("DocumentUniqueId") else None,
            "content": [{"attachment": {"title": title}}],
        }
        _clean(res)
        out.append(_entry(ctx, res, "epa", r.get("EventId") or r.get("Id")))
    return out


# ===========================================================================
# 8) Labor -> Observation + DiagnosticReport (Laborbogen, JSON-Details)
# ===========================================================================
def map_labor(ctx, rows: list[dict]) -> list[dict]:
    import json
    out = []
    headers: dict = {}
    for r in rows:
        try:
            det = json.loads(r["Details"]) if r.get("Details") else {}
        except (ValueError, TypeError):
            continue
        # Gutachten 3.1: qualitative Befunde ("positiv/negativ") tragen nur
        # ErgebnisText - ohne Fallback gingen 6,9 % der Befunde verloren.
        val = det.get("Ergebniswert")
        if val is None:
            val = det.get("ErgebnisText")
        if val is None or str(val).strip() == "":
            continue
        k = r.get("Kuerzel")
        name = (det.get("Testbezeichnung") or k or "").strip()
        unit = (det.get("Einheit") or "").strip()
        coding = [{"system": f"{SYS_LOCAL}/labor-test", "code": k, "display": name}]
        if k in LAB_LOINC:
            coding.insert(0, {"system": SYS_LOINC, "code": LAB_LOINC[k], "display": name})
        obs = {
            "resourceType": "Observation", "status": "final",
            "category": [{"coding": [{"system": SYS_OBSCAT, "code": "laboratory"}]}],
            "code": {"coding": coding, "text": name},
            "subject": ctx.subject,
            "effectiveDateTime": ctx.d(r.get("Datum")),
        }
        try:
            obs["valueQuantity"] = {"value": float(str(val).replace(",", ".")),
                                    "unit": unit, "system": "http://unitsofmeasure.org", "code": unit}
        except ValueError:
            obs["valueString"] = str(val)
        gi = (r.get("Grenzwertindikator") or "").strip()
        iv = {"+": "H", "-": "L", "!": "A"}.get(gi)
        if iv:
            obs["interpretation"] = [{"coding": [{"system": "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation", "code": iv}]}]
        nw = det.get("NormalwertText")
        if nw:
            obs["referenceRange"] = [{"text": nw}]
        _clean(obs)
        e = _entry(ctx, obs, "lab", r.get("Id_LaborHeader"), k, r["Id"])
        out.append(e)
        h = r.get("Id_LaborHeader")
        headers.setdefault(h, {"date": ctx.d(r.get("Datum")), "refs": []})
        headers[h]["refs"].append({"reference": e["fullUrl"]})

    for h, info in headers.items():
        rep = {
            "resourceType": "DiagnosticReport", "status": "final",
            "category": [{"coding": [{"system": "http://terminology.hl7.org/CodeSystem/v2-0074", "code": "LAB"}]}],
            "code": {"coding": [{"system": SYS_LOINC, "code": "11502-2", "display": "Laboratory report"}],
                     "text": f"Laborbefund (Sitzung {h})"},
            "subject": ctx.subject, "effectiveDateTime": info["date"], "issued": info["date"],
            "result": info["refs"],
        }
        _clean(rep)
        out.append(_entry(ctx, rep, "labreport", h))
    return out


# ===========================================================================
# 9) Vitalwerte -> Observation (Record + Value + Parameter)
# ===========================================================================
VITAL_LOINC = {
    "Größe": ("8302-2", "Body height"), "Groesse": ("8302-2", "Body height"),
    "Gewicht": ("29463-7", "Body weight"), "BMI": ("39156-5", "BMI"),
    "Blutdruck systolisch": ("8480-6", "Systolic BP"),
    "Blutdruck diastolisch": ("8462-4", "Diastolic BP"),
    "Puls": ("8867-4", "Heart rate"), "Temperatur": ("8310-5", "Body temperature"),
}
# Blutdruck (Gutachten 2.3): Vitalparameter Id 5 = systolisch, Id 6 = diastolisch,
# beide am selben Record -> EIN Observation mit Komponenten (LOINC 85354-9).
BP_SYS_ID, BP_DIA_ID = 5, 6


def _map_blutdruck(ctx, rec_id, sys_row, dia_row) -> dict | None:
    def num(row):
        try:
            return float(str(_pick(row, "Wert", "Value", "Messwert", "Ergebnis")
                              ).replace(",", "."))
        except (TypeError, ValueError):
            return None
    sys_v, dia_v = num(sys_row), num(dia_row)
    if sys_v is None or dia_v is None:
        return None
    comp = lambda code, disp, v: {"code": {"coding": [{"system": SYS_LOINC,
        "code": code, "display": disp}]}, "valueQuantity": {
        "value": v, "unit": "mmHg", "system": "http://unitsofmeasure.org", "code": "mm[Hg]"}}
    res = {
        "resourceType": "Observation", "status": "final",
        "category": [{"coding": [{"system": SYS_OBSCAT, "code": "vital-signs"}]}],
        "code": {"coding": [{"system": SYS_LOINC, "code": "85354-9",
                             "display": "Blood pressure panel"}], "text": "Blutdruck"},
        "subject": ctx.subject,
        "effectiveDateTime": ctx.d(sys_row.get("Datum")),
        "component": [comp("8480-6", "Systolic blood pressure", sys_v),
                      comp("8462-4", "Diastolic blood pressure", dia_v)],
    }
    _clean(res)
    return _entry(ctx, res, "vital-rr", rec_id)


def map_vitals(ctx, rows: list[dict]) -> list[dict]:
    out = []
    # RR-Paare je Record herausziehen (Rest laeuft einzeln weiter)
    bp_by_rec: dict = {}
    for r in rows:
        vp = r.get("Id_Vitalparameter")
        if r.get("RecordId") is not None and vp in (BP_SYS_ID, BP_DIA_ID):
            bp_by_rec.setdefault(r["RecordId"], {})[vp] = r
    paired_ids = set()
    for rec_id, pair in bp_by_rec.items():
        if BP_SYS_ID in pair and BP_DIA_ID in pair:
            e = _map_blutdruck(ctx, rec_id, pair[BP_SYS_ID], pair[BP_DIA_ID])
            if e:
                out.append(e)
                paired_ids.update(x.get("Id") for x in pair.values())
    for r in rows:
        if r.get("Id") in paired_ids:
            continue
        name = (r.get("DisplayName") or r.get("Name") or "").strip()
        val = _pick(r, "Wert", "Value", "Messwert", "Ergebnis")
        if val is None:
            continue
        loinc = VITAL_LOINC.get(name)
        code = {"coding": [{"system": SYS_LOINC, "code": loinc[0], "display": loinc[1]}], "text": name} \
            if loinc else {"coding": [{"system": f"{SYS_LOCAL}/vital", "code": name}], "text": name}
        unit = (r.get("Masseinheit") or "").strip()
        res = {
            "resourceType": "Observation", "status": "final",
            "category": [{"coding": [{"system": SYS_OBSCAT, "code": "vital-signs"}]}],
            "code": code, "subject": ctx.subject,
            "effectiveDateTime": ctx.d(r.get("Datum")),
        }
        try:
            res["valueQuantity"] = {"value": float(str(val).replace(",", ".")), "unit": unit,
                                    "system": "http://unitsofmeasure.org", "code": unit}
        except ValueError:
            res["valueString"] = str(val)
        _clean(res)
        out.append(_entry(ctx, res, "vital", r.get("Id") or name, r.get("Datum")))
    return out


# ===========================================================================
# 10) Medikation -> MedicationStatement (VerordnungV2 + Medikament + MedikamentAtc
#     + MedikamentDosierungV2 + VerordnungFreitext).
#     Gutachten 2.2/4.1: ItemType 1=Fertigarznei, 2=Rezeptur, 3=Freitext, 4=DiGA.
#     Pzn ist bei ALLEN Typen gefuellt -> Trennmerkmal ist Id_Medikament
#     (gesetzt bei 1/4). Artikelname/Darreichungsform fuer 2/3 aus
#     VerordnungFreitext; Dosierschema aus MedikamentDosierungV2.
# ===========================================================================
MED_KIND = {1: "Fertigarzneimittel", 2: "Rezeptur", 3: "Freitextverordnung", 4: "DiGA"}


def _dosage_text(dos: dict) -> str | None:
    """MedikamentDosierungV2 -> lesbare Dosierung ('1-0-1-0 Tbl.' bzw. Freitext)."""
    if dos.get("IsFreitextDosierung") and dos.get("FreitextDosierung"):
        return str(dos["FreitextDosierung"]).strip()
    schema = [dos.get(k) for k in ("Morgens", "Mittags", "Abends", "Nachts")]
    if any(v not in (None, "", 0, "0") for v in schema):
        txt = "-".join(str(v if v not in (None, "") else 0) for v in schema)
        einheit = (dos.get("Dosiereinheit") or "").strip()
        return f"{txt} {einheit}".strip()
    return (str(dos.get("FreitextDosierung") or "").strip() or None)


def map_medication(ctx, rows: list[dict], dosierung_by: dict | None = None,
                   freitext_by: dict | None = None) -> list[dict]:
    dosierung_by = dosierung_by or {}
    freitext_by = freitext_by or {}
    out = []
    for r in rows:
        item_type = r.get("ItemType")
        pzn = r.get("Pzn")
        atc = r.get("AtcCode")
        ft = freitext_by.get(r.get("Id")) or {}
        name = (r.get("Artikelname") or r.get("Artikellangname")
                or ft.get("Artikelname"))
        wirkstoff = r.get("Bezeichnung")   # MedikamentAtc.Bezeichnung = Wirkstoff
        date = ctx.d(r.get("ReferenceDateTime"))
        # Fertigarznei/DiGA erkennbar an Id_Medikament (Gutachten 2.2)
        strukturiert = bool(r.get("Id_Medikament")) or item_type in (1, 4)
        if not name and not strukturiert:
            continue                       # Rezeptur/Freitext ohne Namen: leer
        coding = []
        if strukturiert and pzn and not str(pzn).startswith("F"):
            coding.append({"system": SYS_PZN, "code": str(pzn), "display": name})
        if atc:
            coding.append({"system": SYS_ATC, "code": str(atc), "display": wirkstoff or name})
        # Status aus Absetzung / Reichweite
        status = "active"
        if r.get("AbgesetztDateTime"):
            status = "stopped"
        elif r.get("ReichtBis") and str(r["ReichtBis"])[:10] < _today():
            status = "completed"
        res = {
            "resourceType": "MedicationStatement",
            "status": status,
            "medicationCodeableConcept": {"coding": coding or None,
                                          "text": ctx.txt(name) or wirkstoff},
            "subject": ctx.subject,
            "effectiveDateTime": date,
        }
        if r.get("ReichtBis"):
            res["effectivePeriod"] = {"start": date, "end": ctx.d(r["ReichtBis"])}
            res.pop("effectiveDateTime", None)
        if r.get("Absetzungsgrund"):
            res["statusReason"] = [{"text": ctx.txt(r["Absetzungsgrund"])}]
        if r.get("Id_Schein"):
            res["context"] = {"reference": ctx.uid("enc", r["Id_Schein"])}
        # Verordnungsart + Darreichungsform + Dosierschema (Gutachten 2.2/4.1)
        kind = MED_KIND.get(item_type)
        if kind:
            res["category"] = {"text": kind}
        if ft.get("Darreichungsform"):
            res.setdefault("extension", []).append(
                {"url": f"{SYS_LOCAL}/darreichungsform",
                 "valueString": str(ft["Darreichungsform"])})
        dosages = []
        for dos in dosierung_by.get(r.get("Id"), []):
            txt = _dosage_text(dos)
            d: dict = {"text": ctx.txt(txt)} if txt else {}
            if dos.get("Hinweis"):
                d["patientInstruction"] = ctx.txt(str(dos["Hinweis"]))
            if d:
                dosages.append(d)
            if dos.get("Behandlungsgrund"):
                res.setdefault("reasonCode", []).append(
                    {"text": ctx.txt(str(dos["Behandlungsgrund"]))})
        if dosages:
            res["dosage"] = dosages
        _clean(res)
        out.append(_entry(ctx, res, "med", r.get("Id")))
    return out


# ===========================================================================
# 10a) Chronische Erkrankungen -> Condition (kuratierte ICD-Liste je Patient,
#      Gutachten 4.4: Felder Icd, Status; hat RowVersion -> Delta-faehig)
# ===========================================================================
def map_chronische(ctx, rows: list[dict]) -> list[dict]:
    out = []
    for r in rows or []:
        icd = _pick(r, "Icd", "IcdCode")
        if not icd:
            continue
        aktiv = str(_pick(r, "Status") or "").lower() not in ("0", "inaktiv", "inactive")
        res = {
            "resourceType": "Condition",
            "clinicalStatus": {"coding": [{"system":
                "http://terminology.hl7.org/CodeSystem/condition-clinical",
                "code": "active" if aktiv else "inactive"}]},
            "category": [{"text": "Chronische Erkrankung"}],
            "code": {"coding": [{"system": SYS_ICD, "code": str(icd)}]},
            "subject": ctx.subject,
            "recordedDate": ctx.d(_pick(r, "CreatedPoint", "ErfasstAm")),
        }
        _clean(res)
        out.append(_entry(ctx, res, "chronisch", _pick(r, "Id") or icd))
    return out


# ===========================================================================
# 10b) Privatabrechnung / IGeL -> Invoice (Rechnung)
# ===========================================================================
def map_invoices(ctx, rows: list[dict]) -> list[dict]:
    out = []
    for r in rows:
        date = ctx.d(r.get("RechnungsDatum"))
        if r.get("IsStornoRechnung"):
            status = "cancelled"
        elif _num(r.get("Restbetrag"), 1) == 0:
            status = "balanced"
        else:
            status = "issued"
        nr = "".join(str(x) for x in [r.get("RechnungsnummerPraefix") or "", r.get("Rechnungsnummer") or ""])
        res = {
            "resourceType": "Invoice",
            "status": status,
            "type": {"text": "IGeL" if r.get("IsIgel") else "Privatrechnung"},
            "identifier": [{"system": f"{SYS_LOCAL}/rechnungsnummer", "value": nr}] if nr else None,
            "subject": ctx.subject,
            "recipient": ctx.subject,
            "date": date,
            "totalGross": {"value": _num(r.get("GesamtBetrag"), 0), "currency": "EUR"},
            "totalNet": {"value": _num(r.get("BetragBerechnet"), 0), "currency": "EUR"},
        }
        if r.get("Id_Schein"):
            res.setdefault("extension", []).append(
                {"url": f"{SYS_LOCAL}/schein", "valueReference": {"reference": ctx.uid("enc", r["Id_Schein"])}})
        _clean(res)
        out.append(_entry(ctx, res, "invoice", r["Id"]))
    return out


# ===========================================================================
# 10c) DMP-Teilnahme -> Condition + EpisodeOfCare (PatientDmp; hier 0 Zeilen,
#      strukturell fuer andere Praxen). Defensiv via _pick.
# ===========================================================================
DMP_DISPLAY = {"DM1": "Diabetes mellitus Typ 1", "DM2": "Diabetes mellitus Typ 2",
               "KHK": "Koronare Herzkrankheit", "COPD": "COPD", "ASTHMA": "Asthma bronchiale",
               "BK": "Brustkrebs", "HI": "Herzinsuffizienz", "OSTEO": "Osteoporose"}
def map_dmp(ctx, rows: list[dict]) -> list[dict]:
    out = []
    for r in rows:
        prog = _pick(r, "DmpTyp", "Indikation", "Programm", "DmpArt")
        start = ctx.d(_pick(r, "EinschreibungDatum", "TeilnahmeSeit", "CreatedPoint"))
        res = {
            "resourceType": "EpisodeOfCare",
            "status": "active" if not _pick(r, "BeendetAm", "AusschreibungDatum") else "finished",
            "type": [{"coding": [{"system": f"{SYS_LOCAL}/dmp", "code": str(prog)}],
                      "text": DMP_DISPLAY.get(str(prog), f"DMP {prog}")}],
            "patient": ctx.subject,
            "period": {"start": start, "end": ctx.d(_pick(r, "BeendetAm", "AusschreibungDatum"))},
        }
        _clean(res)
        out.append(_entry(ctx, res, "dmp", r.get("Id") or prog))
    return out


# ===========================================================================
# 10d) HZV / Selektivvertrags-Teilnahme -> Coverage (HzvPatientTeilnahme;
#      hier 0 Zeilen, strukturell fuer andere Praxen).
# ===========================================================================
def map_hzv(ctx, rows: list[dict]) -> list[dict]:
    out = []
    for r in rows:
        vertrag = _pick(r, "VertragsKennung", "Vertrag", "VertragId", "HzvVertragKennung")
        start = ctx.d(_pick(r, "TeilnahmeSeit", "EinschreibungDatum", "CreatedPoint"))
        res = {
            "resourceType": "Coverage",
            "status": "active" if not _pick(r, "BeendetAm") else "cancelled",
            "type": {"coding": [{"system": f"{SYS_LOCAL}/vertrag", "code": str(vertrag)}],
                     "text": "HZV / Selektivvertrag"},
            "beneficiary": ctx.subject,
            "period": {"start": start, "end": ctx.d(_pick(r, "BeendetAm"))},
        }
        _clean(res)
        out.append(_entry(ctx, res, "hzv", r.get("Id") or vertrag))
    return out


# ===========================================================================
# 11) CAVE / Warnhinweise -> Flag (bzw. AllergyIntolerance bei Intoleranz)
# ===========================================================================
def map_cave(ctx, rows: list[dict]) -> list[dict]:
    out = []
    for r in rows:
        desc = _pick(r, "DescriptionText") or strip_html(_pick(r, "DescriptionHtml"))
        intoler = _pick(r, "IntoleranceText") or strip_html(_pick(r, "IntoleranceHtml"))
        date = ctx.d(_pick(r, "CreatedPoint"))
        if intoler:
            res = {"resourceType": "AllergyIntolerance",
                   "clinicalStatus": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical", "code": "active"}]},
                   "code": {"text": ctx.txt(intoler)}, "patient": ctx.subject,
                   "recordedDate": date}
            key = ("allergy", r.get("Id"))
        else:
            res = {"resourceType": "Flag", "status": "active",
                   "category": [{"text": "CAVE / administrativer Hinweis"}],
                   "code": {"text": ctx.txt(desc) or "CAVE"}, "subject": ctx.subject,
                   "period": {"start": date}}
            key = ("flag", r.get("Id"))
        _clean(res)
        out.append(_entry(ctx, res, *key))
    return out


# ===========================================================================
# 12) HybridDRG -> Claim (strukturell vorgesehen; in dieser Praxis 0 Zeilen)
# ===========================================================================
def map_hybriddrg(ctx, rows: list[dict]) -> list[dict]:
    out = []
    for r in rows:
        drg = _pick(r, "Drg", "DrgCode", "HybridDrg")
        if not drg:
            continue
        res = {
            "resourceType": "Claim", "status": "active", "use": "claim",
            "type": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/claim-type", "code": "institutional"}]},
            "patient": ctx.subject,
            "item": [{"sequence": 1, "productOrService": {
                "coding": [{"system": f"{SYS_LOCAL}/hybrid-drg", "code": str(drg)}], "text": str(drg)}}],
        }
        _clean(res)
        out.append(_entry(ctx, res, "hdrg", r.get("Id") or drg))
    return out


# ===========================================================================
# 13) Chipkarte -> Coverage (VersichertenNr pseudonymisiert)
# ===========================================================================
VERSICHERTENART = {1: "Mitglied", 3: "Familienversichert", 5: "Rentner"}


def map_coverage_chipkarte(ctx, rows: list[dict]) -> list[dict]:
    """Nur die aktuellste eingelesene Chipkarte je Patient -> Coverage.
    VersichertenNr (KVNR) ist ein direkter Identifikator -> wertbasiert gehasht."""
    if not rows:
        return []
    latest = max(rows, key=lambda r: str(_pick(r, "ChipkartenEinlesedatum") or ""))
    kvnr = ctx.hash_id(_pick(latest, "VersichertenNr"), "kvnr")
    res = {
        "resourceType": "Coverage",
        "status": "active",
        "kind": "insurance",
        "subscriberId": kvnr,
        "beneficiary": ctx.subject,
        "type": {"text": VERSICHERTENART.get(latest.get("Versichertenart"), "GKV")},
        "period": {"start": ctx.d(_pick(latest, "ChipkarteGueltigVon")),
                   "end": ctx.d(_pick(latest, "ChipkarteGueltigBis"))},
        "payor": [{"display": _pick(latest, "KassenName"),
                   "identifier": {"system": "http://fhir.de/sid/arge-ik/iknr",
                                  "value": _pick(latest, "IkNr") or _pick(latest, "KostentraegerIkNr")}}],
    }
    for fld, url in [("BesonderePersonengruppe", "besondere-personengruppe"),
                     ("Statusergaenzung", "statusergaenzung"),
                     ("WopKennzeichen", "wop"), ("VersichertenstatusRsa", "rsa-status")]:
        v = _pick(latest, fld)
        if v not in (None, ""):
            res.setdefault("extension", []).append(
                {"url": f"{SYS_LOCAL}/{url}", "valueString": str(v)})
    _clean(res)
    return [_entry(ctx, res, "coverage", latest.get("Id"))]


# ===========================================================================
# 14) Bezugsperson -> RelatedPerson (Namen/Kontakt bei Pseudonymisierung entschaerft)
# ===========================================================================
KONTAKT_TYPE = {1: "phone", 2: "phone", 3: "email", 4: "fax", 5: "url"}


def map_bezugsperson(ctx, rows: list[dict], kontakte_by_bp: dict) -> list[dict]:
    out = []
    anon = ctx.privacy.mode != "off"
    for r in rows:
        rel = _pick(r, "BeziehungBezugsperson") or _pick(r, "BeziehungPatient")
        res = {
            "resourceType": "RelatedPerson",
            "patient": ctx.subject,
            "relationship": [{"text": rel}] if rel else None,
        }
        if not anon:
            res["name"] = [{"family": r.get("Name"),
                            "given": [g for g in [r.get("Vorname")] if g]}]
            tel = []
            for k in kontakte_by_bp.get(r.get("Id"), []):
                tel.append({"system": KONTAKT_TYPE.get(k.get("Type"), "other"),
                            "value": k.get("Data")})
            if tel:
                res["telecom"] = tel
            if r.get("Wohnort") or r.get("Strasse"):
                res["address"] = [{"line": [r["Strasse"]] if r.get("Strasse") else None,
                                   "city": r.get("Wohnort"), "postalCode": r.get("Postleitzahl")}]
        else:
            # nur Kontaktkanal-Typen ohne Werte behalten
            tel = [{"system": KONTAKT_TYPE.get(k.get("Type"), "other")}
                   for k in kontakte_by_bp.get(r.get("Id"), [])]
            if tel:
                res["telecom"] = tel
        _clean(res)
        out.append(_entry(ctx, res, "related", r.get("Id")))
    return out


# ===========================================================================
# 15) ToDo -> Task (Id_Patient/Id_MedDok-bezogene Aufgaben)
# ===========================================================================
TODO_STATUS = {0: "requested", 1: "in-progress", 2: "completed", 3: "cancelled"}
TODO_PRIO = {0: "routine", 1: "routine", 2: "urgent", 3: "asap", 4: "stat"}


def map_todos(ctx, rows: list[dict]) -> list[dict]:
    out = []
    for r in rows:
        res = {
            "resourceType": "Task",
            "status": TODO_STATUS.get(r.get("Status"), "requested"),
            "intent": "order",
            "priority": TODO_PRIO.get(r.get("Priority"), "routine"),
            "description": ctx.txt(_pick(r, "Name")),
            "for": ctx.subject,
            "authoredOn": ctx.d(_pick(r, "CreatedPoint")),
            "note": [{"text": ctx.txt(r["Description"])}] if r.get("Description") else None,
        }
        deadline = ctx.d(_pick(r, "DeadlineDateTime"))
        start = ctx.d(_pick(r, "StartDateTime"))
        if deadline or start:
            res["restriction"] = {"period": {"start": start, "end": deadline}}
        if r.get("DoneDateTime"):
            res["lastModified"] = ctx.d(r["DoneDateTime"])
        if r.get("Id_MedDok"):
            res["focus"] = {"reference": ctx.uid("meddok", r["Id_MedDok"])}
        _clean(res)
        out.append(_entry(ctx, res, "todo", r.get("Id")))
    return out


# ===========================================================================
# 16) Heilmittel (Physio/Ergo/Logo) -> ServiceRequest
# ===========================================================================
def map_heilmittel(ctx, rows: list[dict], hm_by_verordnung: dict) -> list[dict]:
    out = []
    for r in rows:
        icd = _pick(r, "FirstIcdCode")
        items = hm_by_verordnung.get(r.get("Id"), [])
        detail = []
        for h in sorted(items, key=lambda x: x.get("Priority") or 0):
            txt = h.get("Name")
            if h.get("Behandlungseinheit"):
                txt = f"{txt} ({h['Behandlungseinheit']} Einheiten)"
            detail.append({"text": txt})
        res = {
            "resourceType": "ServiceRequest",
            "status": "active", "intent": "order",
            "category": [{"text": "Heilmittelverordnung"}],
            "subject": ctx.subject,
            "authoredOn": ctx.d(_pick(r, "ReferenceDateTime")),
            "code": {"text": _pick(r, "DiagnoseGruppe")},
            "orderDetail": detail or None,
            "reasonCode": [{"coding": [{"system": SYS_ICD, "code": icd,
                                        "display": _pick(r, "FirstIcdText")}]}] if icd else None,
            "patientInstruction": _pick(r, "Therapiefrequenz"),
        }
        for fld, txt in [("Hausbesuch", "Hausbesuch"),
                         ("DringlicherBehandlungsbedarf", "Dringlicher Behandlungsbedarf"),
                         ("IsBlankoverordnung", "Blankoverordnung"),
                         ("IsLangfristigerHeilmittelbedarf", "Langfristiger Heilmittelbedarf")]:
            if r.get(fld):
                res.setdefault("extension", []).append(
                    {"url": f"{SYS_LOCAL}/heilmittel-{fld.lower()}", "valueBoolean": True})
        if r.get("Id_Schein"):
            res["encounter"] = {"reference": ctx.uid("enc", r["Id_Schein"])}
        _clean(res)
        out.append(_entry(ctx, res, "heilmittel", r.get("Id")))
    return out


# ===========================================================================
# 17) Rezept (RezeptV2) -> MedicationRequest (Verordnungs-Vorgang/Formular)
#     Wirkstoff/PZN je Position liegen in VerordnungV2 (bereits als
#     MedicationStatement) bzw. RezeptInfo; hier der Rezept-Kopf mit Kennzeichen.
# ===========================================================================
REZEPT_SUBTYPE = {0: "GKV-Muster-16", 1: "Privat", 2: "eRezept", 3: "BTM",
                  4: "T-Rezept", 5: "Entlassrezept"}


def _rezept_kategorie(r):
    return ("Hilfsmittel" if r.get("IsHilfsmittel") else
            "Sprechstundenbedarf" if r.get("IsSprechstundenbedarf") else
            "Impfstoff" if r.get("IsImpfstoff") else "Arzneimittel")


def _rezept_flags(r):
    ext = []
    if r.get("BtmKennzeichen"):
        ext.append({"url": f"{SYS_LOCAL}/btm", "valueInteger": r["BtmKennzeichen"]})
    for fld in ("IsNoctu", "IsUnfall", "IsArbeitsunfall", "IsErsatzverordnung",
                "IsSprechstundenbedarf", "IsHilfsmittel", "IsImpfstoff"):
        if r.get(fld):
            ext.append({"url": f"{SYS_LOCAL}/rezept-{fld[2:].lower()}", "valueBoolean": True})
    return ext


def _split_info(info):
    """RezeptInfo.Info -> (praeparat_zeile, dosier_text)."""
    if not info:
        return None, None
    lines = [l.strip() for l in str(info).splitlines() if l.strip()]
    if not lines:
        return None, None
    return lines[0], (" ".join(lines[1:]) or None)


def map_rezepte(ctx, rows, info_by_rezept=None, druck_by_info=None, diag_by_rezept=None):
    """Eine MedicationRequest je Verordnungszeile (RezeptInfo). Ohne Zeilen:
    ein Rezept-Kopf als MedicationRequest (data-absent Medikation)."""
    info_by_rezept = info_by_rezept or {}
    druck_by_info = druck_by_info or {}
    diag_by_rezept = diag_by_rezept or {}
    out = []
    for r in rows:
        rid = r.get("Id")
        authored = ctx.d(_pick(r, "Ausstellungsdatum") or _pick(r, "ReferenceDateTime"))
        cat = _rezept_kategorie(r)
        ext = _rezept_flags(r)
        reason = [{"coding": [{"system": SYS_ICD, "code": d.get("Icd"),
                               "display": ctx.txt(d.get("Beschreibung"))}]}
                  for d in diag_by_rezept.get(rid, []) if d.get("Icd")]
        group = {"system": f"{SYS_LOCAL}/rezept", "value": str(rid)}
        lines = info_by_rezept.get(rid, [])
        if not lines:
            res = {
                "resourceType": "MedicationRequest",
                "status": "completed", "intent": "order",
                "category": [{"text": cat}],
                "subject": ctx.subject, "authoredOn": authored,
                "groupIdentifier": group,
                "medicationCodeableConcept": {"text": REZEPT_SUBTYPE.get(r.get("Subtype"), "Rezept")},
                "extension": ext or None,
                "reasonCode": reason or None,
            }
            if r.get("Id_Schein"):
                res["encounter"] = {"reference": ctx.uid("enc", r["Id_Schein"])}
            _clean(res)
            out.append(_entry(ctx, res, "rezept", rid))
            continue
        for li in sorted(lines, key=lambda x: x.get("Rang") or 0):
            praep, dos = _split_info(li.get("Info"))
            # zusaetzliche Druckzeilen (Dosierung/Gebrauchsanweisung) anhaengen
            drucke = [d.get("Druckzeile") for d in
                      sorted(druck_by_info.get(li.get("Id"), []), key=lambda x: x.get("Rang") or 0)
                      if d.get("Druckzeile")]
            dosis = " ".join(x for x in ([dos] + drucke) if x) or None
            pzn = li.get("Pzn")
            strukturiert = bool(li.get("IsStrukturiert")) and pzn and not li.get("IsFreitext")
            med = {"text": ctx.txt(praep) or REZEPT_SUBTYPE.get(r.get("Subtype"), "Rezept")}
            if strukturiert:
                med["coding"] = [{"system": SYS_PZN, "code": str(pzn)}]
            res = {
                "resourceType": "MedicationRequest",
                "status": "completed", "intent": "order",
                "category": [{"text": cat}],
                "subject": ctx.subject, "authoredOn": authored,
                "groupIdentifier": group,
                "medicationCodeableConcept": med,
                "dosageInstruction": [{"text": ctx.txt(dosis)}] if dosis else None,
                "substitution": {"allowedBoolean": not bool(li.get("IsAutIdem"))},
                "extension": ext or None,
                "reasonCode": reason or None,
            }
            if li.get("IsRezeptur"):
                # extension kann oben explizit None sein (ext or None) ->
                # setdefault wuerde None liefern und .append crashen
                res["extension"] = (res.get("extension") or []) + [
                    {"url": f"{SYS_LOCAL}/rezeptur", "valueBoolean": True}]
            if r.get("Id_Schein"):
                res["encounter"] = {"reference": ctx.uid("enc", r["Id_Schein"])}
            _clean(res)
            out.append(_entry(ctx, res, "rezept", rid, li.get("Id")))
    return out


# ===========================================================================
# 17b) MedDok-Anhaenge -> DocumentReference (Metadaten; Binaerdaten on-demand)
# ===========================================================================
_MIME = {"pdf": "application/pdf", "jpg": "image/jpeg", "jpeg": "image/jpeg",
         "png": "image/png", "tif": "image/tiff", "tiff": "image/tiff",
         "gif": "image/gif", "doc": "application/msword", "txt": "text/plain",
         "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
         "rtf": "application/rtf", "xml": "application/xml", "html": "text/html"}


def map_anhaenge(ctx, rows, embed=False):
    """MedDokAnhang -> DocumentReference. Standardmaessig NUR Metadaten
    (FileName, Groesse, contentType, FsRowGuid als Handle). Binaerdaten nur
    wenn embed=True (dann base64 in content.attachment.data)."""
    import base64
    out = []
    for r in rows:
        fn = r.get("FileName") or "Anhang"
        ext = fn.rsplit(".", 1)[-1].lower() if "." in fn else ""
        # Dateinamen tragen haeufig Patientennamen -> bei Pseudonymisierung durch
        # neutralen Namen ersetzen (Endung bleibt fuer contentType/Anzeige erhalten).
        # In-Praxis-Betrieb: privacy.keep_filenames=true behaelt Originalnamen.
        if ctx.privacy.mode != "off" and not getattr(ctx.privacy, "keep_filenames", False):
            fn = f"anhang-{r.get('Id')}" + (f".{ext}" if ext else "")
        att = {"contentType": _MIME.get(ext), "title": fn,
               "size": r.get("AnhangLength")}
        volltext = None
        if embed and r.get("AnhangData") is not None:
            data = r["AnhangData"]
            if isinstance(data, (bytes, bytearray)):
                att["data"] = base64.b64encode(bytes(data)).decode("ascii")
                # Arztbrief-Volltext extrahieren (DOCX inkl. Tabellenzellen) ->
                # als text/plain-Attachment: durchsuchbar (FTS) + annotierbar
                from dokumente import attachment_text
                volltext = attachment_text(bytes(data))
        elif r.get("FsRowGuid"):
            att["url"] = f"meddok-anhang:{r['FsRowGuid']}"   # Handle fuer On-demand-Abruf
        content = [{"attachment": att}]
        if volltext:
            content.append({"attachment": {
                "contentType": "text/plain", "title": "Volltext (extrahiert)",
                "data": base64.b64encode(
                    (ctx.txt(volltext) or "").encode("utf-8")).decode("ascii")}})
        res = {
            "resourceType": "DocumentReference",
            "status": "current",
            "type": {"text": ctx.txt(r.get("Tag")) or "Anhang"},
            "category": [{"text": "MedDok-Anhang"}],
            "subject": ctx.subject,
            "date": ctx.d(r.get("CreatedPoint")),
            "content": content,
        }
        if r.get("Id_MedDok"):
            res.setdefault("extension", []).append(
                {"url": f"{SYS_LOCAL}/meddok-ref", "valueString": str(r["Id_MedDok"])})
        _clean(res)
        out.append(_entry(ctx, res, "anhang", r.get("Id")))
    return out


# ===========================================================================
# 18) Medikationsplan (BMP) -> List, referenziert Verordnungs-MedicationStatements
# ===========================================================================
def map_medikationsplan(ctx, plan_rows, item_rows, freitext_by_id) -> list[dict]:
    if not (plan_rows or item_rows):
        return []
    entries = []
    for it in sorted(item_rows, key=lambda x: x.get("MedikationsplanSortIndex") or 0):
        if it.get("Id_Verordnung"):
            # Referenz auf das MedicationStatement der Verordnung (uid-Schluessel
            # 'med' wie in map_medication - 'medstmt' zeigte ins Leere)
            entries.append({"item": {"reference": ctx.uid("med", it["Id_Verordnung"])}})
        elif it.get("Id_MedikationsplanFreitext"):
            ft = freitext_by_id.get(it["Id_MedikationsplanFreitext"])
            if ft:
                entries.append({"item": {"display": ctx.txt(ft)}})
    if not entries:
        return []
    plan = plan_rows[0] if plan_rows else {}
    res = {
        "resourceType": "List",
        "status": "current", "mode": "working",
        "title": "Medikationsplan (BMP)",
        "code": {"coding": [{"system": SYS_LOINC, "code": "56445-0",
                             "display": "Medication summary"}]},
        "subject": ctx.subject,
        "date": ctx.d(_pick(plan, "CreatedPoint")),
        "note": [{"text": ctx.txt(plan["Comment"])}] if plan.get("Comment") else None,
        "entry": entries,
    }
    _clean(res)
    return [_entry(ctx, res, "medplan", plan.get("Id_Patient") or ctx.pid)]


# ===========================================================================
# 19) Formularvariablen -> strukturierte AU-Anreicherung (MedDokFormularVariable)
# ===========================================================================
def au_from_formularvariablen(ctx, fv: dict) -> dict:
    """Liefert strukturierte AU-Eckdaten aus geparsten Formularvariablen.
    -> {bis, seit, folge, icds, is_eau} (alle optional)."""
    seit = formular_datum(fv.get("_ArbeitsunfaehigSeit"))
    bis = formular_datum(fv.get("_VoraussichtlichArbeitsunfaehigBis"))
    diags = formular_diagnosen(fv.get("_Diagnose"))
    return {
        "seit": ctx.d(seit) if seit else None,
        "bis": ctx.d(bis) if bis else None,
        "folge": bool(fv.get("_Folgebescheinigung")),
        "icds": [d["icd"] for d in diags if d.get("icd")],
        "is_eau": bool(fv.get("_IsEau")),
    }



    import datetime as _dt
    return _dt.date.today().isoformat()


def _num(v, default=1):
    try:
        return float(str(v).replace(",", "."))
    except (ValueError, TypeError):
        return default


def _pick(row: dict, *names):
    for n in names:
        if n in row and row[n] not in (None, ""):
            return row[n]
    return None


def _clean(obj):
    """Entfernt None-Werte und leere Listen/Dicts rekursiv (in-place)."""
    if isinstance(obj, dict):
        for k in list(obj.keys()):
            v = obj[k]
            if v is None:
                del obj[k]
            else:
                _clean(v)
                if v == {} or v == []:
                    del obj[k]
    elif isinstance(obj, list):
        for it in obj:
            _clean(it)
    return obj
