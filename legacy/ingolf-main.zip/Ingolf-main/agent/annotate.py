#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Klinische Annotation von Dokumenttexten (Schritt 3 des Layers).

Nimmt den per documents.extract_text() gewonnenen Volltext und erzeugt
kodierte Annotationen (SNOMED CT primaer; ICD-10-GM/LOINC/ATC ergaenzend),
inklusive Negations- und Kontexterkennung (negiert / Verdacht / Eigenanamnese
vs. Familienanamnese / historisch). Ausgabe in zwei FHIR-Formen:

  A) Annotations-Overlay am DocumentReference  -> fuer die UI (Text-Highlighting
     mit Zeichen-Offsets, Konzept, Negation, Konfidenz).
  B) Abgeleitete Ressourcen (Condition/Observation/MedicationStatement)
     mit derivedFrom -> das Dokument, provenance = 'NLP', damit die ANALYSE
     dokumentbasierte Konzepte wie strukturierte Daten nutzen kann.

Der eigentliche Konzept-Lookup kommt aus reference/terminology.py (lokaler
Katalog-Matcher und/oder FHIR-Terminologieserver). Diese Datei ist der
Orchestrierer + FHIR-Serialisierung; die NER-Strategie ist bewusst austauschbar
(Dictionary-Matcher jetzt, ML/LLM-Extraktor spaeter -- gleiches Annotation-Objekt).
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
import hashlib
import re

try:
    from reference.terminology import TerminologyProvider, Concept, LocalCatalogProvider
except Exception:  # Standalone/Tests
    from terminology import TerminologyProvider, Concept, LocalCatalogProvider  # type: ignore

SYS_LOCAL = "urn:greenbay:clinical"

# Kontext-Trigger (vereinfachtes deutsches ConText/NegEx-Lexikon; produktiv erweitern)
_NEG = ["kein", "keine", "keinen", "nicht", "ohne", "negativ für", "ausgeschlossen",
        "kein hinweis auf", "kein anhalt für", "unauffällig"]
_SUSP = ["verdacht auf", "v.a.", "möglich", "fraglich", "wahrscheinlich", "d.d.", "z.n. abklärung"]
_FAM = ["familienanamnese", "vater", "mutter", "geschwister", "familiär"]
_HIST = ["z.n.", "zustand nach", "anamnestisch", "vorbekannt", "früher"]


@dataclass
class Annotation:
    start: int
    end: int
    text: str
    system: str
    code: str
    display: str
    score: float = 1.0
    negated: bool = False
    uncertain: bool = False
    family: bool = False
    historical: bool = False
    section: str | None = None

    def status(self) -> str:
        if self.negated:   return "refuted"
        if self.uncertain: return "provisional"
        return "confirmed"


# ---------------------------------------------------------------------------
# Segmentierung / Sektionen
# ---------------------------------------------------------------------------
_SECTION_HEADS = [
    ("anamnese", r"anamnese|beschwerden|jetzige erkrankung"),
    ("befund", r"befund|untersuchung|status"),
    ("diagnose", r"diagnos(e|en)|beurteilung"),
    ("prozedur", r"prozedur|eingriff|koloskopie|gastroskopie|endoskopie"),
    ("therapie", r"therapie|procedere|medikation|empfehlung"),
    ("labor", r"labor|laborwerte"),
]


def split_sections(text: str) -> list[tuple[str, int, int]]:
    """Grobe Sektionierung anhand typischer Ueberschriften. Rueckgabe:
    Liste (sectionname, start, end) ueber den Originaltext."""
    idx: list[tuple[int, str]] = []
    for name, pat in _SECTION_HEADS:
        for m in re.finditer(pat, text, flags=re.I):
            # nur zeilennahe Ueberschriften (kurzer Vorspann)
            line_start = text.rfind("\n", 0, m.start()) + 1
            if m.start() - line_start <= 3:
                idx.append((m.start(), name))
    idx.sort()
    if not idx:
        return [("dokument", 0, len(text))]
    out = []
    for i, (pos, name) in enumerate(idx):
        end = idx[i + 1][0] if i + 1 < len(idx) else len(text)
        out.append((name, pos, end))
    return out


def _window(text: str, start: int, back: int = 60) -> str:
    return text[max(0, start - back):start].lower()


# ---------------------------------------------------------------------------
# Annotator
# ---------------------------------------------------------------------------
class Annotator:
    def __init__(self, provider: TerminologyProvider, min_score: float = 0.0):
        self.provider = provider
        self.min_score = min_score

    def annotate(self, text: str) -> list[Annotation]:
        if not text:
            return []
        sections = split_sections(text)

        def section_of(pos: int) -> str:
            for name, s, e in sections:
                if s <= pos < e:
                    return name
            return "dokument"

        anns: list[Annotation] = []
        # NER: bevorzugt Dictionary-Spans (mit Offsets); sonst Provider je Satz.
        spans = self._ner_spans(text)
        for (s, e, concept) in spans:
            if concept.score < self.min_score:
                continue
            pre = _window(text, s)
            a = Annotation(
                start=s, end=e, text=text[s:e],
                system=concept.system, code=concept.code, display=concept.display,
                score=concept.score,
                negated=any(n in pre for n in _NEG),
                uncertain=any(u in pre for u in _SUSP),
                family=any(f in pre for f in _FAM),
                historical=any(h in pre for h in _HIST),
                section=section_of(s),
            )
            anns.append(a)
        return anns

    def _ner_spans(self, text: str) -> list[tuple[int, int, Concept]]:
        # Dictionary-Matcher, wenn der Provider Offsets liefern kann
        finder = getattr(self.provider, "find_spans", None)
        if callable(finder):
            return finder(text)
        # sonst: satzweise an den Provider (grobe Offsets)
        out: list[tuple[int, int, Concept]] = []
        for m in re.finditer(r"[^.;\n]{3,}", text):
            for c in self.provider.bind(m.group().strip())[:1]:
                out.append((m.start(), m.end(), c))
        return out


# ---------------------------------------------------------------------------
# FHIR-Serialisierung
# ---------------------------------------------------------------------------
def _stable_id(*parts) -> str:
    return hashlib.sha1("|".join(str(p) for p in parts).encode()).hexdigest()[:24]


def annotations_extension(anns: list[Annotation]) -> dict:
    """Annotations-Overlay als FHIR-Extension fuer den DocumentReference.
    Traegt Offsets + Konzept + Kontext -> die UI highlightet damit den Volltext."""
    items = []
    for a in anns:
        items.append({"extension": [
            {"url": "span", "valueString": f"{a.start}:{a.end}"},
            {"url": "text", "valueString": a.text},
            {"url": "concept", "valueCoding": {"system": a.system, "code": a.code, "display": a.display}},
            {"url": "status", "valueCode": a.status()},
            {"url": "score", "valueDecimal": round(a.score, 3)},
            {"url": "context", "valueString": ",".join(
                k for k, v in (("negated", a.negated), ("uncertain", a.uncertain),
                               ("family", a.family), ("historical", a.historical)) if v)},
            {"url": "section", "valueString": a.section or ""},
        ]})
    return {"url": f"{SYS_LOCAL}/document-annotations", "extension": items}


def derived_resources(ctx, doc_ref_id: str, anns: list[Annotation],
                      accept_min_score: float = 0.6) -> list[dict]:
    """Erzeugt aus akzeptierten Annotationen abgeleitete FHIR-Ressourcen, die die
    ANALYSE nutzen kann. SNOMED/ICD-Disorder -> Condition; Findings/Prozeduren/Labor
    -> Observation. Alle mit derivedFrom=Dokument und NLP-Provenance/Konfidenz.
    Familienanamnese und negierte Konzepte werden NICHT als aktive Diagnose abgeleitet
    (nur im Overlay sichtbar), um Analyse-Artefakte zu vermeiden."""
    out = []
    for a in anns:
        if a.score < accept_min_score or a.family:
            continue
        prov_ext = [
            {"url": "derivation", "valueCode": "nlp"},
            {"url": "confidence", "valueDecimal": round(a.score, 3)},
            {"url": "sourceDocument", "valueString": doc_ref_id},
            {"url": "span", "valueString": f"{a.start}:{a.end}"},
        ]
        common = {
            "subject": ctx.subject,
            "extension": [{"url": f"{SYS_LOCAL}/nlp-provenance", "extension": prov_ext}],
        }
        is_diag = a.system.endswith("icd-10-gm") or _looks_disorder(a.display)
        if is_diag and not a.negated:
            out.append(ctx_entry(ctx, {
                "resourceType": "Condition",
                "clinicalStatus": {"coding": [{"code": "active"}]} if not a.historical
                                  else {"coding": [{"code": "inactive"}]},
                "verificationStatus": {"coding": [{"code": a.status()}]},
                "code": {"coding": [{"system": a.system, "code": a.code, "display": a.display}],
                         "text": a.text},
                **common,
            }, "nlp-cond", _stable_id(doc_ref_id, a.start, a.code)))
        else:
            out.append(ctx_entry(ctx, {
                "resourceType": "Observation",
                "status": "preliminary",
                "code": {"coding": [{"system": a.system, "code": a.code, "display": a.display}],
                         "text": a.text},
                "dataAbsentReason": {"coding": [{"code": "not-performed"}]} if a.negated else None,
                **common,
            }, "nlp-obs", _stable_id(doc_ref_id, a.start, a.code)))
    return [o for o in out if o]


def _looks_disorder(display: str) -> bool:
    d = (display or "").lower()
    return any(w in d for w in ("itis", "syndrom", "krankheit", "disorder", "carcinom",
                                "karzinom", "kolitis", "crohn", "anämie", "stenose"))


def ctx_entry(ctx, resource: dict, kind: str, key) -> dict | None:
    """Nutzt die vorhandene _entry/_clean-Logik aus mappers.py, wenn verfuegbar."""
    resource = {k: v for k, v in resource.items() if v is not None}
    try:
        from agent.mappers import _entry, _clean
    except Exception:
        try:
            from mappers import _entry, _clean  # type: ignore
        except Exception:
            _entry = _clean = None
    if _clean and _entry:
        _clean(resource)
        return _entry(ctx, resource, kind, key)
    # Fallback ohne mappers
    rid = _stable_id(kind, key)
    return {"resource": {**resource, "id": rid}}


# ---------------------------------------------------------------------------
# Orchestrierung fuer ein Dokument
# ---------------------------------------------------------------------------
def annotate_document(ctx, doc_ref_id: str, text: str, provider: TerminologyProvider,
                      derive: bool = True) -> tuple[dict, list[dict]]:
    """Kompletter Annotationslauf fuer ein Dokument.
    Rueckgabe: (annotations_extension, [derived_resource_entries]).
    Die Extension wird an den DocumentReference gehaengt, die abgeleiteten
    Ressourcen ins Bundle aufgenommen."""
    ann = Annotator(provider).annotate(text or "")
    ext = annotations_extension(ann)
    derived = derived_resources(ctx, doc_ref_id, ann) if derive else []
    return ext, derived
