#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Multi-Patient-Export EUGASTRO -> FHIR R4 (+ openEHR-Vorstufe).

Verallgemeinerung des verifizierten Einzel-Exports (build_bundle.py) auf alle
Patienten, mit inkrementellem Load (rowversion-HWM), Pseudonymisierung/
Anonymisierung und modularen Domaenen-Mappern.

Aufruf:
    python export.py --config config.yaml --mode full  --out ./out
    python export.py --config config.yaml --mode incremental --out ./out
    python export.py --config config.yaml --patient 3659 --out ./out   # Testfall
"""
from __future__ import annotations
import argparse, json, os, sys, datetime as _dt

# Portable (embeddable) Python legt wegen python3xx._pth weder Skriptverzeichnis
# noch cwd auf sys.path -> Geschwister-Module (dbsource, mappers, ...) und das
# Repo-Root (store/, reference/) hier explizit registrieren. Dev-Betrieb: No-Op.
_HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (os.path.dirname(_HERE), _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from dbsource import Source
from privacy import Privacy
from meddok import parse_detail
from gate import assert_clean
import mappers as M
import openehr as OE

# --- MedDok-Kategorien je Domaene -----------------------------------------
CAT_DIAG = ("D", "DD", "DDA", "DDAB", "FDD", "FD")
CAT_NARR = ("A", "V", "FASA", "AVA", "B", "PROC", "I", "TH", "THV")
CAT_FIND = ("SONO", "FIBRO", "FBEUR", "PROCT", "COLO", "GASTR", "URIN")
CAT_LETTERS = ("BRIEF", "EAB", "E")          # -> Composition (Arztbrief/Epikrise)
CAT_AU = ("AU", "ALTAU", "AFAU")             # -> DocumentReference (eAU)
CAT_DOCS = ("KRANK", "KHB", "MDOK")
CAT_ALL = CAT_DIAG + CAT_NARR + CAT_FIND + CAT_LETTERS + CAT_AU + CAT_DOCS + ("L",)

# Tabellen mit RowVersion fuer die Delta-Erkennung (Auswahl der relevanten) --
RV_TABLES = ["MedDok", "Laborbogen", "VerordnungV2", "Schein", "PatientConsent",
             "RezeptV2", "PatientVitalparameterRecord", "PatientCave", "PatientKontakt",
             "ChronischeErkrankung", "Rechnung", "Medikationsplan", "PatientChipkarte",
             "MedikationsplanItem", "PatientHeilmittelV2Verordnung"]

# --- SQL (Spalten gegen die reale DB verifiziert, wo bekannt) --------------
Q_PATIENT_ALL = "SELECT Id FROM dbo.Patient ORDER BY Id"
Q_PATIENT = """
SELECT Id, PatientNr, Name, Vorname, Titel, Geschlecht, Geburtsjahr, Geburtsmonat,
       Geburtstag, VerstorbenAm, Strasse, Hausnummer, Postleitzahl, Wohnort,
       Laenderkennzeichen, IsPrivat, VersichertenNr, IkNr, Versichertenart,
       PatientSeit, LetzterBesuchAm, Staatsangehoerigkeit
FROM dbo.Patient WHERE Id = ?"""

Q_MEDDOK = """
SELECT m.Id, m.Id_Schein, m.ReferenceDateTime, k.Kuerzel,
       CAST(m.Detail AS nvarchar(max)) AS Detail
FROM dbo.MedDok m JOIN dbo.MedDokKategorie k ON k.Id = m.Id_MedDokKategorie
WHERE m.Id_Patient = ? AND k.Kuerzel IN ({})
ORDER BY m.ReferenceDateTime""".format(",".join("'%s'" % c for c in CAT_ALL))

Q_SCHEIN = """
SELECT Id, Scheinart, Scheinuntergruppe, AusstellungsDateTime, ScheinGueltigVon,
       Quartal, Abrechnungsquartal, KassenName, Iknr, IsStationaer,
       UeberweisungVon, UeberweisungAn, WeiterbehandelnderArzt, IsZielauftrag,
       Auftrag, DiagnoseVerdacht, BsnrUeberweiser, LanrUeberweiser,
       IsIgel, AbrechnungsArt, Gebuehrenordnung, RechnungsTyp, PrivatVertragsId,
       HzvVertragKennung, HonorarAnlageId
FROM dbo.Schein WHERE Id_Patient = ?"""

Q_APPT = """
SELECT Id, StartDateTime, EndDateTime, Subject, BesuchsgrundText, Info,
       AppointmentKept, IsMarkedAsCancelled, IsDeleted
FROM dbo.SchedulerAppointment WHERE Id_Patient = ?"""

Q_LABOR = """
SELECT Id, Id_LaborHeader, Datum, Kuerzel, Grenzwertindikator,
       CAST(Details AS nvarchar(max)) AS Details
FROM dbo.Laborbogen
WHERE Id_Patient = ? AND IsAnforderung = 0
  AND COALESCE(JSON_VALUE(CAST(Details AS nvarchar(max)), '$.Ergebniswert'),
               JSON_VALUE(CAST(Details AS nvarchar(max)), '$.ErgebnisText')) IS NOT NULL
ORDER BY Datum, Id_LaborHeader"""

# Vitalwerte: FK Id_VitalparameterRecord, Wert in Value (verifiziert).
# RecordId+Id_Vitalparameter fuer die Blutdruck-Paarung (Gutachten 2.3:
# Id 5 = systolisch, Id 6 = diastolisch am selben Record).
Q_VITAL = """
SELECT rec.Id AS RecordId, rec.Datum, vp.Name, vp.DisplayName, vp.Masseinheit,
       val.Id, val.Id_Vitalparameter, val.Value
FROM dbo.PatientVitalparameterRecord rec
JOIN dbo.PatientVitalparameterValue val ON val.Id_VitalparameterRecord = rec.Id
JOIN dbo.Vitalparameter vp ON vp.Id = val.Id_Vitalparameter
WHERE rec.Id_Patient = ?"""

# Medikation: PZN auf Verordnung, Name aus Medikament, Wirkstoff/ATC aus MedikamentAtc (verifiziert)
Q_MED = """
SELECT v.Id, v.Pzn, v.ItemType, v.ReferenceDateTime, v.ReichtBis, v.AbgesetztDateTime,
       v.Absetzungsgrund, v.Id_Schein, m.Artikelname, m.Artikellangname,
       atc.AtcCode, atc.Bezeichnung
FROM dbo.VerordnungV2 v
LEFT JOIN dbo.Medikament m ON m.Id = v.Id_Medikament
OUTER APPLY (SELECT TOP 1 a.AtcCode, a.Bezeichnung FROM dbo.MedikamentAtc a
             WHERE a.Id_Medikament = m.Id) atc
WHERE v.Id_Patient = ? AND v.IsDeleted = 0
ORDER BY v.ReferenceDateTime"""

# Dosierschema + Freitext-/Rezeptur-Details je Verordnung (Gutachten 4.1):
# ItemType 2/3 haben kein Id_Medikament - Artikelname/Darreichungsform kommen
# NUR aus VerordnungFreitext; Pzn ist bei allen Typen gefuellt (kein Trennmerkmal).
Q_MED_DOSIERUNG = """
SELECT d.* FROM dbo.MedikamentDosierungV2 d
JOIN dbo.VerordnungV2 v ON v.Id = d.Id_Verordnung
WHERE v.Id_Patient = ?"""
Q_MED_FREITEXT = """
SELECT f.* FROM dbo.VerordnungFreitext f
JOIN dbo.VerordnungV2 v ON v.Id = f.Id_Verordnung
WHERE v.Id_Patient = ?"""

# Chronische Erkrankungen (kuratierte ICD-Liste, Gutachten 4.4)
Q_CHRONISCH = "SELECT * FROM dbo.ChronischeErkrankung WHERE Id_Patient = ?"

Q_CAVE = "SELECT * FROM dbo.PatientCave WHERE Id_Patient = ?"
Q_HDRG = "SELECT * FROM dbo.AbrechnungHybridDrg WHERE Id_Patient = ?"

# Privatabrechnung / IGeL (verifiziert)
Q_RECHNUNG = """
SELECT Id, Id_Schein, RechnungsnummerPraefix, Rechnungsnummer, RechnungsDatum,
       GesamtBetrag, BetragBerechnet, Restbetrag, IsIgel, IsStornoRechnung, StornoDatum
FROM dbo.Rechnung WHERE Id_Patient = ?"""

# DMP / HZV: in dieser Praxis 0 Zeilen; strukturell fuer andere Praxen (Spalten defensiv).
Q_DMP = "SELECT * FROM dbo.PatientDmp WHERE Id_Patient = ?"
Q_HZV = "SELECT * FROM dbo.HzvPatientTeilnahme WHERE Id_Patient = ?"

# eAU-Uebertragungsstatus je AU-MedDok (Eau haengt via Id_MedDok)
Q_EAU = """
SELECT e.Id_MedDok, e.State, e.IkNr, e.MailingDateTime, e.ResponseDateTime
FROM dbo.Eau e
JOIN dbo.MedDok m ON m.Id = e.Id_MedDok
WHERE m.Id_Patient = ?"""

# ePA-Austausch (EpaEventLog je Patient -> EpaDocumentMeta)
Q_EPA = """
SELECT ev.Id AS EventId, ev.EventStartDateTime, ev.EventKind, ev.EventState,
       dm.DocumentUniqueId, dm.DocumentCreationDateTime, dm.DocumentMetaJson, dm.IsUpload
FROM dbo.EpaEventLog ev
LEFT JOIN dbo.EpaDocumentMeta dm ON dm.Id = ev.Id_EpaDocumentMeta
WHERE ev.Id_Patient = ? AND ev.Id_EpaDocumentMeta IS NOT NULL"""

# Chipkarte (VersichertenNr, Kasse, Gueltigkeit) -> Coverage
Q_CHIPKARTE = """
SELECT Id, ChipkartenEinlesedatum, ChipkarteGueltigVon, ChipkarteGueltigBis,
       VersichertenNr, Versichertenart, IkNr, KostentraegerIkNr, KassenName,
       BesonderePersonengruppe, Statusergaenzung, WopKennzeichen, VersichertenstatusRsa
FROM dbo.PatientChipkarte WHERE Id_Patient = ?"""

# Bezugsperson -> RelatedPerson (+ Kontaktkanaele)
Q_BEZUGSPERSON = "SELECT * FROM dbo.PatientBezugsperson WHERE Id_Patient = ?"
Q_BEZUGSKONTAKT = """
SELECT k.* FROM dbo.PatientBezugspersonKontakt k
JOIN dbo.PatientBezugsperson b ON b.Id = k.Id_PatientBezugsperson
WHERE b.Id_Patient = ?"""

# ToDo -> Task (patientenbezogen)
Q_TODO = """
SELECT Id, Name, Description, Status, Priority, CreatedPoint, StartDateTime,
       DeadlineDateTime, DoneDateTime, Id_MedDok
FROM dbo.TodoItem WHERE Id_Patient = ?"""

# Heilmittel V2 -> ServiceRequest (+ Heilmittel-Positionen)
Q_HEILMITTEL = "SELECT * FROM dbo.PatientHeilmittelV2Verordnung WHERE Id_Patient = ?"
Q_HEILMITTEL_ITEMS = """
SELECT h.* FROM dbo.PatientHeilmittelV2VerordnungHeilmittel h
JOIN dbo.PatientHeilmittelV2Verordnung v ON v.Id = h.Id_PatientHeilmittelV2Verordnung
WHERE v.Id_Patient = ?"""

# Rezept (RezeptV2) -> MedicationRequest
Q_REZEPT = """
SELECT Id, ReferenceDateTime, Ausstellungsdatum, Subtype, BtmKennzeichen, Id_Schein,
       IsSprechstundenbedarf, IsHilfsmittel, IsImpfstoff, IsNoctu, IsUnfall,
       IsArbeitsunfall, IsErsatzverordnung, Id_MedDok
FROM dbo.RezeptV2 WHERE Id_Patient = ?"""
# Rezept-Positionen (Verordnungszeilen) + Druckzeilen + Rezeptdiagnosen
Q_REZEPTINFO = """
SELECT ri.Id, ri.Id_Rezept, ri.Pzn, ri.Info, ri.IsAutIdem, ri.IsFreitext,
       ri.IsStrukturiert, ri.IsRezeptur, ri.IsHilfsmittelgruppe, ri.Rang
FROM dbo.RezeptInfo ri
JOIN dbo.RezeptV2 r ON r.Id = ri.Id_Rezept
WHERE r.Id_Patient = ?"""
Q_REZEPTDRUCK = """
SELECT rd.Id, rd.Id_RezeptInfo, rd.Druckzeile, rd.Rang
FROM dbo.RezeptInfoDruck rd
JOIN dbo.RezeptInfo ri ON ri.Id = rd.Id_RezeptInfo
JOIN dbo.RezeptV2 r ON r.Id = ri.Id_Rezept
WHERE r.Id_Patient = ?"""
Q_REZEPTDIAG = """
SELECT rd.Id_Rezept, rd.Icd, rd.Beschreibung, rd.Sicherheit, rd.Lokalisation
FROM dbo.RezeptDiagnose rd
JOIN dbo.RezeptV2 r ON r.Id = rd.Id_Rezept
WHERE r.Id_Patient = ?"""

# MedDok-Anhaenge (Metadaten; Binaerdaten optional via --embed-anhaenge)
Q_ANHANG_META = """
SELECT a.Id, a.Id_MedDok, a.FileName, a.Tag, a.AnhangLength, a.FsRowGuid, a.CreatedPoint
FROM dbo.MedDokAnhang a
JOIN dbo.MedDok m ON m.Id = a.Id_MedDok
WHERE m.Id_Patient = ?"""
Q_ANHANG_FULL = """
SELECT a.Id, a.Id_MedDok, a.FileName, a.Tag, a.AnhangLength, a.FsRowGuid,
       a.CreatedPoint, COALESCE(a.AnhangData, a.AnhangFs) AS AnhangData
FROM dbo.MedDokAnhang a
JOIN dbo.MedDok m ON m.Id = a.Id_MedDok
WHERE m.Id_Patient = ?"""

# Medikationsplan (BMP) -> List
Q_MEDPLAN = "SELECT * FROM dbo.Medikationsplan WHERE Id_Patient = ?"
Q_MEDPLAN_ITEMS = """
SELECT Id, IdPatient_Medikationsplan, Id_Verordnung, Id_MedikationsplanFreitext,
       MedikationsplanSortIndex, ItemTyp
FROM dbo.MedikationsplanItem WHERE IdPatient_Medikationsplan = ?"""
Q_MEDPLAN_FREITEXT = """
SELECT f.Id, f.* FROM dbo.MedikationsplanFreitext f
JOIN dbo.MedikationsplanItem i ON i.Id_MedikationsplanFreitext = f.Id
WHERE i.IdPatient_Medikationsplan = ?"""

# MedDokFormularVariable (strukturierte Formularfelder) je Patient
Q_FORMULARVAR = """
SELECT fv.Id_MedDok, fv.FormularVariablen
FROM dbo.MedDokFormularVariable fv
JOIN dbo.MedDok m ON m.Id = fv.Id_MedDok
WHERE m.Id_Patient = ? AND fv.IstZwischenspeicherung = 0"""


def load_config(path: str) -> dict:
    try:
        import yaml  # type: ignore
        with open(path, encoding="utf-8") as f:
            cfg = yaml.safe_load(f)
    except ImportError:
        with open(path, encoding="utf-8") as f:
            cfg = json.load(f)  # Fallback: JSON-Config
    return resolve_config(cfg, os.path.dirname(os.path.dirname(os.path.abspath(path))))


def _unprotect(blob: bytes) -> bytes:
    """DPAPI-geschuetzte Secret-Datei lesen (Gegenstueck zu installer/first_run.py)."""
    if blob.startswith(b"DEV\x00"):
        return blob[4:]
    try:
        import win32crypt  # pywin32, nur Windows
        return win32crypt.CryptUnprotectData(blob, None, None, None, 0)[1]
    except ImportError:
        raise RuntimeError("Secret-Datei ist DPAPI-geschuetzt, aber pywin32 fehlt.")


def resolve_config(cfg: dict, base_dir: str) -> dict:
    """`*_ref`-Verweise (Setup-Wizard) aufloesen: hmac_key_ref -> privacy.hmac_key,
    password_ref -> source.password. Direkte Werte bleiben unveraendert."""
    src = cfg.get("source", {})
    priv = cfg.get("privacy", {})
    if "username" not in src and src.get("user"):
        src["username"] = src["user"]
    for section, ref_key, target in ((priv, "hmac_key_ref", "hmac_key"),
                                     (src, "password_ref", "password")):
        ref = section.get(ref_key)
        if ref and not section.get(target):
            ref_path = os.path.join(base_dir, ref)
            if os.path.exists(ref_path):
                with open(ref_path, "rb") as f:
                    value = _unprotect(f.read())
                section[target] = value if target == "hmac_key" else value.decode("utf-8")
    return cfg


def _annotate_entries(ctx, entries: list[dict], provider, min_score: float = 0.6) -> None:
    """Dokument-Intelligence (docs/DOKUMENTE_ANNOTATION.md): annotiert Text-tragende
    Ressourcen in-place (Overlay-Extension) und haengt abgeleitete Ressourcen an."""
    import base64
    from annotate import annotate_document

    def text_of(res: dict) -> str:
        parts = []
        for c in res.get("content", []) or []:
            att = c.get("attachment") or {}
            if att.get("data") and str(att.get("contentType", "")).startswith("text/"):
                try:
                    parts.append(base64.b64decode(att["data"]).decode("utf-8", "replace"))
                except (ValueError, TypeError):
                    pass
        for s in res.get("section", []) or []:
            div = (s.get("text") or {}).get("div") or ""
            parts.append(__import__("re").sub(r"<[^>]+>", " ", div))
        for key in ("description", "conclusion", "valueString"):
            if res.get(key):
                parts.append(res[key])
        return "\n".join(p for p in parts if p and p.strip()).strip()

    derived_all = []
    for entry in list(entries):
        res = entry.get("resource", {})
        if res.get("resourceType") not in ("DocumentReference", "Composition",
                                           "DiagnosticReport", "Observation"):
            continue
        text = text_of(res)
        if len(text) < 20:
            continue
        ext, derived = annotate_document(ctx, res.get("id"), text, provider)
        if ext.get("extension"):
            res.setdefault("extension", []).append(ext)
            derived_all.extend(d for d in derived if d)
    entries.extend(derived_all)


def check_mode_switch(store_conn, mode: str) -> str | None:
    """Moduswechsel-Schutz: der Store traegt die Kennungen EINES Datenmodus
    (off = echte Ids, pseudonymize = HMAC-Pseudonyme). Ein Lauf mit anderem
    Modus wuerde dieselben Patienten unter neuen Kennungen anlegen (Duplikate,
    Mischbestand) -> Meldung statt Lauf. Merkt sich den Modus im Store."""
    from store.db import get_setting, set_setting
    prev = get_setting(store_conn, "store_privacy_mode")
    has_data = store_conn.execute(
        "SELECT 1 FROM fhir_resource WHERE resource_type='Patient' LIMIT 1").fetchone()
    if has_data and prev and prev != mode:
        return (f"Store enthaelt Daten aus Datenmodus '{prev}', aktueller Modus ist "
                f"'{mode}'. Gleiche Patienten bekaemen neue Kennungen (Duplikate). "
                "Vor dem Moduswechsel in der Verwaltung 'Store leeren' ausfuehren "
                "oder den Datenmodus in den Einstellungen zuruecksetzen.")
    set_setting(store_conn, "store_privacy_mode", mode)
    store_conn.commit()
    return None


def _since_filter(rows: list[dict], since: str | None, *date_fields: str) -> list[dict]:
    """Stichtagsfilter (--since): behaelt Zeilen, deren erstes vorhandenes Datumsfeld
    >= since ist (ISO-Strings vergleichen lexikographisch). Zeilen ohne Datum bleiben."""
    if not since:
        return rows
    out = []
    for r in rows:
        value = next((r[f] for f in date_fields if r.get(f)), None)
        if value is None or str(value)[:10] >= since[:10]:
            out.append(r)
    return out


def build_patient_bundle(src: Source, pid: int, privacy: Privacy, with_openehr: bool,
                         with_epa: bool = False, embed_anhaenge: bool = False,
                         annotate_provider=None, annotate_min_score: float = 0.6,
                         since: str | None = None):
    prow = src.query(Q_PATIENT, (pid,))
    if not prow:
        return None, None
    prow = prow[0]
    pseudonym = privacy.pseudonym(pid)
    subject_ref = "urn:uuid:" + pseudonym if privacy.mode != "off" else f"Patient/{pid}"
    ctx = M.ExportContext(pid, pseudonym, subject_ref, privacy)

    med_rows = _since_filter(src.query(Q_MEDDOK, (pid,)), since, "ReferenceDateTime")
    schein_rows = _since_filter(src.query(Q_SCHEIN, (pid,)), since, "AusstellungsDateTime")
    labor_rows = _since_filter(src.query(Q_LABOR, (pid,)), since, "Datum")
    appt_rows = _since_filter(_safe(src, Q_APPT, pid), since, "StartDateTime")
    vital_rows = _since_filter(_safe(src, Q_VITAL, pid), since, "Datum")
    med_verord = _since_filter(_safe(src, Q_MED, pid), since, "ReferenceDateTime")
    med_dosierung = _safe(src, Q_MED_DOSIERUNG, pid)
    med_freitext = _safe(src, Q_MED_FREITEXT, pid)
    chronisch_rows = _safe(src, Q_CHRONISCH, pid)
    cave_rows = _safe(src, Q_CAVE, pid)
    hdrg_rows = _safe(src, Q_HDRG, pid)
    rechnung_rows = _since_filter(_safe(src, Q_RECHNUNG, pid), since, "RechnungsDatum")
    dmp_rows = _safe(src, Q_DMP, pid)
    hzv_rows = _safe(src, Q_HZV, pid)
    eau_rows = _safe(src, Q_EAU, pid)
    epa_rows = _since_filter(_safe(src, Q_EPA, pid) if with_epa else [], since,
                             "EventStartDateTime")
    chip_rows = _safe(src, Q_CHIPKARTE, pid)
    bezug_rows = _safe(src, Q_BEZUGSPERSON, pid)
    bezug_kontakt = _safe(src, Q_BEZUGSKONTAKT, pid)
    todo_rows = _since_filter(_safe(src, Q_TODO, pid), since, "CreatedPoint")
    heilm_rows = _safe(src, Q_HEILMITTEL, pid)
    heilm_items = _safe(src, Q_HEILMITTEL_ITEMS, pid)
    rezept_rows = _since_filter(_safe(src, Q_REZEPT, pid), since,
                                "ReferenceDateTime", "Ausstellungsdatum")
    rezinfo_rows = _safe(src, Q_REZEPTINFO, pid)
    rezdruck_rows = _safe(src, Q_REZEPTDRUCK, pid)
    rezdiag_rows = _safe(src, Q_REZEPTDIAG, pid)
    anhang_rows = _since_filter(_safe(src, Q_ANHANG_FULL if embed_anhaenge else Q_ANHANG_META,
                                      pid), since, "CreatedPoint")
    medplan_rows = _safe(src, Q_MEDPLAN, pid)
    medplan_items = _safe(src, Q_MEDPLAN_ITEMS, pid)
    medplan_freitext = _safe(src, Q_MEDPLAN_FREITEXT, pid)
    formularvar_rows = _safe(src, Q_FORMULARVAR, pid)

    # MedDok nach Domaene aufteilen
    diag = [r for r in med_rows if r["Kuerzel"] in CAT_DIAG]
    narr = [r for r in med_rows if r["Kuerzel"] in CAT_NARR]
    find = [r for r in med_rows if r["Kuerzel"] in CAT_FIND]
    letters = [r for r in med_rows if r["Kuerzel"] in CAT_LETTERS]
    au = [r for r in med_rows if r["Kuerzel"] in CAT_AU]
    docs = [r for r in med_rows if r["Kuerzel"] in CAT_DOCS]
    leist = [r for r in med_rows if r["Kuerzel"] == "L"]
    eau_by_meddok = {e["Id_MedDok"]: e for e in eau_rows}
    fv_by_meddok = {r["Id_MedDok"]: M.parse_formularvariablen(r.get("FormularVariablen"))
                    for r in formularvar_rows}
    kontakte_by_bp: dict = {}
    for k in bezug_kontakt:
        kontakte_by_bp.setdefault(k.get("Id_PatientBezugsperson"), []).append(k)
    heilm_by_verordnung: dict = {}
    for h in heilm_items:
        heilm_by_verordnung.setdefault(h.get("Id_PatientHeilmittelV2Verordnung"), []).append(h)
    freitext_by_id = {f["Id"]: (f.get("Freitext") or f.get("Text") or f.get("Freitextzeile"))
                      for f in medplan_freitext}
    rezinfo_by_rezept: dict = {}
    for ri in rezinfo_rows:
        rezinfo_by_rezept.setdefault(ri.get("Id_Rezept"), []).append(ri)
    rezdruck_by_info: dict = {}
    for rd in rezdruck_rows:
        rezdruck_by_info.setdefault(rd.get("Id_RezeptInfo"), []).append(rd)
    rezdiag_by_rezept: dict = {}
    for rd in rezdiag_rows:
        rezdiag_by_rezept.setdefault(rd.get("Id_Rezept"), []).append(rd)

    # Leistungen je Schein aufbereiten
    leist_by_schein: dict = {}
    for r in leist:
        det = parse_detail(r.get("Detail"), "L")
        if det.get("kind") == "leistung" and det.get("ziffer"):
            leist_by_schein.setdefault(r.get("Id_Schein"), []).append({
                "ziffer": det["ziffer"], "multiplikator": det.get("multiplikator"),
                "date": r.get("ReferenceDateTime"),
            })

    entries = []
    # Patient zuerst
    pat = M.map_patient(ctx, prow)
    entries.append({"fullUrl": subject_ref, "resource": pat})
    # Domaenen
    entries += M.map_conditions(ctx, diag)
    entries += M.map_scheine(ctx, schein_rows, leist_by_schein)
    entries += M.map_appointments(ctx, appt_rows)
    entries += M.map_narrative(ctx, narr)
    entries += M.map_findings(ctx, find)
    entries += M.map_arztbriefe(ctx, letters)
    entries += M.map_au(ctx, au, eau_by_meddok, fv_by_meddok)
    entries += M.map_documents(ctx, docs)
    entries += M.map_labor(ctx, labor_rows)
    entries += M.map_vitals(ctx, vital_rows)
    dos_by_verordnung: dict = {}
    for d in med_dosierung:
        dos_by_verordnung.setdefault(d.get("Id_Verordnung"), []).append(d)
    ft_by_verordnung = {f.get("Id_Verordnung"): f for f in med_freitext}
    entries += M.map_medication(ctx, med_verord, dos_by_verordnung, ft_by_verordnung)
    entries += M.map_chronische(ctx, chronisch_rows)
    entries += M.map_invoices(ctx, rechnung_rows)
    entries += M.map_dmp(ctx, dmp_rows)
    entries += M.map_hzv(ctx, hzv_rows)
    entries += M.map_cave(ctx, cave_rows)
    entries += M.map_hybriddrg(ctx, hdrg_rows)
    entries += M.map_coverage_chipkarte(ctx, chip_rows)
    entries += M.map_bezugsperson(ctx, bezug_rows, kontakte_by_bp)
    entries += M.map_todos(ctx, todo_rows)
    entries += M.map_heilmittel(ctx, heilm_rows, heilm_by_verordnung)
    entries += M.map_rezepte(ctx, rezept_rows, rezinfo_by_rezept, rezdruck_by_info, rezdiag_by_rezept)
    entries += M.map_medikationsplan(ctx, medplan_rows, medplan_items, freitext_by_id)
    entries += M.map_anhaenge(ctx, anhang_rows, embed=embed_anhaenge)
    if with_epa:
        entries += M.map_epa(ctx, epa_rows)

    # Dokument-Intelligence: Overlay-Annotationen + abgeleitete Ressourcen
    if annotate_provider is not None:
        _annotate_entries(ctx, entries, annotate_provider, annotate_min_score)

    bundle = {
        "resourceType": "Bundle",
        "id": "export-" + pseudonym,
        "type": "collection",
        "timestamp": _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "entry": entries,
    }

    comps = OE.build_compositions(pid, pseudonym, med_rows, labor_rows, privacy) if with_openehr else None

    # Assertion-Gate (CONCEPT.md 5.4): nichts verlaesst den Agent mit
    # Klartext-Identifikatoren. Policy (enforce/warn/off) + Ausnahmen fuer
    # bewusst deaktivierte De-ID-Schichten kommen aus der Privacy-Config.
    assert_clean([bundle] + (comps or []), prow, privacy)
    return bundle, comps


def _safe(src, sql, pid):
    """Query mit Fehlertoleranz (Tabelle/Spalte evtl. abweichend)."""
    try:
        return src.query(sql, (pid,))
    except Exception as e:
        sys.stderr.write(f"[warn] Query uebersprungen ({e})\n")
        return []


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--mode", choices=["full", "incremental"], default="full")
    ap.add_argument("--out", default="./out")
    ap.add_argument("--patient", type=int, help="Einzelner Patient (Test)")
    ap.add_argument("--limit", type=int, help="Nur erste N Patienten (Test)")
    ap.add_argument("--openehr", action="store_true", help="openEHR-Vorstufe zusaetzlich schreiben")
    ap.add_argument("--epa", action="store_true", help="ePA-Austauschmetadaten mit exportieren")
    ap.add_argument("--profile", choices=["r4", "mii", "kbv"], default="r4",
                    help="FHIR-Zielprofil (meta.profile), s. docs/UI_SPEC.md Abschnitt 7")
    ap.add_argument("--db", help="Pfad zum lokalen Store (data/clinical.db): Bundles "
                                 "zusaetzlich dorthin laden (inkl. Vault + ETL-Job)")
    ap.add_argument("--embed-anhaenge", action="store_true", dest="embed_anhaenge",
                    help="Binaerdaten der MedDok-Anhaenge base64 einbetten (Standard: nur Metadaten)")
    ap.add_argument("--annotate", action="store_true",
                    help="Dokument-Intelligence: Texte annotieren (Overlay + abgeleitete "
                         "Ressourcen), s. docs/DOKUMENTE_ANNOTATION.md")
    ap.add_argument("--ocr", action="store_true",
                    help="OCR fuer Scan-PDFs/Bilder aktivieren (Tesseract 'deu' noetig)")
    ap.add_argument("--terminology-server", dest="terminology_server",
                    help="FHIR-Terminologieserver-URL (on-premise), ergaenzt den lokalen Katalog")
    ap.add_argument("--since", help="Nur klinische Daten ab Datum (ISO, z.B. 2021-01-01); "
                                    "Stammdaten/CAVE/Chipkarte bleiben vollstaendig")
    args = ap.parse_args()

    def log(msg: str) -> None:
        """Laufprotokoll -> stdout; der Server leitet das nach logs/sync.log um
        (UI: Verwaltung -> Protokoll). flush, weil stdout in eine Datei geht."""
        print(f"[{_dt.datetime.now():%Y-%m-%d %H:%M:%S}] {msg}", flush=True)

    log(f"Export startet: mode={args.mode} profile={args.profile}"
        f"{' since=' + args.since if args.since else ''}"
        f"{' patient=' + str(args.patient) if args.patient else ''}"
        f" out={args.out}{' db=' + args.db if args.db else ''}")
    cfg = load_config(args.config)
    priv_cfg = cfg.get("privacy", {})
    privacy = Privacy(mode=priv_cfg.get("mode", "pseudonymize"),
                      secret=priv_cfg.get("hmac_key", ""),
                      date_shift=priv_cfg.get("date_shift", True),
                      free_text_deid=priv_cfg.get("free_text_deid", True),
                      keep_filenames=priv_cfg.get("keep_filenames", False),
                      gate=priv_cfg.get("gate", "enforce"))

    # Dokument-Intelligence: Provider aus Config/Flags (annotation:-Block, s. Einstellungen)
    ann_cfg = cfg.get("annotation", {}) or {}
    annotate_on = args.annotate or bool(ann_cfg.get("enabled"))
    min_score = float(ann_cfg.get("min_confidence", 0.6))
    provider = None
    if annotate_on:
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
        from reference.terminology import (LocalCatalogProvider, FhirTerminologyProvider,
                                           CompositeProvider)
        provider = LocalCatalogProvider.from_reference_dir(
            os.path.join(args.out, "reference"))
        ts_url = args.terminology_server or ann_cfg.get("terminology_server")
        if ts_url:
            provider = CompositeProvider(provider, FhirTerminologyProvider(ts_url))

    os.makedirs(args.out, exist_ok=True)
    fhir_dir = os.path.join(args.out, "fhir"); os.makedirs(fhir_dir, exist_ok=True)
    oe_dir = os.path.join(args.out, "openehr"); 
    if args.openehr:
        os.makedirs(oe_dir, exist_ok=True)

    # Optional: lokaler Store (SQLCipher/SQLite) als zusaetzliches Ziel
    store_conn = job_id = None
    if args.db:
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
        from store.db import open_store, new_id
        store_conn = open_store(args.db, key=privacy.secret or None)
        conflict = check_mode_switch(store_conn, privacy.mode)
        if conflict:
            log(f"ABBRUCH: {conflict}")
            store_conn.close()
            sys.exit(1)
        job_id = new_id()
        # PID in den Job: erlaubt 'Sync abbrechen' aus der Verwaltung heraus
        store_conn.execute(
            "INSERT INTO etl_export_job (id, mode, privacy, target, stats)"
            " VALUES (?,?,?,?,?)",
            (job_id, "single" if args.patient else args.mode, privacy.mode, "fhir",
             json.dumps({"pid": os.getpid()})))
        store_conn.commit()

    src = None
    try:
        # Quellverbindung INNERHALB des try: schlaegt der Connect fehl, wird der
        # Job trotzdem sauber als failed protokolliert (kein haengender running-Job)
        log(f"Verbinde mit Quelle {cfg['source'].get('host')}/"
            f"{cfg['source'].get('database')} ...")
        src = Source(cfg["source"]).connect()
        log("Quellverbindung steht.")

        # Watermark
        wm_path = os.path.join(args.out, "_watermark.json")
        prev_hwm = None
        if args.mode == "incremental" and os.path.exists(wm_path):
            prev_hwm = bytes.fromhex(json.load(open(wm_path))["hwm"])
        next_hwm = src.min_active_rowversion()

        # Patientenmenge bestimmen
        if args.patient:
            pids = [args.patient]
        elif args.mode == "incremental" and prev_hwm is not None:
            pids = sorted(src.changed_patient_ids(prev_hwm, RV_TABLES))
        else:
            pids = [r["Id"] for r in src.query(Q_PATIENT_ALL)]
        if args.limit:
            pids = pids[:args.limit]

        # Resume-Checkpoint: nach Absturz beim letzten fertigen Patienten weitermachen
        if store_conn is not None and not args.patient:
            row = store_conn.execute("SELECT rows_loaded FROM etl_watermark"
                                     " WHERE source_table='_resume'").fetchone()
            if row and row["rows_loaded"]:
                resume_pid = int(row["rows_loaded"])
                skipped = len([p for p in pids if p <= resume_pid])
                pids = [p for p in pids if p > resume_pid]
                print(f"Wiederaufsetzen nach Patient {resume_pid}"
                      f" ({skipped} bereits geladen, {len(pids)} verbleibend)")

        n_ok = n_res = 0
        errors: list[dict] = []
        total = len(pids)
        log(f"{total} Patienten zu verarbeiten.")
        for done, pid in enumerate(pids, start=1):
            try:
                bundle, comps = build_patient_bundle(src, pid, privacy, args.openehr,
                                                     args.epa, args.embed_anhaenge,
                                                     annotate_provider=provider,
                                                     annotate_min_score=min_score,
                                                     since=args.since)
                if not bundle:
                    continue
                if args.profile != "r4":
                    import profiles as P
                    bundle = P.apply_bundle(bundle, args.profile)
                pseudonym = bundle["id"].replace("export-", "")
                with open(os.path.join(fhir_dir, f"{pseudonym}.json"), "w", encoding="utf-8") as f:
                    json.dump(bundle, f, ensure_ascii=False, indent=2)
                if store_conn is not None:
                    from store.load import load_bundle
                    load_bundle(store_conn, bundle, job_id=job_id)
                    if privacy.mode == "pseudonymize":
                        from store.vault import store_mapping
                        nr = src.query("SELECT PatientNr FROM dbo.Patient WHERE Id = ?", (pid,))
                        store_mapping(store_conn, privacy.secret, pseudonym, pid,
                                      nr[0]["PatientNr"] if nr else None,
                                      privacy._shift_days(pid))
                if args.openehr and comps:
                    with open(os.path.join(oe_dir, f"{pseudonym}.json"), "w", encoding="utf-8") as f:
                        json.dump({"subject": pseudonym, "compositions": comps}, f, ensure_ascii=False, indent=2)
                n_ok += 1
                n_res += len(bundle["entry"])
            except Exception as exc:
                # Absturzsicherheit: ein fehlerhafter Patient bricht nicht den
                # ganzen Lauf ab -> protokollieren, ueberspringen, weiter.
                # Ausnahme: schlagen schon die ersten 25 fehl, ist der Fehler
                # systematisch -> abbrechen (Job wird als failed protokolliert).
                errors.append({"pid": pid, "error": str(exc)[:300]})
                log(f"FEHLER Patient {pid}: {exc}")
                if len(errors) <= 3:
                    import traceback
                    traceback.print_exc()
                if store_conn is not None:
                    store_conn.rollback()
                if n_ok == 0 and len(errors) >= 25:
                    raise RuntimeError(
                        f"Abbruch: die ersten {len(errors)} Patienten schlugen fehl "
                        f"- systematischer Fehler ({errors[0]['error']})") from exc
                continue
            if done % 100 == 0 or done == total:
                log(f"Fortschritt: {done}/{total} Patienten, {n_res} Ressourcen"
                    + (f", {len(errors)} Fehler" if errors else ""))
            if store_conn is not None:
                # Live-Fortschritt (UI-Verwaltung pollt den Job) + Resume-Checkpoint
                store_conn.execute(
                    "UPDATE etl_export_job SET stats=? WHERE id=?",
                    (json.dumps({"done": done, "total": total, "patients": n_ok,
                                 "resources": n_res, "last_pid": pid,
                                 "errors": len(errors),
                                 "since": args.since}), job_id))
                if not args.patient:
                    store_conn.execute(
                        "INSERT INTO etl_watermark (source_table, strategy, rows_loaded,"
                        " last_run_at) VALUES ('_resume','resume',?,datetime('now'))"
                        " ON CONFLICT(source_table) DO UPDATE SET"
                        " rows_loaded=excluded.rows_loaded, last_run_at=excluded.last_run_at",
                        (pid,))
                store_conn.commit()

        # Watermark fortschreiben: beim Voll-Lauf immer (neue Basislinie); beim
        # Inkrement nur ohne Fehler, damit uebersprungene Patienten beim
        # naechsten Lauf erneut erfasst werden.
        if not args.patient and next_hwm is not None and (args.mode == "full" or not errors):
            hexv = next_hwm.hex() if isinstance(next_hwm, (bytes, bytearray)) else str(next_hwm)
            with open(wm_path, "w") as f:
                json.dump({"hwm": hexv, "at": _dt.datetime.now().isoformat(), "mode": args.mode}, f)
        elif errors and not args.patient:
            log("Watermark NICHT fortgeschrieben (Fehler im Inkrement-Lauf) - "
                "betroffene Patienten werden beim naechsten Sync erneut versucht.")

        if store_conn is not None:
            store_conn.execute("DELETE FROM etl_watermark WHERE source_table='_resume'")
            end_status = "success" if (n_ok > 0 or not errors) else "failed"
            # Fehler nach Ursache gruppieren: '412× name _today is not defined; ...'
            # statt nur des ersten Einzelfalls (Details je Patient im sync.log)
            kinds: dict[str, int] = {}
            for e in errors:
                kinds[e["error"]] = kinds.get(e["error"], 0) + 1
            top = sorted(kinds.items(), key=lambda kv: -kv[1])
            end_error = ("; ".join(f"{n}× {msg[:150]}" for msg, n in top[:3])
                         + (f" (+{len(top) - 3} weitere Ursachen)" if len(top) > 3 else "")
                         if errors else None)
            store_conn.execute(
                "UPDATE etl_export_job SET finished_at=datetime('now'), status=?,"
                " error=?, stats=? WHERE id=?",
                (end_status, end_error,
                 json.dumps({"done": total, "total": total, "patients": n_ok,
                             "resources": n_res, "errors": len(errors),
                             "error_kinds": dict(top[:5]),
                             "error_samples": errors[:5], "since": args.since}), job_id))
            if next_hwm is not None:
                hexv = next_hwm.hex() if isinstance(next_hwm, (bytes, bytearray)) else str(next_hwm)
                store_conn.execute(
                    "INSERT INTO etl_watermark (source_table, strategy, last_rowversion,"
                    " last_run_at, rows_loaded) VALUES ('_global','rowversion',?,"
                    " datetime('now'),?) ON CONFLICT(source_table) DO UPDATE SET"
                    " last_rowversion=excluded.last_rowversion,"
                    " last_run_at=excluded.last_run_at, rows_loaded=excluded.rows_loaded",
                    (hexv, n_res))
            store_conn.commit()

        log(f"Fertig. Patienten: {n_ok}, Ressourcen gesamt: {n_res}, "
            f"Fehler: {len(errors)}, Ausgabe: {fhir_dir}")
    except Exception as exc:
        log(f"ABBRUCH: {exc}")
        if store_conn is not None:
            store_conn.execute("UPDATE etl_export_job SET finished_at=datetime('now'),"
                               " status='failed', error=? WHERE id=?", (str(exc), job_id))
            store_conn.commit()
        raise
    finally:
        if src is not None:
            src.close()
        if store_conn is not None:
            store_conn.close()


if __name__ == "__main__":
    main()
