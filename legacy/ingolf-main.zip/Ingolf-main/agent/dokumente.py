# -*- coding: utf-8 -*-
"""Text-Extraktion aus Dokument-Anhaengen (MedDokAnhang, FILESTREAM-Bytes).

stdlib-only (zipfile + ElementTree), kein python-docx noetig.

Wichtiger Struktur-Befund (verifiziert an echten medatixx-Arztbriefen):
Die DOCX sind FORMULARBASIERT - der gesamte Inhalt steckt in Word-TABELLEN,
nicht in Absaetzen (doc.paragraphs waere leer, 210-278 gefuellte Zellen je
Dokument). Die Extraktion laeuft deshalb ueber ALLE w:p-Elemente im Dokument-
baum - das erfasst Absaetze in Tabellenzellen automatisch mit.
"""
from __future__ import annotations

import io
import zipfile
from xml.etree import ElementTree as ET

_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
DOCX_MAGIC = b"PK\x03\x04"


def is_docx(raw: bytes | None) -> bool:
    return bool(raw) and bytes(raw[:4]) == DOCX_MAGIC


def _part_text(z: zipfile.ZipFile, name: str) -> list[str]:
    try:
        root = ET.fromstring(z.read(name))
    except (KeyError, ET.ParseError):
        return []
    parts = []
    for p in root.iter(_W + "p"):        # iteriert auch w:p in w:tbl/w:tc
        txt = "".join(t.text or "" for t in p.iter(_W + "t")).strip()
        if txt:
            parts.append(txt)
    return parts


def docx_text(raw: bytes) -> str | None:
    """Sichtbarer Text eines DOCX in Dokumentreihenfolge - Absaetze UND
    Tabellenzellen UND Kopf-/Fusszeilen (Gutachten 4c.3: Rechnungen tragen
    Absender/Adresse in header/footer, Formulare den Inhalt in Tabellen).
    None bei ungueltiger/leerer Datei."""
    try:
        with zipfile.ZipFile(io.BytesIO(bytes(raw))) as z:
            names = z.namelist()
            parts = []
            for n in sorted(n for n in names
                            if n.startswith("word/header") and n.endswith(".xml")):
                parts += _part_text(z, n)
            parts += _part_text(z, "word/document.xml")
            for n in sorted(n for n in names
                            if n.startswith("word/footer") and n.endswith(".xml")):
                parts += _part_text(z, n)
    except (zipfile.BadZipFile, ValueError, TypeError):
        return None
    return "\n".join(parts) or None


def attachment_text(raw: bytes | None) -> str | None:
    """Bestmoegliche Text-Extraktion je Dateityp (aktuell: DOCX; PDF/RTF folgen
    mit der Dokumenten-Pipeline, Gutachten 4c)."""
    if not raw:
        return None
    if is_docx(raw):
        return docx_text(raw)
    return None
