# -*- coding: utf-8 -*-
"""Quell-DB-Anbindung (MSSQL, read-only).

Bevorzugt pyodbc; faellt auf pytds zurueck (pure Python, kein ODBC-Treiber noetig
-> No-Admin-Deployment). Liefert Zeilen als dicts und normalisiert Datumswerte
nach ISO-8601 (UTC-naiv, wie in der Quelle gepflegt).
"""
from __future__ import annotations
import datetime as _dt
import re
from typing import Any, Iterable

try:
    import pyodbc  # type: ignore
    _HAVE_PYODBC = True
except Exception:
    _HAVE_PYODBC = False
try:
    import pytds  # type: ignore
    _HAVE_PYTDS = True
except Exception:
    _HAVE_PYTDS = False


def to_iso(v: Any) -> Any:
    """datetime/date -> ISO-8601 String; sonst unveraendert."""
    if isinstance(v, (_dt.datetime, _dt.date)):
        return v.isoformat()
    return v


# Fehlermeldung "unbekannte Spalte" je nach Serversprache/Treiber (Fehler 207).
# Die Umlaute kommen je nach Konsolen-Encoding auch kaputt an -> tolerant matchen.
_MISSING_COL = (
    re.compile(r"Spaltenname\s+[\"']([^\"']+)[\"']"),          # deutsch
    re.compile(r"[Ii]nvalid column name\s+[\"']([^\"']+)[\"']"),  # englisch
)


def _missing_column(exc: Exception) -> str | None:
    text = str(exc)
    for pat in _MISSING_COL:
        m = pat.search(text)
        if m:
            return m.group(1)
    return None


def _null_out(sql: str, col: str) -> str:
    """Fehlende Spalte in der SELECT-Liste durch NULL AS <col> ersetzen.

    Die Ergebniszeilen behalten so ihren Schluessel (Wert None) und alle
    Mapper funktionieren unveraendert. Schema-Abweichungen zwischen
    medatixx-Staenden brechen damit nicht den ganzen Export."""
    return re.sub(rf"\b(?:\w+\.)?{re.escape(col)}\b", f"NULL AS {col}", sql)


class Source:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self._conn = None
        self._paramstyle = "qmark"
        self._adapted: dict[str, str] = {}   # Original-SQL -> an Schema angepasst

    # -- Verbindung ---------------------------------------------------------
    def connect(self):
        c = self.cfg
        if _HAVE_PYODBC and c.get("prefer") != "pytds":
            drv = c.get("driver", "ODBC Driver 18 for SQL Server")
            enc = "yes" if c.get("encrypt", True) else "no"
            tsc = "yes" if c.get("trust_server_certificate", False) else "no"
            cs = (f"DRIVER={{{drv}}};SERVER={c['host']},{c.get('port',1433)};"
                  f"DATABASE={c['database']};UID={c['username']};PWD={c['password']};"
                  f"Encrypt={enc};TrustServerCertificate={tsc};ApplicationIntent=ReadOnly")
            self._conn = pyodbc.connect(cs, readonly=True)
        elif _HAVE_PYTDS:
            # Benannte Instanz ("HOST\INSTANZ"): Port NICHT erzwingen — die
            # Portaufloesung laeuft ueber den SQL Server Browser (UDP 1434).
            # Nur bei reinem Hostnamen den konfigurierten TCP-Port verwenden.
            if not c.get("password"):
                raise RuntimeError(
                    "Quell-DB-Passwort fehlt (Einstellungen -> Quellverbindung "
                    "speichern, damit password_ref aufgeloest werden kann).")
            kwargs = dict(
                dsn=c["host"], database=c["database"],
                user=c.get("username"), password=c.get("password"), as_dict=False,
                cafile=c.get("cafile"),
                validate_host=c.get("trust_server_certificate", False) is False,
            )
            if "\\" not in c["host"]:
                kwargs["port"] = int(c.get("port", 1433))
            self._conn = pytds.connect(**kwargs)
            self._paramstyle = "pyformat"   # pytds erwartet %s statt ?
        else:
            raise RuntimeError("Weder pyodbc noch pytds verfuegbar.")
        return self

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None

    # -- Abfragen -----------------------------------------------------------
    def _prep(self, sql: str, params: tuple) -> str:
        """Alle Quell-SQLs sind im qmark-Stil (?) geschrieben. pytds spricht
        pyformat (%s) -> Platzhalter uebersetzen, Literal-% schuetzen. Ohne
        Parameter formatiert pytds nicht, dann bleibt das SQL unveraendert."""
        if self._paramstyle == "pyformat" and params:
            return sql.replace("%", "%%").replace("?", "%s")
        return sql

    def _run(self, sql: str, params: tuple):
        """Cursor mit ausgefuehrtem SQL. Meldet die Quelle eine unbekannte
        Spalte (Schema-Abweichung zwischen medatixx-Staenden), wird sie in der
        SELECT-Liste durch NULL AS <col> ersetzt und die Abfrage wiederholt;
        die Anpassung wird je Query fuer den Rest des Laufs gemerkt."""
        run_sql = self._adapted.get(sql, sql)
        while True:
            cur = self._conn.cursor()
            try:
                # Ohne Parameter execute(sql) ohne Argument: pytds wuerde sonst
                # auch bei leerem Tupel %-formatieren (Literal-% braeche dann).
                if params:
                    cur.execute(self._prep(run_sql, params), params)
                else:
                    cur.execute(run_sql)
                return cur
            except Exception as exc:
                try:
                    cur.close()
                except Exception:
                    pass
                col = _missing_column(exc)
                new_sql = _null_out(run_sql, col) if col else run_sql
                if not col or new_sql == run_sql:
                    raise
                print(f"[WARN] Quelle kennt Spalte '{col}' nicht - wird als NULL "
                      f"exportiert (Schema-Abweichung).", flush=True)
                run_sql = new_sql
                self._adapted[sql] = new_sql

    def query(self, sql: str, params: Iterable[Any] = ()) -> list[dict]:
        cur = self._run(sql, tuple(params))
        cols = [d[0] for d in cur.description]
        out = []
        for row in cur.fetchall():
            out.append({c: to_iso(v) for c, v in zip(cols, row)})
        cur.close()
        return out

    def scalar(self, sql: str, params: Iterable[Any] = ()):
        cur = self._run(sql, tuple(params))
        r = cur.fetchone()
        cur.close()
        return r[0] if r else None

    # -- rowversion-Helfer --------------------------------------------------
    def min_active_rowversion(self) -> bytes:
        """Untere sichere Grenze fuer die naechste HWM (offene Transaktionen)."""
        return self.scalar("SELECT MIN_ACTIVE_ROWVERSION()")

    def changed_patient_ids(self, hwm: bytes | None, tables: list[str]) -> set[int]:
        """Ids aller Patienten mit Aenderung > hwm in einer der rowversion-Tabellen."""
        ids: set[int] = set()
        if hwm is None:
            return ids  # Full-Load erfolgt separat ueber alle Patienten
        for t in tables:
            sql = (f"SELECT DISTINCT Id_Patient FROM dbo.{t} "
                   f"WHERE RowVersion > CONVERT(binary(8), ?)")
            try:
                for r in self.query(sql, (hwm,)):
                    if r["Id_Patient"] is not None:
                        ids.add(int(r["Id_Patient"]))
            except Exception:
                # Tabelle ohne RowVersion o. Rechteproblem -> ueberspringen
                continue
        return ids
