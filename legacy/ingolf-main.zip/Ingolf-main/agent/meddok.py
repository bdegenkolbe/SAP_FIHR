# -*- coding: utf-8 -*-
"""Parser fuer die MedDok.Detail-XML-Blobs.

Drei beobachtete Schemata:
  <leistung>        -> Abrechnungsziffer (EBM/GOAe): ziffer, multiplikator, ...
  <MedDokDiagnose>  -> Diagnose: Icd, IcdBeschreibung, Sicherheit (G/Z/V/A)
  <MedDokFreitext>  -> Narrativer Text: FreitextPlain (bevorzugt) / FreitextHtml

parse_detail() liefert immer ein dict mit Schluessel "kind".
"""
from __future__ import annotations
import re, html
import xml.etree.ElementTree as ET


def _local(tag: str) -> str:
    return tag.split("}")[-1]


def strip_html(s: str | None) -> str:
    if not s:
        return ""
    s = html.unescape(s)
    s = re.sub(r"(?is)<\s*br\s*/?>", "\n", s)
    s = re.sub(r"(?is)</\s*(p|div|li)\s*>", "\n", s)
    s = re.sub(r"(?s)<[^>]+>", "", s)
    s = html.unescape(s)
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip()


def _find_local(root, name: str) -> str:
    for e in root.iter():
        if _local(e.tag) == name:
            return (e.text or "").strip()
    return ""


def parse_detail(xml_str: str | None, kuerzel: str | None = None) -> dict:
    if not xml_str:
        return {"kind": "empty"}
    try:
        root = ET.fromstring(xml_str)
    except ET.ParseError:
        return {"kind": "raw", "text": strip_html(xml_str)}

    tag = _local(root.tag).lower()

    if tag == "leistung":
        g = lambda n: (root.findtext(n) or "").strip()
        return {
            "kind": "leistung",
            "ziffer": g("ziffer"),
            "multiplikator": g("multiplikator") or "1",
            "nichtabrechenbar": g("nichtabrechenbar") == "true",
            "nichtverguetet": g("nichtverguetet") == "true",
            "idlaborheader": g("idlaborheader"),
        }

    if tag == "meddokdiagnose":
        return {
            "kind": "diagnose",
            "icd": _find_local(root, "Icd") or _find_local(root, "IcdCode"),
            "text": _find_local(root, "IcdBeschreibung") or _find_local(root, "Freitext"),
            "sicherheit": _find_local(root, "Sicherheit"),
            "seite": _find_local(root, "Seitenlokalisation"),
            "ausnahme": _find_local(root, "Ausnahmetatbestand"),
        }

    if tag == "meddokfreitext":
        plain = ""
        for e in root.iter():
            if _local(e.tag) == "FreitextPlain" and (e.text or "").strip():
                plain = e.text.strip()
                break
        if not plain:
            for e in root.iter():
                if _local(e.tag) == "FreitextHtml":
                    plain = strip_html(e.text)
                    break
        return {"kind": "freitext", "text": plain}

    if tag == "meddokformular":
        # Formulare (AU, Einweisung, Ueberweisungs-Vordrucke ...):
        # formularname + shortinfo (menschenlesbare Zusammenfassung).
        return {
            "kind": "formular",
            "formularname": _find_local(root, "formularname"),
            "shortinfo": _find_local(root, "shortinfo"),
        }

    # Fallback: unbekanntes Schema -> Text extrahieren
    return {"kind": "other", "root": tag, "text": strip_html(xml_str)}


# ---------------------------------------------------------------------------
# MedDokFormularVariable: JSON-Array [{id, value}] strukturierter Formularfelder.
# Wir lesen NUR klinisch relevante Felder (Praefix "_" bzw. Formular_*),
# und ignorieren bewusst Patient_*/Praxis_*/Arzt_* (PII / redundante Stammdaten).
# ---------------------------------------------------------------------------
_PII_PREFIXES = ("Patient_", "Praxis_", "Arzt_")


def parse_formularvariablen(json_str):
    """-> dict {feld_id: value}. Nur nicht-PII-Felder. value kann Skalar,
    dict (z.B. KbvDateTime -> .Date) oder Liste (Diagnosen) sein."""
    import json
    out = {}
    if not json_str:
        return out
    try:
        arr = json.loads(json_str)
    except (ValueError, TypeError):
        return out
    if not isinstance(arr, list):
        return out
    for it in arr:
        if not isinstance(it, dict):
            continue
        fid = it.get("id")
        if not fid or fid.startswith(_PII_PREFIXES):
            continue
        out[fid] = it.get("value")
    return out


def formular_datum(value):
    """Extrahiert ein ISO-Datum aus einem Formularwert (String oder KbvDateTime-dict)."""
    if value is None:
        return None
    if isinstance(value, str):
        return value[:19] if len(value) >= 10 else None
    if isinstance(value, dict):
        return (value.get("Date") or "")[:19] or None
    return None


def formular_diagnosen(value):
    """Extrahiert ICD-Diagnosen aus einem _Diagnose-Formularwert.
    -> list[{icd, text, sicherheit}]."""
    out = []
    if not value:
        return out
    items = []
    if isinstance(value, dict):
        items = value.get("$values") or [value]
    elif isinstance(value, list):
        items = value
    for d in items:
        if isinstance(d, dict) and d.get("Icd"):
            out.append({"icd": d.get("Icd"), "text": d.get("IcdBeschreibung"),
                        "sicherheit": d.get("Sicherheit")})
    return out
