#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Lokaler Extraktor fuer MedDokAnhang-BLOBs -> Dateien auf Platte.

LAEUFT IN DER PRAXIS (nicht in einer Analyse-Session): liest AnhangData/AnhangFs
read-only aus dem PVS, bestimmt den echten Dateityp per MAGIC BYTES (die FileName-
Endungen sind unzuverlaessig), schreibt pro Patient eine Datei und ein Manifest.
Optional pseudonyme Ordnernamen (ueber privacy.Privacy).

Aufruf:
  python agent/extract_anhaenge.py --config config/config.yaml --out ./anhaenge \
      [--patient 3659] [--pseudonym] [--limit 0] [--min-bytes 256]

Sicherheit: schreibt ausschliesslich lokal; keine Netzausleitung. Leere Platzhalter
(z.B. 0-Byte-RTF) werden uebersprungen.
"""
from __future__ import annotations
import argparse, os, csv, sys

try:
    from agent.documents import detect_type
    from agent.privacy import Privacy
except Exception:
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from agent.documents import detect_type
    from agent.privacy import Privacy

_EXT = {"pdf": "pdf", "docx": "docx", "doc": "doc", "rtf": "rtf", "jpg": "jpg",
        "png": "png", "tiff": "tif", "gif": "gif", "txt": "txt",
        "zip": "zip", "pptx": "pptx", "xlsx": "xlsx", "unknown": "bin", "empty": "bin"}


def _connect(cfg: dict):
    import pytds
    s = cfg["source"]
    return pytds.connect(server=s["host"].split("\\")[0], database=s["database"],
                         user=s.get("user") or None, password=s.get("password") or None,
                         as_dict=True)


def _load_cfg(path: str) -> dict:
    try:
        import yaml; return yaml.safe_load(open(path, encoding="utf-8"))
    except Exception:
        import json; return json.load(open(path, encoding="utf-8"))


def run(cfg: dict, out: str, patient: int | None, pseudonym: bool,
        limit: int, min_bytes: int) -> int:
    os.makedirs(out, exist_ok=True)
    priv = Privacy(mode="pseudonymize" if pseudonym else "off",
                   secret=(cfg.get("privacy", {}).get("hmac_key") or b"local-extract"))
    conn = _connect(cfg); cur = conn.cursor()
    where = "WHERE AnhangData IS NOT NULL"
    if patient:
        where += f" AND Id_Patient = {int(patient)}"
    top = f"TOP {int(limit)} " if limit else ""
    cur.execute(f"""SELECT {top}Id, Id_Patient, Id_MedDok, FileName, AnhangLength,
                           Tag, AnhangData
                    FROM dbo.MedDokAnhang {where} ORDER BY Id_Patient, Id""")

    manifest = open(os.path.join(out, "manifest.csv"), "w", newline="", encoding="utf-8")
    w = csv.writer(manifest); w.writerow(
        ["patient_dir", "id", "id_meddok", "doctype", "bytes", "filename_original", "written"])
    n_ok = n_skip = 0
    for r in cur:
        data = r["AnhangData"]
        data = bytes(data) if isinstance(data, (bytes, bytearray, memoryview)) else b""
        if len(data) < min_bytes:
            n_skip += 1; continue
        dtype = detect_type(data, r.get("FileName"))
        if dtype == "empty":
            n_skip += 1; continue
        pid = r["Id_Patient"]
        pdir = priv.pseudonym(pid) if pseudonym else f"patient_{pid}"
        d = os.path.join(out, pdir); os.makedirs(d, exist_ok=True)
        ext = _EXT.get(dtype, "bin")
        fname = f"anhang_{r['Id']}.{ext}"
        path = os.path.join(d, fname)
        with open(path, "wb") as f:
            f.write(data)
        # Originalname nur im off-Modus mitschreiben (kann PII enthalten)
        orig = r.get("FileName") if not pseudonym else "(pseudonymisiert)"
        w.writerow([pdir, r["Id"], r.get("Id_MedDok"), dtype, len(data), orig, fname])
        n_ok += 1
    manifest.close(); conn.close()
    print(f"Fertig: {n_ok} Dateien geschrieben, {n_skip} uebersprungen. Ziel: {out}")
    return 0


def main():
    ap = argparse.ArgumentParser(description="MedDokAnhang-BLOBs lokal als Dateien extrahieren")
    ap.add_argument("--config", required=True)
    ap.add_argument("--out", default="./anhaenge")
    ap.add_argument("--patient", type=int, default=None)
    ap.add_argument("--pseudonym", action="store_true", help="pseudonyme Ordnernamen")
    ap.add_argument("--limit", type=int, default=0, help="0 = alle")
    ap.add_argument("--min-bytes", type=int, default=256, help="kleinere BLOBs = Platzhalter, skip")
    a = ap.parse_args()
    return run(_load_cfg(a.config), a.out, a.patient, a.pseudonym, a.limit, a.min_bytes)


if __name__ == "__main__":
    raise SystemExit(main())
