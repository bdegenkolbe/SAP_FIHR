# CLAUDE.md — Arbeitsanleitung für Claude Code

Diese Datei gibt dir (Claude Code) den nötigen Kontext, um an diesem Projekt zu arbeiten,
ohne alle Dokumente neu erschließen zu müssen. Details in `docs/`.

## Was das Projekt ist
Ein in einer Arztpraxis installiertes Werkzeug, das read-only ein Praxis-MSSQL (PVS
„EUGASTRO", gastroenterologisch) ausliest und alle Patientendaten inkrementell nach
FHIR R4 (+ openEHR-Vorstufe) in einen lokalen, verschlüsselten Store exportiert. Dazu
Benutzerverwaltung, Audit und eine Analyseoberfläche mit Volltextannotation.

Randbedingungen (nicht verhandelbar):
- Klardaten verlassen die Praxis nicht. Pseudonymisierung/Anonymisierung ist Export-Option.
- Installation und Betrieb **ohne Adminrechte** (siehe `docs/DEPLOYMENT.md`).
- Read-only auf die Quelle (dedizierter Login `db_datareader`).

## Aktueller Stand
- `agent/` enthält den lauffähigen Multi-Patient-Export (FHIR + openEHR-Vorstufe),
  inkrementell über rowversion-Watermark, mit Pseudonymisierung/Date-Shift; optional
  `--db` (Load in den lokalen Store inkl. Vault/ETL-Job) und `--profile mii|kbv`
  (Profil-Layer `agent/profiles.py`).
- Der Einzel-Export für Patient 3659 (Björn Degenkolbe) ist verifiziert und dient als
  Golden-Record-Testfall.
- Parser/Mapper sind per Smoke-Test (`tests/test_smoke.py`) gegen echte Beispiel-XMLs geprüft.
- `store/` implementiert das lokale Schema aus `docs/SCHEMA.md` §3–4 als SQLite/SQLCipher
  (Präfix-Tabellen sec_/audit_/etl_/vault_/fhir_/nlp_/ref_), mit idempotentem Upsert +
  History, verschlüsseltem Re-ID-Vault, append-only-Audit (Hash-Kette), NLP-lite-Annotation
  (Terminologie-Matching + dt. Negation, stdlib) und FTS5-Volltextindex.
- `server/` + `ui/app/` sind die lauffähige Analyseplattform (FastAPI auf 127.0.0.1:8420,
  SPA ohne Build-Schritt): Login (Argon2id+TOTP, stdlib-TOTP), RBAC nach
  `docs/BENUTZERVERWALTUNG.md`, Patientenauswahl, 360°-Sicht, Kohorten-Analyse mit
  Aggregatschutz (n<5), Break-Glass mit Re-Auth+Begründung, Kataloge, Verwaltung
  (Benutzer/Audit/ETL), Einstellungen (FHIR-Profil). Demo: `tools/seed_demo.py`.
- Tests: `python -m pytest tests/ -q` (Smoke + Store + Auth/RBAC + API-E2E + Profile).
- Dokument-Intelligence (docs/DOKUMENTE_ANNOTATION.md) ist verdrahtet: Export-Flag
  `--annotate` (bzw. `annotation:`-Config) erzeugt Overlay-Annotationen + abgeleitete
  Ressourcen (NLP-Provenance); der Store übernimmt Overlays in nlp_annotation
  (entity_type DOC_CONCEPT); Analyse-Kriterium „Dokument-Konzept" + Provenienz-Schalter
  (structured/nlp/all); UI rendert annotierte Volltexte.
- Alle Laufzeit-Konfigurationen (privacy, annotation, Analyse-Provenienz, FHIR-Profil,
  Theme) liegen zentral in den Einstellungen (`server/settings.py`, app_setting +
  Write-Through nach config/config.yaml).
- KI-Integration ist konzipiert (docs/KI_INTEGRATION.md): Gateway mit 5 Kanälen
  (chat/embed/transcribe/ocr/code, Endpunkte extern bereitgestellt), Datenklassen-Policy +
  Prompt-Gate + Audit, ai-provenance an Entwürfen, Umsetzungsstufen 0-4
  (0=Gateway/Settings, 1=Arztbrief+RAG-Wissensassistent, 2=Transkription/OCR/Embeddings,
  3=NL→Kohorte/Auswertung+Code Interpreter, 4=LLM-Annotation/Kodierung).
  Bereits gebaut: der Code-Interpreter-Unterbau — `sandbox-service/` (1 Container je
  Session, kein Netz, Docker-Compose für den KI-Host; Dev-Tests via
  SANDBOX_RUNNER=subprocess) + Plattform-Client `server/ai/sandbox.RemoteSandbox`
  (tests/test_sandbox.py). Gateway/Settings/UI folgen mit Stufe 0/3.

## Datenlandkarte (Quelle dbo, verifiziert)
Zentralentität `Patient` (PK `Id`), 142 Tabellen mit `Id_Patient`. `MedDok` (1,1 Mio.)
ist die narrative/dokumentarische Drehscheibe: `Id_Schein` verknüpft mit dem Besuch,
`Id_MedDokKategorie` klassifiziert den Eintrag, `Detail` (XML) trägt den Inhalt,
`ReferenceDateTime` das klinische Datum.

Vier MedDok-Detail-Schemata:
- `<leistung>` (Kategorie L, 237k) → EBM/GOÄ-`ziffer`, `multiplikator` → Claim-Item.
- `<MedDokFreitext>` → `FreitextPlain` (bevorzugt) / `FreitextHtml` → narrativer Text.
- `<MedDokDiagnose>` (Kategorien D/DD/…) → `Icd`, `IcdBeschreibung`, `Sicherheit`.
- `<meddokformular>` (AU, Einweisungen, Formulare) → `formularname`, `shortinfo`.

Domäne → Quelle → FHIR (vollständige Tabelle in `docs/SCHEMA.md` §2, Registry in
`config/tables.yaml`):
- Stammdaten `Patient` → Patient
- Diagnosen `MedDok` D/DD/DDA/DDAB/FDD/FD → Condition
- Besuche/Fälle `Schein` → Encounter; Überweisung/Weiterüberweisung → ServiceRequest
- GKV/Privat-Abrechnung `Schein` + `MedDok` L → Claim
- Termine `SchedulerAppointment` → Appointment
- Anamnese/Befund/Verlauf `MedDok` A/V/FASA/AVA/B/E/PROC/I/TH/THV → Observation
- Fachbefunde `MedDok` SONO/FIBRO/FBEUR/PROCT/COLO/GASTR/URIN → DiagnosticReport
- Dokumente `MedDok` BRIEF/EAB/KRANK/KHB/AU/MDOK → DocumentReference
- Labor `Laborbogen` (JSON `Details`) → Observation + DiagnosticReport
- Vitalwerte `PatientVitalparameterRecord`+`Value`+`Vitalparameter` → Observation
- Medikation `VerordnungV2`+`Medikament`+`MedikamentAtc` → MedicationStatement
- CAVE `PatientCave` → Flag / AllergyIntolerance
- Privatabrechnung/IGeL `Rechnung` → Invoice
- Arztbriefe/Epikrisen `MedDok` BRIEF/EAB/E → Composition (voller Text)
- Arbeitsunfähigkeit `MedDok` AU/ALTAU/AFAU (`<meddokformular>`) + `Eau` (eAU-Status via Id_MedDok) → DocumentReference (eAU)
- ePA-Austausch `EpaEventLog`+`EpaDocumentMeta` → DocumentReference (optional, `--epa`)
- Chipkarte `PatientChipkarte` → Coverage (aktuellste Karte; VersichertenNr/KVNR wertbasiert gehasht)
- Bezugsperson `PatientBezugsperson`(+Kontakt) → RelatedPerson (Name/Kontakt bei Pseudonymisierung entschärft)
- ToDo `TodoItem` → Task (patientenbezogen; kein RowVersion → kein Delta)
- Heilmittel `PatientHeilmittelV2Verordnung`(+Heilmittel) → ServiceRequest
- Rezept `RezeptV2` + `RezeptInfo`(+`RezeptInfoDruck`) + `RezeptDiagnose` → MedicationRequest je Verordnungszeile (PZN, Dosierung, ICD-reasonCode, aut-idem, groupIdentifier je Rezept)
- Medikationsplan `Medikationsplan`(+Item/Freitext) → List (BMP), referenziert Verordnungs-MedicationStatements
- Formularvariablen `MedDokFormularVariable` → Anreicherung strukturierter AU-Eckdaten (bevorzugt vor shortinfo)
- `MedDokExtensionData` (496k): rohe BDT/xDT-Feldkennungen, **nicht** als eigener Ressourcentyp exportiert (redundant zu Labor/Leistung; Fallback-Quelle)
- `MedDokAnhang`: Datei-Anhänge → DocumentReference (Standard nur Metadaten; `--embed-anhaenge` bettet base64 ein)
- DMP `PatientDmp` (0 Zeilen hier) → EpisodeOfCare
- HZV/Selektivvertrag `HzvPatientTeilnahme` (0 Zeilen hier) → Coverage; Kennzeichen sonst am Schein
- HybridDRG `AbrechnungHybridDrg` (derzeit 0 Zeilen, strukturell vorgesehen) → Claim

### Referenz-/Katalogdaten (kein PHY) — `reference/build_reference.py`
Einmal-/periodischer Lauf, exportiert Kataloge als FHIR-Terminologie:
- `LaborIdentKatalog` → ObservationDefinition (mit geschlechtsspezifischen Referenzbereichen)
- `Vitalparameter` → ObservationDefinition
- `Medikament`+`MedikamentWirkstoff`+`MedikamentAtc` → Medication (ingredient + ATC)
- `GoaeZiffer` → ChargeItemDefinition (Eigen-/Analogziffern der Praxis)
- `MedDokKategorie` → CodeSystem
Nicht in der DB und extern zu ergänzen: vollständige LOINC-, ICD-10-GM-, ATC-, GOÄ/EBM-Register.

Drei MedDok-Detail-Schemata (Parser in `meddok.py`): `<leistung>`, `<MedDokFreitext>`
(FreitextPlain/Html), `<MedDokDiagnose>`, `<meddokformular>` (Formulare wie AU: formularname+shortinfo).

Inkrementell über `RowVersion` (rowversion) auf den Bewegungstabellen; Löschungen über
periodischen Reconcile (Key-Diff).

## Baureihenfolge (Roadmap)
MVP: (1) Verbindung + Rechte-Check, (2) `tables.yaml` als Registry pflegen, (3) Full-Load
der Kern-Domänen, (4) Pseudonymisierung + Assertion-Gate, (5) FHIR-Mapper (vorhanden) gegen
Golden Record testen, (6) minimale Patienten-Timeline.
Ausbau 1: rowversion-Incremental + restliche Domänen + lokaler Store (SQLCipher) +
Benutzerverwaltung/Audit (DDL in `docs/SCHEMA.md`).
Ausbau 2: NLP-Annotation (spaCy + Negation + Terminologie) + FTS5-Suche + openEHR-CDR
(optional, nur mit IT-Infrastruktur).

## Konventionen
- Python 3.11+, stdlib-first. DB treiberfrei über `pytds` (No-Admin); `pyodbc` optional.
- Lokaler Store im No-Admin-Betrieb: SQLCipher (verschlüsseltes SQLite), Key via DPAPI.
  DDL aus `docs/SCHEMA.md` von PostgreSQL nach SQLite übersetzen (Präfixe statt Schemas,
  JSON1 + generierte Spalten statt jsonb/GIN, append-only-Audit per Trigger).
- FHIR-IDs stabil per uuid5 (idempotenter Upsert). Datumswerte laufen durch den Date-Shift.
- Kodiersysteme: ICD-10-GM, ATC, PZN, LOINC, UCUM.

## Caveats (vor Produktivlauf verifizieren)
- FK-Ketten Vitalwerte/Medikation sind verifiziert und in `agent/export.py` fest verdrahtet:
  Vitals über `PatientVitalparameterValue.Id_VitalparameterRecord` + `.Id_Vitalparameter`,
  Wert in `.Value`; Medikation über `VerordnungV2.Id_Medikament` → `Medikament`,
  ATC/Wirkstoff aus `MedikamentAtc` (`AtcCode`, `Bezeichnung`).
- **Befundgutachten 2026-07 (docs-Upload, inhaltlich gegen die Live-DB belegt):**
  `VerordnungV2.ItemType` 1=Fertigarznei, 2=Rezeptur, 3=Freitext, 4=DiGA; `Pzn` ist bei
  ALLEN Typen gefüllt → Trennmerkmal ist `Id_Medikament`; Artikelname/Darreichungsform
  für 2/3 aus `VerordnungFreitext`, Dosierschema aus `MedikamentDosierungV2` (beide im
  Export). Blutdruck: Vitalparameter Id 5=sys/6=dia am selben Record → EIN Observation
  mit Komponenten. Labor: qualitative Befunde nur in `$.ErgebnisText` → COALESCE-Filter.
  `Eau.State`: 0 neu/1 versendet/3 Fehler/5 storniert/6 Antwort läuft/7 abgeschlossen.
  `MedDokAnhang`: Bytes liegen im FILESTREAM (`AnhangFs`), `AnhangData` ist leer →
  COALESCE; DOCX-Arztbriefe sind TABELLENBASIERT (Text in Zellen, nicht Absätzen) →
  `agent/dokumente.docx_text` iteriert alle w:p (erfasst Tabellen). `ChronischeErkrankung`
  → Condition. `Medikationsplan`-PK ist `Id_Patient`. Offen (P1): NFDM-Familie,
  LaborHeader/-Anforderung, MedDokFormularVariable→Questionnaire (Gutachten 4b),
  Dokumenten-Pipeline mit OCR/SNOMED (4c), Freitext-Notizen N/NOTIZ.
- Geschlecht-Enum: in dieser DB 2=männlich, 1=weiblich (`GENDER` in `mappers.py`).
- `Scheinart` ist ein int-Enum → aktuell lokaler Code; ggf. Mapping-Tabelle ergänzen.
- DMP (`PatientDmp`) und HZV (`HzvPatientTeilnahme`) sind in dieser gastroenterologischen
  Praxis leer (0 Zeilen). Die Mapper (`map_dmp`, `map_hzv`) sind defensiv/config-getrieben
  für andere Praxen vorgesehen; Spaltennamen dort via `describe_table` verifizieren, sobald
  Daten vorliegen. Abrechnungsweg (GKV/Privat/IGeL/HZV) wird zusätzlich aus Schein-Feldern
  (`IsIgel`, `IsPrivat`, `RechnungsTyp`, `HzvVertragKennung`, `HonorarAnlageId`) als
  `Claim.subType` abgeleitet. **Live-Befund 2026-07:** `Schein.IsPrivat` existiert in
  der Praxis-DB nicht — korrekter Ersatz ist `Schein.AbrechnungsArt` (1=GKV,
  2=Privat/IGeL mit `IsIgel`-Trennung, 3=BG/Unfall; im Mapper umgesetzt, alte
  Kennzeichen als Fallback für andere Installationen). `dbsource.Source` faengt
  unbekannte Spalten generisch ab (Fehler 207 -> `NULL AS <col>` + Retry, je Query
  gemerkt), der Export laeuft weiter; fehlende Spalten stehen als `[WARN]` im sync.log.
- Datenqualität: PATID-Anomalie beobachtet (fremde Kennung in einer Laborsitzung) →
  Plausibilitätscheck PatientNr ↔ Id beim Labor-Import.
- Bei `mode=pseudonymize` wird das Geburtsdatum auf das Jahr reduziert; bei Bedarf in
  `privacy.redact_patient` auf date-shifted Volldatum umstellen.

## Datenschutz
Verarbeitung besonderer Kategorien (Art. 9 DSGVO). Rechtsgrundlage/AV vor Produktivbetrieb
klären. Re-Identifikationstabelle (Pseudonym→echte Id) gehört in den separat gesicherten
Vault, niemals in Exportdateien oder in die Analysezone.
## PVS-Ausbau (FHIR/openEHR-natives Praxissystem)

Der Ordner `pvs/` + `docs/pvs/` erweitert die Plattform zum PVS (Strangler-Pattern,
medatixx bleibt zunächst Abrechnungs-/TI-Terminal). **Einstieg: `docs/pvs/00-OVERVIEW.md`**
(Bauplan, Modulreihenfolge, CLI, Definition-of-Done je Spec).

Regeln zusätzlich zu oben:
- `agent/` ist Single Source of Truth für Quell-SQL, Blob-Parser und FHIR-Mapper —
  aus `pvs/` nur importieren (via `pvs/etl/eug_bridge.py`), nie duplizieren.
- Offene Verifikationspunkte sind mit `# VERIFY` markiert (KVDT-Feldkennungen,
  PADneXt-XSD, GOÄ-Punktwert, Zeichensatz). Gegen offizielle Quellen auflösen
  (KBV-ITA-Satzbeschreibung, PADline-Schema), nicht raten.
- Golden Records: 3659 und 76824 (`pvs/etl/validate_golden.py`, Sollwerte fixiert).
- Tests ohne DB: `python -m pytest tests/ -q` (Bestand + `tests/test_pvs.py`).
