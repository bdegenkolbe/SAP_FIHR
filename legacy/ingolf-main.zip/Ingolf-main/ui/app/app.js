/* GREENBAY clinical — SPA (vanilla JS, kein Build-Schritt: No-Admin-tauglich).
   Screens gemäß docs/UI_SPEC.md; Design aus /design/tokens.css + app.css. */
"use strict";

const state = {
  token: sessionStorage.getItem("gb_token") || null,
  me: null,               // {username, permissions, mode}
  route: location.hash.slice(1) || "patients",
  expr: { items: [], ops: [] },   // Kohorten-Builder: Ausdrucksbaum (Kette+Klammern)
  mfaRequired: true,      // aus /api/status (Einstellung auth_mfa)
};

// ---------- API-Client ----------
async function api(path, opts = {}) {
  const headers = { "Content-Type": "application/json", ...(opts.headers || {}) };
  if (state.token) headers["Authorization"] = "Bearer " + state.token;
  const res = await fetch(path, { ...opts, headers });
  if (res.status === 401 && state.me) { logout(); throw new Error("Session abgelaufen"); }
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail || res.statusText);
  }
  return res.json();
}
const esc = (s) => String(s ?? "").replace(/[&<>"']/g,
  (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// ---------- Mehrsprachigkeit (ui/app/i18n.js; Referenzsprache Deutsch) ----------
let LANG = localStorage.getItem("gb_lang") || "de";
const t = (key) => {
  const packs = window.GB_I18N || { de: {} };
  return (packs[LANG] || {})[key] ?? (packs.de || {})[key] ?? key;
};
function setLang(lang) {
  if (!(window.GB_I18N || {})[lang]) return;
  LANG = lang;
  localStorage.setItem("gb_lang", lang);
  route();
}

// ---------- Shell / Routing ----------
const NAV = [
  ["patients", "🧑‍⚕️", "nav.patients", ["patient.search.pseudo", "patient.search.clear"]],
  ["analyse", "📊", "nav.analyse", ["analysis.run"]],
  ["kataloge", "📚", "nav.kataloge", []],
  ["verwaltung", "🛡️", "nav.verwaltung", ["user.manage", "audit.read", "etl.manage"]],
  ["einstellungen", "⚙️", "nav.einstellungen", []],
];
// Externe Module (Prototypen): PVS-Sicht (docs/pvs/70-PVS-SICHT-SPEC.md)
const NAV_EXTERNAL = [
  ["/mockups/pvssicht.html", "🩺", "nav.pvs", ["patient.view.clear"]],
];

function can(...perms) {
  if (!perms.length) return true;
  return perms.some((p) => state.me?.permissions?.includes(p));
}

function shell(content) {
  const badge = state.me?.mode === "clear"
    ? `<span class="mode-badge clear" title="Klardaten-Modus — protokolliert">🔓 KLAR</span>`
    : `<span class="mode-badge pseudonym">🔒 ${esc((state.me?.mode || "pseudonym").toUpperCase())}</span>`;
  return `
  <nav class="rail" aria-label="Hauptnavigation">
    <div class="gb-logo"><span class="mark">GREENBAY</span> <span class="sub">clinical</span></div>
    ${NAV.filter(([, , , p]) => can(...p)).map(([r, icon, key]) =>
      `<a class="nav-item ${state.route.startsWith(r) ? "active" : ""}" href="#${r}">${icon} ${esc(t(key))}</a>`).join("")}
    ${NAV_EXTERNAL.filter(([, , , p]) => can(...p)).map(([href, icon, key]) =>
      `<a class="nav-item" href="${href}" target="_blank" rel="noopener">${icon} ${esc(t(key))} ↗</a>`).join("")}
    <div class="spacer"></div>
    <a class="nav-item" href="#" id="nav-logout">⏻ ${esc(t("nav.logout"))}</a>
  </nav>
  <div>
    <header class="topbar">
      <div class="search"><input type="search" id="global-q" placeholder="Suche: Pseudonym · ICD · ATC · Freitext …" aria-label="Globale Suche"></div>
      ${badge}
      <span class="user-chip">👤 ${esc(state.me?.username || "")}</span>
    </header>
    <main class="main" id="main">${content}</main>
  </div>`;
}

function render(content, bare = false) {
  const root = document.getElementById("root");
  root.className = bare ? "shell bare" : "shell";
  root.innerHTML = bare ? content : shell(content);
  if (!bare) {
    document.getElementById("nav-logout").onclick = (e) => { e.preventDefault(); logout(); };
    const q = document.getElementById("global-q");
    q.onkeydown = (e) => {
      if (e.key === "Enter") { location.hash = "patients?q=" + encodeURIComponent(q.value); }
    };
  }
}

function logout() {
  api("/api/logout", { method: "POST" }).catch(() => {});
  sessionStorage.removeItem("gb_token");
  state.token = null; state.me = null;
  route();
}

// ---------- Setup & Login ----------
async function viewSetup() {
  render(`<div class="auth-wrap"><div class="card auth-card"><div class="card-b">
    <div class="gb-logo"><span class="mark">GREENBAY</span> <span class="sub">clinical</span></div>
    <h1>Ersteinrichtung</h1>
    <p>Es existiert noch kein Benutzer. Lege das <b>Owner-Konto</b> an (BENUTZERVERWALTUNG §4).</p>
    <label>Benutzername</label><input class="input" id="su-user">
    <label>Vollständiger Name</label><input class="input" id="su-name">
    <label>Passwort (min. 12 Zeichen)</label><input class="input" type="password" id="su-pass">
    <div class="mt"><button class="btn btn-grad" id="su-go">Owner anlegen</button></div>
    <div id="su-out" class="mt"></div>
  </div></div></div>`, true);
  document.getElementById("su-go").onclick = async () => {
    try {
      const r = await api("/api/setup", { method: "POST", body: JSON.stringify({
        username: val("su-user"), full_name: val("su-name"), password: val("su-pass") }) });
      document.getElementById("su-out").innerHTML = `
        <p class="pill ok">Owner angelegt — TOTP jetzt einrichten!</p>
        <p><b>TOTP-URI</b> (Authenticator-App):</p><div class="qr-uri">${esc(r.totp_uri)}</div>
        <p class="mt"><b>Recovery-Codes</b> (einmalige Anzeige!):</p>
        <div class="qr-uri">${r.recovery_codes.map(esc).join("<br>")}</div>
        <div class="mt"><a class="btn btn-primary" href="#login" onclick="location.reload()">Zum Login</a></div>`;
    } catch (e) { document.getElementById("su-out").innerHTML = errBox(e); }
  };
}

async function viewLogin() {
  render(`<div class="auth-wrap"><div class="card auth-card"><div class="card-b">
    <div class="gb-logo"><span class="mark">GREENBAY</span> <span class="sub">clinical</span></div>
    <h1>Anmelden</h1>
    <label>Benutzername</label><input class="input" id="li-user" autocomplete="username">
    <label>Passwort</label><input class="input" type="password" id="li-pass">
    ${state.mfaRequired ? `
    <label>TOTP-Code (oder leer + Recovery-Code)</label><input class="input" id="li-totp" inputmode="numeric">
    <label>Recovery-Code (nur falls TOTP nicht verfügbar)</label><input class="input" id="li-rec">`
    : '<p><small>Zwei-Faktor-Anmeldung ist deaktiviert (Einstellung „Anmeldung").</small></p>'}
    <div class="mt"><button class="btn btn-grad" id="li-go">Anmelden</button></div>
    <div id="li-out" class="mt"></div>
  </div></div></div>`, true);
  const go = async () => {
    try {
      const r = await api("/api/login", { method: "POST", body: JSON.stringify({
        username: val("li-user"), password: val("li-pass"),
        totp: val("li-totp") || null, recovery_code: val("li-rec") || null }) });
      state.token = r.token; sessionStorage.setItem("gb_token", r.token);
      state.me = { username: r.username, permissions: r.permissions, mode: r.mode };
      location.hash = "patients"; route();
    } catch (e) { document.getElementById("li-out").innerHTML = errBox(e); }
  };
  document.getElementById("li-go").onclick = go;
  document.querySelectorAll(".auth-card input").forEach((i) =>
    i.addEventListener("keydown", (e) => { if (e.key === "Enter") go(); }));
}

// ---------- Patienten (UI_SPEC §3) ----------
async function viewPatients(params) {
  const q = params.get("q") || "";
  render(`
    <div class="card"><div class="card-h"><span class="card-title">Patientenauswahl</span>
      <button class="btn" id="as-cohort" title="Filter ans Analysetool übergeben">Als Kohorte analysieren →</button></div>
    <div class="card-b">
      <div class="row">
        <input class="input" style="flex:2" id="pq" placeholder="Pseudonym / ICD / Freitext" value="${esc(q)}">
        <input class="input" style="flex:1" id="picd" placeholder="ICD-Filter, Präfix (I10 findet I10.90)">
        <input class="input" style="flex:1" id="patc" placeholder="ATC-Filter, Präfix (z. B. A10)">
        <button class="btn btn-primary" id="pgo">Suchen</button>
      </div>
      <div id="plist" class="mt">${skeletonRows(5)}</div>
    </div></div>`);
  const load = async () => {
    const el = document.getElementById("plist");
    el.innerHTML = skeletonRows(5);
    try {
      const query = new URLSearchParams({ q: val("pq"), icd: val("picd"), atc: val("patc") });
      const r = await api("/api/patients?" + query);
      if (!r.items.length) {
        el.innerHTML = `<div class="empty">Keine Treffer.<br><small>Filter lockern oder anderen Begriff versuchen.</small></div>`;
        return;
      }
      el.innerHTML = `
        <p class="pill info">${r.total} Treffer</p>
        <table class="data"><thead><tr><th>${r.items.some((p) => p.name) ? "Name · " : ""}Pseudonym</th><th>Alter/Geschl.</th>
        <th>Aktive Diagnosen</th><th>Letzter Laborwert</th><th>Medik.</th><th>Letzter Besuch</th></tr></thead>
        <tbody>${r.items.map((p) => `
          <tr class="click" data-p="${esc(p.pseudonym)}">
            <td>${p.name ? `<b>${esc(p.name)}</b> <small>· ${esc(p.pseudonym)}</small>`
              : `<b>${esc(p.pseudonym)}</b>`}${p.cave_count ? ' <span class="pill crit">CAVE</span>' : ""}</td>
            <td>${p.age ?? "–"} / ${esc(gender(p.gender))}</td>
            <td>${p.diagnoses.map((d) => `<span class="pill">${esc(d.icd)}</span>`).join(" ")}</td>
            <td>${labPill(p.last_lab)}</td>
            <td>${p.medication_count}</td>
            <td>${esc((p.last_visit || "–").slice(0, 10))}</td>
          </tr>`).join("")}</tbody></table>`;
      el.querySelectorAll("tr.click").forEach((tr) =>
        tr.onclick = () => { location.hash = "patient/" + tr.dataset.p; });
    } catch (e) { el.innerHTML = errBox(e); }
  };
  document.getElementById("pgo").onclick = load;
  document.getElementById("as-cohort").onclick = () => {
    const icd = val("picd"), term = val("pq");
    const g = [];
    if (icd) g.push({ type: "icd", code: icd });
    if (val("patc")) g.push({ type: "atc", code: val("patc") });
    if (term) g.push({ type: "text", term, negated: false });
    state.expr = { items: g, ops: g.slice(1).map(() => "and") };
    location.hash = "analyse";
  };
  load();
}

// ---------- 360°-Patientensicht (UI_SPEC §4) ----------
async function viewPatient(pseudonym) {
  render(`<div id="p360">${skeletonRows(8)}</div>`);
  let d;
  try { d = await api("/api/patients/" + encodeURIComponent(pseudonym)); }
  catch (e) { document.getElementById("p360").innerHTML = errBox(e); return; }

  const kpi = (n, l) => `<div class="card kpi"><div class="num">${n}</div><div class="lbl">${l}</div></div>`;
  const tabs = [t("tab.uebersicht"), t("tab.diagnosen"), t("tab.labor"),
    t("tab.medikation"), t("tab.dokumente"), t("tab.termine"), t("tab.abrechnung")];
  document.getElementById("p360").innerHTML = `
    <div class="row" style="justify-content:space-between">
      <div><h1>${d.name ? `${esc(d.name)} <small style="opacity:.5">· ${esc(pseudonym)}</small>` : esc(pseudonym)}</h1>
        <div class="row mt" style="margin-top:6px">
          <span class="pill">${d.age ?? "–"} Jahre · ${esc(gender(d.gender))}</span>
          ${(d.flags || []).map((f) => `<span class="pill crit">⚠ ${esc(f.code?.text || f.text?.div || "CAVE")}</span>`).join("")}
        </div></div>
      <div class="row">
        <button class="btn" id="ai-analyze">${esc(t("ai.analyze"))}</button>
        ${can("reid.request") ? `<button class="btn" style="color:var(--crit)" id="breakglass">${esc(t("p360.breakglass"))}</button>` : ""}
      </div>
    </div>
    <div class="grid cols-4 mt">
      ${kpi(d.kpis.active_diagnoses, "Aktive Diagnosen")}
      ${kpi(d.kpis.active_medication, "Dauermedikation")}
      ${kpi(`${d.kpis.labs_flagged}<small>/${d.kpis.labs_total}</small>`, "Labor auffällig")}
      ${kpi(d.kpis.au_entries, "AU / Dokumente")}
    </div>
    <div class="tabs mt" role="tablist">${tabs.map((t, i) =>
      `<span class="tab ${i === 0 ? "active" : ""}" role="tab" tabindex="0" data-t="${i}">${t}</span>`).join("")}</div>
    <div id="tabbody"></div>
    <div id="modal"></div>`;

  const body = document.getElementById("tabbody");
  const wireUebersicht = () => {
    document.querySelectorAll(".lab-tile").forEach((t) => t.onclick = () => {
      d._labKey = t.dataset.k;
      showTab(2);
    });
  };
  const wireLabor = () => {
    const sel = document.getElementById("lab-sel");
    if (sel) sel.onchange = () => { d._labKey = sel.value; showTab(2); };
    document.querySelectorAll(".lab-mini").forEach((m) => m.onclick = () => {
      d._labKey = m.dataset.k;
      showTab(2);
    });
  };
  const showTab = (i) => {
    document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t.dataset.t == i));
    if (i == 0) { body.innerHTML = tabUebersicht(d); wireUebersicht(); }
    if (i == 1) body.innerHTML = tabDiagnosen(d);
    if (i == 2) { body.innerHTML = tabLabor(d); wireLabor(); }
    if (i == 3) body.innerHTML = tabMedikation(d);
    if (i == 4) body.innerHTML = tabDokumente(d);
    if (i == 5) body.innerHTML = tabTermine(d);
    if (i == 6) body.innerHTML = tabAbrechnung(d);
  };
  document.querySelectorAll(".tab").forEach((t) => {
    t.onclick = () => showTab(t.dataset.t);
    t.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") showTab(t.dataset.t); };
  });
  showTab(0);

  const bg = document.getElementById("breakglass");
  if (bg) bg.onclick = () => breakGlassModal(pseudonym);

  document.getElementById("ai-analyze").onclick = () => {
    const m = document.getElementById("modal");
    m.innerHTML = `<div class="modal-back"><div class="card modal" style="max-width:820px;width:92%">
      <div class="card-h"><span class="card-title">${esc(t("ai.title"))} — ${esc(pseudonym)}</span>
        <button class="btn" id="ai-close">${esc(t("common.close"))}</button></div>
      <div class="card-b">
        <label>Frage (optional — leer = Gesamteinschätzung zu Labor/Diagnosen/Medikation)</label>
        <input class="input" id="ai-q" placeholder="z. B. Passt die Medikation zu den Leberwerten?">
        <div class="row mt"><button class="btn btn-primary" id="ai-go">Analysieren</button></div>
        <div id="ai-out" class="mt"></div>
      </div></div></div>`;
    document.getElementById("ai-close").onclick = () => (m.innerHTML = "");
    document.getElementById("ai-go").onclick = async () => {
      const out = document.getElementById("ai-out");
      out.innerHTML = skeletonRows(3);
      try {
        const r = await api("/api/ai/analyze", { method: "POST",
          body: JSON.stringify({ pseudonym, question: val("ai-q") }) });
        out.innerHTML = `<pre style="white-space:pre-wrap;max-height:50vh;overflow:auto">${esc(r.answer)}</pre>
          <p class="mt"><span class="pill warn">${esc(t("ai.disclaimer"))}</span></p>`;
      } catch (e) { out.innerHTML = errBox(e); }
    };
  };
}

function tabUebersicht(d) {
  // Statuskacheln nach Patientendashboard-Mockup: letzter Wert, Trendpfeil,
  // Referenz; auffällige Werte rot markiert; Klick öffnet den Labor-Explorer.
  const tiles = (d.lab_series || [])
    .filter((s) => s.points.filter((p) => typeof p.v === "number").length >= 2)
    .sort((a, b) => b.points.length - a.points.length).slice(0, 8).map((s) => {
      const pts = s.points.filter((p) => typeof p.v === "number");
      const last = pts[pts.length - 1], prev = pts[pts.length - 2];
      const delta = last.v - prev.v;
      const arrow = Math.abs(delta) < 1e-9 ? "→" : delta > 0 ? "↑" : "↓";
      return `<div class="card kpi lab-tile" data-k="${esc(s.code)}"
        style="text-align:left;padding:12px 14px;cursor:pointer${last.flag
          ? ";border-left:3px solid var(--crit)" : ";border-left:3px solid var(--gb-teal)"}">
        <small>${esc(s.name)}</small>
        <div class="num" style="font-size:24px">${fmtNum(last.v)} <small>${esc(s.unit || "")}</small></div>
        <small>${arrow} ${fmtNum(Math.round(delta * 100) / 100)} · Ref ${esc(s.reference || "–")}</small>
      </div>`;
    }).join("");
  return `${tiles ? `<p><small>Aktueller Status (Klick öffnet Verlauf):</small></p>
    <div class="grid cols-4">${tiles}</div>` : ""}
    <div class="grid cols-2 mt">
    <div class="card"><div class="card-h"><span class="card-title">Behandlungs-Timeline</span></div>
      <div class="card-b" style="max-height:460px;overflow:auto">
        ${d.timeline.length ? `<ul class="timeline">${[...d.timeline].reverse().map((e) => `
          <li class="${e.critical ? "critical" : ""}"><span class="date">${esc(e.date.slice(0, 10))}</span>
          <span class="dot"></span><span><b>${esc(rtLabel(e.type))}</b> ${esc(e.label || "")}
          ${e.flag ? `<span class="pill ${e.flag.startsWith("H") ? "warn" : "info"}">${esc(e.flag)}</span>` : ""}</span></li>`).join("")}</ul>`
        : '<div class="empty">Keine Ereignisse.</div>'}</div></div>
    <div class="stack">
      <div class="card"><div class="card-h"><span class="card-title">Aktive Probleme</span></div>
        <div class="card-b">${d.conditions.slice(-8).reverse().map((c) => `
          <div class="row" style="justify-content:space-between;padding:4px 0">
            <span><span class="pill">${esc(c.code?.coding?.[0]?.code || "?")}</span>
            ${esc(c.code?.text || c.code?.coding?.[0]?.display || "")}</span>
            <small>${esc((c.recordedDate || "").slice(0, 10))}</small></div>`).join("")
          || '<div class="empty">Keine Diagnosen.</div>'}</div></div>
      <div class="card"><div class="card-h"><span class="card-title">Aktuelle Medikation</span></div>
        <div class="card-b">${(d.medications || []).filter((m) => m.status === "active").slice(-6).reverse().map((m) => `
          <div class="row" style="justify-content:space-between;padding:4px 0">
            <b>${esc(m.medicationCodeableConcept?.text || "–")}</b>
            <small>${esc((m.effectiveDateTime || m.authoredOn || "").slice(0, 10))}</small></div>`).join("")
          || '<div class="empty">Keine aktive Medikation.</div>'}</div></div>
    </div></div>`;
}
function tabDiagnosen(d) {
  return card(t("tab.diagnosen"), table([t("common.date"), t("dx.icd"), t("dx.name"),
    t("dx.sicherheit")],
    d.conditions.map((c) => [ (c.recordedDate || "").slice(0, 10),
      pill(c.code?.coding?.[0]?.code), esc(c.code?.text || c.code?.coding?.[0]?.display || ""),
      esc(vsLabel(c.verificationStatus?.coding?.[0]?.code))])));
}
function tabLabor(d) {
  // Labor-Explorer (Patientendashboard-Mockup): Analyt-Auswahl + große Kurve
  // mit Referenzkorridor, klickbares Sparkline-Grid, Volltabelle Werte×Zeit.
  const series = (d.lab_series || []).filter((s) => s.points.length);
  if (!series.length) return emptyCard("Keine Laborwerte.");
  const withTrend = series.filter((s) => s.points.length > 1);
  const key = d._labKey && series.some((s) => s.code === d._labKey)
    ? d._labKey : (withTrend[0] || series[0]).code;
  d._labKey = key;
  const s = series.find((x) => x.code === key);
  const pts = s.points.filter((p) => typeof p.v === "number");
  const last = pts[pts.length - 1];
  const options = [...series].sort((a, b) => (a.name || "").localeCompare(b.name || ""))
    .map((x) => `<option value="${esc(x.code)}" ${x.code === key ? "selected" : ""}>${esc(x.name)}</option>`).join("");
  const minis = withTrend.map((x) => {
    const lp = x.points.filter((p) => typeof p.v === "number").slice(-1)[0];
    return `<div class="card lab-mini" data-k="${esc(x.code)}" style="padding:10px 12px;cursor:pointer${
        x.code === key ? ";outline:2px solid var(--gb-blue)" : ""}">
      <div class="row" style="justify-content:space-between"><small><b>${esc(x.name)}</b></small>
        <small>${lp ? `<span class="${lp.flag ? "pill warn" : ""}">${fmtNum(lp.v)}</span>` : "–"}
        ${esc(x.unit || "")}</small></div>
      ${sparkline(x.points, x.reference, 300, 36)}</div>`;
  }).join("");
  const dates = [...new Set(series.flatMap((x) => x.points.map((p) => p.t.slice(0, 10))))].sort();
  const shown = dates.slice(-12);
  const rows = series.map((x) => {
    const map = {};
    x.points.forEach((p) => { map[p.t.slice(0, 10)] = p; });
    return [esc(x.name), `<small>${esc(x.reference || "–")}</small>`,
      ...shown.map((dt) => { const p = map[dt];
        return p ? `<span class="${p.flag ? "pill warn" : ""}">${fmtNum(p.v)}</span>` : "·"; })];
  });
  return `
    <div class="card"><div class="card-h">
      <span class="card-title">Labor-Explorer</span>
      <select class="input" id="lab-sel" style="width:auto">${options}</select></div>
      <div class="card-b">
        <div class="row" style="gap:20px;flex-wrap:wrap;margin-bottom:8px">
          <small>Referenz: <b>${esc(s.reference || "–")}</b></small>
          <small>Aktuell: <b>${last ? fmtNum(last.v) + " " + esc(s.unit || "") : "–"}</b>
            ${last && last.flag ? pillCls(last.flag, "warn") : ""}
            ${last ? `· ${esc(last.t.slice(0, 10))}` : ""}</small>
          <small>${pts.length} Werte</small>
        </div>
        ${bigChart(s)}
      </div></div>
    ${minis ? `<div class="grid cols-3 mt">${minis}</div>` : ""}
    <div class="card mt"><div class="card-h">
      <span class="card-title">Volltabelle (letzte ${shown.length} Zeitpunkte)</span></div>
      <div class="card-b" style="overflow-x:auto">${table(["Analyt", "Ref",
        ...shown.map((x) => x.slice(2))], rows)}</div></div>`;
}
function tabMedikation(d) {
  return card("Medikation", table(["Seit", "Präparat", "Codes", "Status"],
    d.medications.map((m) => {
      const cc = m.medicationCodeableConcept || {};
      const codes = (cc.coding || []).map((c) => pill(c.code)).join(" ");
      return [(m.effectiveDateTime || m.authoredOn || "").slice(0, 10),
        esc(cc.text || "–"), codes, esc(m.status || "")];
    })));
}
function tabDokumente(d) {
  if (!d.documents) return emptyCard("Keine Berechtigung für Dokumente (text.read).");
  const ext = (res, suffix) => (res.extension || [])
    .find((e) => e.url?.endsWith(suffix))?.valueString;
  const isEau = (doc) => doc.resourceType === "DocumentReference"
    && (doc.type?.coding || []).some((c) => c.code === "eAU");
  const isAnhang = (doc) => (doc.category || []).some((c) => c.text === "MedDok-Anhang");
  const decode = (att) => {
    if (!att?.data || !String(att.contentType || "").startsWith("text/")) return null;
    try { return new TextDecoder().decode(Uint8Array.from(atob(att.data), (c) => c.charCodeAt(0))); }
    catch { return null; }
  };
  const fullText = (doc) => {
    if (doc.resourceType === "Composition")
      return (doc.section || []).map((s) => (s.text?.div || "").replace(/<[^>]+>/g, " ")).join("\n").trim();
    return decode(doc.content?.[0]?.attachment);
  };
  const annotationsOf = (doc) => {
    const ext = (doc.extension || []).find((e) => e.url?.endsWith("/document-annotations"));
    return (ext?.extension || []).map((item) => {
      const f = Object.fromEntries((item.extension || []).map((e) => [e.url, e]));
      const [start, end] = (f.span?.valueString || "0:0").split(":").map(Number);
      return { start, end, status: f.status?.valueCode || "confirmed",
               concept: f.concept?.valueCoding || {},
               context: f.context?.valueString || "",
               score: f.score?.valueDecimal };
    }).sort((a, b) => a.start - b.start);
  };
  const annotated = (text, anns) => {
    // Volltext mit farbigen Highlights (Dokument-Intelligence-Overlay)
    const cls = { refuted: "crit", provisional: "warn", confirmed: "ok" };
    let out = "", pos = 0;
    for (const a of anns) {
      if (a.start < pos || a.end > text.length) continue;
      out += esc(text.slice(pos, a.start));
      out += `<mark class="pill ${cls[a.status] || "info"}" style="padding:1px 6px"
        title="${esc((a.concept.system || "") + " " + (a.concept.code || ""))} · ${esc(a.status)}
${esc(a.context)}">${esc(text.slice(a.start, a.end))}</mark>`;
      pos = a.end;
    }
    out += esc(text.slice(pos));
    return out;
  };
  const conceptPanel = (anns) => anns.length ? `<div class="row mt" style="gap:6px">
    ${anns.map((a) => `<span class="pill ${{ refuted: "crit", provisional: "warn" }[a.status] || "ok"}">
      ${esc(a.concept.display || a.concept.code || "?")}
      <small>${esc(a.concept.code || "")}${a.status !== "confirmed" ? " · " + esc(a.status) : ""}</small>
    </span>`).join("")}</div>` : "";
  const expandable = (doc, label) => {
    const t = fullText(doc);
    if (!t) return esc(doc.description || "–");
    const anns = annotationsOf(doc);
    const badge = anns.length
      ? ` <span class="pill info">${anns.length} Konzepte annotiert</span>` : "";
    return `<details><summary style="cursor:pointer">${esc(label || "Volltext anzeigen")}${badge}</summary>
      <p style="white-space:pre-wrap">${anns.length ? annotated(t, anns) : esc(t)}</p>
      ${conceptPanel(anns)}</details>`;
  };

  const aus = d.documents.filter(isEau)
    .sort((a, b) => (b.date || "").localeCompare(a.date || ""));
  const briefe = d.documents.filter((doc) => doc.resourceType === "Composition");
  const anhaenge = d.documents.filter(isAnhang);
  const sonstige = d.documents.filter((doc) =>
    doc.resourceType === "DocumentReference" && !isEau(doc) && !isAnhang(doc));

  // eAU-Zeitachse (UI_SPEC §4): Erst/Folge, Zeitraum, Status, Diagnosen
  const auBlock = card("eAU-Zeitachse", aus.length ? `<ul class="timeline">${aus.map((a) => {
    const p = a.context?.period || {};
    const folge = (a.category || []).some((c) => /folge/i.test(c.text || ""));
    const status = ext(a, "eau-status");
    const icds = ext(a, "au-diagnosen");
    return `<li><span class="date">${esc((a.date || "").slice(0, 10))}</span><span class="dot"></span>
      <span><span class="pill ${folge ? "info" : "warn"}">${folge ? "Folge" : "Erst"}</span>
      ${p.start ? `<b>${esc(p.start.slice(0, 10))}</b> bis <b>${esc((p.end || "offen").slice(0, 10))}</b>` : ""}
      ${icds ? icds.split(",").map((i) => `<span class="pill">${esc(i)}</span>`).join(" ") : ""}
      ${status ? `<span class="pill info">eAU-Status ${esc(status)}</span>` : ""}
      ${ext(a, "is-eau") || (a.extension || []).some((e) => e.url?.endsWith("is-eau")) ? '<span class="pill ok">eAU</span>' : ""}
      </span></li>`;
  }).join("")}</ul>` : '<div class="empty">Keine AU-Bescheinigungen.</div>');

  const briefBlock = card("Arztbriefe & Epikrisen", briefe.length
    ? table(["Datum", "Typ", "Inhalt"], briefe.map((b) => [
        (b.date || "").slice(0, 10), esc(b.title || b.type?.text || "–"), expandable(b)]))
    : '<div class="empty">Keine Arztbriefe.</div>');

  const docBlock = card("Dokumente", sonstige.length
    ? table(["Datum", "Typ", "Inhalt"], sonstige.map((doc) => [
        (doc.date || "").slice(0, 10), esc(doc.type?.text || "–"), expandable(doc)]))
    : '<div class="empty">Keine weiteren Dokumente.</div>');

  const anhangBlock = card("Anhänge", anhaenge.length
    ? table(["Datum", "Datei", "Typ", "Größe"], anhaenge.map((a) => {
        const att = a.content?.[0]?.attachment || {};
        return [(a.date || "").slice(0, 10), esc(att.title || "–"),
          esc(att.contentType || a.type?.text || "–"),
          att.size ? `${Math.round(att.size / 1024)} KB` : "–"];
      }))
    : '<div class="empty">Keine Anhänge.</div>');

  return `<div class="stack">${auBlock}${briefBlock}${docBlock}${anhangBlock}</div>`;
}
function tabTermine(d) {
  return card("Termine", table(["Beginn", "Betreff", "Status"],
    d.appointments.map((a) => [(a.start || "").slice(0, 16).replace("T", " "),
      esc(a.description || a.comment || "–"), esc(a.status || "")])));
}
function tabAbrechnung(d) {
  return card("Abrechnung & Versicherung", table(["Typ", "Datum", "Info"],
    d.billing.map((b) => [esc(b.resourceType),
      ((b.period || {}).start || b.created || b.date || "").slice(0, 10),
      esc(b.type?.[0]?.text || b.type?.text || b.class?.code || b.subType?.text || "–")])));
}

function breakGlassModal(pseudonym) {
  const m = document.getElementById("modal");
  m.innerHTML = `<div class="modal-back"><div class="card modal">
    <div class="card-h"><b>🔓 Break-Glass: Klardaten anfordern</b></div>
    <div class="card-b">
      <p>Re-Identifikation ist ein <b>protokollierter</b> Vorgang (Audit, append-only).</p>
      <label>Begründung (Zweckbindung, Pflicht)</label><input class="input" id="bg-reason">
      <label>Passwort (Re-Auth)</label><input class="input" type="password" id="bg-pass">
      ${state.mfaRequired ? '<label>TOTP-Code</label><input class="input" id="bg-totp">' : ""}
      <div class="row mt">
        <button class="btn btn-primary" id="bg-go" style="background:var(--crit);border-color:var(--crit)">Anfordern</button>
        <button class="btn" id="bg-cancel">Abbrechen</button>
      </div><div id="bg-out" class="mt"></div>
    </div></div></div>`;
  document.getElementById("bg-cancel").onclick = () => (m.innerHTML = "");
  document.getElementById("bg-go").onclick = async () => {
    try {
      const r = await api(`/api/patients/${encodeURIComponent(pseudonym)}/reid`, {
        method: "POST", body: JSON.stringify({ reason: val("bg-reason"),
          password: val("bg-pass"), totp: val("bg-totp") }) });
      document.getElementById("bg-out").innerHTML = `
        <p class="pill crit">Klardaten (protokolliert):</p>
        <p><b>Quell-ID:</b> ${esc(r.source_id)} · <b>PatientNr:</b> ${esc(r.source_nr || "–")}</p>`;
    } catch (e) { document.getElementById("bg-out").innerHTML = errBox(e); }
  };
}

// ---------- Analyse (UI_SPEC §5) ----------
// Ausdrucks-Baukasten: state.expr ist ein Baum aus Sequenzen.
//   Sequenz  = { items: [Term, ...], ops: ["and"|"or"|"and-not"|"or-not", ...] }
//   Term     = Kriterium (Chip) oder Sequenz (Klammer/Kasten)
// Bedienung: Beziehung zwischen zwei Termen per Klick rollieren; einen Term
// per Drag & Drop auf einen anderen ziehen -> Klammer; Klammern verhalten sich
// wie Terme (verschiebbar, negierbar ¬, verschachtelbar). Auswertung links
// nach rechts (server/analysis._eval_node).
const X_OPS = ["and", "or", "and-not", "or-not"];
function opLabel(op) {
  return { "and": t("ana.and"), "or": t("ana.or"),
    "and-not": t("ana.and") + " ¬", "or-not": t("ana.or") + " ¬" }[op] || op;
}
function exprNode(path) {
  let n = state.expr;
  for (const idx of String(path).split(".").filter((x) => x !== ""))
    n = n.items[parseInt(idx)];
  return n;
}
function exprRemoveByIdentity(node, obj) {
  const i = node.items.indexOf(obj);
  if (i >= 0) {
    node.items.splice(i, 1);
    node.ops.splice(Math.max(0, i - 1), 1);
    return true;
  }
  return node.items.some((it) => it.items && exprRemoveByIdentity(it, obj));
}
function exprReplaceByIdentity(node, obj, repl) {
  const i = node.items.indexOf(obj);
  if (i >= 0) { node.items[i] = repl; return true; }
  return node.items.some((it) => it.items && exprReplaceByIdentity(it, obj, repl));
}
function exprCleanup(node) {
  for (const it of node.items) if (it.items) exprCleanup(it);
  // Negation nicht-erster Terme in die Beziehung falten: 'und ¬' vor einem
  // NICHT-Term hebt sich auf ('und'), sonst wandert das NICHT in den Verbinder.
  // Damit gibt es keine doppelte Verneinung in der Anzeige.
  for (let i = 1; i < node.items.length; i++) {
    if (node.items[i].not) {
      delete node.items[i].not;
      const op = node.ops[i - 1] || "and";
      node.ops[i - 1] = { "and": "and-not", "or": "or-not",
                          "and-not": "and", "or-not": "or" }[op] || "and-not";
    }
  }
  // 1-elementige Klammern aufloesen, leere entfernen (Root bleibt bestehen)
  for (let i = 0; i < node.items.length; i++) {
    const it = node.items[i];
    if (!it.items) continue;
    if (it.items.length === 1) {
      const inner = it.items[0];
      if (it.not) inner.not = !inner.not;   // NICHT der Klammer wandert mit
      node.items[i] = inner;
      i--;                                   // erneut pruefen (Falten/Unwrap)
    } else if (!it.items.length) {
      node.items.splice(i, 1);
      node.ops.splice(Math.max(0, i - 1), 1);
      i--;
    }
  }
}
function exprFindByJson(node, key) {
  for (const it of node.items) {
    if (it.items) { const f = exprFindByJson(it, key); if (f) return f; }
    else if (JSON.stringify(it) === key) return it;
  }
  return null;
}
function renderExpr(node = state.expr, path = "") {
  if (!path && !node.items.length)
    return `<span class="empty" style="padding:8px">${esc(t("ana.noCriteria"))}</span>`;
  const parts = [];
  node.items.forEach((it, i) => {
    const p = path ? `${path}.${i}` : String(i);
    if (i > 0) {
      parts.push(`<button class="btn x-op" data-path="${path}" data-i="${i - 1}"
        title="${esc(t("ana.opHint"))}" style="font-weight:700;padding:4px 10px">
        ${esc(opLabel(node.ops[i - 1] || "and"))}</button>`);
    } else {
      // Fuehrender NICHT-Schalter: nur das erste Glied hat keine eingehende
      // Beziehung — seine Negation sitzt hier (sonst immer im Verbinder).
      parts.push(`<button class="btn x-lead" data-path="${p}" title="${esc(t("ana.leadHint"))}"
        style="padding:4px 8px;${it.not ? "font-weight:700;color:var(--crit)" : "opacity:.35"}">
        ${it.not ? esc(t("ana.not")) : "¬"}</button>`);
    }
    if (it.items) {
      parts.push(`<span class="x-group" data-path="${p}" draggable="true"
        style="border:2px solid var(--gb-blue);border-radius:12px;padding:6px 8px;cursor:grab;
        display:inline-flex;gap:6px;align-items:center;flex-wrap:wrap;background:rgba(59,130,246,.06)">
        <b style="opacity:.4">(</b>${renderExpr(it, p)}<b style="opacity:.4">)</b>
        <button class="x-del" data-path="${p}" title="Klammer samt Inhalt entfernen">✕</button></span>`);
    } else {
      parts.push(`<span class="token x-chip" data-path="${p}"
        draggable="true" style="cursor:grab">
        ${esc(tokenLabel(it))}
        <button class="x-del" data-path="${p}" aria-label="Merkmal entfernen">✕</button></span>`);
    }
  });
  return parts.join("");
}
function tokenLabel(c) {
  const multi = (list) => (list || []).join(" ∨ ");
  return { icd: `ICD ${c.codes ? multi(c.codes) : c.code}`,
    atc: `ATC ${c.codes ? multi(c.codes) : c.code}`,
    lab: `${c.code} ${c.op} ${c.value}`,
    age: c.bands ? `Alter ${c.bands.map(([a, b]) => a + "–" + b).join(" ∨ ")}`
                 : `Alter ${c.min}–${c.max}`,
    gender: `Geschlecht ${(c.values || [c.value]).map((v) => gender(v)).join(" ∨ ")}`,
    medname: `Medikament „${c.term}"`,
    text: `Text „${c.term}" (nicht-negiert)`,
    concept: `Dokument-Konzept ${c.code}${c.include_uncertain ? " (inkl. Verdacht)" : ""}`,
    period: `Zeitraum ${c.from}–${c.to}` }[c.type] || c.type;
}
async function viewAnalyse() {
  render(`
    <div class="card"><div class="card-h"><span class="card-title">${esc(t("ana.title"))}</span>
      <div class="row">
        <button class="btn" id="c-help">${esc(t("ana.help"))}</button>
        <button class="btn btn-grad" id="c-run">${esc(t("ana.run"))}</button>
      </div></div>
    <div class="card-b">
      <div class="row" id="c-tokens" style="flex-wrap:wrap;gap:8px;align-items:center">${renderExpr()}</div>
      <p style="margin:6px 0 0"><small>${esc(t("ana.exprHint"))}</small></p>
      <div class="row mt">
        <select class="input" id="c-type" style="width:auto">
          <option value="icd">Diagnose (ICD)</option><option value="atc">Therapie (ATC)</option>
          <option value="lab">Laborwert</option><option value="age">Alter</option>
          <option value="gender">Geschlecht</option><option value="text">Freitext (nicht-negiert)</option>
          <option value="concept">Dokument-Konzept (SNOMED/NLP)</option>
          <option value="period">Zeitraum</option></select>
        <input class="input" id="c-v1" placeholder="Wert (z. B. K76 / HOMA / 18)" style="width:220px">
        <input class="input" id="c-v2" placeholder="Zusatz (z. B. > 3 / 80 / bis-Datum)" style="width:200px">
        <button class="btn" id="c-add">${esc(t("ana.addCriterion"))}</button>
        <input class="input" id="c-lab" placeholder="Verlaufskurve: Labor-Code (z. B. HOMA)" style="width:260px">
      </div>
      <div id="c-out" class="mt"></div>
    </div></div><div id="modal"></div>`);
  const refreshTokens = () => {
    document.getElementById("c-tokens").innerHTML = renderExpr();
    wireExpr();
  };
  const mergeInto = (fromPath, toPath) => {
    const dragged = exprNode(fromPath), target = exprNode(toPath);
    if (!dragged || !target || dragged === target) return;
    exprRemoveByIdentity(state.expr, dragged);
    if (target.items) {                 // auf Klammer ziehen -> anhaengen
      target.items.push(dragged);
      target.ops.push("and");
    } else {                            // auf Chip ziehen -> neue Klammer
      exprReplaceByIdentity(state.expr, target,
        { items: [target, dragged], ops: ["and"] });
    }
    exprCleanup(state.expr);
    refreshTokens();
    run();
  };
  const wireExpr = () => {
    const root = document.getElementById("c-tokens");
    root.querySelectorAll(".x-op").forEach((b) => b.onclick = () => {
      const node = exprNode(b.dataset.path);
      const i = parseInt(b.dataset.i);
      node.ops[i] = X_OPS[(X_OPS.indexOf(node.ops[i] || "and") + 1) % X_OPS.length];
      refreshTokens();
      run();
    });
    root.querySelectorAll(".x-del").forEach((b) => b.onclick = (e) => {
      e.stopPropagation();
      exprRemoveByIdentity(state.expr, exprNode(b.dataset.path));
      exprCleanup(state.expr);
      refreshTokens();
      run();
    });
    root.querySelectorAll(".x-lead").forEach((b) => b.onclick = (e) => {
      e.stopPropagation();
      const n = exprNode(b.dataset.path);
      n.not = !n.not;
      refreshTokens();
      run();
    });
    root.querySelectorAll("[draggable]").forEach((el) => {
      el.ondragstart = (e) => {
        e.stopPropagation();
        e.dataTransfer.setData("text/plain", el.dataset.path);
      };
      el.ondragover = (e) => { e.preventDefault(); e.stopPropagation(); };
      el.ondrop = (e) => {
        e.preventDefault();
        e.stopPropagation();
        const from = e.dataTransfer.getData("text/plain");
        const to = el.dataset.path;
        if (from === "" || from == null || from === to) return;
        if (to.startsWith(from + ".")) return;   // Klammer nicht in sich selbst
        mergeInto(from, to);
      };
    });
  };
  const appendTerm = (c) => {
    state.expr.items.push(c);
    if (state.expr.items.length > 1) state.expr.ops.push("and");
    refreshTokens();
  };
  const addPending = () => {
    // Kriterium aus den Eingabefeldern uebernehmen (auch implizit durch
    // "Kohorte berechnen": ein getippter, nicht hinzugefuegter Wert zaehlt mit).
    const ty = val("c-type"), v1 = val("c-v1"), v2 = val("c-v2");
    if (!v1) return false;
    const c = { icd: () => ({ type: "icd", code: v1 }),
      atc: () => ({ type: "atc", code: v1 }),
      lab: () => { const m = v2.match(/([<>]=?|=)\s*([\d.,]+)/) || [null, ">", "0"];
        return { type: "lab", code: v1, op: m[1], value: parseFloat(m[2].replace(",", ".")) }; },
      age: () => ({ type: "age", min: parseInt(v1 || "0"), max: parseInt(v2 || "150") }),
      gender: () => ({ type: "gender",
        value: { m: "male", w: "female", d: "other" }[v1.toLowerCase()] || v1 }),
      text: () => ({ type: "text", term: v1, negated: false }),
      concept: () => ({ type: "concept", code: v1, term: v1,
                        include_uncertain: /verdacht|uncertain/i.test(v2) }),
      period: () => ({ type: "period", from: v1, to: v2 || "9999" }) }[ty]();
    document.getElementById("c-v1").value = "";
    document.getElementById("c-v2").value = "";
    appendTerm(c);
    return true;
  };
  document.getElementById("c-add").onclick = addPending;
  const run = async () => {
    addPending();
    const out = document.getElementById("c-out");
    if (!state.expr.items.length) { out.innerHTML = ""; return; }
    out.innerHTML = skeletonRows(4);
    try {
      const def = { expr: state.expr, lab_trend: val("c-lab") || null };
      const r = await api("/api/analysis/cohort", { method: "POST", body: JSON.stringify(def) });
      out.innerHTML = `
        <div class="grid cols-4">
          <div class="card kpi"><div class="num">${r.size_masked}</div><div class="lbl">${esc(t("ana.size"))}</div></div>
          <div class="card kpi"><div class="num">${Object.values(r.gender).map(esc).join(" / ") || "–"}</div><div class="lbl">${esc(t("ana.mw"))}</div></div>
          <div class="card kpi"><div class="num">${r.therapy.length}</div><div class="lbl">${esc(t("ana.therapies"))}</div></div>
          <div class="card kpi"><div class="num">${r.co_diagnoses.length}</div><div class="lbl">${esc(t("ana.codx"))}</div></div>
        </div>
        <p class="mt"><small>${esc(t("ana.drillHint"))}</small></p>
        <div class="grid cols-2 mt">
          <div id="ch-ther">${card(t("ana.therapy"),
            donut(r.therapy.map((x) => [x.name || x.atc || "ohne Name/Code", x.n,
              x.atc ? "atc:" + x.atc : (x.name ? "med:" + x.name : "")])))}</div>
          <div id="ch-diag">${card(t("ana.codxFilter"),
            bars(r.co_diagnoses.map((c) => [c.icd + " " + (c.display || ""), c.n, c.icd])))}</div>
        </div>
        <div class="grid cols-2 mt">
          <div id="ch-age">${card(t("ana.age"),
            bars(Object.entries(r.age_bands || {}).map(([b, n]) => [b, n, b])))}</div>
          <div id="ch-gender">${card(t("ana.gender"),
            bars(Object.entries(r.gender || {}).map(([g, n]) => [t("gender." + g), n, g])))}</div>
        </div>
        ${r.lab_trend.length ? card(t("ana.trend"), trendChart(r.lab_trend)) : ""}
        <div class="row mt">
          ${can("export.research") ? `<button class="btn btn-primary" id="c-export">${esc(t("ana.export"))}</button>` : ""}
          <span class="pill info">${esc(t("ana.aggProtect"))}</span>
        </div>`;
      // Chart-Klick: Merkmal an die Kette anhaengen (mit "und"); erneuter
      // Klick auf denselben Wert entfernt ihn wieder. Beziehung danach am
      // Verbinder rollieren, Klammern per Drag & Drop.
      const drillToggle = (crit) => {
        const found = exprFindByJson(state.expr, JSON.stringify(crit));
        if (found) {
          exprRemoveByIdentity(state.expr, found);
          exprCleanup(state.expr);
        } else {
          state.expr.items.push(crit);
          if (state.expr.items.length > 1) state.expr.ops.push("and");
        }
        refreshTokens();
        run();
      };
      const drill = (rootId, fn) => {
        document.querySelectorAll(`#${rootId} [data-sel]`).forEach((el) => {
          el.onclick = () => fn(el.dataset.sel);
        });
      };
      drill("ch-ther", (sel) => {
        if (!sel) return;
        if (sel.startsWith("atc:")) drillToggle({ type: "atc", code: sel.slice(4) });
        else if (sel.startsWith("med:")) drillToggle({ type: "medname", term: sel.slice(4) });
      });
      drill("ch-diag", (icd) => icd && drillToggle({ type: "icd", code: icd }));
      drill("ch-age", (band) => {
        const m = band.match(/(\d+)\s*[–-]\s*(\d+)/);
        if (m) drillToggle({ type: "age", min: parseInt(m[1]), max: parseInt(m[2]) });
      });
      drill("ch-gender", (g) => g && drillToggle({ type: "gender", value: g }));
      const ex = document.getElementById("c-export");
      if (ex) ex.onclick = async () => {
        const bundle = await api("/api/analysis/export", { method: "POST", body: JSON.stringify(def) });
        const blob = new Blob([JSON.stringify(bundle, null, 2)], { type: "application/fhir+json" });
        const a = Object.assign(document.createElement("a"),
          { href: URL.createObjectURL(blob), download: "forschungsexport.json" });
        a.click();
      };
    } catch (e) { out.innerHTML = errBox(e); }
  };
  document.getElementById("c-run").onclick = run;
  const EXAMPLES = [
    { label: "Hypertonie – alle I10.x",
      expr: { items: [{ type: "icd", code: "I10" }], ops: [] } },
    { label: "Diabetes Typ 2 unter Metformin",
      expr: { items: [{ type: "icd", code: "E11" }, { type: "atc", code: "A10BA02" }],
              ops: ["and"] } },
    { label: "Lebererkrankungen (K70–K77), Alter ab 50",
      expr: { items: [{ type: "icd", code: "K7" }, { type: "age", min: 50, max: 150 }],
              ops: ["and"] } },
    { label: "(I10 und E11 und ¬ K76) oder B18",
      expr: { items: [
        { items: [{ type: "icd", code: "I10" }, { type: "icd", code: "E11" },
                  { type: "icd", code: "K76" }], ops: ["and", "and-not"] },
        { type: "icd", code: "B18" }], ops: ["or"] } },
    { label: "Zöliakie im Volltext (nicht-negiert)",
      expr: { items: [{ type: "text", term: "Zöliakie", negated: false }], ops: [] } },
    { label: "Chron. Hepatitis (B18) mit TSH-Verlaufskurve", lab: "TSH",
      expr: { items: [{ type: "icd", code: "B18" }], ops: [] } },
  ];
  document.getElementById("c-help").onclick = () => {
    const m = document.getElementById("modal");
    m.innerHTML = `<div class="modal-back"><div class="card modal" style="max-width:760px;width:92%">
      <div class="card-h"><span class="card-title">Kohorten-Builder – Anleitung</span>
        <button class="btn" id="h-close">${esc(t("common.close"))}</button></div>
      <div class="card-b" style="max-height:70vh;overflow:auto">
        <p><b>So geht's:</b> Kriteriumstyp wählen → Wert eintragen → <b>+ Kriterium</b> →
        <b>Kohorte berechnen</b>. Ein getippter, noch nicht hinzugefügter Wert wird beim
        Berechnen automatisch übernommen.</p>
        <p class="mt"><b>Logik als Kette:</b> Merkmale stehen in einer Reihe, zwischen je
        zwei Merkmalen sitzt die <b>Beziehung</b> — Klick darauf rolliert
        <b>und → oder → und ¬ → oder ¬</b>. Ausgewertet wird von links nach rechts.
        <b>Klammern:</b> ein Merkmal per <b>Drag &amp; Drop auf ein anderes ziehen</b>
        → beide wandern in einen Kasten (Klammer), der sich wie ein Merkmal verhält:
        verschiebbar, negierbar (¬), beliebig schachtelbar. Ziehen auf einen Kasten
        hängt das Merkmal dort an. <b>¬</b> am Chip/Kasten negiert ihn, ✕ entfernt.</p>
        <p class="mt">Beispiel „(I10 <i>und</i> E11 <i>und ¬</i> K76) <i>oder</i> B18":
        I10, E11, K76 hinzufügen → I10 auf E11 ziehen, K76 auf den Kasten ziehen →
        Beziehung vor K76 auf „und ¬" rollieren → B18 hinzufügen → Beziehung vor B18
        auf „oder".</p>
        <table class="data mt"><thead><tr><th>Kriterium</th><th>Wert</th><th>Zusatz</th><th>Beispiel</th></tr></thead><tbody>
          <tr><td>Diagnose (ICD)</td><td>Code-<b>Präfix</b></td><td>–</td>
            <td>„I10" findet auch I10.90; „K7" findet K70–K77</td></tr>
          <tr><td>Therapie (ATC)</td><td>Code-<b>Präfix</b></td><td>–</td>
            <td>„A10" = alle Antidiabetika, „A10BA02" = Metformin</td></tr>
          <tr><td>Laborwert</td><td>Kürzel/Name</td><td>Operator + Wert</td>
            <td>Wert „TSH", Zusatz „&gt; 2,5"</td></tr>
          <tr><td>Alter</td><td>von</td><td>bis</td><td>„50" / „79"</td></tr>
          <tr><td>Geschlecht</td><td>m / w / d</td><td>–</td><td>„w"</td></tr>
          <tr><td>Freitext</td><td>Begriff</td><td>–</td>
            <td>„Sodbrennen" – nur nicht-negierte Erwähnungen (NLP)</td></tr>
          <tr><td>Dokument-Konzept</td><td>Code/Begriff</td><td>„Verdacht" = inkl. unsichere</td>
            <td>SNOMED-/Katalogkonzept aus der Annotation</td></tr>
          <tr><td>Zeitraum</td><td>von (ISO)</td><td>bis (ISO)</td><td>„2021-01-01" / „2024-12-31"</td></tr>
        </tbody></table>
        <p class="mt"><b>Verlaufskurve:</b> Labor-Code in das Feld rechts eintragen
        (z. B. „TSH") → Median je Quartal für die Kohorte.<br>
        <b>Aggregatschutz:</b> Fallzahlen unter 5 werden maskiert.
        <b>Forschungsexport:</b> lädt die Kohorte pseudonymisiert als FHIR-Bundle.</p>
        <p class="mt"><b>Beispielabfragen (Klick übernimmt und rechnet):</b></p>
        <div class="row" style="flex-wrap:wrap;gap:8px">
          ${EXAMPLES.map((e, i) => `<button class="btn h-ex" data-i="${i}">${esc(e.label)}</button>`).join("")}
        </div>
      </div></div></div>`;
    document.getElementById("h-close").onclick = () => (m.innerHTML = "");
    document.querySelectorAll(".h-ex").forEach((b) => b.onclick = () => {
      const ex = EXAMPLES[parseInt(b.dataset.i)];
      state.expr = JSON.parse(JSON.stringify(ex.expr));
      document.getElementById("c-lab").value = ex.lab || "";
      refreshTokens();
      m.innerHTML = "";
      run();
    });
  };
  wireExpr();
  if (state.expr.items.length) run();
}

// ---------- Kataloge ----------
async function viewKataloge() {
  const canBuild = can("etl.manage", "user.manage");
  render(`<div class="card"><div class="card-h">
    <span class="card-title">Kataloge (Referenz-/Terminologiedaten)</span>
    <div class="row">
      ${canBuild ? `<button class="btn" id="cat-log">Protokoll</button>
      <button class="btn btn-primary" id="cat-build">⟳ Kataloge aus Quell-DB laden</button>` : ""}
    </div></div>
    <div class="card-b"><div id="cat-prog"></div><div id="cat">${skeletonRows(4)}</div></div></div>
    <div id="modal"></div>`);
  const load = async () => {
    try {
      const r = await api("/api/catalogs");
      document.getElementById("cat").innerHTML = r.catalogs.length
        ? table(["Katalog", "Ressourcentyp", "Einträge", "Version"],
            r.catalogs.map((c) => [esc(c.catalog), esc(c.resource_type), c.n, esc(c.version || "–")]))
          + `<p class="mt"><small>Quelle: LaborIdentKatalog, Vitalparameter, Medikamente (ATC),
             GOÄ-Ziffern, MedDok-Kategorien. Externe Register (LOINC, ICD-10-GM) werden
             versioniert eingespielt (CONCEPT.md 13.4).</small></p>`
        : `<div class="empty">Noch keine Kataloge geladen.${canBuild
            ? "<br><small>Oben „Kataloge aus Quell-DB laden“ klicken (dauert wenige Minuten).</small>" : ""}</div>`;
      return r.catalogs.length;
    } catch (e) { document.getElementById("cat").innerHTML = errBox(e); return 0; }
  };
  // Live-Status wie beim Sync: Job mode='reference' pollt Schritt/Fortschritt
  const poll = async (active) => {
    if (location.hash.slice(1) !== "kataloge" || !canBuild) return;
    const prog = document.getElementById("cat-prog");
    try {
      const r = await api("/api/admin/etl");
      const job = (r.jobs || []).find((j) => j.mode === "reference");
      let s = {};
      try { s = JSON.parse((job || {}).stats || "{}"); } catch {}
      if (job && job.status === "running") {
        const pct = s.total ? Math.round(((s.done || 0) / s.total) * 100) : 0;
        prog.innerHTML = `<div class="row" style="justify-content:space-between">
            <b>Katalog-Lauf läuft: ${esc(s.step || "…")}</b>
            <span>Schritt ${(s.done || 0) + 1} / ${s.total || 6}</span></div>
          <div style="background:var(--border-2);border-radius:6px;height:12px;margin:8px 0 14px">
            <div style="width:${pct}%;height:12px;border-radius:6px;background:var(--gb-grad)"></div></div>`;
        setTimeout(() => poll(true), 2000);
        return;
      }
      if (job && job.status === "failed") {
        prog.innerHTML = `<p><span class="pill crit">Katalog-Lauf fehlgeschlagen:
          ${esc(job.error || "?")}</span> <small>Details: Protokoll</small></p>`;
      } else if (job && active) {
        const counts = Object.entries(s.counts || {})
          .map(([k, v]) => `${k}: ${v}`).join(" · ");
        prog.innerHTML = `<p><span class="pill ok">Kataloge geladen${counts ? " · " + esc(counts) : ""}</span></p>`;
      }
      if (active) load();
    } catch { /* ohne etl.manage kein Status - Ansicht bleibt lesend */ }
  };
  const btn = document.getElementById("cat-build");
  if (btn) btn.onclick = async () => {
    try {
      await api("/api/admin/catalogs/build", { method: "POST" });
      setTimeout(() => poll(true), 1500);
    } catch (e) {
      document.getElementById("cat-prog").innerHTML =
        `<span class="pill crit">${esc(e.message)}</span>`;
    }
  };
  const logBtn = document.getElementById("cat-log");
  if (logBtn) logBtn.onclick = async () => {
    try { await downloadLog("reference"); }
    catch (e) {
      document.getElementById("cat-prog").innerHTML =
        `<span class="pill crit">${esc(e.message)}</span>`;
    }
  };
  load();
  poll(true);
}

// ---------- Verwaltung ----------
async function viewVerwaltung() {
  const blocks = [];
  if (can("user.manage")) blocks.push(`<div class="card"><div class="card-h">
    <span class="card-title">Benutzer & Rollen</span>
    <button class="btn" id="u-new">+ Benutzer</button></div>
    <div class="card-b" id="u-list">${skeletonRows(3)}</div></div>`);
  if (can("etl.manage", "user.manage")) blocks.push(`<div class="card"><div class="card-h">
    <span class="card-title">ETL-Status & Store</span>
    <div class="row">
      <button class="btn" id="sync-inc">⟳ Sync jetzt</button>
      <button class="btn" id="sync-full">Voll-Lauf</button>
      <button class="btn" id="sync-log">Protokoll</button>
      <button class="btn" id="store-reset" style="color:var(--crit)">Store leeren</button>
    </div></div>
    <div class="card-b"><div id="sync-progress"></div><div id="e-list">${skeletonRows(3)}</div></div></div>`);
  if (can("audit.read")) blocks.push(`<div class="card"><div class="card-h">
    <span class="card-title">Audit-Log (append-only, Hash-Kette)</span>
    <div class="row"><span id="a-chain"></span>
      <button class="btn" id="a-toggle">Aufklappen ▾</button></div></div>
    <div class="card-b" id="a-wrap" style="display:none">
      <div id="a-list" style="max-height:380px;overflow:auto">${skeletonRows(3)}</div></div></div>`);
  render(`<div class="stack">${blocks.join("") || emptyCard("Keine Verwaltungsrechte.")}</div><div id="modal"></div>`);

  if (can("user.manage")) {
    const load = async () => {
      const r = await api("/api/admin/users");
      document.getElementById("u-list").innerHTML = table(
        ["Benutzer", "Name", "Rollen", "MFA", "Status", "Letzter Login", ""],
        r.users.map((u) => [esc(u.username), esc(u.full_name), esc(u.roles || "–"),
          u.mfa_enabled ? "✓" : "–", esc(u.status), esc(u.last_login_at || "–"),
          `<button class="btn" data-u="${esc(u.id)}" data-s="${u.status === "active" ? "locked" : "active"}">
           ${u.status === "active" ? "Sperren" : "Aktivieren"}</button>`]));
      document.querySelectorAll("#u-list .btn").forEach((b) => b.onclick = async () => {
        await api(`/api/admin/users/${b.dataset.u}/status`, { method: "POST",
          body: JSON.stringify({ status: b.dataset.s }) });
        load();
      });
    };
    load();
    document.getElementById("u-new").onclick = () => userModal(load);
  }
  if (can("audit.read")) {
    const r = await api("/api/admin/audit");
    // Kettenstatus immer sichtbar im Kopf; die Tabelle klappt auf Wunsch auf.
    document.getElementById("a-chain").innerHTML =
      `${r.chain_valid ? '<span class="pill ok">Hash-Kette intakt</span>' : '<span class="pill crit">Hash-Kette VERLETZT</span>'}
       <small>(${r.chain_checked} Einträge)</small>`;
    document.getElementById("a-list").innerHTML =
      table(["Zeit", "Nutzer", "Aktion", "Objekt", "OK"],
        r.events.slice(0, 200).map((e) => [esc(e.ts), esc(e.username || "–"), esc(e.action),
          esc([e.object_type, e.object_id].filter(Boolean).join(" ")), e.success ? "✓" : "✗"]));
    const tgl = document.getElementById("a-toggle"), wrap = document.getElementById("a-wrap");
    tgl.onclick = () => {
      const open = wrap.style.display === "none";
      wrap.style.display = open ? "" : "none";
      tgl.textContent = open ? "Einklappen ▴" : "Aufklappen ▾";
    };
  }
  if (can("etl.manage", "user.manage")) {
    const renderEtl = async () => {
      const r = await api("/api/admin/etl");
      const running = r.jobs.find((j) => j.status === "running");
      const prog = document.getElementById("sync-progress");
      if (!prog) return false;
      if (running) {
        let stats = {};
        try { stats = JSON.parse(running.stats || "{}"); } catch {}
        const pct = stats.total ? Math.round((stats.done / stats.total) * 100) : 0;
        // Zeitschätzung aus bisherigem Durchsatz (started_at ist UTC aus SQLite)
        let eta = "";
        if ((stats.done || 0) > 3 && stats.total && running.started_at) {
          const elapsed = Date.now() - Date.parse(running.started_at.replace(" ", "T") + "Z");
          if (elapsed > 60000) {
            const restMin = Math.round((elapsed / stats.done) * (stats.total - stats.done) / 60000);
            const rate = stats.done / (elapsed / 60000);
            eta = ` · noch ${restMin >= 90 ? "~" + (restMin / 60).toFixed(1) + " Std."
              : restMin >= 1 ? "~" + restMin + " Min." : "< 1 Min."} (${rate.toFixed(1)} Pat./Min.)`;
          }
        }
        prog.innerHTML = `<div class="row" style="justify-content:space-between">
            <b>Sync läuft (${esc(running.mode)}${stats.since ? " · ab " + esc(stats.since) : ""})</b>
            <span>${stats.done || 0} / ${stats.total || "?"} Patienten · ${stats.resources || 0} Ressourcen
              ${stats.errors ? ` · ${stats.errors} Fehler` : ""}${eta}
              <button class="btn" id="sync-stop" style="margin-left:12px">■ Abbrechen</button></span></div>
          <div style="background:var(--border-2);border-radius:6px;height:12px;margin:8px 0 16px">
            <div style="width:${pct}%;height:12px;border-radius:6px;background:var(--gb-grad)"></div></div>`;
        document.getElementById("sync-stop").onclick = async () => {
          if (!confirm("Laufenden Sync abbrechen? Der nächste Lauf setzt beim letzten"
                       + " fertigen Patienten wieder auf.")) return;
          await api("/api/admin/sync/stop", { method: "POST" });
          renderEtl();
        };
      } else {
        prog.innerHTML = "";
      }
      document.getElementById("e-list").innerHTML =
        card2("Ressourcen im Store", bars(r.resources.slice(0, 10).map((c) => [c.resource_type, c.n]))) +
        table(["Job", "Modus", "Privacy", "Status", "Start", "Statistik", "Fehler"],
          r.jobs.map((j) => {
            let s = {}; try { s = JSON.parse(j.stats || "{}"); } catch {}
            const stat = s.total ? `${s.done ?? s.patients ?? "?"}/${s.total} Pat. · ${s.resources ?? 0} Res.`
                + (s.errors ? ` · ${s.errors} Fehler` : "")
              : (j.stats || "–");
            const err = j.error
              ? `<span title="${esc(j.error)}">${esc(j.error.length > 90
                  ? j.error.slice(0, 90) + "…" : j.error)}</span>`
              : "–";
            return [esc(j.id.slice(0, 8)), esc(j.mode), esc(j.privacy),
              j.status === "running" ? '<span class="pill info">läuft</span>'
                : j.status === "success" ? '<span class="pill ok">ok</span>'
                : `<span class="pill crit">${esc(j.status)}</span>`,
              esc(j.started_at), esc(String(stat)), err];
          }));
      return !!running;
    };
    const poll = async () => {
      if (location.hash.slice(1) !== "verwaltung") return;    // Ansicht verlassen
      const active = await renderEtl().catch(() => false);
      setTimeout(poll, active ? 2500 : 10000);
    };
    poll();
    const startSync = (mode) => async () => {
      try {
        await api("/api/admin/sync", { method: "POST", body: JSON.stringify({ mode }) });
        renderEtl();
      } catch (e) {
        if (/bereits ein Sync/.test(e.message)
            && confirm("Es scheint bereits ein Sync zu laufen. Abgestürzten Lauf "
                       + "verwerfen und neu starten?")) {
          await api("/api/admin/sync", { method: "POST",
            body: JSON.stringify({ mode, force: true }) }).then(renderEtl)
            .catch((e2) => document.getElementById("sync-progress").innerHTML =
              `<span class="pill crit">${esc(e2.message)}</span>`);
          return;
        }
        document.getElementById("sync-progress").innerHTML =
          `<span class="pill crit">${esc(e.message)}</span>`;
      }
    };
    document.getElementById("sync-inc").onclick = startSync("incremental");
    document.getElementById("sync-full").onclick = startSync("full");
    document.getElementById("store-reset").onclick = async () => {
      const w = prompt("ACHTUNG: Löscht alle geladenen Klinikdaten aus dem Analyse-Store"
        + " (Benutzer, Rollen, Audit und Kataloge bleiben erhalten). Nötig z. B. beim"
        + " Wechsel des Datenmodus. Zum Bestätigen LOESCHEN eingeben:");
      if (w !== "LOESCHEN") return;
      try {
        await api("/api/admin/store/reset", { method: "POST",
          body: JSON.stringify({ confirm: "LOESCHEN" }) });
        renderEtl();
      } catch (e) {
        document.getElementById("sync-progress").innerHTML =
          `<span class="pill crit">${esc(e.message)}</span>`;
      }
    };
    document.getElementById("sync-log").onclick = async () => {
      try { await downloadLog("sync"); }
      catch (e) {
        document.getElementById("sync-progress").innerHTML =
          `<span class="pill crit">${esc(e.message)}</span>`;
      }
    };
  }
}
function userModal(onDone) {
  const roles = ["owner", "clinician", "mfa", "analyst", "researcher", "auditor", "admin_tech"];
  const m = document.getElementById("modal");
  m.innerHTML = `<div class="modal-back"><div class="card modal">
    <div class="card-h" style="background:var(--gb-grad-soft);color:var(--ink)"><b>Neuer Benutzer</b></div>
    <div class="card-b">
      <label>Benutzername</label><input class="input" id="nu-user">
      <label>Name</label><input class="input" id="nu-name">
      <label>Passwort (min. 12)</label><input class="input" id="nu-pass">
      <label>Rollen</label><div class="row">${roles.map((r) =>
        `<label class="pill"><input type="checkbox" value="${r}" class="nu-role"> ${r}</label>`).join("")}</div>
      <div class="row mt"><button class="btn btn-primary" id="nu-go">Anlegen</button>
      <button class="btn" id="nu-cancel">Abbrechen</button></div>
      <div id="nu-out" class="mt"></div></div></div></div>`;
  document.getElementById("nu-cancel").onclick = () => (m.innerHTML = "");
  document.getElementById("nu-go").onclick = async () => {
    try {
      const roles = [...document.querySelectorAll(".nu-role:checked")].map((c) => c.value);
      const r = await api("/api/admin/users", { method: "POST", body: JSON.stringify({
        username: val("nu-user"), full_name: val("nu-name"), password: val("nu-pass"), roles }) });
      document.getElementById("nu-out").innerHTML = `
        <p class="pill ok">Angelegt.</p><p><b>TOTP-URI:</b></p><div class="qr-uri">${esc(r.totp_uri)}</div>
        <p class="mt"><b>Recovery-Codes:</b></p><div class="qr-uri">${r.recovery_codes.map(esc).join("<br>")}</div>`;
      onDone();
    } catch (e) { document.getElementById("nu-out").innerHTML = errBox(e); }
  };
}

// ---------- Einstellungen (alle Laufzeit-Konfigurationen) ----------
async function viewEinstellungen() {
  render(`<div id="s-root">${skeletonRows(6)}</div>`);
  try {
    const s = await api("/api/settings");
    const ro = can("settings.manage") ? "" : "disabled";
    const sel = (id, options, value) => `<select class="input" id="${id}" ${ro}
      style="max-width:360px">${options.map(([v, label]) =>
      `<option value="${v}" ${value === v ? "selected" : ""}>${label}</option>`).join("")}</select>`;
    const chk = (id, value) => sel(id, [["true", "aktiv"], ["false", "aus"]], value);

    document.getElementById("s-root").innerHTML = `<div class="stack">
      ${card("Datenschutz (privacy — wirkt auch auf Agent/Nachtlauf via config.yaml)", `
        <label>Datenmodus</label>${sel("s-mode",
          [["off", "off — Klardaten (Praxisbetrieb, alles bleibt im Haus)"],
           ["pseudonymize", "pseudonymize — Pseudonyme + Date-Shift"],
           ["anonymize", "anonymize — zusätzlich generalisiert"]], s.privacy_mode)}
        <label class="mt">Assertion-Gate</label>${sel("s-gate",
          [["enforce", "enforce — Abbruch bei Klartext-Fund"],
           ["warn", "warn — nur Warnung ins Log"],
           ["off", "off — deaktiviert"]], s.privacy_gate)}
        <label class="mt">Freitext-De-Identifikation (Namen in Texten/Titeln maskieren)</label>
        ${chk("s-deid", s.privacy_free_text_deid)}
        <label class="mt">Original-Dateinamen der Anhänge behalten</label>
        ${chk("s-filenames", s.privacy_keep_filenames)}
        <label class="mt">Date-Shift (konsistente Datumsverschiebung je Patient)</label>
        ${chk("s-dateshift", s.privacy_date_shift)}
        <p class="mt"><small>${s.config_write_through
          ? "✓ Änderungen werden in config/config.yaml fortgeschrieben (wird bei Bedarf angelegt) — Agent/Nachtlauf nutzen dieselben Werte."
          : "Hinweis: GREENBAY_HOME nicht gesetzt (Dev-Betrieb) — Einstellungen gelten nur für den Server."}</small></p>`)}
      ${card("Dokument-Intelligence (docs/DOKUMENTE_ANNOTATION.md)", `
        <label>Annotation beim Export (Overlay + abgeleitete Ressourcen)</label>
        ${chk("s-ann", s.annotation_enabled)}
        <label class="mt">OCR für Scan-PDFs/Bilder (Tesseract 'deu')</label>
        ${chk("s-ocr", s.annotation_ocr)}
        <label class="mt">Confidence-Schwelle für abgeleitete Ressourcen (0–1)</label>
        <input class="input" id="s-conf" ${ro} style="max-width:360px"
          value="${esc(s.annotation_min_confidence)}">
        <label class="mt">Terminologieserver-URL (on-premise, optional)</label>
        <input class="input" id="s-ts" ${ro} style="max-width:360px"
          placeholder="http://localhost:8081/fhir" value="${esc(s.annotation_terminology_server)}">`)}
      ${card("Quellverbindung (SQL Server, read-only)", `
        <div class="grid cols-3">
          <div><label>Host / Instanz</label>
            <input class="input" id="src-host" ${ro} placeholder="PRAXIS-SQL\\EUGASTRO"
              value="${esc(s.source_host)}"></div>
          <div><label>Port</label>
            <input class="input" id="src-port" ${ro} value="${esc(s.source_port)}"></div>
          <div><label>Datenbank</label>
            <input class="input" id="src-db" ${ro} value="${esc(s.source_database)}"></div>
        </div>
        <div class="grid cols-3 mt">
          <div><label>Authentifizierung</label>${sel("src-auth",
            [["sql", "SQL-Login"], ["windows", "Windows"]], s.source_auth)}</div>
          <div><label>Benutzer (read-only!)</label>
            <input class="input" id="src-user" ${ro} value="${esc(s.source_username)}"></div>
          <div><label>Passwort (wird DPAPI-geschützt abgelegt)</label>
            <input class="input" type="password" id="src-pass" ${ro}
              placeholder="unverändert lassen = leer"></div>
        </div>
        <div class="row mt">
          <button class="btn" id="src-test" ${ro}>Verbindung testen</button>
          <button class="btn btn-primary" id="src-save" ${ro}>Quellverbindung speichern</button>
          <span id="src-out"></span>
        </div>`)}
      ${card("Sync & Zeitplan", `
        <div class="grid cols-3">
          <div><label>Nächtlicher Sync</label>${chk("s-syncon", s.sync_enabled)}</div>
          <div><label>Uhrzeit (Scheduled Task)</label>
            <input class="input" id="s-synctime" ${ro} value="${esc(s.sync_time)}"></div>
          <div><label>Stichtag: nur Daten ab (leer = alles)</label>
            <input class="input" id="s-since" ${ro} placeholder="2021-01-01"
              value="${esc(s.load_since)}"></div>
        </div>
        <p class="mt"><small>Manueller Lauf: Verwaltung → „ETL-Status & Store" →
        Sync-Knopf (mit Live-Fortschritt).</small></p>`)}
      ${card("Anmeldung", `
        <label>Zwei-Faktor-Anmeldung (TOTP)</label>${sel("s-mfa",
          [["off", "aus — nur Passwort (Standard: Einzelplatz in der Praxis)"],
           ["required", "erforderlich — Passwort + Authenticator-Code"]], s.auth_mfa)}
        <p class="mt"><small>Gilt für Login und Break-Glass-Re-Auth. Passwort,
        Rollen und Audit bleiben immer aktiv. TOTP-Secrets bleiben gespeichert —
        Einschalten wirkt sofort, ohne Neu-Einrichtung.</small></p>`)}
      ${card("Analyse", `
        <label>Datenbasis der Kohortenanalyse (Provenienz)</label>${sel("s-nlp",
          [["all", "strukturiert + NLP-abgeleitet"],
           ["structured", "nur strukturiert"],
           ["nlp", "nur NLP-abgeleitet (Dokument-Konzepte)"]], s.analysis_include_nlp)}`)}
      ${card("KI-Integration (Stufe 0/1 — docs/KI_INTEGRATION.md)", `
        <div class="grid cols-2">
          <div><label>Provider</label>${sel("s-ai-provider",
            [["off", "aus"], ["anthropic", "Anthropic (Claude)"],
             ["openai", "OpenAI"], ["custom", "eigener Endpunkt (OpenAI-kompatibel)"]],
            s.ai_provider)}</div>
          <div><label>Modell (leer = Provider-Standard)</label>
            <input class="input" id="s-ai-model" ${ro} placeholder="z. B. claude-sonnet-5"
              value="${esc(s.ai_model)}"></div>
          <div><label>Basis-URL (leer = Provider-Standard)</label>
            <input class="input" id="s-ai-url" ${ro} placeholder="https://…"
              value="${esc(s.ai_base_url)}"></div>
          <div><label>API-Key (wird DPAPI-geschützt abgelegt)</label>
            <input class="input" type="password" id="s-ai-key" ${ro}
              placeholder="unverändert lassen = leer"></div>
        </div>
        <p class="mt"><small>⚠️ Bei Cloud-Providern verlassen die übergebenen Daten
        (Labor/Diagnosen/Medikation, pseudonym-/kennungsbezogen) die Praxis Richtung
        Anbieter. Jeder KI-Aufruf wird auditiert; Ergebnisse sind Entwürfe
        (ai-provenance) und ersetzen keine ärztliche Bewertung.</small></p>`)}
      ${card("Darstellung & FHIR", `
        <label>FHIR-Zielprofil (UI_SPEC §7)</label>${sel("s-profile",
          [["r4", "R4 (bare) — maximale Kompatibilität"],
           ["mii", "MII-KDS — Forschungsnetz"],
           ["kbv", "KBV-Basis — Versorgung"]], s.fhir_profile)}
        <label class="mt">Theme</label>${sel("s-theme",
          [["light", "Hell"], ["dark", "Dunkel (Token-Variante)"]], s.theme)}
        <label class="mt">${esc(t("set.language"))}</label>${sel("s-lang",
          [["de", "Deutsch"], ["en", "English"], ["fr", "Français"],
           ["es", "Español"], ["ru", "Русский"]], localStorage.getItem("gb_lang") || "de")}
        <p class="mt"><small>Die Sprache gilt je Browser/Arbeitsplatz und wirkt sofort.
        Fachbegriffe der Quelldaten (Freitexte, Katalognamen) bleiben in der
        Originalsprache.</small></p>`)}
      ${can("settings.manage")
        ? '<div><button class="btn btn-primary" id="s-save">Alle Einstellungen speichern</button> <span id="s-out"></span></div>'
        : '<p><small>Nur lesend — Recht settings.manage erforderlich.</small></p>'}
      <p><small>Quellverbindung, Zeitplan und alle Schutzschichten werden hier zentral
      gepflegt; das DB-Passwort wird DPAPI-geschützt abgelegt und nie im Klartext
      gespeichert oder angezeigt. Die Ersteinrichtung (docs/SETUP.md) bleibt als
      alternativer Weg beim allerersten Start bestehen.</small></p>
    </div>`;
    const langSel = document.getElementById("s-lang");
    if (langSel) langSel.onchange = () => setLang(langSel.value);
    const save = document.getElementById("s-save");
    if (save) save.onclick = async () => {
      try {
        await api("/api/settings", { method: "POST", body: JSON.stringify({
          privacy_mode: val("s-mode"), privacy_gate: val("s-gate"),
          privacy_free_text_deid: val("s-deid"), privacy_keep_filenames: val("s-filenames"),
          privacy_date_shift: val("s-dateshift"),
          annotation_enabled: val("s-ann"), annotation_ocr: val("s-ocr"),
          annotation_min_confidence: val("s-conf"),
          annotation_terminology_server: val("s-ts"),
          analysis_include_nlp: val("s-nlp"), auth_mfa: val("s-mfa"),
          sync_enabled: val("s-syncon"), sync_time: val("s-synctime"),
          load_since: val("s-since"),
          ai_provider: val("s-ai-provider"), ai_base_url: val("s-ai-url"),
          ai_model: val("s-ai-model"), ai_api_key: val("s-ai-key") || undefined,
          fhir_profile: val("s-profile"), theme: val("s-theme") }) });
        const k = document.getElementById("s-ai-key");
        if (k) k.value = "";
        document.getElementById("s-out").innerHTML = '<span class="pill ok">Gespeichert</span>';
      } catch (e) {
        document.getElementById("s-out").innerHTML = `<span class="pill crit">${esc(e.message)}</span>`;
      }
    };
    const srcPayload = () => ({
      source_host: val("src-host"), source_port: val("src-port"),
      source_database: val("src-db"), source_auth: val("src-auth"),
      source_username: val("src-user"), password: val("src-pass") || undefined });
    const srcOut = (html) => (document.getElementById("src-out").innerHTML = html);
    const srcTest = document.getElementById("src-test");
    if (srcTest) srcTest.onclick = async () => {
      srcOut('<span class="pill info">teste …</span>');
      try {
        const r = await api("/api/admin/source/test", { method: "POST",
          body: JSON.stringify(srcPayload()) });
        srcOut(r.ok
          ? `<span class="pill ok">OK · ${esc(r.server_version || "")} · ${r.patients} Patienten
             ${r.datareader ? "· db_datareader ✓" : '· <b>kein db_datareader!</b>'}</span>`
          : `<span class="pill crit">Fehler: ${esc(r.error || "unbekannt")}</span>` +
            (r.hint ? `<div class="mt"><small>💡 ${esc(r.hint)}</small></div>` : ""));
      } catch (e) { srcOut(`<span class="pill crit">${esc(e.message)}</span>`); }
    };
    const srcSave = document.getElementById("src-save");
    if (srcSave) srcSave.onclick = async () => {
      try {
        const r = await api("/api/admin/source", { method: "POST",
          body: JSON.stringify(srcPayload()) });
        srcOut(`<span class="pill ok">Gespeichert${r.password_stored ? " (inkl. Passwort)" : ""}</span>`);
        document.getElementById("src-pass").value = "";
      } catch (e) { srcOut(`<span class="pill crit">${esc(e.message)}</span>`); }
    };
  } catch (e) { document.getElementById("s-root").innerHTML = errBox(e); }
}

// ---------- kleine Helfer / Charts ----------
const val = (id) => document.getElementById(id)?.value?.trim() || "";
const gender = (g) => g
  ? ({ male: t("gender.m"), female: t("gender.w"), other: t("gender.d") }[g] || "–") : "–";
const rtLabel = (type) => t("rt." + type) === "rt." + type ? type : t("rt." + type);
const vsLabel = (code) => code
  ? (t("vs." + code) === "vs." + code ? code : t("vs." + code)) : "–";
const pill = (t) => t ? `<span class="pill">${esc(t)}</span>` : "–";
const pillCls = (t, cls) => `<span class="pill ${cls}">${esc(t)}</span>`;
const errBox = (e) => `<div class="error-state">⚠ ${esc(e.message || e)}<br>
  <button class="btn mt" onclick="route()">Erneut versuchen</button></div>`;
const emptyCard = (msg) => `<div class="card"><div class="card-b empty">${esc(msg)}</div></div>`;
const card = (title, body) => `<div class="card"><div class="card-h">
  <span class="card-title">${esc(title)}</span></div><div class="card-b">${body}</div></div>`;
const card2 = card;
const skeletonRows = (n) => Array.from({ length: n },
  () => '<div class="skeleton" style="margin:10px 0"></div>').join("");
const table = (head, rows) => rows.length ? `<table class="data"><thead><tr>
  ${head.map((h) => `<th>${esc(h)}</th>`).join("")}</tr></thead><tbody>
  ${rows.map((r) => `<tr>${r.map((c) => `<td>${c}</td>`).join("")}</tr>`).join("")}</tbody></table>`
  : '<div class="empty">Keine Daten.</div>';

const fmtNum = (v) => typeof v === "number" ? (Math.round(v * 100) / 100).toLocaleString("de-DE") : (v ?? "?");
async function downloadLog(name) {
  // Protokoll als Datei (kann sehr lang werden -> kein Dialog)
  const r = await api(`/api/admin/sync/log?name=${name}&full=1`);
  const blob = new Blob([r.log || "(Protokoll ist leer)"], { type: "text/plain" });
  const a = Object.assign(document.createElement("a"),
    { href: URL.createObjectURL(blob), download: `greenbay-${name}.log` });
  a.click();
}
function labPill(lab) {
  if (!lab) return "–";
  const cls = { H: "warn", HH: "crit", L: "warn", LL: "crit", A: "crit" }[lab.flag] || "ok";
  return `<span class="pill ${cls}">${esc(lab.name)}: ${esc(String(fmtNum(lab.value)))} ${esc(lab.unit || "")}</span>`;
}
function sparkline(points, reference, w = 320, h = 44) {
  const pts = (points || []).filter((p) => typeof p.v === "number");
  if (pts.length < 2) return '<small class="empty" style="padding:4px">zu wenige Werte</small>';
  const vs = pts.map((p) => p.v);
  const min = Math.min(...vs), max = Math.max(...vs), span = (max - min) || 1;
  const x = (i) => 4 + (i / (pts.length - 1)) * (w - 8);
  const y = (v) => h - 6 - ((v - min) / span) * (h - 12);
  const path = pts.map((p, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(p.v).toFixed(1)}`).join(" ");
  let ref = "";
  const rm = (reference || "").match(/([\d.,]+)\s*[-–]\s*([\d.,]+)/);
  if (rm) {
    const lo = parseFloat(rm[1].replace(",", ".")), hi = parseFloat(rm[2].replace(",", "."));
    ref = `<rect class="spark-ref" x="0" y="${y(Math.min(hi, max)).toFixed(1)}" width="${w}"
           height="${Math.abs(y(Math.max(lo, min)) - y(Math.min(hi, max))).toFixed(1)}"/>`;
  }
  const dots = pts.map((p, i) => p.flag ? `<circle cx="${x(i).toFixed(1)}" cy="${y(p.v).toFixed(1)}"
    r="3" fill="var(--${p.flag.startsWith("H") || p.flag.startsWith("L") ? "warn" : "info"})"/>` : "").join("");
  return `<svg viewBox="0 0 ${w} ${h}" width="100%" height="${h}" role="img"
    aria-label="Wertverlauf">${ref}<path class="spark" d="${path}"/>${dots}</svg>`;
}
function parseRef(reference) {
  // "3,9 – 10,2" | "< 5,2" | "> 1,04" -> {min?, max?}
  const t = reference || "";
  const num = (x) => parseFloat(x.replace(",", "."));
  let m = t.match(/([\d.,]+)\s*[-–]\s*([\d.,]+)/);
  if (m) return { min: num(m[1]), max: num(m[2]) };
  m = t.match(/<\s*=?\s*([\d.,]+)/);
  if (m) return { max: num(m[1]) };
  m = t.match(/>\s*=?\s*([\d.,]+)/);
  if (m) return { min: num(m[1]) };
  return {};
}
function bigChart(s, w = 760, h = 260) {
  // Großer Wertverlauf mit Referenzkorridor + Achsen (Labor-Explorer)
  const pts = (s.points || []).filter((p) => typeof p.v === "number");
  if (pts.length < 2) return '<div class="empty">Zu wenige Werte für eine Kurve.</div>';
  const ref = parseRef(s.reference);
  const vs = pts.map((p) => p.v);
  let min = Math.min(...vs, ref.min ?? Infinity, ref.max ?? Infinity);
  let max = Math.max(...vs, ref.max ?? -Infinity, ref.min ?? -Infinity);
  if (min === max) { min -= 1; max += 1; }
  const pad = (max - min) * 0.1;
  min -= pad; max += pad;
  const L = 52, R = 14, T = 12, B = 26;
  const x = (i) => L + (i / (pts.length - 1)) * (w - L - R);
  const y = (v) => T + (1 - (v - min) / (max - min)) * (h - T - B);
  let band = "";
  if (ref.min != null || ref.max != null) {
    const top = y(Math.min(ref.max ?? max, max));
    const bot = y(Math.max(ref.min ?? min, min));
    band = `<rect x="${L}" y="${top.toFixed(1)}" width="${w - L - R}"
        height="${Math.max(0, bot - top).toFixed(1)}" fill="var(--gb-teal)" opacity="0.10"/>`
      + [ref.max, ref.min].filter((v) => v != null).map((v) =>
        `<line x1="${L}" x2="${w - R}" y1="${y(v).toFixed(1)}" y2="${y(v).toFixed(1)}"
         stroke="var(--gb-teal)" stroke-dasharray="4 4" opacity=".55"/>`).join("");
  }
  const path = pts.map((p, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(p.v).toFixed(1)}`).join(" ");
  const dots = pts.map((p, i) => `<circle cx="${x(i).toFixed(1)}" cy="${y(p.v).toFixed(1)}"
      r="${p.flag ? 5 : 3.5}" fill="${p.flag ? "var(--crit)" : "var(--gb-blue)"}">
      <title>${esc(p.t.slice(0, 10))}: ${fmtNum(p.v)} ${esc(s.unit || "")}${p.flag ? " · " + esc(p.flag) : ""}</title>
    </circle>`).join("");
  const ticks = Array.from({ length: 4 }, (_, i) => min + pad / 2 + ((max - min - pad) * i) / 3);
  const axis = ticks.map((v) => `<text x="${L - 8}" y="${(y(v) + 3).toFixed(1)}" text-anchor="end"
      font-size="10" fill="currentColor" opacity=".55">${fmtNum(Math.round(v * 100) / 100)}</text>`).join("")
    + `<text x="${L}" y="${h - 8}" font-size="10" fill="currentColor" opacity=".55">${esc(pts[0].t.slice(0, 10))}</text>
       <text x="${w - R}" y="${h - 8}" text-anchor="end" font-size="10" fill="currentColor" opacity=".55">${esc(pts[pts.length - 1].t.slice(0, 10))}</text>`;
  return `<svg viewBox="0 0 ${w} ${h}" width="100%" role="img" aria-label="Wertverlauf ${esc(s.name || "")}">
    ${band}<path d="${path}" fill="none" stroke="var(--gb-blue)" stroke-width="2.2"/>${dots}${axis}</svg>`;
}

// items: [label, n] oder [label, n, sel] — mit sel wird das Element klickbar
// (data-sel), der Aufrufer verdrahtet den Filter (Kohorten-Drilldown).
function donut(items) {
  const total = items.reduce((s, [, n]) => s + (typeof n === "number" ? n : 4), 0) || 1;
  const colors = ["var(--gb-pink)", "var(--gb-violet)", "var(--gb-blue)", "var(--gb-teal)",
    "var(--gb-secondary)", "var(--gb-accent)"];
  const selAttr = (sel) => sel ? ` data-sel="${esc(String(sel))}" style="cursor:pointer"` : "";
  let acc = 0;
  const segs = items.slice(0, 6).map(([label, n, sel], i) => {
    const v = typeof n === "number" ? n : 4;
    if (v >= total) {  // Einzelsegment: Vollkreis statt degeneriertem Bogen
      return `<circle cx="60" cy="60" r="48" stroke="${colors[i % 6]}" stroke-width="16"
              fill="none"${selAttr(sel)}><title>${esc(label)}: ${esc(String(n))}</title></circle>`;
    }
    const a0 = (acc / total) * 2 * Math.PI; acc += v;
    const a1 = (acc / total) * 2 * Math.PI;
    const large = a1 - a0 > Math.PI ? 1 : 0;
    const p = (a) => `${(60 + 48 * Math.sin(a)).toFixed(1)},${(60 - 48 * Math.cos(a)).toFixed(1)}`;
    return `<path d="M${p(a0)} A48,48 0 ${large} 1 ${p(a1)}" stroke="${colors[i % 6]}"
            stroke-width="16" fill="none"${selAttr(sel)}><title>${esc(label)}: ${esc(String(n))}</title></path>`;
  }).join("");
  const legend = items.slice(0, 6).map(([label, n, sel], i) =>
    `<div class="row"${selAttr(sel)} style="gap:8px${sel ? ";cursor:pointer" : ""}"><span style="width:10px;height:10px;border-radius:3px;
     background:${colors[i % 6]}"></span><small>${esc(label)} (${esc(String(n))})</small></div>`).join("");
  return items.length ? `<div class="row"><svg viewBox="0 0 120 120" width="140" class="chart-donut">
    ${segs}</svg><div class="stack" style="gap:4px">${legend}</div></div>`
    : '<div class="empty">Keine Daten.</div>';
}
function bars(items) {
  const max = Math.max(...items.map(([, n]) => (typeof n === "number" ? n : 4)), 1);
  return items.length ? items.map(([label, n, sel]) => {
    const v = typeof n === "number" ? n : 4;
    return `<div class="bar-row"${sel ? ` data-sel="${esc(String(sel))}" style="cursor:pointer"` : ""}>
      <small>${esc(label)}</small>
      <div><div class="bar" style="width:${(v / max) * 100}%"></div></div>
      <small><b>${esc(String(n))}</b></small></div>`;
  }).join("") : '<div class="empty">Keine Daten.</div>';
}
function trendChart(trend) {
  const pts = trend.map((t, i) => ({ t: t.period, v: t.median }));
  return sparkline(pts.map((p) => ({ ...p, flag: null })), null, 720, 100) +
    table(["Quartal", "Median", "n"], trend.map((t) => [esc(t.period), t.median, esc(String(t.n))]));
}

// ---------- Router ----------
async function route() {
  state.route = location.hash.slice(1) || "patients";
  const [path, query] = state.route.split("?");
  const params = new URLSearchParams(query || "");

  const status = await api("/api/status").catch(() => ({ setup_required: false }));
  state.mfaRequired = status.mfa_required !== false;
  if (status.setup_required) return viewSetup();
  if (!state.token) return viewLogin();
  if (!state.me) {
    try { state.me = await api("/api/me"); }
    catch { return viewLogin(); }
  }

  if (path.startsWith("patient/")) return viewPatient(decodeURIComponent(path.slice(8)));
  if (path.startsWith("analyse")) return viewAnalyse();
  if (path.startsWith("kataloge")) return viewKataloge();
  if (path.startsWith("verwaltung")) return viewVerwaltung();
  if (path.startsWith("einstellungen")) return viewEinstellungen();
  return viewPatients(params);
}
window.addEventListener("hashchange", route);
route();
