# -*- coding: utf-8 -*-
"""KI-Integration Stufe 0/1: Einstellungen (Provider + DPAPI-Key), Gateway,
/api/ai/analyze (Audit, Fehlerpfade)."""
import json
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from fastapi.testclient import TestClient  # noqa: E402

from server.main import app  # noqa: E402
from server.runtime import Runtime, set_runtime  # noqa: E402
from store.load import load_bundle  # noqa: E402
from tests.util_demo import build_demo_bundles  # noqa: E402

MASTER = b"master-secret-fuer-tests-0123456789abcdef"
PW = "sehr-langes-owner-passwort"


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("GREENBAY_HOME", str(tmp_path))
    rt = Runtime(db_path=tmp_path / "clinical.db", master=MASTER)
    set_runtime(rt)
    bundles, _priv = build_demo_bundles(2, secret=MASTER.decode())
    for _pid, _nr, bundle in bundles:
        load_bundle(rt.conn, bundle)
    c = TestClient(app)
    c.post("/api/setup", json={"username": "owner", "password": PW})
    s = c.post("/api/login", json={"username": "owner", "password": PW}).json()
    return c, {"Authorization": "Bearer " + s["token"]}, tmp_path, rt


class TestEinstellungen:
    def test_key_wird_dpapi_datei_nie_klartext_in_db(self, client):
        c, h, tmp, rt = client
        r = c.post("/api/settings", headers=h, json={
            "ai_provider": "anthropic", "ai_model": "claude-sonnet-5",
            "ai_api_key": "sk-ant-geheim-123"})
        assert r.status_code == 200 and r.json()["ai_key_stored"] is True
        blob = (tmp / "secret" / "aikey.bin").read_bytes()
        assert blob.startswith(b"DEV\x00") or b"sk-ant-geheim-123" not in blob
        # nie in app_setting oder GET /api/settings
        row = rt.conn.execute("SELECT COUNT(*) AS n FROM app_setting"
                              " WHERE value LIKE '%sk-ant-geheim%'").fetchone()
        assert row["n"] == 0
        assert "sk-ant" not in json.dumps(c.get("/api/settings", headers=h).json())


class TestAnalyze:
    def _psn(self, c, h):
        return c.get("/api/patients", headers=h).json()["items"][0]["pseudonym"]

    def test_ohne_konfiguration_422(self, client):
        c, h, _tmp, _rt = client
        r = c.post("/api/ai/analyze", headers=h,
                   json={"pseudonym": self._psn(c, h)})
        assert r.status_code == 422

    def test_analyze_mit_mock_gateway_und_audit(self, client, monkeypatch):
        c, h, _tmp, rt = client
        c.post("/api/settings", headers=h, json={
            "ai_provider": "anthropic", "ai_api_key": "sk-test"})
        seen = {}

        def fake_chat(provider, api_key, system, user, **kw):
            seen.update(provider=provider, key=api_key, system=system, user=user)
            return "**Einschätzung:** Gamma-GT-Verlauf unauffällig."

        from server.ai import gateway
        monkeypatch.setattr(gateway, "chat", fake_chat)
        psn = self._psn(c, h)
        r = c.post("/api/ai/analyze", headers=h,
                   json={"pseudonym": psn, "question": "Leberwerte?"})
        assert r.status_code == 200, r.text
        body = r.json()
        assert "Einschätzung" in body["answer"] and body["disclaimer"]
        assert seen["provider"] == "anthropic" and seen["key"] == "sk-test"
        assert "Labor" in seen["user"] or "Diagnosen" in seen["user"]
        assert "Leberwerte?" in seen["user"]
        ev = rt.conn.execute("SELECT * FROM audit_event WHERE action='ai.analyze'"
                             " ORDER BY id DESC LIMIT 1").fetchone()
        assert ev is not None and ev["object_id"] == psn

    def test_gateway_fehler_wird_502_und_auditiert(self, client, monkeypatch):
        c, h, _tmp, rt = client
        c.post("/api/settings", headers=h, json={
            "ai_provider": "openai", "ai_api_key": "sk-test"})
        from server.ai import gateway

        def boom(*a, **kw):
            raise gateway.AiError("KI-Endpunkt nicht erreichbar: test")

        monkeypatch.setattr(gateway, "chat", boom)
        r = c.post("/api/ai/analyze", headers=h, json={"pseudonym": self._psn(c, h)})
        assert r.status_code == 502
        ev = rt.conn.execute("SELECT success FROM audit_event WHERE action='ai.analyze'"
                             " ORDER BY id DESC LIMIT 1").fetchone()
        assert ev["success"] == 0


class TestGatewayParsing:
    def test_anthropic_und_openai_antwortformate(self, monkeypatch):
        from server.ai import gateway
        calls = {}

        def fake_post(url, headers, payload):
            calls["url"] = url
            calls["headers"] = headers
            calls["payload"] = payload
            if "/v1/messages" in url:
                return {"content": [{"type": "text", "text": "Antwort A"}]}
            return {"choices": [{"message": {"content": "Antwort O"}}]}

        monkeypatch.setattr(gateway, "_post", fake_post)
        assert gateway.chat("anthropic", "k", "sys", "usr") == "Antwort A"
        assert calls["headers"]["x-api-key"] == "k"
        assert calls["payload"]["model"] == "claude-sonnet-5"
        assert gateway.chat("openai", "k", "sys", "usr") == "Antwort O"
        assert calls["headers"]["Authorization"] == "Bearer k"
        assert gateway.chat("custom", "k", "s", "u",
                            base_url="http://ki-host:8000") == "Antwort O"
        assert calls["url"].startswith("http://ki-host:8000/")
        with pytest.raises(gateway.AiError):
            gateway.chat("foo", "k", "s", "u")
