# -*- coding: utf-8 -*-
"""Tests: Auth (Passwort, TOTP, Sessions, Rate-Limit) + RBAC-Rechtematrix."""
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from server import auth, rbac  # noqa: E402
from store.db import open_store  # noqa: E402

MASTER = b"master-secret-fuer-tests-0123456789abcdef"


@pytest.fixture
def conn(tmp_path):
    c = open_store(tmp_path / "clinical.db")
    rbac.seed(c)
    yield c
    c.close()


class TestPasswort:
    def test_argon2_roundtrip(self):
        h = auth.hash_password("korrekt-pferd-batterie-klammer")
        assert auth.verify_password(h, "korrekt-pferd-batterie-klammer")
        assert not auth.verify_password(h, "falsch")


class TestTotp:
    def test_rfc6238_stable(self):
        secret = auth.totp_new_secret()
        at = 1_700_000_000
        code = auth.totp_code(secret, at)
        assert len(code) == 6 and code.isdigit()
        assert auth.totp_verify(secret, code, at)
        assert auth.totp_verify(secret, code, at + 29)   # Fenster ±1 Schritt
        assert not auth.totp_verify(secret, code, at + 120)


class TestLoginFlow:
    def _mk_user(self, conn, roles=("owner",)):
        return auth.create_user(conn, MASTER, "doc", "Dr. Demo",
                                "sehr-langes-passwort-123", list(roles))

    def test_login_requires_totp(self, conn):
        u = self._mk_user(conn)
        with pytest.raises(auth.AuthError):
            auth.login(conn, MASTER, "doc", "sehr-langes-passwort-123")
        session = auth.login(conn, MASTER, "doc", "sehr-langes-passwort-123",
                             totp=auth.totp_code(u["totp_secret"]))
        assert session["token"]
        row = auth.session_user(conn, session["token"])
        assert row["username"] == "doc"

    def test_recovery_code_single_use(self, conn):
        u = self._mk_user(conn)
        code = u["recovery_codes"][0]
        auth.login(conn, MASTER, "doc", "sehr-langes-passwort-123", recovery_code=code)
        with pytest.raises(auth.AuthError):
            auth.login(conn, MASTER, "doc", "sehr-langes-passwort-123", recovery_code=code)

    def test_rate_limit(self, conn):
        self._mk_user(conn)
        for _ in range(auth.MAX_FAILED_LOGINS):
            with pytest.raises(auth.AuthError):
                auth.login(conn, MASTER, "doc", "falsch")
        with pytest.raises(auth.AuthError, match="gesperrt"):
            auth.login(conn, MASTER, "doc", "sehr-langes-passwort-123")

    def test_logout_revokes(self, conn):
        u = self._mk_user(conn)
        s = auth.login(conn, MASTER, "doc", "sehr-langes-passwort-123",
                       totp=auth.totp_code(u["totp_secret"]))
        auth.logout(conn, s["token"])
        assert auth.session_user(conn, s["token"]) is None


class TestRechtematrix:
    """BENUTZERVERWALTUNG.md §3 — Stichproben der Matrix."""

    def _perms(self, conn, roles):
        u = auth.create_user(conn, MASTER, "u_" + "_".join(roles), "U",
                             "sehr-langes-passwort-123", list(roles))
        return rbac.permissions_of(conn, u["id"]), u["id"]

    def test_owner_hat_alles(self, conn):
        perms, _ = self._perms(conn, ["owner"])
        assert set(rbac.PERMISSIONS) == perms

    def test_analyst_nie_klardaten(self, conn):
        perms, uid = self._perms(conn, ["analyst"])
        assert "patient.view.clear" not in perms
        assert "analysis.run" in perms
        assert rbac.default_mode(conn, uid) == "pseudonym"

    def test_researcher_kein_freitext(self, conn):
        perms, uid = self._perms(conn, ["researcher"])
        assert "text.read" not in perms
        assert "export.research" in perms
        assert rbac.default_mode(conn, uid) == "anonym"

    def test_deny_gewinnt_bei_rollenkombination(self, conn):
        # analyst + clinician: klar erlaubt durch clinician, analyst-Deny gewinnt NICHT
        # die Klardaten-Sperre gilt je Rolle; Kombination clinician+analyst -> deny
        perms, _ = self._perms(conn, ["clinician", "analyst"])
        assert "patient.view.clear" not in perms  # deny (analyst) gewinnt immer

    def test_mfa_kein_analysetool(self, conn):
        perms, _ = self._perms(conn, ["mfa"])
        assert "analysis.run" not in perms
        assert "patient.view.pseudo" in perms

    def test_admin_tech_keine_klinikdaten(self, conn):
        perms, _ = self._perms(conn, ["admin_tech"])
        assert "etl.manage" in perms
        assert not {"patient.view.clear", "patient.view.pseudo"} & perms


class TestEntsperrung:
    def test_erfolgreicher_login_leert_fehlversuche(self, conn):
        u = auth.create_user(conn, MASTER, "doc2", "D", "sehr-langes-passwort-123",
                             ["owner"], mfa_required=False)
        for _ in range(3):
            with pytest.raises(auth.AuthError):
                auth.login(conn, MASTER, "doc2", "falsch")
        auth.login(conn, MASTER, "doc2", "sehr-langes-passwort-123", require_mfa=False)
        n = conn.execute("SELECT COUNT(*) AS n FROM sec_login_versuch"
                         " WHERE username='doc2' AND success=0").fetchone()["n"]
        assert n == 0   # Zähler nach Erfolg zurückgesetzt

    def test_unlock_tool_hebt_sperre_auf(self, conn, tmp_path, monkeypatch):
        auth.create_user(conn, MASTER, "doc3", "D", "sehr-langes-passwort-123",
                         ["owner"], mfa_required=False)
        for _ in range(auth.MAX_FAILED_LOGINS):
            with pytest.raises(auth.AuthError):
                auth.login(conn, MASTER, "doc3", "falsch")
        with pytest.raises(auth.AuthError, match="gesperrt"):
            auth.login(conn, MASTER, "doc3", "sehr-langes-passwort-123",
                       require_mfa=False)
        conn.execute("DELETE FROM sec_login_versuch WHERE username='doc3'")
        conn.commit()
        session = auth.login(conn, MASTER, "doc3", "sehr-langes-passwort-123",
                             require_mfa=False)
        assert session["token"]
