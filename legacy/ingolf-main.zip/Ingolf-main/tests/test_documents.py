# -*- coding: utf-8 -*-
"""Tests: Dokumentenverarbeitung (Gate, De-ID von Dateinamen/Titeln,
Volltext-Erhalt + FTS, AU/eAU-Abbildung)."""
import base64
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "agent"))

import gate  # noqa: E402
import mappers as M  # noqa: E402
from privacy import Privacy  # noqa: E402
from tests.util_demo import build_demo_bundles, KRANK_TEXT  # noqa: E402

PROW = {"Id": 3650, "Name": "Testfall3650", "Vorname": "Demo", "PatientNr": 73650,
        "Strasse": "Musterweg", "Wohnort": "Beispielstadt", "VersichertenNr": "X110987654"}


def _ctx(pid=3650, mode="pseudonymize"):
    priv = Privacy(mode=mode, secret="demo-secret-0123456789", date_shift=True)
    ps = priv.pseudonym(pid)
    return M.ExportContext(pid, ps, "urn:uuid:" + ps, priv), priv


class TestGate:
    def test_blockt_klartext_namen(self):
        bundle = {"entry": [{"resource": {"valueString": "Befund für Testfall3650"}}]}
        with pytest.raises(gate.GateViolation, match="Name"):
            gate.assert_clean(bundle, PROW, "pseudonymize")

    def test_blockt_kvnr_muster(self):
        bundle = {"note": [{"text": "KVNR A123456789 dokumentiert"}]}
        with pytest.raises(gate.GateViolation, match="KVNR"):
            gate.assert_clean(bundle, None, "pseudonymize")

    def test_blockt_dateinamen_mit_patientennamen(self):
        bundle = {"content": [{"attachment": {"title": "Sono_Testfall3650_2024.pdf"}}]}
        with pytest.raises(gate.GateViolation):
            gate.assert_clean(bundle, PROW, "pseudonymize")

    def test_sauberes_bundle_passiert(self):
        bundle = {"entry": [{"resource": {"valueString": "Steatosis hepatis, HOMA 3,4"}}]}
        gate.assert_clean(bundle, PROW, "pseudonymize")

    def test_off_modus_inaktiv(self):
        bundle = {"valueString": "Testfall3650"}
        gate.assert_clean(bundle, PROW, "off")   # Klardaten nur intern -> kein Gate

    def test_kurze_werte_ignoriert(self):
        # Hausnummern/Kuerzel (<3 Zeichen) duerfen keine False Positives ausloesen
        assert gate.check({"a": "2D im Text"}, {"Name": "2D"}) == []


class TestGateKonfigurierbar:
    """In-Praxis-Betrieb (privacy-Config): Gate-Policy + Schicht-Ausnahmen."""

    LEAKY_DOC = {"resourceType": "DocumentReference",
                 "description": "Brief an Testfall3650",
                 "content": [{"attachment": {"title": "Sono_Testfall3650_2024.pdf"}}]}

    def test_warn_bricht_nicht_ab(self, capsys):
        priv = Privacy(mode="pseudonymize", secret="s" * 16, gate="warn")
        gate.assert_clean(self.LEAKY_DOC, PROW, priv)   # kein Raise
        assert "GATE-WARNUNG" in capsys.readouterr().err

    def test_gate_off(self):
        priv = Privacy(mode="pseudonymize", secret="s" * 16, gate="off")
        gate.assert_clean(self.LEAKY_DOC, PROW, priv)

    def test_free_text_deid_aus_nimmt_narrative_felder_aus(self):
        priv = Privacy(mode="pseudonymize", secret="s" * 16, free_text_deid=False,
                       keep_filenames=True)
        gate.assert_clean(self.LEAKY_DOC, PROW, priv)   # Dokument mit Namen passiert
        # Strukturfelder bleiben trotzdem geschuetzt:
        with pytest.raises(gate.GateViolation):
            gate.assert_clean({"identifier": [{"value": "Testfall3650"}]}, PROW, priv)

    def test_keep_filenames_nur_dateinamen(self):
        priv = Privacy(mode="pseudonymize", secret="s" * 16, keep_filenames=True)
        gate.assert_clean(
            {"content": [{"attachment": {"title": "Sono_Testfall3650.pdf"}}]}, PROW, priv)
        with pytest.raises(gate.GateViolation):  # description weiterhin geprueft
            gate.assert_clean({"description": "Testfall3650"}, PROW, priv)

    def test_export_mit_praxis_preset(self):
        """Pseudonym-Export mit Dokumenten im Original (Namen bleiben drin)."""
        bundles, _ = build_demo_bundles(2, privacy_opts={
            "free_text_deid": False, "keep_filenames": True})
        _pid, _nr, bundle = bundles[0]
        text = str(bundle)
        assert "Dr. Weber" in text                    # Brief unveraendert
        assert "Sono_Testfall3650_2024.pdf" in text   # Dateiname unveraendert

    def test_privacy_text_respektiert_schalter(self):
        priv = Privacy(mode="pseudonymize", secret="s" * 16, free_text_deid=False)
        assert priv.text(1, "Dr. Weber am 01.02.2024") == "Dr. Weber am 01.02.2024"


class TestAnhangUndEpa:
    def test_anhang_dateiname_maskiert(self):
        ctx, _ = _ctx()
        rows = [{"Id": 95000, "FileName": "Sono_Testfall3650_2024.pdf", "Tag": "Sono",
                 "AnhangLength": 1024, "FsRowGuid": "g-1", "CreatedPoint": None,
                 "Id_MedDok": 1}]
        [entry] = M.map_anhaenge(ctx, rows)
        att = entry["resource"]["content"][0]["attachment"]
        assert "Testfall3650" not in str(entry)
        assert att["title"].endswith(".pdf")           # Endung bleibt erhalten
        assert att["contentType"] == "application/pdf"

    def test_anhang_klarmodus_behaelt_dateinamen(self):
        ctx, _ = _ctx(mode="off")
        rows = [{"Id": 95000, "FileName": "Sono_Testfall3650_2024.pdf", "Tag": None,
                 "AnhangLength": 1, "FsRowGuid": "g-1", "CreatedPoint": None}]
        [entry] = M.map_anhaenge(ctx, rows)
        assert entry["resource"]["content"][0]["attachment"]["title"] == \
            "Sono_Testfall3650_2024.pdf"

    def test_epa_titel_deidentifiziert(self):
        ctx, _ = _ctx()
        rows = [{"EventId": 1, "EventStartDateTime": None, "IsUpload": True,
                 "DocumentUniqueId": "doc-1",
                 "DocumentMetaJson": '{"title": "Arztbrief Dr. Weber 01.02.2024"}'}]
        [entry] = M.map_epa(ctx, rows)
        text = str(entry)
        assert "Weber" not in text and "01.02.2024" not in text


class TestDokumentVolltext:
    def test_volltext_erhalten_und_description_gekuerzt(self):
        bundles, _ = build_demo_bundles(2)
        docs = [e["resource"] for _pid, _nr, b in bundles for e in b["entry"]
                if e["resource"]["resourceType"] == "DocumentReference"
                and (e["resource"].get("type", {}).get("coding") or [{}])[0].get("code") == "KRANK"]
        assert docs, "KRANK-Dokument erwartet"
        doc = docs[0]
        assert len(doc["description"]) <= 280
        assert "Cholezystektomie" not in doc["description"]   # liegt hinter der Kuerzung
        full = base64.b64decode(doc["content"][0]["attachment"]["data"]).decode("utf-8")
        assert "Cholezystektomie" in full

    def test_volltext_im_fts_index(self, tmp_path):
        from store.db import open_store
        from store.load import load_bundle
        from store.annotate import search_fulltext
        conn = open_store(tmp_path / "clinical.db")
        bundles, _ = build_demo_bundles(2)
        for _pid, _nr, bundle in bundles:
            load_bundle(conn, bundle)
        hits = search_fulltext(conn, "Cholezystektomie", negated=None)
        assert hits, "Begriff hinter der 280-Zeichen-Grenze muss auffindbar sein"
        conn.close()


class TestAuAbbildung:
    def _au(self):
        bundles, priv = build_demo_bundles(2)
        pid, _nr, bundle = bundles[0]
        aus = [e["resource"] for e in bundle["entry"]
               if e["resource"]["resourceType"] == "DocumentReference"
               and (e["resource"].get("type", {}).get("coding") or [{}])[0].get("code") == "eAU"]
        return pid, priv, aus

    def test_au_eckdaten(self):
        pid, priv, aus = self._au()
        assert len(aus) == 1
        au = aus[0]
        assert au["category"][0]["text"] == "Erstbescheinigung"
        expected_end = priv.shift(pid, "2024-02-15")
        assert au["context"]["period"]["end"] == expected_end   # Date-Shift angewandt
        ext = {e["url"].rsplit("/", 1)[-1]: e for e in au.get("extension", [])}
        assert "K76.0" in ext["au-diagnosen"]["valueString"]
        assert ext["eau-status"]["valueString"] == "zwischenstatus-fehler"  # Eau.State 3 (Gutachten 2.1)

    def test_arztbrief_deidentifiziert(self):
        bundles, _ = build_demo_bundles(2)
        _pid, _nr, bundle = bundles[0]
        letters = [e["resource"] for e in bundle["entry"]
                   if e["resource"]["resourceType"] == "Composition"]
        assert letters, "Arztbrief erwartet"
        assert "Weber" not in str(letters[0])   # Behandlername maskiert


def test_gesamter_demo_export_passiert_gate():
    """build_patient_bundle ruft das Gate selbst auf - ein Durchlauf ohne
    GateViolation belegt: kein Klartext-Identifikator im Gesamtexport."""
    bundles, _ = build_demo_bundles(6)
    assert len(bundles) == 6
