# -*- coding: utf-8 -*-
"""Gemeinsame Demo-Daten für Tests + Seed: FakeSource simuliert die EUGASTRO-Quelle,
erzeugt N synthetische Patienten und liefert Bundles über die echte Export-Kette
(agent/export.build_patient_bundle)."""
from __future__ import annotations

import datetime as dt
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "agent"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

DIAG_XML = ('<MedDokDiagnose><Icd>{icd}</Icd><IcdBeschreibung>{txt}</IcdBeschreibung>'
            '<Sicherheit>{sich}</Sicherheit></MedDokDiagnose>')
FT_XML = '<MedDokFreitext><FreitextPlain>{text}</FreitextPlain></MedDokFreitext>'
FORMULAR_XML = ('<meddokformular><formularname>{name}</formularname>'
                '<shortinfo>{info}</shortinfo></meddokformular>')

# Langer Einweisungstext (> 280 Zeichen): der Begriff am Ende darf nur über den
# eingebetteten Volltext auffindbar sein (Test gegen description-Kuerzung).
KRANK_TEXT = ("Einweisung zur stationären Abklärung bei persistierenden rechtsseitigen "
              "Oberbauchschmerzen. Sonographisch echoreiche Leber, laborchemisch "
              "erhöhte Transaminasen. Unter ambulanter Therapie keine Besserung. "
              "Vorbefunde und Medikationsplan liegen bei. Bei Nachweis von "
              "Konkrementen ist die Indikation zur elektiven Cholezystektomie zu prüfen.")


def _patient(pid: int, geschlecht: int, geb_jahr: int) -> dict:
    return {"Id": pid, "PatientNr": 70000 + pid, "Name": f"Testfall{pid}",
            "Vorname": "Demo", "Titel": None, "Geschlecht": geschlecht,
            "Geburtsjahr": geb_jahr, "Geburtsmonat": 6, "Geburtstag": 15,
            "VerstorbenAm": None, "Strasse": "Musterweg", "Hausnummer": "1",
            "Postleitzahl": "04416", "Wohnort": "Beispielstadt",
            "Laenderkennzeichen": "D", "IsPrivat": pid % 3 == 0, "VersichertenNr": None,
            "IkNr": None, "Versichertenart": 1, "PatientSeit": dt.datetime(2015, 1, 1),
            "LetzterBesuchAm": dt.datetime(2024, 10, 1), "Staatsangehoerigkeit": None}


def make_tables(n_patients: int = 8) -> dict:
    """n_patients synthetische Patienten. Patienten mit gerader Id bekommen
    Fettleber (K76.0) + erhöhten HOMA + Metformin; ungerade eine negierte
    Zöliakie-Erwähnung (für Negations-/Kohortentests)."""
    tables: dict = {"Patient": [], "MedDok": [], "Schein": [], "Laborbogen": [],
                    "Vitals": [], "VerordnungV2": [], "Eau": [], "Anhang": []}
    mid = 90000
    for i in range(n_patients):
        pid = 3650 + i
        tables["Patient"].append(_patient(pid, 2 if i % 2 == 0 else 1, 1955 + 3 * i))
        base = dt.datetime(2024, 1, 10 + i, 9, 0)
        if i % 2 == 0:  # Kohorten-Fall: Fettleber + HOMA hoch + Metformin
            mid += 1
            tables["MedDok"].append({
                "Id": mid, "Id_Patient": pid, "Id_Schein": 5000 + i,
                "ReferenceDateTime": base, "Kuerzel": "D",
                "Detail": DIAG_XML.format(icd="K76.0", txt="Steatosis hepatis", sich="G")})
            mid += 1
            tables["MedDok"].append({
                "Id": mid, "Id_Patient": pid, "Id_Schein": 5000 + i,
                "ReferenceDateTime": base, "Kuerzel": "A",
                "Detail": FT_XML.format(
                    text="Deutliche Hinweise auf Insulinresistenz, Gewichtszunahme.")})
            tables["Laborbogen"].append({
                "Id": 70000 + i, "Id_Patient": pid, "Id_LaborHeader": 60000 + i,
                "Datum": base + dt.timedelta(days=2), "Kuerzel": "HOMA",
                "Grenzwertindikator": "+",
                "Details": json.dumps({"Ergebniswert": str(3.1 + 0.2 * i).replace(".", ","),
                                       "Einheit": "", "Testbezeichnung": "HOMA-Index",
                                       "NormalwertText": "< 2,5"})})
            tables["VerordnungV2"].append({
                "Id": 80000 + i, "Id_Patient": pid, "Pzn": "01766741", "ItemType": 1,
                "ReferenceDateTime": base, "ReichtBis": None, "AbgesetztDateTime": None,
                "Absetzungsgrund": None, "Id_Schein": 5000 + i,
                "Artikelname": "Metformin 850", "Artikellangname": "Metformin 850 mg",
                "AtcCode": "A10BA02", "Bezeichnung": "Metformin"})
            # Dokumentstrecke: AU (+ eAU-Status), Arztbrief, Einweisung, Anhang
            mid += 1
            au_id = mid
            tables["MedDok"].append({
                "Id": mid, "Id_Patient": pid, "Id_Schein": 5000 + i,
                "ReferenceDateTime": base + dt.timedelta(days=1), "Kuerzel": "AU",
                "Detail": FORMULAR_XML.format(
                    name="Arbeitsunfähigkeitsbescheinigung",
                    info="Erstbescheinigung, arbeitsunfähig bis 15.02.2024, K76.0")})
            tables["Eau"].append({
                "Id_Patient": pid, "Id_MedDok": au_id, "State": 3,
                "IkNr": "108035576", "MailingDateTime": base + dt.timedelta(days=1),
                "ResponseDateTime": base + dt.timedelta(days=2)})
            mid += 1
            tables["MedDok"].append({
                "Id": mid, "Id_Patient": pid, "Id_Schein": 5000 + i,
                "ReferenceDateTime": base + dt.timedelta(days=3), "Kuerzel": "BRIEF",
                "Detail": FT_XML.format(
                    text="Sehr geehrter Dr. Weber, wir berichten über den o.g. "
                         "Patienten mit gesicherter Steatosis hepatis.")})
            mid += 1
            krank_id = mid
            tables["MedDok"].append({
                "Id": mid, "Id_Patient": pid, "Id_Schein": 5000 + i,
                "ReferenceDateTime": base + dt.timedelta(days=4), "Kuerzel": "KRANK",
                "Detail": FT_XML.format(text=KRANK_TEXT)})
            tables["Anhang"].append({
                "Id": 95000 + i, "Id_Patient": pid, "Id_MedDok": krank_id,
                "FileName": f"Sono_Testfall{pid}_2024.pdf", "Tag": "Sono-Bild",
                "AnhangLength": 245760, "FsRowGuid": f"guid-{pid}",
                "CreatedPoint": base + dt.timedelta(days=4)})
        else:  # Negationsfall: kein Hinweis auf Zöliakie
            mid += 1
            tables["MedDok"].append({
                "Id": mid, "Id_Patient": pid, "Id_Schein": 5000 + i,
                "ReferenceDateTime": base, "Kuerzel": "B",
                "Detail": FT_XML.format(
                    text="Duodenalbiopsie unauffällig, kein Hinweis auf Zöliakie.")})
        tables["Schein"].append({
            "Id": 5000 + i, "Scheinart": 0, "Scheinuntergruppe": "00",
            "AusstellungsDateTime": base, "ScheinGueltigVon": None, "Quartal": "2024-1",
            "Abrechnungsquartal": "2024-1", "KassenName": "AOK PLUS", "Iknr": "108035576",
            "IsStationaer": False, "UeberweisungVon": None, "UeberweisungAn": None,
            "WeiterbehandelnderArzt": None, "IsZielauftrag": False, "Auftrag": None,
            "DiagnoseVerdacht": None, "BsnrUeberweiser": None, "LanrUeberweiser": None,
            "IsIgel": False, "IsPrivat": False, "RechnungsTyp": None,
            "HzvVertragKennung": None, "HonorarAnlageId": None})
    return tables


class FakeSource:
    """Simuliert agent.dbsource.Source.query() über den Demo-Tabellen."""

    def __init__(self, tables: dict):
        self.tables = tables

    def query(self, sql, params=()):
        s = " ".join(sql.split())
        pid = params[0] if params else None

        def rows(name, key="Id_Patient"):
            return [dict(r) for r in self.tables.get(name, []) if r.get(key) == pid]

        if "FROM dbo.Patient WHERE Id" in s:
            return [dict(r) for r in self.tables["Patient"] if r["Id"] == pid]
        if s.startswith("SELECT Id FROM dbo.Patient"):
            return [{"Id": r["Id"]} for r in self.tables["Patient"]]
        if "SELECT PatientNr FROM dbo.Patient" in s:
            return [{"PatientNr": r["PatientNr"]} for r in self.tables["Patient"]
                    if r["Id"] == pid]
        if "FROM dbo.MedDok m JOIN" in s:
            return rows("MedDok")
        if "FROM dbo.Schein WHERE" in s:
            return rows("Schein")
        if "FROM dbo.Laborbogen" in s:
            return rows("Laborbogen")
        if "FROM dbo.PatientVitalparameterRecord" in s:
            return rows("Vitals")
        if "FROM dbo.VerordnungV2" in s:
            return rows("VerordnungV2")
        if "FROM dbo.Eau" in s:
            return rows("Eau")
        if "FROM dbo.MedDokAnhang" in s:
            return rows("Anhang")
        return []

    def min_active_rowversion(self):
        return b"\x00\x00\x00\x00\x00\x0f\x42\x40"

    def close(self):
        pass


def demo_terminology_provider():
    """Kleines SNOMED-Lexikon passend zu den Demo-Texten (Dokument-Intelligence)."""
    from reference.terminology import LocalCatalogProvider, DictEntry, Concept
    SCT = "http://snomed.info/sct"
    return LocalCatalogProvider([
        DictEntry("Steatosis hepatis", Concept(SCT, "197321007", "Steatosis of liver disorder")),
        DictEntry("Zöliakie", Concept(SCT, "396331005", "Coeliac disease disorder")),
        DictEntry("Cholezystektomie", Concept(SCT, "38102005", "Cholecystectomy procedure")),
        DictEntry("Insulinresistenz", Concept(SCT, "48606007", "Insulin resistance finding")),
    ])


def build_demo_bundles(n_patients: int = 8, secret: str = "demo-secret-0123456789",
                       mode: str = "pseudonymize", privacy_opts: dict | None = None,
                       annotate: bool = False):
    """Liefert [(pid, patient_nr, bundle)] über die echte Export-Kette."""
    import export as E
    from privacy import Privacy
    privacy = Privacy(mode=mode, secret=secret, date_shift=True, **(privacy_opts or {}))
    provider = demo_terminology_provider() if annotate else None
    src = FakeSource(make_tables(n_patients))
    out = []
    for prow in src.tables["Patient"]:
        bundle, _ = E.build_patient_bundle(src, prow["Id"], privacy, with_openehr=False,
                                           annotate_provider=provider)
        out.append((prow["Id"], prow["PatientNr"], bundle))
    return out, privacy
