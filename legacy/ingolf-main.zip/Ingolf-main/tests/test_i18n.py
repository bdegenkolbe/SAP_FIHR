# -*- coding: utf-8 -*-
"""Mehrsprachigkeit: alle Sprachpakete in ui/app/i18n.js müssen dieselben
Schlüssel tragen wie die Referenzsprache Deutsch (fehlende Übersetzungen
fallen sonst still auf Deutsch zurück)."""
import json
import os
import shutil
import subprocess

import pytest

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
I18N = os.path.join(REPO, "ui", "app", "i18n.js")
LANGS = ("de", "en", "fr", "es", "ru")


@pytest.fixture(scope="module")
def packs():
    node = shutil.which("node")
    if not node:
        pytest.skip("node nicht verfügbar")
    out = subprocess.run(
        [node, "-e",
         "global.window={};"
         f"require('fs');eval(require('fs').readFileSync({I18N!r},'utf8'));"
         "console.log(JSON.stringify(window.GB_I18N))"],
        capture_output=True, text=True, timeout=30)
    assert out.returncode == 0, out.stderr
    return json.loads(out.stdout)


def test_alle_sprachen_vorhanden(packs):
    assert set(LANGS) <= set(packs.keys())


def test_schluesselparitaet(packs):
    ref = set(packs["de"].keys())
    assert ref, "Referenzsprache de ist leer"
    for lang in LANGS:
        missing = ref - set(packs[lang].keys())
        extra = set(packs[lang].keys()) - ref
        assert not missing, f"{lang}: fehlende Übersetzungen: {sorted(missing)[:10]}"
        assert not extra, f"{lang}: überzählige Schlüssel: {sorted(extra)[:10]}"


def test_keine_leeren_werte(packs):
    for lang in LANGS:
        empty = [k for k, v in packs[lang].items() if not str(v).strip()]
        assert not empty, f"{lang}: leere Übersetzungen: {empty[:10]}"
