# -*- coding: utf-8 -*-
"""Smoke-Test ohne DB: MedDok-Parser + FHIR-Mapper gegen echte Beispiel-XMLs.

Ausfuehren:  python tests/test_smoke.py   (oder: python -m pytest tests/ -q)
"""
import os, sys, json

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "agent"))

from meddok import parse_detail            # noqa: E402
from privacy import Privacy                # noqa: E402
import mappers as M                        # noqa: E402

LEIST = ('<leistung xmlns:xsd="http://www.w3.org/2001/XMLSchema"><ziffer>32006</ziffer>'
         '<multiplikator>1</multiplikator><nichtabrechenbar>false</nichtabrechenbar>'
         '<idlaborheader>0</idlaborheader></leistung>')
FT_PLAIN = ('<MedDokFreitext><FreitextHtml>&lt;P&gt;Beratung erfolgt&lt;/P&gt;</FreitextHtml>'
            '<FreitextPlain>Beratung erfolgt\n</FreitextPlain></MedDokFreitext>')
FT_HTML = ('<MedDokFreitext><FreitextHtml>&lt;HTML&gt;&lt;BODY&gt;&lt;P&gt;akutes '
           'Nierenversagen, V.a. Prostata-CA&lt;/P&gt;&lt;/BODY&gt;&lt;/HTML&gt;</FreitextHtml>'
           '</MedDokFreitext>')
DIAG = ('<MedDokDiagnose xmlns:xsi="x"><Icd>K76.0</Icd><IcdBeschreibung>Steatosis hepatis'
        '</IcdBeschreibung><Sicherheit>G</Sicherheit></MedDokDiagnose>')


def test_parse_leistung():
    d = parse_detail(LEIST, "L")
    assert d["kind"] == "leistung" and d["ziffer"] == "32006"


def test_parse_freitext_plain_and_html():
    assert parse_detail(FT_PLAIN, "V")["text"] == "Beratung erfolgt"
    assert "Nierenversagen" in parse_detail(FT_HTML, "A")["text"]


def test_parse_diagnose():
    d = parse_detail(DIAG)
    assert d["icd"] == "K76.0" and d["sicherheit"] == "G"


def _ctx():
    priv = Privacy(mode="pseudonymize", secret="testsecret", date_shift=True)
    pid = 3659
    ps = priv.pseudonym(pid)
    return M.ExportContext(pid, ps, "urn:uuid:" + ps, priv), priv, pid


def test_patient_mapper():
    ctx, priv, pid = _ctx()
    prow = {"Id": 3659, "PatientNr": 76824, "Name": "Degenkolbe", "Vorname": "Björn",
            "Geschlecht": 2, "Geburtsjahr": 1976, "Geburtsmonat": 7, "Geburtstag": 24,
            "Strasse": "August-Bebel-Str.", "Hausnummer": "2D", "Postleitzahl": "04416",
            "Wohnort": "Markkleeberg", "Laenderkennzeichen": "D", "IsPrivat": True}
    pat = M.map_patient(ctx, prow)
    assert pat["gender"] == "male"
    assert "name" not in pat and pat["identifier"][0]["system"] == "urn:pseudonym"


def test_schein_produces_encounter_referral_claim():
    ctx, priv, pid = _ctx()
    scheine = [{"Id": 10, "Scheinart": 6, "AusstellungsDateTime": "2026-05-24T07:00:00",
                "Quartal": "2026-04-01", "KassenName": "AOK PLUS", "IsStationaer": False,
                "UeberweisungAn": "Radiologie", "IsZielauftrag": True, "Auftrag": "MRT Abdomen"}]
    leist_by = {10: [{"ziffer": "32006", "multiplikator": "1", "date": "2026-05-24T07:00:00"}]}
    kinds = {e["resource"]["resourceType"] for e in M.map_scheine(ctx, scheine, leist_by)}
    assert {"Encounter", "ServiceRequest", "Claim"} <= kinds


def test_labor_loinc_and_report():
    ctx, priv, pid = _ctx()
    rows = [{"Id": 1, "Id_LaborHeader": 999, "Datum": "2026-05-19T00:00:00", "Kuerzel": "GPT",
             "Grenzwertindikator": "+",
             "Details": json.dumps({"Ergebniswert": "55", "Einheit": "U/l",
                                     "Testbezeichnung": "GPT", "NormalwertText": "< 50"})}]
    out = M.map_labor(ctx, rows)
    kinds = {e["resource"]["resourceType"] for e in out}
    assert {"Observation", "DiagnosticReport"} <= kinds
    obs = next(e for e in out if e["resource"]["resourceType"] == "Observation")["resource"]
    assert obs["code"]["coding"][0]["code"] == "1742-6"   # LOINC GPT


def test_date_shift_consistent():
    ctx, priv, pid = _ctx()
    assert priv.shift(pid, "2026-05-24T07:00:00") == priv.shift(pid, "2026-05-24T07:00:00")


def test_medication_structured_vs_freetext():
    ctx, priv, pid = _ctx()
    rows = [
        {"Id": 1, "Pzn": "18241201", "ItemType": 1, "ReferenceDateTime": "2026-05-24T07:51:31",
         "ReichtBis": None, "AbgesetztDateTime": None, "Artikelname": "MOUNJARO 7.5MG KWIKPEN",
         "AtcCode": "A10BX16", "Bezeichnung": "Tirzepatid"},
        {"Id": 2, "Pzn": "Fa9fd6...", "ItemType": 3, "ReferenceDateTime": "2025-01-08T09:45:18",
         "Artikelname": None, "AtcCode": None, "Bezeichnung": None},  # Freitext ohne Name -> skip
    ]
    out = M.map_medication(ctx, rows)
    assert len(out) == 1
    coding = out[0]["resource"]["medicationCodeableConcept"]["coding"]
    systems = {c["system"] for c in coding}
    assert "http://fhir.de/CodeSystem/ifa/pzn" in systems
    assert "http://fhir.de/CodeSystem/bfarm/atc" in systems


def test_invoice_mapper():
    ctx, priv, pid = _ctx()
    rows = [{"Id": 1, "Id_Schein": 10, "RechnungsnummerPraefix": "R-", "Rechnungsnummer": 2026001,
             "RechnungsDatum": "2026-05-24", "GesamtBetrag": "184.50", "BetragBerechnet": "155.04",
             "Restbetrag": "0", "IsIgel": True, "IsStornoRechnung": False}]
    inv = M.map_invoices(ctx, rows)[0]["resource"]
    assert inv["resourceType"] == "Invoice" and inv["status"] == "balanced"
    assert inv["totalGross"]["currency"] == "EUR" and inv["type"]["text"] == "IGeL"


def test_parse_formular_au():
    xml = ('<meddokformular><formularname>Arbeitsunfähigkeitsbescheinigung</formularname>'
           '<shortinfo>AU (Folgeb.) erstellt, AU bis 08.09.2026, Diagnose(n): F43.0</shortinfo>'
           '</meddokformular>')
    d = parse_detail(xml, "AU")
    assert d["kind"] == "formular" and "08.09.2026" in d["shortinfo"]


def test_au_mapper_extracts_bis_and_icd():
    ctx, priv, pid = _ctx()
    xml = ('<meddokformular><formularname>AU</formularname>'
           '<shortinfo>AU (Folgeb.) erstellt, AU bis 08.09.2026, Diagnose(n): F43.0</shortinfo>'
           '</meddokformular>')
    rows = [{"Id": 1, "Kuerzel": "AU", "ReferenceDateTime": "2026-08-01T09:00:00", "Detail": xml}]
    eau = {1: {"State": 3, "IkNr": "101575519"}}
    res = M.map_au(ctx, rows, eau)[0]["resource"]
    assert res["resourceType"] == "DocumentReference"
    assert res["category"][0]["text"] == "Folgebescheinigung"
    assert res["context"]["period"]["end"] is not None
    assert any("F43.0" in e.get("valueString", "") for e in res.get("extension", []))


def test_arztbrief_composition():
    ctx, priv, pid = _ctx()
    ft = '<MedDokFreitext><FreitextPlain>Sehr geehrte Kollegin, wir berichten...</FreitextPlain></MedDokFreitext>'
    rows = [{"Id": 1, "Kuerzel": "BRIEF", "ReferenceDateTime": "2026-05-24T07:00:00", "Detail": ft}]
    res = M.map_arztbriefe(ctx, rows)[0]["resource"]
    assert res["resourceType"] == "Composition" and res["section"][0]["text"]["status"] == "generated"


def test_reference_labor_katalog():
    import os as _os, sys as _sys
    _sys.path.insert(0, _os.path.join(_os.path.dirname(__file__), "..", "reference"))
    import reference_mappers as R
    rows = [{"Id": 3, "Ident": "Hb", "Bezeichnung": "Hämoglobin", "Einheit": "g/dl",
             "Normwerte": '[{"Geschlecht":"2","NormalwertText":"m: 8.7-10.9"},{"Geschlecht":"1","NormalwertText":"w: 7.6-9.5"}]',
             "IsGnr_Ebm": False, "IsGnr_Goae": False}]
    od = R.map_labor_katalog(rows)[0]
    assert od["resourceType"] == "ObservationDefinition"
    genders = {iv.get("gender") for iv in od["qualifiedInterval"]}
    assert "male" in genders and "female" in genders


def test_coverage_hashes_kvnr():
    ctx, priv, pid = _ctx()
    rows = [{"Id": 1, "ChipkartenEinlesedatum": "2026-01-02", "VersichertenNr": "A955850466",
             "Versichertenart": 1, "IkNr": "107202793", "KassenName": "IKK classic",
             "ChipkarteGueltigBis": "2027-12-31"}]
    res = M.map_coverage_chipkarte(ctx, rows)[0]["resource"]
    assert res["resourceType"] == "Coverage"
    assert res["subscriberId"] and res["subscriberId"] != "A955850466"   # gehasht
    assert res["payor"][0]["identifier"]["value"] == "107202793"


def test_coverage_kvnr_clear_when_off():
    from privacy import Privacy
    priv = Privacy(mode="off")
    ctx = M.ExportContext(7, "7", "Patient/7", priv)
    rows = [{"Id": 1, "ChipkartenEinlesedatum": "2026-01-02", "VersichertenNr": "A955850466",
             "Versichertenart": 1}]
    res = M.map_coverage_chipkarte(ctx, rows)[0]["resource"]
    assert res["subscriberId"] == "A955850466"


def test_todo_to_task():
    ctx, priv, pid = _ctx()
    rows = [{"Id": 5, "Name": "Laborkontrolle", "Status": 1, "Priority": 2,
             "CreatedPoint": "2026-03-01T08:00:00", "DeadlineDateTime": "2026-03-10T00:00:00",
             "Id_MedDok": 42}]
    res = M.map_todos(ctx, rows)[0]["resource"]
    assert res["resourceType"] == "Task" and res["status"] == "in-progress"
    assert res["priority"] == "urgent" and res["restriction"]["period"]["end"]
    assert res["focus"]["reference"].startswith("urn:uuid:")


def test_heilmittel_servicerequest():
    ctx, priv, pid = _ctx()
    rows = [{"Id": 1, "ReferenceDateTime": "2026-02-01T10:00:00", "FirstIcdCode": "M54.5",
             "FirstIcdText": "Kreuzschmerz", "DiagnoseGruppe": "WS", "Therapiefrequenz": "2x/Woche",
             "Hausbesuch": True, "Id_Schein": 99}]
    items = {1: [{"Name": "Krankengymnastik", "Behandlungseinheit": 6, "Priority": 1}]}
    res = M.map_heilmittel(ctx, rows, items)[0]["resource"]
    assert res["resourceType"] == "ServiceRequest"
    assert res["reasonCode"][0]["coding"][0]["code"] == "M54.5"
    assert any("Krankengymnastik" in (d.get("text") or "") for d in res["orderDetail"])


def test_au_from_formularvariablen_structured():
    ctx, priv, pid = _ctx()
    fv_json = ('[{"id":"_Folgebescheinigung","value":true},'
               '{"id":"_ArbeitsunfaehigSeit","value":"2026-08-01T00:00:00"},'
               '{"id":"_VoraussichtlichArbeitsunfaehigBis","value":"2026-08-15T00:00:00"},'
               '{"id":"_IsEau","value":true},'
               '{"id":"_Diagnose","value":{"$values":[{"Icd":"K50.9","Sicherheit":"G"}]}},'
               '{"id":"Patient_Name","value":"GEHEIM"}]')
    fv = {10: M.parse_formularvariablen(fv_json)}
    assert "Patient_Name" not in fv[10]          # PII gefiltert
    rows = [{"Id": 10, "Kuerzel": "AU", "ReferenceDateTime": "2026-08-01T09:00:00", "Detail": ""}]
    res = M.map_au(ctx, rows, {}, fv)[0]["resource"]
    assert res["category"][0]["text"] == "Folgebescheinigung"
    assert res["context"]["period"]["end"]
    assert any("K50.9" in e.get("valueString", "") for e in res.get("extension", []))
    assert any(e.get("url", "").endswith("is-eau") for e in res.get("extension", []))


def test_medikationsplan_list():
    ctx, priv, pid = _ctx()
    plan = [{"Id_Patient": pid, "CreatedPoint": "2026-01-15T09:00:00", "Comment": "Stand Januar"}]
    items = [{"Id": 1, "Id_Verordnung": 555, "MedikationsplanSortIndex": 1},
             {"Id": 2, "Id_MedikationsplanFreitext": 77, "MedikationsplanSortIndex": 2}]
    ft = {77: "Bedarfsmedikation nach Bedarf"}
    res = M.map_medikationsplan(ctx, plan, items, ft)[0]["resource"]
    assert res["resourceType"] == "List" and len(res["entry"]) == 2
    assert res["entry"][0]["item"]["reference"].startswith("urn:uuid:")


def test_bezugsperson_redacts_name_when_pseudonymized():
    ctx, priv, pid = _ctx()
    rows = [{"Id": 1, "Name": "Muster", "Vorname": "Erika", "BeziehungBezugsperson": "Ehefrau"}]
    kontakte = {1: [{"Type": 1, "Data": "0341-123456"}]}
    res = M.map_bezugsperson(ctx, rows, kontakte)[0]["resource"]
    assert res["resourceType"] == "RelatedPerson"
    assert "name" not in res                       # Name entschaerft
    assert res["relationship"][0]["text"] == "Ehefrau"
    assert res["telecom"][0].get("value") is None  # Kontaktwert entfernt


def test_rezept_lines_to_medicationrequests():
    ctx, priv, pid = _ctx()
    rows = [{"Id": 900, "Ausstellungsdatum": "2026-04-01T10:00:00", "Subtype": 2,
             "BtmKennzeichen": 0, "Id_Schein": 12}]
    info = {900: [
        {"Id": 1, "Id_Rezept": 900, "Pzn": "20366364", "IsStrukturiert": True, "IsAutIdem": False,
         "Info": "VANCOMYCIN CAREFARM 125MG HKP 28 St N2 PZN20366364\r\n»1-1-1-1« - 4x tägl.", "Rang": 1},
        {"Id": 2, "Id_Rezept": 900, "Pzn": None, "IsFreitext": True, "IsAutIdem": True,
         "Info": "Individuelle Rezeptur", "Rang": 2}]}
    druck = {1: [{"Id": 5, "Id_RezeptInfo": 1, "Druckzeile": "morgens und abends", "Rang": 1}]}
    diag = {900: [{"Icd": "A04.7", "Beschreibung": "C. difficile"}]}
    res = M.map_rezepte(ctx, rows, info, druck, diag)
    assert len(res) == 2
    r0 = res[0]["resource"]
    assert r0["resourceType"] == "MedicationRequest"
    assert r0["medicationCodeableConcept"]["coding"][0]["code"] == "20366364"
    assert "1-1-1-1" in r0["dosageInstruction"][0]["text"]
    assert "morgens und abends" in r0["dosageInstruction"][0]["text"]
    assert r0["substitution"]["allowedBoolean"] is True   # aut-idem nicht gesetzt -> Substitution erlaubt
    assert r0["reasonCode"][0]["coding"][0]["code"] == "A04.7"
    assert r0["groupIdentifier"]["value"] == "900"
    r1 = res[1]["resource"]
    assert "coding" not in r1["medicationCodeableConcept"]   # Freitext -> keine PZN
    assert r1["substitution"]["allowedBoolean"] is False     # aut-idem gesetzt


def test_medication_reichtbis_abgelaufen_ist_completed():
    """Praxis-Befund: NameError _today (413 Patienten je Voll-Lauf)."""
    ctx, priv, pid = _ctx()
    rows = [{"Id": 9, "Pzn": "123", "ItemType": 1, "ReferenceDateTime": "2020-01-01",
             "ReichtBis": "2020-06-01", "AbgesetztDateTime": None,
             "Artikelname": "ALT-MED", "AtcCode": "A02BC02", "Bezeichnung": "X"}]
    out = M.map_medication(ctx, rows)
    assert out[0]["resource"]["status"] == "completed"


def test_rezeptur_ohne_flags_crasht_nicht():
    """Praxis-Befund: 'NoneType' object has no attribute 'append' —
    extension war explizit None (ext or None) und IsRezeptur haengte an."""
    ctx, priv, pid = _ctx()
    rows = [{"Id": 7, "Ausstellungsdatum": "2026-01-01", "Subtype": 0}]
    info = {7: [{"Id": 1, "Id_Rezept": 7, "IsRezeptur": True, "IsFreitext": True,
                 "Info": "Individuelle Rezeptur", "Rang": 1}]}
    res = M.map_rezepte(ctx, rows, info, {}, {})[0]["resource"]
    urls = [e["url"] for e in res.get("extension", [])]
    assert any(u.endswith("/rezeptur") for u in urls)


def test_schein_abrechnungsart():
    """Gutachten 1.1: Schein.IsPrivat existiert nicht -> AbrechnungsArt
    (1=GKV, 2=Privat/IGeL, 3=BG/Unfall)."""
    ctx, priv, pid = _ctx()
    leist = {1: [{"ziffer": "1", "multiplikator": 1, "date": "2024-01-01"}],
             2: [{"ziffer": "1", "multiplikator": 1, "date": "2024-01-01"}],
             3: [{"ziffer": "1", "multiplikator": 1, "date": "2024-01-01"}],
             4: [{"ziffer": "1", "multiplikator": 1, "date": "2024-01-01"}]}
    scheine = [
        {"Id": 1, "Scheinart": 1, "AbrechnungsArt": 1, "AusstellungsDateTime": "2024-01-01"},
        {"Id": 2, "Scheinart": 10, "AbrechnungsArt": 2, "IsIgel": 0, "AusstellungsDateTime": "2024-01-01"},
        {"Id": 3, "Scheinart": 10, "AbrechnungsArt": 2, "IsIgel": 1, "AusstellungsDateTime": "2024-01-01"},
        {"Id": 4, "Scheinart": 20, "AbrechnungsArt": 3, "AusstellungsDateTime": "2024-01-01"},
    ]
    claims = [e["resource"] for e in M.map_scheine(ctx, scheine, leist)
              if e["resource"]["resourceType"] == "Claim"]
    subtypes = [c["subType"]["coding"][0]["code"] for c in claims]
    assert subtypes == ["GKV", "Privat", "IGeL", "BG/Unfall"]


def test_medication_itemtypes_und_dosierung():
    """Gutachten 2.2/4.1: ItemType 1-4, Freitext-Details aus VerordnungFreitext,
    Dosierschema aus MedikamentDosierungV2 (PZN kein Trennmerkmal mehr)."""
    ctx, priv, pid = _ctx()
    rows = [
        {"Id": 1, "Pzn": "111", "ItemType": 1, "Id_Medikament": 5,
         "ReferenceDateTime": "2026-01-01", "Artikelname": "MOUNJARO",
         "AtcCode": "A10BX16", "Bezeichnung": "Tirzepatid"},
        {"Id": 2, "Pzn": "222", "ItemType": 2, "Id_Medikament": None,
         "ReferenceDateTime": "2026-01-02", "Artikelname": None},
        {"Id": 3, "Pzn": "333", "ItemType": 3, "Id_Medikament": None,
         "ReferenceDateTime": "2026-01-03", "Artikelname": None},
    ]
    ft = {2: {"Id_Verordnung": 2, "Artikelname": "Individuelle Salbenrezeptur",
              "Darreichungsform": "Salbe", "Type": 2},
          3: {"Id_Verordnung": 3, "Artikelname": "Kompressionsstruempfe", "Type": 3}}
    dos = {1: [{"Id_Verordnung": 1, "Morgens": 1, "Mittags": 0, "Abends": 1,
                "Nachts": 0, "Dosiereinheit": "Tbl.", "Behandlungsgrund": "Diabetes"}]}
    out = M.map_medication(ctx, rows, dos, ft)
    assert len(out) == 3
    r1, r2, r3 = (e["resource"] for e in out)
    assert r1["category"]["text"] == "Fertigarzneimittel"
    assert r1["dosage"][0]["text"] == "1-0-1-0 Tbl."
    assert r1["reasonCode"][0]["text"] == "Diabetes"
    assert r2["medicationCodeableConcept"]["text"] == "Individuelle Salbenrezeptur"
    assert "coding" not in r2["medicationCodeableConcept"]     # Pzn 222 ist kein echter Code
    assert r2["category"]["text"] == "Rezeptur"
    assert any(e["url"].endswith("/darreichungsform")
               for e in r2.get("extension", []))
    assert r3["medicationCodeableConcept"]["text"] == "Kompressionsstruempfe"


def test_blutdruck_paarung():
    """Gutachten 2.3: Vitalparameter 5/6 am selben Record -> EIN Observation
    mit sys/dia-Komponenten (LOINC 85354-9); andere Werte bleiben einzeln."""
    ctx, priv, pid = _ctx()
    rows = [
        {"Id": 1, "RecordId": 10, "Id_Vitalparameter": 5, "Value": "134",
         "Name": "RR sys", "Masseinheit": "mmHg", "Datum": "2026-01-01"},
        {"Id": 2, "RecordId": 10, "Id_Vitalparameter": 6, "Value": "80",
         "Name": "RR dia", "Masseinheit": "mmHg", "Datum": "2026-01-01"},
        {"Id": 3, "RecordId": 10, "Id_Vitalparameter": 2, "Value": "72",
         "Name": "Puls", "Masseinheit": "1/min", "Datum": "2026-01-01"},
    ]
    out = [e["resource"] for e in M.map_vitals(ctx, rows)]
    bp = [r for r in out if r.get("component")]
    assert len(bp) == 1 and len(out) == 2                     # RR-Panel + Puls
    vals = {c["code"]["coding"][0]["code"]: c["valueQuantity"]["value"]
            for c in bp[0]["component"]}
    assert vals == {"8480-6": 134.0, "8462-4": 80.0}


def test_labor_ergebnistext_fallback():
    """Gutachten 3.1: qualitative Befunde (nur ErgebnisText) nicht verwerfen."""
    import json as _json
    ctx, priv, pid = _ctx()
    rows = [{"Id": 1, "Id_LaborHeader": 9, "Datum": "2026-01-01", "Kuerzel": "HBsAG",
             "Details": _json.dumps({"Testbezeichnung": "HBs-Antigen",
                                     "ErgebnisText": "negativ"})}]
    out = [e["resource"] for e in M.map_labor(ctx, rows)
           if e["resource"]["resourceType"] == "Observation"]
    assert out and out[0]["valueString"] == "negativ"


def test_eau_state_klartext():
    """Gutachten 2.1: Eau.State-Enum -> lesbarer Status."""
    ctx, priv, pid = _ctx()
    rows = [{"Id": 77, "Kuerzel": "AU", "ReferenceDateTime": "2026-01-01",
             "Detail": "<meddokformular><formularname>AU</formularname></meddokformular>"}]
    out = M.map_au(ctx, rows, {77: {"State": 7, "IkNr": None}})
    ext = out[0]["resource"].get("extension", [])
    status = [e["valueString"] for e in ext if e["url"].endswith("/eau-status")]
    assert status == ["abgeschlossen"]


def test_chronische_erkrankung():
    ctx, priv, pid = _ctx()
    rows = [{"Id": 1, "Icd": "K76.0", "Status": 1},
            {"Id": 2, "Icd": "E11.9", "Status": "0"}]
    out = [e["resource"] for e in M.map_chronische(ctx, rows)]
    assert out[0]["clinicalStatus"]["coding"][0]["code"] == "active"
    assert out[1]["clinicalStatus"]["coding"][0]["code"] == "inactive"
    assert out[0]["category"][0]["text"] == "Chronische Erkrankung"


def _fake_docx(paragraph_text="", table_cells=(), header_text="", footer_text=""):
    """Minimal-DOCX (ZIP + document.xml); Inhalt optional nur in Tabellenzellen
    (medatixx-Formularvorlagen: doc.paragraphs waere leer) und/oder in
    Kopf-/Fusszeilen (Rechnungen: Absender/Adresse, Gutachten 4c.3)."""
    import io as _io
    import zipfile as _zip
    w = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    para = lambda txt: f'<w:p><w:r><w:t>{txt}</w:t></w:r></w:p>'
    body = ""
    if paragraph_text:
        body += para(paragraph_text)
    if table_cells:
        cells = "".join(f'<w:tc>{para(c)}</w:tc>' for c in table_cells)
        body += f'<w:tbl><w:tr>{cells}</w:tr></w:tbl>'
    xml = (f'<?xml version="1.0"?><w:document xmlns:w="{w}"><w:body>{body}'
           f'</w:body></w:document>')
    buf = _io.BytesIO()
    with _zip.ZipFile(buf, "w") as z:
        z.writestr("[Content_Types].xml", "<Types/>")
        z.writestr("word/document.xml", xml)
        if header_text:
            z.writestr("word/header1.xml",
                       f'<?xml version="1.0"?><w:hdr xmlns:w="{w}">{para(header_text)}</w:hdr>')
        if footer_text:
            z.writestr("word/footer1.xml",
                       f'<?xml version="1.0"?><w:ftr xmlns:w="{w}">{para(footer_text)}</w:ftr>')
    return buf.getvalue()


def test_docx_text_erfasst_tabellenzellen():
    """DOCX-Addendum: medatixx-Briefe sind tabellenbasiert - ein Extraktor,
    der nur Absaetze liest, hielte sie fuer leer."""
    from dokumente import docx_text, is_docx
    raw = _fake_docx(table_cells=("Diagnose:", "K76.0 Fettleber", "Befund unauffaellig"))
    assert is_docx(raw)
    text = docx_text(raw)
    assert "K76.0 Fettleber" in text and "Befund unauffaellig" in text
    assert docx_text(b"kein zip") is None


def test_docx_text_erfasst_kopf_und_fusszeilen():
    """Gutachten 4c.3 (rev.): Rechnungen tragen Absender/Adresse in Kopf-/
    Fusszeilen - ein Body-only-Extraktor verliert sie."""
    from dokumente import docx_text
    raw = _fake_docx(paragraph_text="Rechnungsbetrag 120,00 EUR",
                     header_text="Praxis Dr. Beispiel, Musterweg 1",
                     footer_text="Bankverbindung IBAN DE00")
    text = docx_text(raw)
    assert "Praxis Dr. Beispiel" in text
    assert "Rechnungsbetrag" in text
    assert "IBAN DE00" in text
    # Reihenfolge: Kopf -> Body -> Fuss
    assert text.index("Praxis") < text.index("Rechnungsbetrag") < text.index("IBAN")


def test_anhang_volltext_extrahiert():
    """Eingebetteter DOCX-Anhang bekommt ein durchsuchbares text/plain-Attachment."""
    import base64 as _b64
    ctx, priv, pid = _ctx()
    raw = _fake_docx(table_cells=("Arztbrief", "Gastroskopie ohne Befund"))
    rows = [{"Id": 5, "Id_MedDok": 9, "FileName": "brief.docx",
             "AnhangLength": len(raw), "AnhangData": raw,
             "CreatedPoint": "2026-01-01"}]
    res = M.map_anhaenge(ctx, rows, embed=True)[0]["resource"]
    texts = [a["attachment"] for a in res["content"]
             if a["attachment"].get("contentType") == "text/plain"]
    assert texts, "Volltext-Attachment fehlt"
    decoded = _b64.b64decode(texts[0]["data"]).decode("utf-8")
    assert "Gastroskopie" in decoded


def test_medikationsplan_referenziert_med():
    """List-Eintraege muessen auf uid('med', ...) zeigen (medstmt war Leere)."""
    ctx, priv, pid = _ctx()
    items = [{"Id": 1, "Id_Verordnung": 42, "MedikationsplanSortIndex": 1}]
    out = M.map_medikationsplan(ctx, [{"Id_Patient": pid}], items, {})
    ref = out[0]["resource"]["entry"][0]["item"]["reference"]
    assert ref == ctx.uid("med", 42)


def test_rezept_without_lines_fallback():
    ctx, priv, pid = _ctx()
    rows = [{"Id": 5, "Ausstellungsdatum": "2026-04-01T10:00:00", "Subtype": 3, "IsHilfsmittel": False}]
    res = M.map_rezepte(ctx, rows)[0]["resource"]
    assert res["resourceType"] == "MedicationRequest"
    assert res["medicationCodeableConcept"]["text"] == "BTM"


def test_anhang_metadata_only_by_default():
    ctx, priv, pid = _ctx()
    rows = [{"Id": 1, "Id_MedDok": 42, "FileName": "befund.pdf", "Tag": "Befund",
             "AnhangLength": 12345, "FsRowGuid": "abc-123", "CreatedPoint": "2026-03-01T09:00:00",
             "AnhangData": b"%PDF-1.4 binary"}]
    res = M.map_anhaenge(ctx, rows, embed=False)[0]["resource"]
    att = res["content"][0]["attachment"]
    assert att["contentType"] == "application/pdf" and att["size"] == 12345
    assert "data" not in att and att["url"].startswith("meddok-anhang:")


def test_anhang_embed_base64():
    ctx, priv, pid = _ctx()
    rows = [{"Id": 1, "Id_MedDok": 42, "FileName": "x.png", "AnhangLength": 3,
             "AnhangData": b"abc", "CreatedPoint": "2026-03-01T09:00:00"}]
    res = M.map_anhaenge(ctx, rows, embed=True)[0]["resource"]
    att = res["content"][0]["attachment"]
    assert att["data"] == "YWJj" and att["contentType"] == "image/png"


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    ok = 0
    for fn in fns:
        fn(); ok += 1; print("PASS", fn.__name__)
    print(f"\n{ok}/{len(fns)} Tests bestanden.")
