# -*- coding: utf-8 -*-
"""Tests: stille Ersteinrichtung (installer/first_run.py) — keine Konsolenfragen,
Basis für die Browser-Einrichtung (Owner via /api/setup, Quelle via Einstellungen)."""
import os
import subprocess
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

FIRST_RUN = os.path.join(os.path.dirname(__file__), "..", "installer", "first_run.py")


def test_stiller_bootstrap_ohne_eingaben(tmp_path):
    """Läuft ohne stdin durch (< /dev/null) und legt Secret, Store und Config an."""
    result = subprocess.run(
        [sys.executable, FIRST_RUN, "--appdir", str(tmp_path)],
        stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=120)
    assert result.returncode == 0, result.stdout + result.stderr
    assert (tmp_path / "secret" / "master.bin").exists()
    assert (tmp_path / "data" / "clinical.db").exists()
    assert (tmp_path / "config" / "config.yaml").exists()
    assert "im Browser" in result.stdout

    # Store ist nutzbar: Rollen geseedet, noch kein Benutzer -> Browser-Setup nötig
    from store.db import open_store
    conn = open_store(tmp_path / "data" / "clinical.db")
    assert conn.execute("SELECT COUNT(*) AS n FROM sec_role").fetchone()["n"] >= 7
    assert conn.execute("SELECT COUNT(*) AS n FROM sec_app_user").fetchone()["n"] == 0
    conn.close()


def test_idempotent_und_secret_bleibt(tmp_path):
    """Zweiter Lauf ändert weder Secret noch Config (App-Update-Szenario)."""
    for _ in range(2):
        result = subprocess.run(
            [sys.executable, FIRST_RUN, "--appdir", str(tmp_path)],
            stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=120)
        assert result.returncode == 0, result.stdout + result.stderr
        if "secret_v1" not in dir():
            secret_v1 = (tmp_path / "secret" / "master.bin").read_bytes()
    assert (tmp_path / "secret" / "master.bin").read_bytes() == secret_v1
    assert "bleibt unveraendert" in result.stdout


def test_web_setup_funktioniert_auf_bootstrap_basis(tmp_path):
    """Nach dem stillen Bootstrap: Owner-Anlage über die Browser-Maske (/api/setup)."""
    subprocess.run([sys.executable, FIRST_RUN, "--appdir", str(tmp_path)],
                   stdin=subprocess.DEVNULL, capture_output=True, timeout=120)
    # Dasselbe Secret laden, das der Bootstrap abgelegt hat (Dev: DEV-Präfix)
    blob = (tmp_path / "secret" / "master.bin").read_bytes()
    assert blob.startswith(b"DEV\x00")
    master = blob[4:]
    from fastapi.testclient import TestClient
    from server.runtime import Runtime, set_runtime
    from server.main import app
    set_runtime(Runtime(db_path=tmp_path / "data" / "clinical.db", master=master))
    client = TestClient(app)
    assert client.get("/api/status").json()["setup_required"] is True
    r = client.post("/api/setup", json={"username": "owner",
                                        "password": "browser-setup-passwort"})
    assert r.status_code == 200 and r.json()["totp_uri"].startswith("otpauth://")
