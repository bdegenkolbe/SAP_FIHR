# -*- coding: utf-8 -*-
"""PVS-Tests ohne Quell-DB: Kernel, Fall, KVDT-Encoder, GOAe, Golden-Validator."""
import os, sys, tempfile
from decimal import Decimal

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from pvs.model.events import Event
from pvs.model.fall import build_fall, derive_fall_art, quartal_norm, fall_to_fhir
from pvs.store.kernelstore import KernelStore
from pvs.kvdt.encoder import encode_field, encode_satz, parse
from pvs.kvdt.serializer import serialize_quartal
from pvs.goae.goae import GoaePosition, GoaeRechnung, naechste_rechnungsnr, padx_paket


def _store():
    return KernelStore(os.path.join(tempfile.mkdtemp(), "pvs.db"))


# --- Kernel ------------------------------------------------------------------
def test_event_idempotenz_und_supersedes():
    st = _store()
    ev = Event(occurred_at="2026-05-24T07:52:00", patient_id="76824",
               event_type="diagnose.dokumentiert", resource_type="Condition",
               resource_id="cond-eug-1",
               payload={"resourceType": "Condition", "code": {"text": "I10.9-"}},
               source="migration:eugastro", source_ref="urn:uuid:abc")
    assert st.append_event(ev) == "inserted"
    ev2 = Event(**{**ev.__dict__, "event_id": None})  # gleicher Inhalt
    ev2 = Event(occurred_at=ev.occurred_at, patient_id=ev.patient_id,
                event_type=ev.event_type, resource_type=ev.resource_type,
                resource_id=ev.resource_id, payload=ev.payload,
                source=ev.source, source_ref="urn:uuid:abc")
    assert st.append_event(ev2) == "unchanged"
    ev3 = Event(occurred_at=ev.occurred_at, patient_id=ev.patient_id,
                event_type=ev.event_type, resource_type=ev.resource_type,
                resource_id=ev.resource_id,
                payload={"resourceType": "Condition", "code": {"text": "I10.90"}},
                source=ev.source, source_ref="urn:uuid:abc")
    assert st.append_event(ev3) == "superseded"
    res = st.current("76824", "Condition")
    assert len(res) == 1 and res[0]["code"]["text"] == "I10.90"


def test_timeline_reihenfolge():
    st = _store()
    for i, t in enumerate(["2026-02-05", "2026-05-24", "2026-07-14"]):
        st.append_event(Event(occurred_at=t, patient_id="p", 
                              event_type="notiz.erfasst",
                              resource_type="Communication",
                              resource_id=f"n{i}", payload={"i": i},
                              source="ui", source_ref=f"n:{i}"))
    tl = st.timeline("p")
    assert [r["occurred_at"] for r in tl] == ["2026-02-05", "2026-05-24", "2026-07-14"]


def test_timeline_zeigt_nur_kettenkopf():
    st = _store()
    e = Event(occurred_at="2026-01-01", patient_id="p",
              event_type="notiz.erfasst", resource_type="Communication",
              resource_id="n1", payload={"v": 1}, source="ui", source_ref="n:1")
    st.append_event(e)
    e2 = Event(occurred_at="2026-01-01", patient_id="p",
               event_type="notiz.erfasst", resource_type="Communication",
               resource_id="n1", payload={"v": 2}, source="ui", source_ref="n:1")
    assert st.append_event(e2) == "superseded"
    tl = st.timeline("p")
    assert len(tl) == 1 and '"v":2' in tl[0]["payload"]


# --- Fall ---------------------------------------------------------------------
SCHEIN_76824 = {"Id": 555, "Scheinart": 4, "Scheinuntergruppe": "00",
                "AusstellungsDateTime": "2026-05-24T07:50:00",
                "Quartal": "22026", "Abrechnungsquartal": None,
                "KassenName": "Barmenia", "Iknr": None,
                "IsPrivat": 1, "IsIgel": 0, "RechnungsTyp": 1}


def test_fall_art_und_quartal():
    assert derive_fall_art(SCHEIN_76824) == "PRIVAT"
    assert quartal_norm(SCHEIN_76824) == "2/2026"
    assert quartal_norm({"Quartal": "20262"}) == "2/2026"   # JJJJQ (K4)
    assert quartal_norm({"Quartal": "42025"}) == "4/2025"   # QJJJJ
    assert quartal_norm({"Quartal": "3/2026"}) == "3/2026"
    assert derive_fall_art({"IsIgel": 1}) == "IGEL"
    assert derive_fall_art({"HzvVertragKennung": "X"}) == "HZV"
    assert derive_fall_art({"BsnrUeberweiser": "123"}) == "UEBERWEISUNG"
    assert derive_fall_art({}) == "KURATIV"


def test_fall_aggregat_und_fhir():
    f = build_fall("76824", SCHEIN_76824, behandler_kuerzel="IS")
    assert f["fall_art"] == "PRIVAT" and f["privat"]["versicherung"] == "Barmenia"
    st = _store()
    st.upsert_fall(f)
    st.upsert_fall(f)  # idempotent ueber source_ref
    got = st.faelle("76824", "2/2026")
    assert len(got) == 1 and got[0]["behandler"][0]["kuerzel"] == "IS"
    fhir = fall_to_fhir(f)
    types = {r["resourceType"] for r in fhir}
    assert types == {"Encounter", "Account", "Coverage"}
    cov = [r for r in fhir if r["resourceType"] == "Coverage"][0]
    assert cov["type"]["coding"][0]["code"] == "PKV"


# --- KVDT ----------------------------------------------------------------------
def test_xdt_encoder_roundtrip():
    line = encode_field("8000", "0101")
    assert line == "0138000" + "0101" + "\r\n"
    satz = encode_satz([("8000", "0101"), ("3000", "76824"), ("6001", "I10.9-")])
    fields = parse(satz)
    assert fields == [("8000", "0101"), ("3000", "76824"), ("6001", "I10.9-")]


def test_kvdt_privat_wird_uebersprungen():
    fall = build_fall("76824", SCHEIN_76824)
    out, stats = serialize_quartal(
        [fall], {"76824": {}}, bs={"bsnr": "123456789", "name": "MVZ eugastro"},
        paket={"laufende_nr": "001", "kvdt_version": "T", "empfaenger_kv": "72"})
    assert stats == {"faelle": 0, "uebersprungen_privat": 1}
    assert "0101" not in [f for f, _ in parse(out) if f == "8000"] or True
    satzarten = [v for f, v in parse(out) if f == "8000"]
    assert satzarten == ["con0", "besa", "adt0", "adt9", "con9"]


def test_kvdt_gkv_fall():
    schein = {"Id": 7, "Scheinuntergruppe": "00", "Quartal": "22026",
              "AusstellungsDateTime": "2026-05-02T09:00:00",
              "KassenName": "AOK", "Iknr": "108018007"}
    fall = build_fall("42", schein)
    fall["leistungen"] = [{"datum": "02052026", "gnr": "03000",
                           "bsnr": "123456789", "lanr": "999999900"}]
    fall["diagnosen_kvdt"] = [{"icd": "I10.9-", "sicherheit": "G"}]
    pat = {"42": {"patient_nr": "42", "name": "Test", "vorname": "GKV",
                  "geburtsdatum": "01011980", "geschlecht": "M"}}
    out, stats = serialize_quartal(
        [fall], pat, bs={"bsnr": "123456789", "name": "MVZ"},
        paket={"laufende_nr": "001", "kvdt_version": "T", "empfaenger_kv": "72"})
    assert stats["faelle"] == 1
    fields = dict(parse(out))
    assert fields["4101"] == "20262" and fields["6001"] == "I10.9-"
    assert fields["5001"] == "03000"


# --- GOAe ------------------------------------------------------------------------
def test_goae_faktor_schwelle():
    ok = GoaePosition("1", "Beratung", "2026-07-14", punktzahl=80,
                      faktor=Decimal("2.3"))
    assert ok.betrag > 0
    try:
        GoaePosition("1", "Beratung", "2026-07-14", punktzahl=80,
                     faktor=Decimal("3.5"))
        assert False, "Begruendungspflicht nicht erzwungen"
    except ValueError:
        pass
    mit = GoaePosition("1", "Beratung", "2026-07-14", punktzahl=80,
                       faktor=Decimal("3.5"), begruendung="erhoehter Aufwand")
    assert mit.betrag > ok.betrag


def test_goae_rechnung_und_padx():
    r = GoaeRechnung(rechnungsnr="EUG2026-00001", datum="2026-07-14",
                     patient={"name": "M", "vorname": "B", "geburtsdatum": "1976-07-24"},
                     behandler={"name": "IS"},
                     positionen=[GoaePosition("1", "Beratung", "2026-07-14", 80)])
    assert r.gesamt == r.positionen[0].betrag
    pkg = padx_paket([r], "K1")
    import io, zipfile
    names = zipfile.ZipFile(io.BytesIO(pkg)).namelist()
    assert any(n.endswith("auftrag.pad") for n in names)
    assert "rechnung_EUG2026-00001.xml" in names
    assert naechste_rechnungsnr("EUG2026-00007", "EUG", 2026) == "EUG2026-00008"


# --- Golden-Validator (Mechanik, mit synthetischem Teilbestand) -------------------
def test_golden_validator_mechanik():
    from pvs.etl.validate_golden import validate, GOLDEN_76824
    st = _store()
    pid = "76824"
    st.append_event(Event(
        occurred_at="2026-05-24T07:52:00", patient_id=pid,
        event_type="diagnose.dokumentiert", resource_type="Condition",
        resource_id="c1", source="t", source_ref="c:1",
        payload={"resourceType": "Condition",
                 "code": {"coding": [{"code": "I10.9-"}]},
                 "note": [{"text": "Diagnosesicherheit (KBV): G"}]}))
    rep = validate(st, pid)
    d = dict((n, ok) for n, ok, _ in rep.checks)
    assert d["Diagnose I10.9- (G)"] is True
    assert d["Diagnose K76.0 (G)"] is False        # fehlt bewusst
    assert rep.ok is False                          # unvollstaendiger Bestand faellt durch


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn(); print(f"PASS {name}")
            except AssertionError as e:
                fails += 1; print(f"FAIL {name}: {e}")
    raise SystemExit(fails)
