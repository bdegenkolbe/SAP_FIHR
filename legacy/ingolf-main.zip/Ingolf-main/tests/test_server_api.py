# -*- coding: utf-8 -*-
"""End-to-End-Tests der Analyse-API: Setup -> Login -> Patienten -> 360° ->
Break-Glass -> Kohorten (Aggregatschutz) -> Verwaltung -> Einstellungen."""
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from fastapi.testclient import TestClient  # noqa: E402

from server import auth  # noqa: E402
from server.main import app  # noqa: E402
from server.runtime import Runtime, set_runtime  # noqa: E402
from store.load import load_bundle  # noqa: E402
from store.vault import store_mapping  # noqa: E402
from tests.util_demo import build_demo_bundles  # noqa: E402

MASTER = b"master-secret-fuer-tests-0123456789abcdef"
PW = "sehr-langes-owner-passwort"


@pytest.fixture
def client(tmp_path):
    rt = Runtime(db_path=tmp_path / "clinical.db", master=MASTER)
    set_runtime(rt)
    # Demo-Daten laden (8 Patienten, 4 davon Fettleber-Kohorte)
    bundles, privacy = build_demo_bundles(8, secret=MASTER.decode())
    for pid, nr, bundle in bundles:
        load_bundle(rt.conn, bundle)
        store_mapping(rt.conn, MASTER, bundle["id"].replace("export-", ""), pid, nr,
                      privacy._shift_days(pid))
    return TestClient(app)


def _owner(client) -> tuple[dict, dict]:
    r = client.post("/api/setup", json={"username": "owner", "full_name": "Praxis",
                                        "password": PW})
    assert r.status_code == 200, r.text
    setup = r.json()
    r = client.post("/api/login", json={"username": "owner", "password": PW,
                                        "totp": auth.totp_code(setup["totp_secret"])})
    assert r.status_code == 200, r.text
    return setup, r.json()


def _auth(session):
    return {"Authorization": "Bearer " + session["token"]}


class TestSetupUndLogin:
    def test_setup_once(self, client):
        assert client.get("/api/status").json()["setup_required"] is True
        _owner(client)
        assert client.get("/api/status").json()["setup_required"] is False
        r = client.post("/api/setup", json={"username": "x", "password": "p" * 12})
        assert r.status_code == 409

    def test_login_wrong_password(self, client):
        _owner(client)
        r = client.post("/api/login", json={"username": "owner", "password": "falsch"})
        assert r.status_code == 401

    def test_unauthenticated_rejected(self, client):
        assert client.get("/api/patients").status_code == 401


class TestPatienten:
    def test_search_and_360(self, client):
        _, session = _owner(client)
        r = client.get("/api/patients", headers=_auth(session))
        assert r.status_code == 200
        body = r.json()
        assert body["total"] == 8
        psn = body["items"][0]["pseudonym"]
        r = client.get(f"/api/patients/{psn}", headers=_auth(session))
        assert r.status_code == 200
        d = r.json()
        assert d["kpis"] and "timeline" in d and "lab_series" in d

    def test_360_vertraegt_kaputte_ressourcen(self, client):
        """Echte Quelldaten liefern code:null, leere coding-Listen, period:null
        usw. - die 360°-Sicht darf daran nicht mit 500 scheitern (Praxis-PC)."""
        _, session = _owner(client)
        from server.runtime import get_runtime
        import json as _json
        rt = get_runtime()
        psn = client.get("/api/patients", headers=_auth(session)
                         ).json()["items"][0]["pseudonym"]
        kaputt = [
            {"resourceType": "Condition", "id": "c-null", "code": None,
             "recordedDate": "2022-01-01"},
            {"resourceType": "Condition", "id": "c-leer",
             "code": {"coding": []}, "recordedDate": "2022-01-02"},
            {"resourceType": "Observation", "id": "o-kaputt", "status": "final",
             "category": [{"coding": []}], "code": {"text": "?"},
             "interpretation": [], "effectiveDateTime": "2022-01-03"},
            {"resourceType": "Observation", "id": "o-lab-ohne-wert", "status": "final",
             "category": [{"coding": [{"code": "laboratory"}]}],
             "code": {"coding": [{"code": "XX"}]}, "referenceRange": [],
             "effectiveDateTime": "2022-01-04"},
            {"resourceType": "Encounter", "id": "e-period-null", "period": None},
            # 'list' object has no attribute 'get' (Praxis-PC): code/type als Liste
            {"resourceType": "Condition", "id": "c-code-liste",
             "code": ["I10.90"], "recordedDate": "2022-01-05"},
            {"resourceType": "Observation", "id": "o-code-liste", "status": "final",
             "category": [{"coding": [{"code": "laboratory"}]}],
             "code": ["XX"], "valueQuantity": ["kaputt"],
             "effectiveDateTime": "2022-01-06"},
            {"resourceType": "DocumentReference", "id": "d-type-liste",
             "type": ["Brief"], "date": "2022-01-07"},
        ]
        for res in kaputt:
            rt.conn.execute(
                "INSERT INTO fhir_resource (id, resource_type, pseudonym, content,"
                " status) VALUES (?,?,?,?, 'active')",
                (res["id"], res["resourceType"], psn, _json.dumps(res)))
        rt.conn.commit()
        r = client.get(f"/api/patients/{psn}", headers=_auth(session))
        assert r.status_code == 200, r.text
        d = r.json()
        assert any(e["id"] == "c-null" for e in d["timeline"])   # taucht dennoch auf

    def test_klardaten_name_wird_angezeigt(self, client):
        """Datenmodus off: Patient-Ressource traegt den Namen -> Suche und
        360-Grad liefern ihn (die UI zeigte sonst nur Nummern, was faelschlich
        wie Pseudonymisierung aussah)."""
        import json as _json
        _, session = _owner(client)
        from server.runtime import get_runtime
        rt = get_runtime()
        rt.conn.execute(
            "INSERT INTO fhir_resource (id, resource_type, pseudonym, content, status)"
            " VALUES ('9001','Patient','9001',?, 'active')",
            (_json.dumps({"resourceType": "Patient", "id": "9001",
                          "name": [{"family": "Degenkolbe", "given": ["Björn"]}],
                          "gender": "male", "birthDate": "1976-07-24"}),))
        rt.conn.commit()
        r = client.get("/api/patients?q=9001", headers=_auth(session)).json()
        me = next(i for i in r["items"] if i["pseudonym"] == "9001")
        assert me["name"] == "Degenkolbe, Björn"
        d = client.get("/api/patients/9001", headers=_auth(session)).json()
        assert d["name"] == "Degenkolbe, Björn"
        # Pseudonymisierte Patienten (Demo-Daten) haben keinen Namen
        other = client.get("/api/patients", headers=_auth(session)).json()["items"][0]
        if other["pseudonym"] != "9001":
            assert other["name"] is None

    def test_icd_filter(self, client):
        _, session = _owner(client)
        r = client.get("/api/patients?icd=K76", headers=_auth(session))
        assert r.json()["total"] == 4  # nur die Fettleber-Kohorte

    def test_break_glass_flow(self, client):
        setup, session = _owner(client)
        psn = client.get("/api/patients?icd=K76",
                         headers=_auth(session)).json()["items"][0]["pseudonym"]
        # ohne Begründung -> 422
        r = client.post(f"/api/patients/{psn}/reid", headers=_auth(session),
                        json={"password": PW, "totp": auth.totp_code(setup["totp_secret"])})
        assert r.status_code == 422
        # mit Re-Auth + Begründung -> Klardaten + Audit
        r = client.post(f"/api/patients/{psn}/reid", headers=_auth(session),
                        json={"password": PW, "totp": auth.totp_code(setup["totp_secret"]),
                              "reason": "Behandlungsanlass: Befundklärung"})
        assert r.status_code == 200, r.text
        assert r.json()["source_id"].isdigit()
        log = client.get("/api/admin/audit", headers=_auth(session)).json()
        assert log["chain_valid"] is True
        assert any(e["action"] == "reid.request" and e["success"] for e in log["events"])

    def test_break_glass_wrong_reauth(self, client):
        _, session = _owner(client)
        psn = client.get("/api/patients", headers=_auth(session)).json()["items"][0]["pseudonym"]
        r = client.post(f"/api/patients/{psn}/reid", headers=_auth(session),
                        json={"password": "falsch", "totp": "000000",
                              "reason": "Behandlungsanlass: Befundklärung"})
        assert r.status_code == 401


class TestAnalyse:
    def test_icd_praefix_findet_untercodes(self, client):
        """'I10' als Kriterium muss I10.90 finden (Praefix-Suche, Praxis-Frage)."""
        _, session = _owner(client)
        from server.runtime import get_runtime
        import json as _json
        rt = get_runtime()
        psn = client.get("/api/patients", headers=_auth(session)
                         ).json()["items"][0]["pseudonym"]
        rt.conn.execute(
            "INSERT INTO fhir_resource (id, resource_type, pseudonym, content, status)"
            " VALUES ('c-i1090','Condition',?,?, 'active')",
            (psn, _json.dumps({"resourceType": "Condition", "id": "c-i1090",
                               "code": {"coding": [{"code": "I10.90"}]},
                               "recordedDate": "2023-05-01"})))
        rt.conn.commit()
        for such in ("I10", "i10", "I10.90"):
            r = client.post("/api/analysis/cohort", headers=_auth(session),
                            json={"op": "AND",
                                  "criteria": [{"type": "icd", "code": such}]})
            assert r.status_code == 200, r.text
            assert r.json()["size"] >= 1, f"'{such}' fand I10.90 nicht"

    def test_grosse_kohorte_ueber_variablenlimit(self, client):
        """Grosse Kohorte (I10 ueber die ganze Praxis) sprengte die IN-Liste:
        ein SQL-Platzhalter je Patient -> 'too many SQL variables' -> 500.
        Jetzt json_each mit EINEM Parameter; Quartalslogik vertraegt zudem
        Jahres-Datumswerte aus echten Daten."""
        import sqlite3
        _, session = _owner(client)
        from server.runtime import get_runtime
        import json as _json
        rt = get_runtime()
        if not hasattr(rt.conn, "setlimit"):
            pytest.skip("Connection.setlimit erst ab Python 3.11")
        rows = []
        for i in range(1200):
            psn = f"gp{i:04d}"
            rows.append((psn, "Patient", psn, _json.dumps(
                {"resourceType": "Patient", "id": psn, "gender": "female",
                 "birthDate": "1960"})))
            rows.append((f"gc{i:04d}", "Condition", psn, _json.dumps(
                {"resourceType": "Condition", "id": f"gc{i:04d}",
                 "code": {"coding": [{"code": "I10.90"}]},
                 "recordedDate": "2023-02-01"})))
        rows.append(("go-jahr", "Observation", "gp0000", _json.dumps(
            {"resourceType": "Observation", "id": "go-jahr", "status": "final",
             "category": [{"coding": [{"code": "laboratory"}]}],
             "code": {"coding": [{"code": "XX"}], "text": "XX"},
             "valueQuantity": {"value": 1.0},
             "effectiveDateTime": "2023"})))          # nur Jahr -> darf nicht crashen
        rows.append(("go-voll", "Observation", "gp0001", _json.dumps(
            {"resourceType": "Observation", "id": "go-voll", "status": "final",
             "category": [{"coding": [{"code": "laboratory"}]}],
             "code": {"coding": [{"code": "XX"}], "text": "XX"},
             "valueQuantity": {"value": 2.0},
             "effectiveDateTime": "2023-05-01"})))
        rt.conn.executemany(
            "INSERT INTO fhir_resource (id, resource_type, pseudonym, content, status)"
            " VALUES (?,?,?,?, 'active')", rows)
        rt.conn.commit()
        old_limit = rt.conn.setlimit(sqlite3.SQLITE_LIMIT_VARIABLE_NUMBER, 999)
        try:
            r = client.post("/api/analysis/cohort", headers=_auth(session),
                            json={"op": "AND", "lab_trend": "XX",
                                  "criteria": [{"type": "icd", "code": "I10"}]})
            assert r.status_code == 200, r.text
            body = r.json()
            assert body["size"] == 1200
            assert body["lab_trend"] == [{"period": "2023-Q2", "median": 2.0, "n": "<5"}]
            r = client.post("/api/analysis/export", headers=_auth(session),
                            json={"op": "AND",
                                  "criteria": [{"type": "icd", "code": "I10"}]})
            assert r.status_code == 200
        finally:
            rt.conn.setlimit(sqlite3.SQLITE_LIMIT_VARIABLE_NUMBER, old_limit)

    def _insert_patients(self, rt, spec):
        """spec: {pseudonym: [icd, ...]} -> Patient- + Condition-Ressourcen."""
        import json as _json
        for psn, icds in spec.items():
            rt.conn.execute(
                "INSERT INTO fhir_resource (id, resource_type, pseudonym, content, status)"
                " VALUES (?,?,?,?, 'active')",
                (psn, "Patient", psn, _json.dumps({"resourceType": "Patient", "id": psn})))
            for i, icd in enumerate(icds):
                rt.conn.execute(
                    "INSERT INTO fhir_resource (id, resource_type, pseudonym, content, status)"
                    " VALUES (?,?,?,?, 'active')",
                    (f"{psn}-c{i}", "Condition", psn,
                     _json.dumps({"resourceType": "Condition", "id": f"{psn}-c{i}",
                                  "code": {"coding": [{"code": icd}]},
                                  "recordedDate": "2023-01-01"})))
        rt.conn.commit()

    def test_verschachtelte_logik_gruppen_und_nicht(self, client):
        """(A und B und NICHT C) ODER (D und E): Gruppen, Negation, Rekursion."""
        _, session = _owner(client)
        from server.runtime import get_runtime
        rt = get_runtime()
        self._insert_patients(rt, {
            "nA": ["I10.90", "E11.90"],              # A+B, kein C -> Gruppe 1 ✓
            "nB": ["I10.90", "E11.90", "K76.0"],     # A+B+C -> NICHT C schliesst aus
            "nC": ["B18.2", "K74.6"],                # D+E -> Gruppe 2 ✓
            "nD": ["B18.2"],                         # nur D -> ✗
        })
        definition = {"op": "OR", "criteria": [
            {"op": "AND", "criteria": [
                {"type": "icd", "code": "I10"}, {"type": "icd", "code": "E11"},
                {"type": "icd", "code": "K76", "not": True}]},
            {"op": "AND", "criteria": [
                {"type": "icd", "code": "B18"}, {"type": "icd", "code": "K74"}]},
        ]}
        r = client.post("/api/analysis/cohort", headers=_auth(session), json=definition)
        assert r.status_code == 200, r.text
        assert r.json()["size"] == 2                 # genau nA und nC

    def test_mehrfachauswahl_codes_ist_oder(self, client):
        """Chart-Mehrfachauswahl: codes-Liste wirkt als ODER innerhalb des Kriteriums."""
        _, session = _owner(client)
        from server.runtime import get_runtime
        rt = get_runtime()
        self._insert_patients(rt, {"mA": ["I10.90"], "mB": ["K76.0"], "mC": ["E11.90"]})
        r = client.post("/api/analysis/cohort", headers=_auth(session), json={
            "op": "AND", "criteria": [{"type": "icd", "codes": ["I10", "K76"]}]})
        assert r.status_code == 200
        assert r.json()["size"] >= 2                 # mA + mB (Demo-Daten evtl. mehr)

    def test_ausdrucksbaukasten_expr(self, client):
        """Neues Builder-Modell: Kette mit rollierenden Beziehungen + Klammern.
        (I10 und E11 und¬ K76) oder B18; Faltung links nach rechts."""
        _, session = _owner(client)
        from server.runtime import get_runtime
        rt = get_runtime()
        self._insert_patients(rt, {
            "xA": ["I10.90", "E11.90"],            # Klammer ✓
            "xB": ["I10.90", "E11.90", "K76.0"],   # und¬ K76 schliesst aus
            "xC": ["B18.2"],                       # oder B18 ✓
            "xD": ["E11.90"],                      # ✗
        })
        expr = {"items": [
            {"items": [{"type": "icd", "code": "I10"}, {"type": "icd", "code": "E11"},
                       {"type": "icd", "code": "K76"}], "ops": ["and", "and-not"]},
            {"type": "icd", "code": "B18"}], "ops": ["or"]}
        r = client.post("/api/analysis/cohort", headers=_auth(session), json={"expr": expr})
        assert r.status_code == 200, r.text
        assert r.json()["size"] == 2               # xA + xC
        # Links-nach-rechts: (B18 oder E11) und I10
        r2 = client.post("/api/analysis/cohort", headers=_auth(session), json={"expr": {
            "items": [{"type": "icd", "code": "B18"}, {"type": "icd", "code": "E11"},
                      {"type": "icd", "code": "I10"}], "ops": ["or", "and"]}})
        assert r2.json()["size"] == 2              # xA + xB
        # oder¬: I10 ∪ Komplement(B18)
        from server import analysis as A
        uni = A._universe(rt.conn)
        out = A._eval_node(rt.conn, {"items": [{"type": "icd", "code": "I10"},
                                               {"type": "icd", "code": "B18"}],
                                     "ops": ["or-not"]}, "all", uni)
        assert "xC" not in out and "xA" in out and "xD" in out

    def test_therapie_atc_position_und_medname_filter(self, client):
        """Praxis-Befund '?'-Segment: ATC kann an coding[0] ODER coding[1]
        stehen (oder fehlen) -> system-basierte Ermittlung; Medikamente ohne
        Code sind ueber den Namen filterbar (medname)."""
        import json as _json
        _, session = _owner(client)
        from server.runtime import get_runtime
        rt = get_runtime()
        self._insert_patients(rt, {"tA": ["I10.90"], "tB": ["I10.90"]})
        meds = [
            ("m-atc0", "tA", {"coding": [{"system": "http://fhir.de/CodeSystem/bfarm/atc",
                                          "code": "A10BA02"}], "text": "Metformin"}),
            ("m-name", "tB", {"text": "TANNOLACT BADEZUSATZ"}),   # ohne Code
        ]
        for mid, psn, cc in meds:
            rt.conn.execute(
                "INSERT INTO fhir_resource (id, resource_type, pseudonym, content, status)"
                " VALUES (?,?,?,?, 'active')",
                (mid, "MedicationStatement", psn,
                 _json.dumps({"resourceType": "MedicationStatement", "id": mid,
                              "status": "active", "medicationCodeableConcept": cc})))
        rt.conn.commit()
        r = client.post("/api/analysis/cohort", headers=_auth(session), json={
            "expr": {"items": [{"type": "icd", "code": "I10"}], "ops": []}})
        therapy = r.json()["therapy"]
        assert any(x["atc"] == "A10BA02" for x in therapy)      # ATC an coding[0] erkannt
        assert any(x["name"] == "TANNOLACT BADEZUSATZ" and not x["atc"] for x in therapy)
        r2 = client.post("/api/analysis/cohort", headers=_auth(session), json={
            "expr": {"items": [{"type": "medname", "term": "TANNOLACT"}], "ops": []}})
        assert r2.json()["size"] == 1                            # tB via Name

    def test_cohort_and_masking(self, client):
        _, session = _owner(client)
        definition = {"op": "AND", "criteria": [
            {"type": "icd", "code": "K76"},
            {"type": "lab", "code": "HOMA", "op": ">", "value": 3},
        ], "lab_trend": "HOMA"}
        r = client.post("/api/analysis/cohort", headers=_auth(session), json=definition)
        assert r.status_code == 200, r.text
        stats = r.json()
        assert stats["size"] == 4
        assert stats["size_masked"] == "<5"          # Aggregatschutz
        assert stats["lab_trend"], "Verlaufskurve erwartet"

    def test_text_criterion_negation(self, client):
        _, session = _owner(client)
        # nicht-negierte Insulinresistenz -> nur die Kohortenfälle
        r = client.post("/api/analysis/cohort", headers=_auth(session), json={
            "op": "AND", "criteria": [{"type": "text", "term": "Insulinresistenz"}]})
        assert r.json()["size"] == 4
        # Zöliakie ist überall negiert -> nicht-negierte Suche = 0
        r = client.post("/api/analysis/cohort", headers=_auth(session), json={
            "op": "AND", "criteria": [{"type": "text", "term": "Zöliakie"}]})
        assert r.json()["size"] == 0

    def test_research_export_permission(self, client):
        setup, owner_session = _owner(client)
        # Analyst darf Kohorten rechnen, aber keinen Forschungsexport
        analyst = client.post("/api/admin/users", headers=_auth(owner_session),
                              json={"username": "ana", "password": "a" * 12,
                                    "roles": ["analyst"]}).json()
        s = client.post("/api/login", json={"username": "ana", "password": "a" * 12,
                                            "totp": auth.totp_code(analyst["totp_secret"])}).json()
        definition = {"criteria": [{"type": "icd", "code": "K76"}]}
        assert client.post("/api/analysis/cohort", headers=_auth(s),
                           json=definition).status_code == 200
        assert client.post("/api/analysis/export", headers=_auth(s),
                           json=definition).status_code == 403
        # Owner darf exportieren; Bundle enthält keine Klartext-Identifikatoren
        r = client.post("/api/analysis/export", headers=_auth(owner_session),
                        json=definition)
        assert r.status_code == 200
        text = r.text
        assert "Testfall" not in text and "Musterweg" not in text


class TestVerwaltungUndSettings:
    def test_user_lifecycle(self, client):
        _, session = _owner(client)
        r = client.post("/api/admin/users", headers=_auth(session),
                        json={"username": "mfa1", "password": "m" * 12, "roles": ["mfa"]})
        assert r.status_code == 200
        users = client.get("/api/admin/users", headers=_auth(session)).json()["users"]
        target = next(u for u in users if u["username"] == "mfa1")
        r = client.post(f"/api/admin/users/{target['id']}/status", headers=_auth(session),
                        json={"status": "locked"})
        assert r.status_code == 200

    def test_mfa_role_cannot_manage_users(self, client):
        setup, owner_session = _owner(client)
        u = client.post("/api/admin/users", headers=_auth(owner_session),
                        json={"username": "mfa2", "password": "m" * 12,
                              "roles": ["mfa"]}).json()
        s = client.post("/api/login", json={"username": "mfa2", "password": "m" * 12,
                                            "totp": auth.totp_code(u["totp_secret"])}).json()
        assert client.get("/api/admin/users", headers=_auth(s)).status_code == 403
        assert client.get("/api/admin/audit", headers=_auth(s)).status_code == 403

    def test_settings_profile_switch(self, client):
        _, session = _owner(client)
        r = client.post("/api/settings", headers=_auth(session),
                        json={"fhir_profile": "mii"})
        assert r.status_code == 200
        assert client.get("/api/settings",
                          headers=_auth(session)).json()["fhir_profile"] == "mii"
        r = client.post("/api/settings", headers=_auth(session),
                        json={"fhir_profile": "quatsch"})
        assert r.status_code == 422

    def test_etl_status(self, client):
        _, session = _owner(client)
        r = client.get("/api/admin/etl", headers=_auth(session))
        assert r.status_code == 200
        assert any(c["resource_type"] == "Patient" for c in r.json()["resources"])
