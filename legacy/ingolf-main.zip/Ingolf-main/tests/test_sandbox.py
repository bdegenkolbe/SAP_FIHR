# -*- coding: utf-8 -*-
"""Tests: Code-Interpreter-Sandbox (Service + Kernel + Plattform-Client).

Laufen ohne Docker über SANDBOX_RUNNER=subprocess (identisches Protokoll wie
das Container-Profil). Der Netz-Block selbst ist Eigenschaft des DockerRunners
(--network none) und wird auf dem KI-Host abgenommen (README/DoD)."""
import importlib
import os
import sys
import threading
import time

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "sandbox-service"))

TOKEN = "test-token-0123456789"


@pytest.fixture()
def service(tmp_path, monkeypatch):
    """Sandbox-Service mit Subprozess-Runner in frischem Verzeichnis."""
    monkeypatch.setenv("SANDBOX_RUNNER", "subprocess")
    monkeypatch.setenv("SANDBOX_SESSIONS", str(tmp_path / "sessions"))
    monkeypatch.setenv("SANDBOX_TOKEN", TOKEN)
    import app as sandbox_app
    importlib.reload(sandbox_app)
    from fastapi.testclient import TestClient
    client = TestClient(sandbox_app.app)
    yield client, sandbox_app
    for sid in list(sandbox_app._last_used):
        sandbox_app.runner.destroy(sid)


def _auth():
    return {"Authorization": "Bearer " + TOKEN}


class TestService:
    def test_auth_erforderlich(self, service):
        client, _ = service
        assert client.post("/sessions").status_code == 401
        assert client.post("/sessions",
                           headers={"Authorization": "Bearer falsch"}).status_code == 401

    def test_zustand_bleibt_ueber_zellen(self, service):
        client, _ = service
        sid = client.post("/sessions", headers=_auth()).json()["id"]
        r1 = client.post(f"/sessions/{sid}/exec", headers=_auth(),
                         json={"code": "x = 21"}).json()
        assert r1["ok"], r1
        r2 = client.post(f"/sessions/{sid}/exec", headers=_auth(),
                         json={"code": "print(x * 2)"}).json()
        assert r2["ok"] and r2["stdout"].strip() == "42"

    def test_fehler_traceback_statt_absturz(self, service):
        client, _ = service
        sid = client.post("/sessions", headers=_auth()).json()["id"]
        r = client.post(f"/sessions/{sid}/exec", headers=_auth(),
                        json={"code": "1/0"}).json()
        assert r["ok"] is False and "ZeroDivisionError" in r["error"]
        # Session lebt weiter
        r2 = client.post(f"/sessions/{sid}/exec", headers=_auth(),
                         json={"code": "print('lebt')"}).json()
        assert r2["ok"]

    def test_zell_timeout_killt_endlosschleife(self, service):
        client, _ = service
        sid = client.post("/sessions", headers=_auth()).json()["id"]
        start = time.time()
        r = client.post(f"/sessions/{sid}/exec", headers=_auth(),
                        json={"code": "while True: pass", "cell_timeout": 2}).json()
        assert time.time() - start < 15
        assert r["ok"] is False and "Zeitlimit" in r["error"]

    def test_datei_roundtrip_und_artefakt(self, service):
        client, _ = service
        sid = client.post("/sessions", headers=_auth()).json()["id"]
        client.put(f"/sessions/{sid}/files/eingabe.csv", headers=_auth(),
                   content=b"wert\n1\n2\n3\n")
        r = client.post(f"/sessions/{sid}/exec", headers=_auth(), json={"code": (
            "import csv\n"
            "werte = [int(z['wert']) for z in csv.DictReader(open('eingabe.csv'))]\n"
            "open('summe.txt','w').write(str(sum(werte)))\n"
            "print('ok')")}).json()
        assert r["ok"], r
        assert any(a["name"] == "summe.txt" for a in r["artifacts"])
        data = client.get(f"/sessions/{sid}/files/summe.txt", headers=_auth()).content
        assert data == b"6"

    def test_pfad_traversal_blockiert(self, service):
        client, _ = service
        sid = client.post("/sessions", headers=_auth()).json()["id"]
        assert client.put(f"/sessions/{sid}/files/..%2Fboese", headers=_auth(),
                          content=b"x").status_code in (404, 422)

    def test_session_delete(self, service):
        client, _ = service
        sid = client.post("/sessions", headers=_auth()).json()["id"]
        assert client.delete(f"/sessions/{sid}", headers=_auth()).json()["ok"]
        assert client.post(f"/sessions/{sid}/exec", headers=_auth(),
                           json={"code": "1"}).status_code == 404


class TestRemoteSandboxClient:
    @pytest.fixture()
    def live_service(self, tmp_path, monkeypatch):
        """Service als echter HTTP-Server (uvicorn-Thread) für den urllib-Client."""
        monkeypatch.setenv("SANDBOX_RUNNER", "subprocess")
        monkeypatch.setenv("SANDBOX_SESSIONS", str(tmp_path / "sessions"))
        monkeypatch.setenv("SANDBOX_TOKEN", TOKEN)
        import app as sandbox_app
        importlib.reload(sandbox_app)
        import uvicorn
        config = uvicorn.Config(sandbox_app.app, host="127.0.0.1", port=8481,
                                log_level="error")
        server = uvicorn.Server(config)
        thread = threading.Thread(target=server.run, daemon=True)
        thread.start()
        deadline = time.time() + 10
        while not server.started and time.time() < deadline:
            time.sleep(0.05)
        yield "http://127.0.0.1:8481"
        server.should_exit = True
        thread.join(timeout=5)

    def test_client_end_to_end(self, live_service):
        from server.ai.sandbox import RemoteSandbox
        with RemoteSandbox(live_service, TOKEN) as sb:
            sb.upload("zahlen.csv", b"a\n1\n2\n")
            r = sb.exec("import csv\n"
                        "n = sum(1 for _ in csv.DictReader(open('zahlen.csv')))\n"
                        "open('anzahl.txt','w').write(str(n))")
            assert r["ok"], r
            assert sb.download("anzahl.txt") == b"2"
            assert sb.manifest[0]["sha256"]      # Audit-Manifest gepflegt

    def test_client_fehlerpfad(self):
        from server.ai.sandbox import RemoteSandbox, SandboxUnavailable
        sb = RemoteSandbox("http://127.0.0.1:59999", "egal", timeout=2)
        with pytest.raises(SandboxUnavailable):
            sb.create()
