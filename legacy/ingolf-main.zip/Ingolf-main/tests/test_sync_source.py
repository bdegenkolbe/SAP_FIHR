# -*- coding: utf-8 -*-
"""Tests: Sync über die UI (Quellverbindung, Verbindungstest, Sync-Endpunkt,
--since-Filter, Fortschritt/Resume-Mechanik)."""
import json
import os
import sys
import time

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "agent"))

from tests.util_demo import FakeSource, make_tables  # noqa: E402


@pytest.fixture
def client(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from server.main import app
    from server.runtime import Runtime, set_runtime
    monkeypatch.setenv("GREENBAY_HOME", str(tmp_path))
    rt = Runtime(db_path=tmp_path / "clinical.db", master=b"m" * 32)
    set_runtime(rt)
    c = TestClient(app)
    from server import auth
    setup = c.post("/api/setup", json={"username": "owner", "password": "p" * 16}).json()
    s = c.post("/api/login", json={"username": "owner", "password": "p" * 16,
                                   "totp": auth.totp_code(setup["totp_secret"])}).json()
    return c, {"Authorization": "Bearer " + s["token"]}, tmp_path, rt


class TestQuellverbindung:
    def test_save_mit_passwort(self, client):
        c, h, tmp_path, _rt = client
        r = c.post("/api/admin/source", headers=h, json={
            "source_host": "PRAXIS-SQL\\EUGASTRO", "source_port": "1433",
            "source_database": "EUGASTRO", "source_auth": "sql",
            "source_username": "svc_export_ro", "password": "geheim-123"})
        assert r.status_code == 200 and r.json()["password_stored"] is True
        # Passwort DPAPI-/Dev-geschützt, nie im Klartext in der Config
        blob = (tmp_path / "secret" / "dbpass.bin").read_bytes()
        assert b"geheim-123" not in blob or blob.startswith(b"DEV\x00")
        import yaml
        cfg = yaml.safe_load((tmp_path / "config" / "config.yaml").read_text())
        assert cfg["source"]["host"] == "PRAXIS-SQL\\EUGASTRO"
        assert cfg["source"]["port"] == 1433                    # als int geschrieben
        assert cfg["source"].get("password") is None
        assert cfg["source"]["password_ref"] == "secret/dbpass.bin"
        # GET /api/settings liefert kein Passwort zurück
        got = c.get("/api/settings", headers=h).json()
        assert "password" not in json.dumps(got)

    def test_agent_kann_passwort_aufloesen(self, client):
        c, h, tmp_path, _rt = client
        c.post("/api/admin/source", headers=h, json={
            "source_host": "h", "source_username": "u", "password": "geheim-123"})
        import export as E
        cfg = E.load_config(str(tmp_path / "config" / "config.yaml"))
        assert cfg["source"]["password"] == "geheim-123"

    def test_verbindungstest_fehlerpfad(self, client):
        c, h, _tmp, _rt = client
        r = c.post("/api/admin/source/test", headers=h, json={
            "source_host": "definitiv-nicht-da.invalid", "source_port": "1433",
            "source_database": "X", "source_username": "u", "password": "p"})
        assert r.status_code == 200
        body = r.json()
        assert body["ok"] is False and body["error"]

    def test_verbindungstest_ohne_host(self, client):
        c, h, _tmp, _rt = client
        assert c.post("/api/admin/source/test", headers=h, json={}).status_code == 422


class TestSyncEndpoint:
    def test_ohne_config_422(self, client):
        c, h, _tmp, _rt = client
        assert c.post("/api/admin/sync", headers=h,
                      json={"mode": "incremental"}).status_code == 422

    def test_sync_startet_subprozess_und_job_schlaegt_sauber_fehl(self, client):
        """Quelle nicht erreichbar -> Export-Subprozess legt Job an und markiert
        ihn als failed (absturzsicheres Protokoll)."""
        c, h, tmp_path, rt = client
        c.post("/api/admin/source", headers=h, json={
            "source_host": "definitiv-nicht-da.invalid", "source_username": "u",
            "password": "p"})
        r = c.post("/api/admin/sync", headers=h, json={"mode": "full"})
        assert r.status_code == 200, r.text
        deadline = time.time() + 30
        job = None
        while time.time() < deadline:
            jobs = c.get("/api/admin/etl", headers=h).json()["jobs"]
            job = next((j for j in jobs if j["mode"] == "full"), None)
            if job and job["status"] != "running":
                break
            time.sleep(1)
        assert job is not None, "Export-Subprozess hat keinen Job angelegt"
        assert job["status"] == "failed"
        assert job["error"]

    def test_laufender_job_blockiert_ohne_force(self, client):
        c, h, tmp_path, rt = client
        c.post("/api/admin/source", headers=h, json={"source_host": "h"})
        rt.conn.execute("INSERT INTO etl_export_job (id, mode, privacy, target, status)"
                        " VALUES ('j1','full','pseudonymize','fhir','running')")
        rt.conn.commit()
        assert c.post("/api/admin/sync", headers=h,
                      json={"mode": "incremental"}).status_code == 409
        r = c.post("/api/admin/sync", headers=h,
                   json={"mode": "incremental", "force": True})
        assert r.status_code == 200
        old = rt.conn.execute("SELECT status FROM etl_export_job WHERE id='j1'").fetchone()
        assert old["status"] == "failed"

    def test_protokoll_endpunkt(self, client):
        """Verwaltung -> 'Protokoll': Ende von logs/sync.log in der UI."""
        c, h, tmp_path, _rt = client
        logdir = tmp_path / "logs"
        logdir.mkdir(exist_ok=True)
        (logdir / "sync.log").write_text("zeile1\nModuleNotFoundError: dbsource\n",
                                         encoding="utf-8")
        r = c.get("/api/admin/sync/log", headers=h)
        assert r.status_code == 200
        assert "ModuleNotFoundError" in r.json()["log"]

    def test_rbac_analyst_darf_nicht_syncen(self, client):
        c, h, _tmp, rt = client
        from server import auth
        u = c.post("/api/admin/users", headers=h, json={
            "username": "ana", "password": "a" * 12, "roles": ["analyst"]}).json()
        s = c.post("/api/login", json={"username": "ana", "password": "a" * 12,
                                       "totp": auth.totp_code(u["totp_secret"])}).json()
        ah = {"Authorization": "Bearer " + s["token"]}
        assert c.post("/api/admin/sync", headers=ah, json={}).status_code == 403
        assert c.post("/api/admin/source", headers=ah, json={}).status_code == 403


class TestPytdsParamstyle:
    """pytds spricht pyformat (%s), alle Quell-SQLs sind qmark (?): Source
    uebersetzt die Platzhalter. Ohne Uebersetzung stirbt jede parametrisierte
    Abfrage mit 'TypeError: not all arguments converted' (Praxis-PC, Job failed
    am ersten Patienten)."""

    def _source(self, monkeypatch, seen):
        import dbsource

        class _Cur:
            description = [("Id",)]

            def execute(self, sql, params=()):
                seen["sql"], seen["params"] = sql, params

            def fetchall(self):
                return [(1,)]

            def fetchone(self):
                return (1,)

            def close(self):
                pass

        class _Conn:
            def cursor(self):
                return _Cur()

            def close(self):
                pass

        monkeypatch.setattr(dbsource, "_HAVE_PYODBC", False, raising=False)
        monkeypatch.setattr(dbsource.pytds, "connect", lambda **kw: _Conn())
        return dbsource.Source({"host": "h", "port": 1433, "database": "d",
                                "username": "u", "password": "p"}).connect()

    def test_qmark_wird_zu_pyformat(self, monkeypatch):
        seen = {}
        src = self._source(monkeypatch, seen)
        rows = src.query("SELECT Id FROM dbo.Patient WHERE Id = ? AND Nr LIKE '10%'",
                         (3659,))
        assert seen["sql"] == ("SELECT Id FROM dbo.Patient WHERE Id = %s"
                               " AND Nr LIKE '10%%'")          # Literal-% geschuetzt
        assert seen["params"] == (3659,)
        assert rows == [{"Id": 1}]

    def test_ohne_parameter_unveraendert(self, monkeypatch):
        """pytds formatiert nur bei Parametern - parameterloses SQL (z. B.
        MIN_ACTIVE_ROWVERSION) darf nicht umgeschrieben werden."""
        seen = {}
        src = self._source(monkeypatch, seen)
        src.scalar("SELECT MIN_ACTIVE_ROWVERSION()")
        assert seen["sql"] == "SELECT MIN_ACTIVE_ROWVERSION()"
        assert seen["params"] == ()


class TestFehlendeSpalten:
    """Schema-Abweichung zwischen medatixx-Staenden (Praxis-PC: Schein hat kein
    IsPrivat): unbekannte Spalten werden als NULL AS <col> nachgebildet und die
    Abfrage wiederholt - der Export laeuft weiter statt abzubrechen."""

    def _source(self, monkeypatch, state):
        import dbsource

        class _Cur:
            description = [("Id",)]

            def execute(self, sql, params=()):
                state["attempts"].append(sql)
                if "NULL AS IsPrivat" not in sql and "IsPrivat" in sql:
                    raise Exception('Ungültiger Spaltenname "IsPrivat".')

            def fetchall(self):
                return [(1,)]

            def close(self):
                pass

        class _Conn:
            def cursor(self):
                return _Cur()

            def close(self):
                pass

        monkeypatch.setattr(dbsource, "_HAVE_PYODBC", False, raising=False)
        monkeypatch.setattr(dbsource.pytds, "connect", lambda **kw: _Conn())
        return dbsource.Source({"host": "h", "port": 1433, "database": "d",
                                "username": "u", "password": "p"}).connect()

    def test_spalte_wird_genullt_und_gemerkt(self, monkeypatch):
        state = {"attempts": []}
        src = self._source(monkeypatch, state)
        q = "SELECT Id, IsIgel, IsPrivat FROM dbo.Schein WHERE Id_Patient = ?"
        rows = src.query(q, (1,))
        assert rows == [{"Id": 1}]
        assert len(state["attempts"]) == 2                    # Fehlversuch + Retry
        assert "NULL AS IsPrivat" in state["attempts"][-1]
        assert "IsIgel" in state["attempts"][-1]              # andere Spalten bleiben
        src.query(q, (2,))                                    # Anpassung ist gemerkt
        assert len(state["attempts"]) == 3

    def test_englische_meldung_und_alias_praefix(self, monkeypatch):
        import dbsource
        assert dbsource._missing_column(
            Exception("Invalid column name 'HzvVertragKennung'.")) == "HzvVertragKennung"
        out = dbsource._null_out("SELECT s.Id, s.IsPrivat FROM dbo.Schein s", "IsPrivat")
        assert "NULL AS IsPrivat" in out and "s.IsPrivat" not in out

    def test_unbekannter_fehler_wird_durchgereicht(self, monkeypatch):
        import dbsource

        class _Cur:
            def execute(self, sql, params=()):
                raise Exception("Timeout")

            def close(self):
                pass

        class _Conn:
            def cursor(self):
                return _Cur()

        monkeypatch.setattr(dbsource, "_HAVE_PYODBC", False, raising=False)
        monkeypatch.setattr(dbsource.pytds, "connect", lambda **kw: _Conn())
        src = dbsource.Source({"host": "h", "port": 1433, "database": "d",
                               "username": "u", "password": "p"}).connect()
        with pytest.raises(Exception, match="Timeout"):
            src.query("SELECT 1", (1,))


class TestPortableLaufzeit:
    """Praxis-PC: die embeddable Python-Laufzeit (python3xx._pth) legt weder
    Skriptverzeichnis noch cwd auf sys.path. '-P' (safe_path, 3.11+) simuliert
    das - export.py muss seine Pfade selbst registrieren, sonst stirbt der
    Sync-Subprozess sofort am Import (Symptom: Klick ohne Wirkung)."""

    def test_export_importiert_ohne_scriptdir(self):
        import subprocess
        repo = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        r = subprocess.run(
            [sys.executable, "-P", os.path.join(repo, "agent", "export.py"), "--help"],
            capture_output=True, text=True, cwd=repo, timeout=60)
        assert r.returncode == 0, r.stderr

    @pytest.mark.skipif(os.name == "nt", reason="/bin/false ist POSIX")
    def test_sofort_sterbender_syncprozess_meldet_fehler(self, client, monkeypatch):
        """Stirbt der Prozess vor dem Job-Eintrag, muss die UI einen Fehler
        sehen (HTTP 500 mit Log-Hinweis) statt 'ok' ohne Job."""
        c, h, _tmp, _rt = client
        c.post("/api/admin/source", headers=h, json={
            "source_host": "h", "source_username": "u", "password": "p"})
        monkeypatch.setattr(sys, "executable", "/bin/false")
        r = c.post("/api/admin/sync", headers=h, json={"mode": "incremental"})
        assert r.status_code == 500
        assert "sofort beendet" in r.json()["detail"]


class TestKatalogLauf:
    def test_build_legt_job_an_und_meldet_fehler(self, client):
        """Katalog-Knopf: Subprozess legt Job mode='reference' an; bei
        unerreichbarer Quelle wird er sauber als failed protokolliert
        (UI pollt den Fortschritt wie beim Sync)."""
        c, h, _tmp, _rt = client
        c.post("/api/admin/source", headers=h, json={
            "source_host": "definitiv-nicht-da.invalid", "source_username": "u",
            "password": "p"})
        r = c.post("/api/admin/catalogs/build", headers=h)
        assert r.status_code == 200, r.text
        deadline = time.time() + 30
        job = None
        while time.time() < deadline:
            jobs = c.get("/api/admin/etl", headers=h).json()["jobs"]
            job = next((j for j in jobs if j["mode"] == "reference"), None)
            if job and job["status"] != "running":
                break
            time.sleep(1)
        assert job is not None, "Katalog-Subprozess hat keinen Job angelegt"
        assert job["status"] == "failed" and job["error"]

    def test_referenzjob_blockiert_sync_nicht(self, client):
        c, h, _tmp, rt = client
        c.post("/api/admin/source", headers=h, json={"source_host": "h",
                                                     "source_username": "u", "password": "p"})
        rt.conn.execute("INSERT INTO etl_export_job (id, mode, privacy, target, status)"
                        " VALUES ('jref','reference','off','ref','running')")
        rt.conn.commit()
        # Sync darf trotz laufendem Katalog-Lauf starten ...
        assert c.post("/api/admin/sync", headers=h,
                      json={"mode": "incremental"}).status_code == 200
        # ... aber ein zweiter Katalog-Lauf wird abgewiesen
        assert c.post("/api/admin/catalogs/build", headers=h).status_code == 409

    def test_build_reference_loest_password_ref(self, client):
        """Praxis-Befund KeyError 'password': build_reference muss die
        DPAPI-Passwort-Referenz aufloesen wie der Export."""
        c, h, tmp_path, _rt = client
        c.post("/api/admin/source", headers=h, json={
            "source_host": "h", "source_username": "u", "password": "geheim-777"})
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "reference"))
        import build_reference as BR
        cfg = BR.load_config(str(tmp_path / "config" / "config.yaml"))
        assert cfg["source"]["password"] == "geheim-777"

    def test_protokoll_endpunkt_reference(self, client):
        c, h, tmp_path, _rt = client
        logdir = tmp_path / "logs"
        logdir.mkdir(exist_ok=True)
        (logdir / "reference.log").write_text("[1/6] Verbindung\n", encoding="utf-8")
        r = c.get("/api/admin/sync/log?name=reference", headers=h)
        assert r.status_code == 200 and "Verbindung" in r.json()["log"]
        assert c.get("/api/admin/sync/log?name=../secret", headers=h).status_code == 422


class TestAbbrechenUndReset:
    def test_stop_beendet_prozess_und_markiert_job(self, client):
        import json as _json
        import subprocess
        c, h, _tmp, rt = client
        proc = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(600)"])
        rt.conn.execute(
            "INSERT INTO etl_export_job (id, mode, privacy, target, status, stats)"
            " VALUES ('jstop','full','off','fhir','running',?)",
            (_json.dumps({"pid": proc.pid}),))
        rt.conn.commit()
        r = c.post("/api/admin/sync/stop", headers=h)
        assert r.status_code == 200 and "jstop" in r.json()["stopped"]
        proc.wait(timeout=10)                                  # Prozess wurde beendet
        row = rt.conn.execute(
            "SELECT status, error FROM etl_export_job WHERE id='jstop'").fetchone()
        assert row["status"] == "failed" and "abgebrochen" in row["error"]

    def test_reset_leert_klinikdaten_behaelt_benutzer(self, client):
        c, h, _tmp, rt = client
        rt.conn.execute(
            "INSERT INTO fhir_resource (id, resource_type, pseudonym, content, status)"
            " VALUES ('p1','Patient','p1','{}','active')")
        rt.conn.commit()
        assert c.post("/api/admin/store/reset", headers=h, json={}).status_code == 422
        r = c.post("/api/admin/store/reset", headers=h, json={"confirm": "LOESCHEN"})
        assert r.status_code == 200 and r.json()["deleted"]["fhir_resource"] == 1
        assert rt.conn.execute("SELECT COUNT(*) AS c FROM fhir_resource"
                               ).fetchone()["c"] == 0
        assert rt.conn.execute("SELECT COUNT(*) AS c FROM sec_app_user"
                               ).fetchone()["c"] >= 1          # Benutzer bleiben

    def test_reset_blockiert_bei_laufendem_sync(self, client):
        c, h, _tmp, rt = client
        rt.conn.execute("INSERT INTO etl_export_job (id, mode, privacy, target, status)"
                        " VALUES ('jrun','full','off','fhir','running')")
        rt.conn.commit()
        r = c.post("/api/admin/store/reset", headers=h, json={"confirm": "LOESCHEN"})
        assert r.status_code == 409

    def test_moduswechsel_schutz(self, client):
        """Store mit off-Daten + Lauf mit pseudonymize -> klare Meldung statt
        Duplikat-Bestand; gleicher Modus laeuft durch."""
        import export as E
        _c, _h, _tmp, rt = client
        assert E.check_mode_switch(rt.conn, "off") is None     # leerer Store: ok
        rt.conn.execute(
            "INSERT INTO fhir_resource (id, resource_type, pseudonym, content, status)"
            " VALUES ('p1','Patient','p1','{}','active')")
        rt.conn.commit()
        assert E.check_mode_switch(rt.conn, "off") is None     # gleicher Modus: ok
        msg = E.check_mode_switch(rt.conn, "pseudonymize")
        assert msg and "Store leeren" in msg


class TestMfaSchalter:
    """Einstellung auth_mfa=off (Einzelplatz-Praxis): Login/Re-Auth nur mit Passwort."""

    def test_default_ist_aus_login_ohne_totp(self, client):
        c, h, _tmp, _rt = client
        assert c.get("/api/status").json()["mfa_required"] is False  # Standard: aus
        r = c.post("/api/login", json={"username": "owner", "password": "p" * 16})
        assert r.status_code == 200 and r.json()["token"]

    def test_totp_pflicht_wenn_required(self, client):
        c, h, _tmp, _rt = client
        c.post("/api/settings", headers=h, json={"auth_mfa": "required"})
        r = c.post("/api/login", json={"username": "owner", "password": "p" * 16})
        assert r.status_code == 401          # ohne TOTP kein Login
        assert c.get("/api/status").json()["mfa_required"] is True

    def test_wiedereinschalten_wirkt_sofort(self, client):
        from server import auth as auth_mod
        c, h, tmp_path, rt = client
        c.post("/api/settings", headers=h, json={"auth_mfa": "off"})
        c.post("/api/login", json={"username": "owner", "password": "p" * 16})
        c.post("/api/settings", headers=h, json={"auth_mfa": "required"})
        # TOTP-Secret blieb erhalten -> Anmeldung mit Code funktioniert weiter
        from store import vault
        row = rt.conn.execute("SELECT mfa_secret FROM sec_app_user"
                              " WHERE username='owner'").fetchone()
        secret = vault.decrypt(rt.master, row["mfa_secret"])
        r = c.post("/api/login", json={"username": "owner", "password": "p" * 16,
                                       "totp": auth_mod.totp_code(secret)})
        assert r.status_code == 200


class TestSinceFilter:
    def test_since_filtert_klinische_daten(self):
        import export as E
        from privacy import Privacy
        priv = Privacy(mode="pseudonymize", secret="s" * 16)
        src = FakeSource(make_tables(2))
        pid = src.tables["Patient"][0]["Id"]
        voll, _ = E.build_patient_bundle(src, pid, priv, with_openehr=False)
        gefiltert, _ = E.build_patient_bundle(src, pid, priv, with_openehr=False,
                                              since="2030-01-01")
        types_voll = [e["resource"]["resourceType"] for e in voll["entry"]]
        types_filt = [e["resource"]["resourceType"] for e in gefiltert["entry"]]
        assert "Condition" in types_voll and "Observation" in types_voll
        assert types_filt == ["Patient"]          # Stammdaten bleiben immer
        # Stichtag vor allen Daten -> identischer Umfang
        alles, _ = E.build_patient_bundle(src, pid, priv, with_openehr=False,
                                          since="2000-01-01")
        assert len(alles["entry"]) == len(voll["entry"])

    def test_since_helper(self):
        from export import _since_filter
        rows = [{"Datum": "2020-05-01"}, {"Datum": "2022-05-01"}, {"Anderes": 1}]
        out = _since_filter(rows, "2021-01-01", "Datum")
        assert len(out) == 2                      # 2022 + Zeile ohne Datum
        assert _since_filter(rows, None, "Datum") == rows


class TestBenannteInstanz:
    """medatixx & Co: 'HOST\\INSTANZ' -> Portauflösung via SQL Server Browser,
    kein erzwungener TCP-Port (der frühere 1433-Zwang lief in TimeoutError)."""

    def _capture(self, monkeypatch):
        import dbsource
        captured = {}

        def fake_connect(**kw):
            captured.update(kw)

            class _C:  # minimales Verbindungsobjekt
                def close(self):
                    pass
            return _C()

        monkeypatch.setattr(dbsource, "_HAVE_PYODBC", False, raising=False)
        monkeypatch.setattr(dbsource.pytds, "connect", fake_connect)
        return dbsource, captured

    def test_instanz_nutzt_dsn_ohne_port(self, monkeypatch):
        dbsource, captured = self._capture(monkeypatch)
        dbsource.Source({"host": "medatixxsrv01\\x2dbserver", "port": 1433,
                         "database": "x2praxisdb", "username": "rwe",
                         "password": "geheim"}).connect()
        assert captured["dsn"] == "medatixxsrv01\\x2dbserver"
        assert "port" not in captured           # Browser-Dienst löst den Port auf

    def test_einfacher_host_nutzt_port(self, monkeypatch):
        dbsource, captured = self._capture(monkeypatch)
        dbsource.Source({"host": "sqlhost", "port": 1533, "database": "db",
                         "username": "u", "password": "p"}).connect()
        assert captured["dsn"] == "sqlhost" and captured["port"] == 1533
