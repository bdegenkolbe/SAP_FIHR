# -*- coding: utf-8 -*-
"""Tests: FHIR-Profil-Layer (R4 · MII-KDS · KBV, UI_SPEC §7)."""
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "agent"))

import profiles as P  # noqa: E402

BUNDLE = {"resourceType": "Bundle", "entry": [
    {"resource": {"resourceType": "Patient", "id": "p1"}},
    {"resource": {"resourceType": "Condition", "id": "c1"}},
    {"resource": {"resourceType": "Appointment", "id": "a1"}},  # kein Profil-Mapping
]}


def test_r4_bare_unveraendert():
    out = P.apply_bundle(BUNDLE, "r4")
    assert out is BUNDLE
    assert "meta" not in BUNDLE["entry"][0]["resource"]


def test_mii_setzt_profile_urls():
    out = P.apply_bundle(BUNDLE, "mii")
    pat = out["entry"][0]["resource"]
    assert "medizininformatik-initiative" in pat["meta"]["profile"][0]
    cond = out["entry"][1]["resource"]
    assert "modul-diagnose" in cond["meta"]["profile"][0]
    # Ressourcen ohne Mapping bleiben ohne meta.profile
    assert "meta" not in out["entry"][2]["resource"]
    # Original unangetastet (Doppelausleitung möglich)
    assert "meta" not in BUNDLE["entry"][0]["resource"]


def test_kbv_und_idempotenz():
    out = P.apply_bundle(BUNDLE, "kbv")
    pat = P.apply_resource(out["entry"][0]["resource"], "kbv")
    assert len(pat["meta"]["profile"]) == 1  # idempotent
    assert pat["meta"]["profile"][0].startswith("https://fhir.kbv.de/")


def test_unbekanntes_profil():
    with pytest.raises(ValueError):
        P.apply_resource({"resourceType": "Patient"}, "hl7v2")
