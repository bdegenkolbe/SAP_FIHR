# -*- coding: utf-8 -*-
"""Tests: Dokument-Intelligence-Layer (docs/DOKUMENTE_ANNOTATION.md) —
Export-Verdrahtung, Store-Ingestion, Analyse-Kriterium, Einstellungen."""
import json
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "agent"))

from tests.util_demo import build_demo_bundles  # noqa: E402


def _entries(bundle, rtype):
    return [e["resource"] for e in bundle["entry"]
            if e["resource"]["resourceType"] == rtype]


def _overlay(res):
    for ext in res.get("extension", []) or []:
        if str(ext.get("url", "")).endswith("/document-annotations"):
            return ext.get("extension", [])
    return []


class TestExportAnnotation:
    def test_overlay_und_derived(self):
        bundles, _ = build_demo_bundles(2, annotate=True)
        _pid, _nr, bundle = bundles[0]   # gerader Patient: Kohortenfall
        letters = _entries(bundle, "Composition")
        assert letters and _overlay(letters[0]), "Arztbrief muss annotiert sein"
        # abgeleitete Ressource mit NLP-Provenance (Steatosis aus dem Brief)
        derived = [c for c in _entries(bundle, "Condition")
                   if any(str(e.get("url", "")).endswith("/nlp-provenance")
                          for e in c.get("extension", []))]
        assert derived, "abgeleitete Condition (SNOMED, NLP) erwartet"
        codes = {c["code"]["coding"][0]["code"] for c in derived}
        assert "197321007" in codes

    def test_negiertes_konzept_nicht_abgeleitet(self):
        bundles, _ = build_demo_bundles(2, annotate=True)
        _pid, _nr, bundle = bundles[1]   # ungerader Patient: "kein Hinweis auf Zöliakie"
        obs = _entries(bundle, "Observation")
        overlays = [item for o in obs for item in _overlay(o)]
        assert overlays, "Befund muss annotiert sein"
        # Overlay kennt das Konzept als negiert ...
        neg = [i for i in overlays
               if any(e.get("url") == "context" and "negated" in (e.get("valueString") or "")
                      for e in i.get("extension", []))]
        assert neg, "Zöliakie muss als negiert markiert sein"
        # ... aber keine abgeleitete Condition daraus
        derived = [c for c in _entries(bundle, "Condition")
                   if any(str(e.get("url", "")).endswith("/nlp-provenance")
                          for e in c.get("extension", []))]
        assert all(c["code"]["coding"][0]["code"] != "396331005" for c in derived)

    def test_ohne_provider_unveraendert(self):
        bundles, _ = build_demo_bundles(2, annotate=False)
        _pid, _nr, bundle = bundles[0]
        assert not any(_overlay(r) for e in bundle["entry"] for r in [e["resource"]])


class TestStoreIngestion:
    def test_overlay_landet_in_nlp_annotation(self, tmp_path):
        from store.db import open_store
        from store.load import load_bundle
        conn = open_store(tmp_path / "clinical.db")
        bundles, _ = build_demo_bundles(2, annotate=True)
        for _pid, _nr, bundle in bundles:
            load_bundle(conn, bundle)
        rows = conn.execute(
            "SELECT code, negated FROM nlp_annotation WHERE entity_type='DOC_CONCEPT'"
        ).fetchall()
        codes = {r["code"] for r in rows}
        assert "197321007" in codes                     # Steatosis (Brief)
        assert any(r["code"] == "396331005" and r["negated"] for r in rows)  # Zöliakie negiert
        conn.close()


class TestAnalyseUndSettings:
    @pytest.fixture
    def client(self, tmp_path, monkeypatch):
        from fastapi.testclient import TestClient
        from server.main import app
        from server.runtime import Runtime, set_runtime
        from store.load import load_bundle
        monkeypatch.setenv("GREENBAY_HOME", str(tmp_path))
        rt = Runtime(db_path=tmp_path / "clinical.db", master=b"m" * 32)
        set_runtime(rt)
        bundles, _ = build_demo_bundles(6, secret="m" * 32, annotate=True)
        for _pid, _nr, bundle in bundles:
            load_bundle(rt.conn, bundle)
        return TestClient(app), tmp_path

    def _login(self, client):
        from server import auth
        setup = client.post("/api/setup", json={"username": "owner",
                                                "password": "p" * 16}).json()
        s = client.post("/api/login", json={"username": "owner", "password": "p" * 16,
                                            "totp": auth.totp_code(setup["totp_secret"])}).json()
        return {"Authorization": "Bearer " + s["token"]}

    def test_kriterium_dokument_konzept(self, client):
        c, _ = client
        h = self._login(c)
        # Steatosis-Konzept (aus Briefen): nur die 3 geraden Patienten
        r = c.post("/api/analysis/cohort", headers=h, json={
            "criteria": [{"type": "concept", "code": "197321007"}]})
        assert r.status_code == 200, r.text
        assert r.json()["size"] == 3
        # negierte Zöliakie darf keine Treffer liefern
        r = c.post("/api/analysis/cohort", headers=h, json={
            "criteria": [{"type": "concept", "code": "396331005"}]})
        assert r.json()["size"] == 0

    def test_derivation_structured_schliesst_nlp_aus(self, client):
        c, _ = client
        h = self._login(c)
        # SNOMED-Code existiert nur als NLP-abgeleitete Condition
        base = {"criteria": [{"type": "icd", "code": "197321007"}]}
        all_r = c.post("/api/analysis/cohort", headers=h,
                       json={**base, "derivation": "all"}).json()
        structured = c.post("/api/analysis/cohort", headers=h,
                            json={**base, "derivation": "structured"}).json()
        assert all_r["size"] == 3 and structured["size"] == 0

    def test_settings_roundtrip_und_write_through(self, client):
        c, tmp_path = client
        h = self._login(c)
        # config.yaml anlegen -> Write-Through muss greifen
        cfg_dir = tmp_path / "config"
        cfg_dir.mkdir(exist_ok=True)
        (cfg_dir / "config.yaml").write_text(
            "source:\n  host: praxis\nprivacy:\n  mode: pseudonymize\n", encoding="utf-8")
        r = c.post("/api/settings", headers=h, json={
            "privacy_mode": "off", "privacy_gate": "warn",
            "privacy_free_text_deid": "false", "privacy_keep_filenames": "true",
            "annotation_enabled": "true", "annotation_min_confidence": "0.7",
            "analysis_include_nlp": "structured", "fhir_profile": "mii"})
        assert r.status_code == 200, r.text
        got = c.get("/api/settings", headers=h).json()
        assert got["privacy_gate"] == "warn"
        assert got["annotation_min_confidence"] == "0.7"
        assert got["config_write_through"] is True
        import yaml
        cfg = yaml.safe_load((cfg_dir / "config.yaml").read_text(encoding="utf-8"))
        assert cfg["privacy"]["mode"] == "off"
        assert cfg["privacy"]["gate"] == "warn"
        assert cfg["privacy"]["keep_filenames"] is True
        assert cfg["annotation"]["enabled"] is True
        assert cfg["annotation"]["min_confidence"] == 0.7
        assert cfg["fhir"]["profile"] == "mii"
        assert cfg["source"]["host"] == "praxis"   # Bestand bleibt erhalten

    def test_settings_validierung(self, client):
        c, _ = client
        h = self._login(c)
        assert c.post("/api/settings", headers=h,
                      json={"privacy_gate": "quatsch"}).status_code == 422
        assert c.post("/api/settings", headers=h,
                      json={"annotation_min_confidence": "7"}).status_code == 422
