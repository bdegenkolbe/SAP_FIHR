#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Vollstaendige Modul-/Konzept-Validierung (ohne DB).
Prueft: Import aller Module, Mapper-Vollstaendigkeit ggü. export.py,
strukturelle FHIR-Wohlgeformtheit, JSON-Serialisierbarkeit, Referenz-Integritaet,
Privacy-Invarianten, sowie Konsistenz der Konzeptdokumente."""
import sys, os, re, json, ast, glob

import os as _os
ROOT = _os.path.abspath(_os.path.join(_os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "agent"))
sys.path.insert(0, os.path.join(ROOT, "reference"))

import mappers as M
from privacy import Privacy
import meddok, reference_mappers as R

problems, checks = [], 0


def ok(cond, msg):
    global checks
    checks += 1
    if not cond:
        problems.append(msg)


# --- 1) Alle in export.py aufgerufenen Mapper existieren -------------------
exp_src = open(os.path.join(ROOT, "agent", "export.py"), encoding="utf-8").read()
called = set(re.findall(r"M\.(map_\w+)", exp_src))
for fn in called:
    ok(hasattr(M, fn), f"export.py ruft M.{fn} auf, das in mappers.py fehlt")

# --- 2) FHIR-Strukturpruefung: jeder Mapper erzeugt wohlgeformte Ressourcen -
priv = Privacy(mode="pseudonymize", secret="testsecret", date_shift=True)
ctx = M.ExportContext(3659, priv.pseudonym(3659), "urn:uuid:" + priv.pseudonym(3659), priv)

ALLOWED_RT = {
    "Patient", "Condition", "Encounter", "ServiceRequest", "Claim", "Appointment",
    "Observation", "DiagnosticReport", "Composition", "DocumentReference", "Invoice",
    "MedicationStatement", "MedicationRequest", "Medication", "AllergyIntolerance",
    "Flag", "Coverage", "RelatedPerson", "Task", "List", "EpisodeOfCare",
    "ObservationDefinition", "ChargeItemDefinition", "CodeSystem",
}


def check_entries(entries, label):
    for e in entries:
        res = e["resource"] if "resource" in e else e
        rt = res.get("resourceType")
        ok(rt in ALLOWED_RT, f"{label}: unerwarteter resourceType {rt}")
        ok(bool(res.get("id")), f"{label}: Ressource ohne id")
        # JSON-serialisierbar?
        try:
            json.dumps(res, ensure_ascii=False)
        except (TypeError, ValueError) as ex:
            problems.append(f"{label}: nicht JSON-serialisierbar ({ex})")
        # keine None-Werte oder leere Container nach _clean
        _assert_clean(res, label)
        # Referenzen wohlgeformt
        for ref in _iter_refs(res):
            ok(ref.startswith("urn:uuid:") or ref.startswith("Patient/"),
               f"{label}: ungueltige reference '{ref}'")


def _assert_clean(obj, label):
    if isinstance(obj, dict):
        for k, v in obj.items():
            ok(v is not None, f"{label}: None-Wert bei {k}")
            _assert_clean(v, label)
    elif isinstance(obj, list):
        for it in obj:
            _assert_clean(it, label)


def _iter_refs(obj):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k == "reference" and isinstance(v, str):
                yield v
            else:
                yield from _iter_refs(v)
    elif isinstance(obj, list):
        for it in obj:
            yield from _iter_refs(it)


# Synthetische Eingaben je Mapper
D = "2026-05-01T10:00:00"
check_entries([{"resource": M.map_patient(ctx, {"PatientNr": "1", "Name": "X", "Vorname": "Y",
              "Geschlecht": 2, "Geburtsjahr": 1975, "Geburtsmonat": 6, "Geburtstag": 1})}], "patient")
check_entries(M.map_conditions(ctx, [{"Id": 1, "Kuerzel": "D",
              "Detail": '<MedDokDiagnose><Icd>K50.9</Icd><Sicherheit>G</Sicherheit></MedDokDiagnose>',
              "ReferenceDateTime": D}]), "conditions")
check_entries(M.map_scheine(ctx, [{"Id": 1, "Scheinart": 0, "Quartal": "20261",
              "ReferenceDateTime": D, "KassenName": "AOK"}], {}), "scheine")
check_entries(M.map_narrative(ctx, [{"Id": 1, "Kuerzel": "A",
              "Detail": '<MedDokFreitext><FreitextPlain>Text</FreitextPlain></MedDokFreitext>',
              "ReferenceDateTime": D}]), "narrative")
check_entries(M.map_findings(ctx, [{"Id": 1, "Kuerzel": "SONO",
              "Detail": '<MedDokFreitext><FreitextPlain>Befund</FreitextPlain></MedDokFreitext>',
              "ReferenceDateTime": D}]), "findings")
check_entries(M.map_arztbriefe(ctx, [{"Id": 1, "Kuerzel": "BRIEF",
              "Detail": '<MedDokFreitext><FreitextPlain>Brief</FreitextPlain></MedDokFreitext>',
              "ReferenceDateTime": D}]), "arztbriefe")
check_entries(M.map_au(ctx, [{"Id": 1, "Kuerzel": "AU", "ReferenceDateTime": D,
              "Detail": '<meddokformular><shortinfo>AU bis 10.05.2026, Diagnose(n): K50.9</shortinfo></meddokformular>'}],
              {1: {"State": 3, "IkNr": "107202793"}}, {}), "au")
check_entries(M.map_documents(ctx, [{"Id": 1, "Kuerzel": "KRANK",
              "Detail": '<MedDokFreitext><FreitextPlain>Einweisung</FreitextPlain></MedDokFreitext>',
              "ReferenceDateTime": D}]), "documents")
check_entries(M.map_labor(ctx, [{"Id_LaborHeader": 1, "Ident": "HB", "Testbezeichnung": "Hb",
              "Ergebniswert": "14.2", "Einheit": "g/dl", "ReferenceDateTime": D}]), "labor")
check_entries(M.map_vitals(ctx, [{"Id": 1, "Name": "RR", "DisplayName": "Blutdruck",
              "Value": "120", "Masseinheit": "mmHg", "Datum": D}]), "vitals")
check_entries(M.map_medication(ctx, [{"Id": 1, "Pzn": "12345678", "ItemType": 1,
              "Artikelname": "ASS", "ReferenceDateTime": D}]), "medication")
check_entries(M.map_invoices(ctx, [{"Id": 1, "RechnungsDatum": D, "GesamtBetrag": "42.00",
              "IsIgel": True}]), "invoices")
check_entries(M.map_cave(ctx, [{"Id": 1, "IntoleranceText": "Penicillin", "CreatedPoint": D}]), "cave-allergy")
check_entries(M.map_cave(ctx, [{"Id": 2, "DescriptionText": "Marcumar!", "CreatedPoint": D}]), "cave-flag")
check_entries(M.map_coverage_chipkarte(ctx, [{"Id": 1, "ChipkartenEinlesedatum": "2026-01-01",
              "VersichertenNr": "A123", "Versichertenart": 1, "IkNr": "107202793",
              "KassenName": "IKK"}]), "coverage")
check_entries(M.map_bezugsperson(ctx, [{"Id": 1, "Name": "M", "Vorname": "E",
              "BeziehungBezugsperson": "Ehefrau"}], {1: [{"Type": 1, "Data": "0341"}]}), "bezugsperson")
check_entries(M.map_todos(ctx, [{"Id": 1, "Name": "Kontrolle", "Status": 1, "Priority": 2,
              "CreatedPoint": D, "Id_MedDok": 9}]), "todos")
check_entries(M.map_heilmittel(ctx, [{"Id": 1, "ReferenceDateTime": D, "FirstIcdCode": "M54.5",
              "DiagnoseGruppe": "WS"}], {1: [{"Name": "KG", "Behandlungseinheit": 6}]}), "heilmittel")
check_entries(M.map_rezepte(ctx, [{"Id": 1, "Ausstellungsdatum": D, "Subtype": 2,
              "BtmKennzeichen": 0, "IsHilfsmittel": False}],
              {1: [{"Id": 9, "Id_Rezept": 1, "Pzn": "20366364", "IsStrukturiert": True,
                    "Info": "ASS 100 PZN20366364\r\n1-0-0", "Rang": 1}]},
              {9: [{"Id": 3, "Id_RezeptInfo": 9, "Druckzeile": "morgens", "Rang": 1}]},
              {1: [{"Icd": "I10", "Beschreibung": "Hypertonie"}]}), "rezepte")
check_entries(M.map_anhaenge(ctx, [{"Id": 1, "Id_MedDok": 5, "FileName": "b.pdf",
              "AnhangLength": 10, "FsRowGuid": "g1", "CreatedPoint": D}], embed=False), "anhaenge")
check_entries(M.map_medikationsplan(ctx, [{"Id_Patient": 3659, "CreatedPoint": D}],
              [{"Id": 1, "Id_Verordnung": 5, "MedikationsplanSortIndex": 1}], {}), "medplan")
check_entries(M.map_dmp(ctx, []), "dmp-empty")
check_entries(M.map_hzv(ctx, []), "hzv-empty")

# --- 3) Referenz-Mapper -----------------------------------------------------
check_entries(R.map_labor_katalog([{"Id": 1, "Ident": "HB", "Bezeichnung": "Hb", "Einheit": "g/dl",
              "Normwerte": '[{"Geschlecht":"2","NormalwertText":"m"}]',
              "IsGnr_Ebm": False, "IsGnr_Goae": False}]), "ref-labor")
check_entries(R.map_vitalparameter([{"Id": 1, "Name": "RR", "DisplayName": "Blutdruck",
              "Masseinheit": "mmHg"}]), "ref-vital")
check_entries(R.map_medikament([{"Id": 1, "Pzn": "1", "Artikelname": "ASS",
              "Darreichungsform": "TAB"}], {1: [{"Wirkstoff": "ASS", "Wirkstaerke": "100mg", "Rang": "1"}]},
              {1: {"AtcCode": "B01AC06", "Bezeichnung": "ASS"}}), "ref-med")
check_entries(R.map_goae([{"Id": 1, "Ziffer": "a424", "LegendeKurz": "Elasto", "LegendeLang": "Elasto"}]), "ref-goae")
cs = R.map_meddok_kategorie([{"Kuerzel": "D", "Bezeichnung": "Diagnose"}])
ok(cs["resourceType"] == "CodeSystem" and cs["concept"], "ref-codesystem leer")

# --- 4) Privacy-Invarianten -------------------------------------------------
ok(priv.pseudonym(3659) == priv.pseudonym(3659), "Pseudonym nicht stabil")
ok(priv.pseudonym(1) != priv.pseudonym(2), "Pseudonym-Kollision")
ok(priv.hash_id("A955850466", "kvnr") != "A955850466", "KVNR nicht gehasht")
ok(priv.hash_id("A955850466", "kvnr") == priv.hash_id("A955850466", "kvnr"), "KVNR-Hash nicht stabil")
ok(Privacy(mode="off").hash_id("X", "kvnr") == "X", "off-Modus veraendert KVNR")
ok("[DATUM]" in (priv.text(3659, "am 01.05.2026 erschienen") or ""), "Datum nicht de-identifiziert")
# Formularvariablen: PII-Praefixe werden gefiltert
fv = meddok.parse_formularvariablen('[{"id":"Patient_Name","value":"X"},{"id":"_IsEau","value":true}]')
ok("Patient_Name" not in fv and fv.get("_IsEau") is True, "Formularvariablen-PII-Filter defekt")

# --- 5) Konzeptdokumente gegen Code abgleichen -----------------------------
for doc in ["docs/CONCEPT.md", "docs/SCHEMA.md", "docs/DEPLOYMENT.md", "CLAUDE.md",
            "README.md", "config/tables.yaml", "requirements.txt"]:
    ok(os.path.exists(os.path.join(ROOT, doc)), f"Dokument fehlt: {doc}")

concept = open(os.path.join(ROOT, "docs/CONCEPT.md"), encoding="utf-8").read()
schema = open(os.path.join(ROOT, "docs/SCHEMA.md"), encoding="utf-8").read()
claude = open(os.path.join(ROOT, "CLAUDE.md"), encoding="utf-8").read()
tables = open(os.path.join(ROOT, "config/tables.yaml"), encoding="utf-8").read()
alldocs = concept + schema + claude + tables

# Jede neue Domaene sollte in der Doku auftauchen
for term in ["Chipkarte", "Coverage", "Bezugsperson", "RelatedPerson", "Heilmittel",
             "Medikationsplan", "Formularvariable", "ExtensionData", "Todo", "Task"]:
    ok(term in alldocs, f"Doku erwaehnt neue Domaene nicht: {term}")

# --- 6) tables.yaml YAML-parsebar ------------------------------------------
try:
    import yaml
    yaml.safe_load(tables)
except ImportError:
    pass
except Exception as ex:
    problems.append(f"tables.yaml nicht parsebar: {ex}")

# --- Ergebnis --------------------------------------------------------------
print(f"Checks ausgefuehrt: {checks}")
if problems:
    print(f"\n{len(problems)} PROBLEM(E):")
    for p in problems:
        print("  -", p)
    sys.exit(1)
print("VALIDIERUNG BESTANDEN - keine Befunde.")
