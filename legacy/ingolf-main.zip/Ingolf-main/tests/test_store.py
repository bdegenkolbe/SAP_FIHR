# -*- coding: utf-8 -*-
"""Tests: lokaler Store (Schema, Upsert/History, Audit-Kette, Vault, Annotation)."""
import os
import sqlite3
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from store.db import audit, open_store, verify_audit_chain, get_setting, set_setting  # noqa: E402
from store.load import load_bundle, upsert_resource, reconcile_deletes  # noqa: E402
from store import vault  # noqa: E402
from tests.util_demo import build_demo_bundles  # noqa: E402

MASTER = b"master-secret-fuer-tests-0123456789abcdef"


@pytest.fixture
def conn(tmp_path):
    c = open_store(tmp_path / "clinical.db")
    yield c
    c.close()


class TestSchemaUndAudit:
    def test_audit_append_only(self, conn):
        audit(conn, "login", user_id=None, detail={"x": 1})
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute("UPDATE audit_event SET action='manipuliert' WHERE id=1")
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute("DELETE FROM audit_event WHERE id=1")

    def test_audit_hash_chain(self, conn):
        for i in range(5):
            audit(conn, f"aktion{i}")
        ok, n = verify_audit_chain(conn)
        assert ok and n == 5

    def test_settings_roundtrip(self, conn):
        assert get_setting(conn, "fhir_profile", "r4") == "r4"
        set_setting(conn, "fhir_profile", "mii")
        assert get_setting(conn, "fhir_profile") == "mii"


class TestUpsert:
    RES = {"resourceType": "Condition", "id": "c1",
           "code": {"coding": [{"code": "K76.0", "display": "Steatosis"}]},
           "subject": {"reference": "Patient/psn1"}, "recordedDate": "2024-03-01"}

    def test_create_update_history(self, conn):
        assert upsert_resource(conn, dict(self.RES), "psn1") == "create"
        assert upsert_resource(conn, dict(self.RES), "psn1") == "unchanged"
        changed = dict(self.RES, recordedDate="2024-04-01")
        assert upsert_resource(conn, changed, "psn1") == "update"
        row = conn.execute("SELECT version_id, effective, code_primary FROM fhir_resource"
                           " WHERE id='c1'").fetchone()
        assert row["version_id"] == 2
        assert row["effective"] == "2024-04-01"     # generierte Spalte
        assert row["code_primary"] == "K76.0"
        hist = conn.execute("SELECT COUNT(*) AS n FROM fhir_resource_history"
                            " WHERE id='c1'").fetchone()["n"]
        assert hist == 2

    def test_references_extracted(self, conn):
        upsert_resource(conn, dict(self.RES), "psn1")
        ref = conn.execute("SELECT * FROM fhir_reference WHERE src_id='c1'").fetchone()
        assert ref["ref_type"] == "Patient" and ref["ref_id"] == "psn1"

    def test_reconcile_marks_deleted(self, conn):
        upsert_resource(conn, dict(self.RES), "psn1")
        upsert_resource(conn, dict(self.RES, id="c2"), "psn1")
        n = reconcile_deletes(conn, [("Condition", "c1")], "psn1")
        assert n == 1
        status = conn.execute("SELECT status FROM fhir_resource WHERE id='c2'").fetchone()
        assert status["status"] == "deleted"


class TestVault:
    def test_encrypt_roundtrip(self):
        blob = vault.encrypt(MASTER, "3659")
        assert b"3659" not in blob
        assert vault.decrypt(MASTER, blob) == "3659"

    def test_tamper_detected(self):
        blob = bytearray(vault.encrypt(MASTER, "3659"))
        blob[-1] ^= 0xFF
        with pytest.raises(Exception):
            vault.decrypt(MASTER, bytes(blob))

    def test_wrong_key_fails(self):
        blob = vault.encrypt(MASTER, "3659")
        with pytest.raises(Exception):
            vault.decrypt(b"anderer-schluessel-0123456789abcdef", blob)

    def test_store_and_resolve(self, conn):
        vault.store_mapping(conn, MASTER, "PABC", 3659, 76824, -120)
        r = vault.resolve(conn, MASTER, "PABC")
        assert r["source_id"] == "3659" and r["source_nr"] == "76824"
        assert r["date_shift_days"] == -120
        assert vault.resolve(conn, MASTER, "PXXX") is None


class TestBundleLoad:
    def test_demo_bundles_load_and_annotate(self, conn):
        bundles, _priv = build_demo_bundles(4)
        for _pid, _nr, bundle in bundles:
            result = load_bundle(conn, bundle)
            assert result["create"] > 0
        n = conn.execute("SELECT COUNT(*) AS n FROM fhir_resource"
                         " WHERE status='active'").fetchone()["n"]
        assert n > 10
        # Annotationen: negierte Zöliakie darf existieren, aber als negiert markiert
        neg = conn.execute(
            "SELECT COUNT(*) AS n FROM nlp_annotation"
            " WHERE code='K90.0' AND negated=1").fetchone()["n"]
        assert neg >= 1
        pos = conn.execute(
            "SELECT COUNT(*) AS n FROM nlp_annotation"
            " WHERE lower(text_snippet) LIKE '%insulinresistenz%' AND negated=0"
        ).fetchone()["n"]
        assert pos >= 1

    def test_idempotent_reload(self, conn):
        bundles, _ = build_demo_bundles(2)
        for _pid, _nr, bundle in bundles:
            load_bundle(conn, bundle)
        for _pid, _nr, bundle in bundles:
            result = load_bundle(conn, bundle)
            assert result["create"] == 0
            assert result["update"] == 0  # identischer Inhalt -> unchanged
