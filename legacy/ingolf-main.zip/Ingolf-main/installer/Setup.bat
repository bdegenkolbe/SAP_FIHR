@echo off
REM ==========================================================================
REM  GREENBAY clinical - Setup ohne Adminrechte (Windows 10/11)
REM
REM  Self-Bootstrap: diese eine Datei genuegt. Sie laedt bei Bedarf
REM    1. den Anwendungscode als Zip von GitHub  (curl, in Windows enthalten)
REM    2. eine portable Python-Laufzeit von python.org (embeddable, kein Admin)
REM  und installiert alles nach %LOCALAPPDATA%\GreenbayClinical.
REM
REM  Privates GitHub-Repo: vor dem Start  set GB_TOKEN=<github_pat>  setzen
REM  Anderer Branch:       set GB_BRANCH=main   (Default: main)
REM ==========================================================================
setlocal EnableDelayedExpansion
title GREENBAY clinical - Setup

set "APPDIR=%LOCALAPPDATA%\GreenbayClinical"
set "PYDIR=%APPDIR%\python"
set "SRC=%~dp0"
set "TMPD=%TEMP%\gb-setup"

REM --- Optionale Konfigurationsdatei neben Setup.bat: setup.env -------------
REM     Zeilen der Form  GB_TOKEN=github_pat_xxx  /  GB_BRANCH=...  /  GB_REPO=...
REM     erspart das manuelle "set" in der Eingabeaufforderung.
if exist "%SRC%setup.env" (
    echo   Lese Konfiguration aus setup.env ...
    for /f "usebackq eol=# tokens=1,* delims==" %%A in ("%SRC%setup.env") do set "%%A=%%B"
)
if not defined GB_REPO   set "GB_REPO=bdegenkolbe/Ingolf"
REM Branch-Kandidaten: expliziter GB_BRANCH zuerst, sonst main + Entwicklungsbranch
if defined GB_BRANCH ( set "BRANCHES=%GB_BRANCH%" ) else ( set "BRANCHES=main claude/starte-mal-lfobbx" )
set "PYVER=3.12.8"

echo(
echo  ============================================================
echo   GREENBAY clinical - Installation (ohne Administratorrechte)
echo  ============================================================
echo   Zielordner: %APPDIR%
echo(

if not exist "%APPDIR%"  mkdir "%APPDIR%"
for %%D in (app data data\out config secret logs) do if not exist "%APPDIR%\%%D" mkdir "%APPDIR%\%%D"
if exist "%TMPD%" rmdir /S /Q "%TMPD%" >nul 2>&1
mkdir "%TMPD%" >nul 2>&1

REM --- 1) Anwendungscode beschaffen: lokal (neben Setup.bat) oder von GitHub
set "CODESRC="
if exist "%SRC%agent\export.py"    set "CODESRC=%SRC%"
if exist "%SRC%..\agent\export.py" set "CODESRC=%SRC%..\"
if not defined CODESRC (
    echo [1/7] Lade Anwendungscode von GitHub ^(%GB_REPO%^)...
    where curl >nul 2>&1 || ( echo [FEHLER] curl fehlt ^(Windows 10 1803+ noetig^). & goto :fail )
    set "AUTH_HDR="
    if defined GB_TOKEN set "AUTH_HDR=Authorization: Bearer %GB_TOKEN%"
    for %%B in (%BRANCHES%) do (
        if not defined CODESRC (
            echo        Versuche Branch %%B ...
            if defined AUTH_HDR (
                curl -L -sS -f --header "!AUTH_HDR!" -o "%TMPD%\repo.zip" ^
                  "https://codeload.github.com/%GB_REPO%/zip/refs/heads/%%B" 2>"%TMPD%\curl.err"
            ) else (
                curl -L -sS -f -o "%TMPD%\repo.zip" ^
                  "https://codeload.github.com/%GB_REPO%/zip/refs/heads/%%B" 2>"%TMPD%\curl.err"
            )
            if !errorlevel! == 0 (
                tar -xf "%TMPD%\repo.zip" -C "%TMPD%"
                for /d %%R in ("%TMPD%\*") do if exist "%%R\agent\export.py" set "CODESRC=%%R\"
                if not defined CODESRC echo        [Hinweis] Branch %%B enthaelt keinen Anwendungscode - naechster Versuch.
            ) else (
                echo        [Hinweis] Download von %%B fehlgeschlagen:
                type "%TMPD%\curl.err" 2>nul
            )
        )
    )
    if not defined CODESRC (
        echo [FEHLER] Kein Branch mit Anwendungscode erreichbar.
        echo          Moeglichkeiten: Netzwerk/Proxy blockiert github.com ^(Meldung oben^),
        echo          oder privates Repo: vorher  set GB_TOKEN=github_pat_xxx
        echo          oder Branch waehlen:        set GB_BRANCH=claude/starte-mal-lfobbx
        goto :fail
    )
) else (
    echo [1/7] Nutze lokalen Anwendungscode: %CODESRC%
)

REM --- 2) Python-Laufzeit: mitgeliefert, im PATH, oder Download (embeddable)
set "PY="
if exist "%CODESRC%python\python.exe" (
    echo [2/7] Kopiere mitgelieferte Python-Laufzeit...
    xcopy /E /I /Q /Y "%CODESRC%python" "%PYDIR%" >nul
    set "PY=%PYDIR%\python.exe"
)
if not defined PY (
    REM Update-Lauf: die bereits installierte portable Laufzeit wiederverwenden
    REM statt neu zu laden (deren Dateien sind bei laufender App gesperrt).
    if exist "%PYDIR%\python.exe" (
        "%PYDIR%\python.exe" -c "import sys" >nul 2>&1
        if !errorlevel! == 0 (
            set "PY=%PYDIR%\python.exe"
            echo [2/7] Nutze bereits installierte Python-Laufzeit: %PYDIR%\python.exe
        )
    )
)
if not defined PY (
    REM Vorhandenes Python nur nutzen, wenn es ECHT ist: der Microsoft-Store-
    REM Alias-Stub (...\Microsoft\WindowsApps\python.exe) besteht 'where',
    REM startet aber kein Python. Deshalb: Stub aussortieren + Probelauf.
    for /f "delims=" %%P in ('where python 2^>nul') do (
        if not defined PY (
            echo %%P | find /i "\Microsoft\WindowsApps\" >nul
            if !errorlevel! neq 0 (
                "%%P" -c "import sys" >nul 2>&1
                if !errorlevel! == 0 set "PY=%%P"
            )
        )
    )
    if defined PY echo [2/7] Nutze vorhandenes Python: !PY!
)
if not defined PY (
    echo [2/7] Lade portable Python-Laufzeit %PYVER% von python.org...
    if not exist "%PYDIR%" mkdir "%PYDIR%"
    curl -L -sS -f -o "%TMPD%\python-embed.zip" ^
      "https://www.python.org/ftp/python/%PYVER%/python-%PYVER%-embed-amd64.zip" 2>"%TMPD%\curl.err"
    if !errorlevel! neq 0 (
        type "%TMPD%\curl.err" 2>nul
        echo [FEHLER] Python-Download fehlgeschlagen.
        goto :fail
    )
    tar -xf "%TMPD%\python-embed.zip" -C "%PYDIR%"
    if !errorlevel! neq 0 (
        REM Entpacken teils fehlgeschlagen: passiert, wenn die App noch laeuft
        REM und python.exe/DLLs sperrt. Funktioniert die vorhandene Laufzeit,
        REM geht es damit weiter; sonst App schliessen und Setup wiederholen.
        "%PYDIR%\python.exe" -c "import sys" >nul 2>&1
        if !errorlevel! == 0 (
            echo        [Hinweis] Entpacken unvollstaendig ^(Dateien in Benutzung^) - vorhandene Laufzeit wird weiterverwendet.
        ) else (
            echo [FEHLER] Python-Laufzeit konnte nicht entpackt werden.
            echo          Bitte GREENBAY clinical beenden ^(Fenster schliessen,
            echo          ggf. Task-Manager: python.exe unter %APPDIR%^) und Setup erneut starten.
            goto :fail
        )
    )
    REM embeddable Python: 'import site' aktivieren, damit pip funktioniert
    powershell -NoProfile -Command ^
      "(Get-Content '%PYDIR%\python312._pth') -replace '#import site','import site' | Set-Content '%PYDIR%\python312._pth'"
    curl -L -s -f -o "%TMPD%\get-pip.py" "https://bootstrap.pypa.io/get-pip.py"
    "%PYDIR%\python.exe" "%TMPD%\get-pip.py" --no-warn-script-location >nul
    set "PY=%PYDIR%\python.exe"
)

REM --- 3) Anwendungsdateien kopieren
echo [3/7] Kopiere Anwendung...
for %%D in (agent store server reference ui docs config installer tools) do ^
if exist "%CODESRC%%%D" xcopy /E /I /Q /Y "%CODESRC%%%D" "%APPDIR%\app\%%D" >nul
copy /Y "%CODESRC%requirements.txt" "%APPDIR%\app\" >nul 2>&1

REM --- 4) Abhaengigkeiten installieren: online, sonst Offline-Wheels
echo [4/7] Installiere Abhaengigkeiten...
"%PY%" -m pip --version >nul 2>&1 || "%PY%" -m ensurepip >nul 2>&1
ping -n 1 pypi.org >nul 2>&1
if !errorlevel! == 0 (
    "%PY%" -m pip install --quiet --no-warn-script-location -r "%APPDIR%\app\requirements.txt"
) else (
    "%PY%" -m pip install --quiet --no-index --find-links "%CODESRC%wheels" -r "%APPDIR%\app\requirements.txt"
)
if !errorlevel! neq 0 ( echo [FEHLER] Abhaengigkeiten fehlgeschlagen. & goto :fail )
REM Windows-Schutzschichten (best effort): DPAPI-Bindung + Store-Verschluesselung.
REM Getrennt installieren: sqlcipher3-binary hat nur Linux-Wheels, unter Windows
REM kommt die Verschluesselung aus sqlcipher3-wheels (gleiches Modul sqlcipher3).
"%PY%" -m pip install --quiet --no-warn-script-location pywin32 >nul 2>&1
if !errorlevel! neq 0 echo        [Hinweis] pywin32 fehlgeschlagen - DPAPI-Schutz eingeschraenkt.
"%PY%" -m pip install --quiet --no-warn-script-location sqlcipher3-wheels >nul 2>&1
if !errorlevel! neq 0 "%PY%" -m pip install --quiet --no-warn-script-location sqlcipher3-binary >nul 2>&1
"%PY%" -c "import sqlcipher3" >nul 2>&1
if !errorlevel! neq 0 echo        [Hinweis] sqlcipher3 nicht installierbar - Store bleibt unverschluesselt.

REM --- 5) Stille Ersteinrichtung (Master-Secret, Store, Minimal-Config).
REM        Owner-Konto + Quell-DB werden danach IM BROWSER eingerichtet.
echo [5/7] Ersteinrichtung (ohne Rueckfragen)...
"%PY%" "%APPDIR%\app\installer\first_run.py" --appdir "%APPDIR%"
if !errorlevel! neq 0 ( echo [Hinweis] Ersteinrichtung unvollstaendig - beim ersten Start nachholbar. )

REM --- 6) Per-User Scheduled Task (naechtlicher Inkrement-Export in den Store)
echo [6/7] Registriere nutzerbezogenen Zeitplan (03:30 Uhr)...
schtasks /Create /F /SC DAILY /ST 03:30 /TN "GREENBAY clinical - Sync" ^
  /TR "\"%PY%\" \"%APPDIR%\app\agent\export.py\" --config \"%APPDIR%\config\config.yaml\" --mode incremental --out \"%APPDIR%\data\out\" --db \"%APPDIR%\data\clinical.db\"" ^
  /RU "%USERNAME%" >nul 2>&1
if !errorlevel! neq 0 ( echo [Hinweis] Task konnte nicht angelegt werden ^(Richtlinie^) - manuell moeglich. )

REM --- 7) Start.bat + Startmenue-Verknuepfung
echo [7/7] Erstelle Start.bat und Startmenue-Verknuepfung...
> "%APPDIR%\Start.bat" (
  echo @echo off
  echo title GREENBAY clinical
  echo "%PY%" "%APPDIR%\app\server\run.py"
)
set "LNK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\GREENBAY clinical.lnk"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%LNK%'); $s.TargetPath='%APPDIR%\Start.bat'; $s.WorkingDirectory='%APPDIR%'; $s.Save()" >nul 2>&1

rmdir /S /Q "%TMPD%" >nul 2>&1
echo(
echo  ============================================================
echo   Installation abgeschlossen. Naechste Schritte (im Browser):
echo    1. Start: Startmenue "GREENBAY clinical" oder %APPDIR%\Start.bat
echo       -^> http://127.0.0.1:8710 oeffnet sich automatisch
echo    2. Owner-Konto + TOTP in der Ersteinrichtungs-Maske anlegen
echo    3. Einstellungen -^> Quellverbindung (SQL Server) eintragen + testen
echo   Naechtlicher Sync laeuft um 03:30 Uhr (Task "GREENBAY clinical - Sync").
echo  ============================================================
echo(
pause
exit /b 0

:fail
echo(
echo  Installation abgebrochen.
pause
exit /b 1
