@echo off
REM GREENBAY clinical starten (nach erfolgter Installation via Setup.bat).
REM Startet den lokalen Server (nur 127.0.0.1) und oeffnet den Browser.
title GREENBAY clinical
set "APPDIR=%LOCALAPPDATA%\GreenbayClinical"

if not exist "%APPDIR%\app\server\run.py" (
    echo GREENBAY clinical ist noch nicht installiert.
    echo Bitte zuerst Setup.bat ausfuehren.
    pause
    exit /b 1
)

set "PY=%APPDIR%\python\python.exe"
if not exist "%PY%" set "PY=python"

"%PY%" "%APPDIR%\app\server\run.py"
