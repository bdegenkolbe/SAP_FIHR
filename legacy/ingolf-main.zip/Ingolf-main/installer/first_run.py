#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GREENBAY clinical - Ersteinrichtung (No-Admin, still).

Läuft ohne jede Konsolenfrage. Alles Interaktive passiert im Browser:
  - Owner-Konto + TOTP:      Ersteinrichtungs-Maske beim ersten Start (http://127.0.0.1:8710)
  - Quell-DB + Verbindungstest: Einstellungen -> "Quellverbindung (SQL Server)"

Dieses Skript legt nur die technische Basis an:
  1. Master-Secret erzeugen, DPAPI-geschützt ablegen (secret/master.bin)
  2. Lokalen Store (data/clinical.db) anlegen, Rollen/Rechte seeden
  3. Minimale config/config.yaml schreiben (Defaults; Rest kommt aus der UI
     per Write-Through)

Optional: --interactive stellt die alten Konsolenfragen (Quell-DB, Owner) für
Sonderfälle bereit; Standard im Setup ist der stille Lauf.
"""
from __future__ import annotations
import argparse, os, sys, json, secrets, base64, getpass


def _dpapi_protect(raw: bytes) -> bytes:
    """Master-Secret mit Windows DPAPI (CurrentUser) schuetzen. Fallback: unverschluesselt
    NICHT zulassen -> stattdessen deutlich markieren, dass DPAPI fehlt."""
    try:
        import win32crypt  # pywin32
        blob = win32crypt.CryptProtectData(raw, "GREENBAY clinical master secret",
                                           None, None, None, 0)
        return blob
    except Exception:
        # Fallback (nur Nicht-Windows/Dev): mit lokalem Schluessel maskieren + Warnung.
        sys.stderr.write("[WARN] DPAPI nicht verfuegbar - Secret NICHT hardwaregebunden "
                         "geschuetzt. Nur fuer Entwicklung akzeptabel.\n")
        return b"DEV\x00" + raw


def _write_config(cfgdir: str, cfg: dict) -> str:
    path = os.path.join(cfgdir, "config.yaml")
    with open(path, "w", encoding="utf-8") as f:
        try:
            import yaml
            yaml.safe_dump(cfg, f, allow_unicode=True, sort_keys=False)
        except Exception:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    return path


def bootstrap(appdir: str) -> bytes:
    """Stiller Kern: Secret + Store + Minimal-Config. Idempotent."""
    cfgdir = os.path.join(appdir, "config")
    secdir = os.path.join(appdir, "secret")
    os.makedirs(cfgdir, exist_ok=True)
    os.makedirs(secdir, exist_ok=True)

    # 1) Master-Secret (nur anlegen, wenn noch keins existiert!)
    master_path = os.path.join(secdir, "master.bin")
    if os.path.exists(master_path):
        print("  Master-Secret vorhanden - bleibt unveraendert.")
        blob = open(master_path, "rb").read()
        if blob.startswith(b"DEV\x00"):
            master = blob[4:]
        else:
            import win32crypt
            master = win32crypt.CryptUnprotectData(blob, None, None, None, 0)[1]
    else:
        master = secrets.token_bytes(32)
        with open(master_path, "wb") as f:
            f.write(_dpapi_protect(master))
        print("  Master-Secret erzeugt (DPAPI-geschuetzt).")

    # 2) Store anlegen + Rollen/Rechte seeden (Owner kommt aus der Browser-Maske)
    sys.path.insert(0, os.path.join(appdir, "app"))
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))  # Dev-Betrieb
    from store.db import open_store
    from server import rbac
    conn = open_store(os.path.join(appdir, "data", "clinical.db"), key=master)
    rbac.seed(conn)
    n_users = conn.execute("SELECT COUNT(*) AS n FROM sec_app_user").fetchone()["n"]
    conn.close()
    print(f"  Store bereit (Benutzer: {n_users}).")

    # 3) Minimal-Config (Quelle/Feineinstellungen pflegt die UI per Write-Through)
    cfg_path = os.path.join(cfgdir, "config.yaml")
    if not os.path.exists(cfg_path):
        _write_config(cfgdir, {
            "source": {"driver": "pytds"},
            # Klardaten-Praxisbetrieb als Standard (alle Daten bleiben im Haus);
            # Pseudonymisierung ist Export-Option (Einstellungen -> Datenschutz).
            "privacy": {"mode": "off", "gate": "off", "free_text_deid": False,
                        "hmac_key_ref": "secret/master.bin", "date_shift": True},
            "fhir": {"profile": "r4"},
            "server": {"bind": "127.0.0.1", "port": 8710},
        })
        print("  config/config.yaml angelegt (Defaults).")
    else:
        print("  config/config.yaml vorhanden - bleibt unveraendert.")
    return master


def interactive(appdir: str) -> None:
    """Alter Konsolen-Wizard fuer Sonderfaelle (Owner + Quell-DB an der Konsole)."""
    def ask(prompt, default=None, secret=False):
        d = f" [{default}]" if default else ""
        val = (getpass.getpass if secret else input)(f"  {prompt}{d}: ").strip()
        return val or default

    master = bootstrap(appdir)

    print("\n[Owner-Konto]")
    ouser = ask("Benutzername", "owner")
    while True:
        p1 = ask("Passwort (min. 12 Zeichen)", secret=True)
        p2 = ask("Passwort (Wdh.)", secret=True)
        if p1 and p1 == p2 and len(p1) >= 12:
            break
        print("  -> mind. 12 Zeichen und identisch.")
    from store.db import open_store
    from server import auth, rbac
    conn = open_store(os.path.join(appdir, "data", "clinical.db"), key=master)
    rbac.seed(conn)
    if conn.execute("SELECT COUNT(*) AS n FROM sec_app_user").fetchone()["n"]:
        print("  [Hinweis] Benutzer existieren bereits - Owner-Anlage uebersprungen.")
    else:
        result = auth.create_user(conn, master, ouser, ouser, p1, ["owner"])
        print("\n  TOTP-Enrollment (Authenticator-App):\n  " + result["totp_uri"])
        print("\n  Recovery-Codes (einmalig sichtbar):")
        print("  " + "  ".join(result["recovery_codes"]))
        ask("ENTER wenn notiert", default="")
    conn.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--appdir", required=True)
    ap.add_argument("--interactive", action="store_true",
                    help="Konsolen-Wizard (Owner an der Konsole) statt Browser-Einrichtung")
    args = ap.parse_args()

    print("=" * 60)
    print("  GREENBAY clinical - Ersteinrichtung")
    print("=" * 60)
    try:
        if args.interactive:
            interactive(args.appdir)
        else:
            bootstrap(args.appdir)
    except Exception as exc:
        print(f"[FEHLER] Ersteinrichtung: {exc}")
        return 1

    print("\n  Fertig. Die restliche Einrichtung laeuft im Browser:")
    print("    1. Anwendung starten (Startmenue 'GREENBAY clinical' / Start.bat)")
    print("    2. Owner-Konto + TOTP in der Ersteinrichtungs-Maske anlegen")
    print("    3. Einstellungen -> Quellverbindung (SQL Server) eintragen + testen")
    return 0


if __name__ == "__main__":
    sys.exit(main())
