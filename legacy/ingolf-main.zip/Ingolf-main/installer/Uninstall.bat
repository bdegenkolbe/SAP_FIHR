@echo off
REM GREENBAY clinical - Deinstallation (No-Admin). Entfernt Task, Verknuepfung, Ordner.
setlocal
set "APPDIR=%LOCALAPPDATA%\GreenbayClinical"
echo Entferne Zeitplan...
schtasks /Delete /F /TN "GREENBAY clinical - Sync" >nul 2>&1
echo Entferne Startmenue-Verknuepfung...
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\GREENBAY clinical.lnk" >nul 2>&1
echo Loesche Anwendungsordner (Daten bleiben, bis bestaetigt)...
choice /M "Auch Daten und Konfiguration loeschen"
if %errorlevel%==1 ( rmdir /S /Q "%APPDIR%" & echo Vollstaendig entfernt. ) else ( echo App entfernt, Daten belassen: %APPDIR%\data )
pause
