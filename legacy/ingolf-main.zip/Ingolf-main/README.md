# Klinische Datenplattform (EUGASTRO → FHIR/openEHR)

In der Praxis betriebenes Werkzeug: liest read-only das Praxis-MSSQL, exportiert alle
Patientendaten inkrementell nach FHIR R4 (und optional openEHR) in einen lokalen,
gesicherten Store, mit Benutzerverwaltung und Pseudonymisierung/Anonymisierung als
Export-Option. Dazu eine Analyseoberfläche mit intelligenter Volltextannotation.

Klardaten verlassen die Praxis nicht. Installation und Betrieb ohne Adminrechte.

## Struktur
```
klinik-datenplattform/
├── CLAUDE.md              # Arbeitsanleitung für Claude Code (zuerst lesen)
├── docs/
│   ├── CONCEPT.md         # Gesamtkonzept + Zielarchitektur (+ §13 Ergänzungen)
│   ├── SCHEMA.md          # Quell-Inventar + lokales DB-Schema (DDL)
│   ├── DEPLOYMENT.md      # No-Admin-Deployment (SQLCipher, pytds, DPAPI)
│   ├── SETUP.md           # Doppelklick-Installation ohne Adminrechte
│   ├── BENUTZERVERWALTUNG.md  # Rollen, Rechtematrix, Break-Glass
│   └── UI_SPEC.md         # Screens, Design-System, FHIR-Profil-Umschaltung
├── config/
│   ├── config.example.yaml
│   └── tables.yaml        # Datenlandkarte / Export-Registry
├── agent/                 # Extraktion → Mapping → Privacy → Load
│   ├── dbsource.py  privacy.py  meddok.py  mappers.py  openehr.py  export.py
│   └── profiles.py        # FHIR-Profil-Layer (R4 · MII-KDS · KBV)
├── store/                 # lokaler Store: SQLCipher/SQLite, Vault, NLP-Annotation, FTS5
│   ├── schema.sql  db.py  load.py  vault.py  annotate.py
├── server/                # Analyse-/Verwaltungs-API (FastAPI, nur 127.0.0.1)
│   ├── main.py  auth.py  rbac.py  patients.py  analysis.py  runtime.py
├── ui/
│   ├── design/            # Design-System (tokens.css, Single Source of Truth) + Logo
│   ├── mockups/           # klickbare Prototypen (Referenz)
│   └── app/               # produktive SPA (vanilla JS, kein Build-Schritt — No-Admin)
├── reference/             # Katalog-/Referenzdaten → FHIR-Terminologie (kein PHY)
│   ├── reference_mappers.py  build_reference.py  terminology.py
├── pvs/                   # PVS-Erweiterung: Kernel, Fall/Schein, KVDT, GOÄ/PADneXt
│   └── docs/pvs/          # Zielbild + Specs 00–70 + Review (Strangler-Pattern)
├── installer/             # No-Admin-Setup: Setup.bat, first_run.py, Uninstall.bat
├── tools/seed_demo.py     # Demo-DB + Owner-Konto ohne Praxis-DB (UI sofort testbar)
├── tests/                 # Smoke + Store + Auth/RBAC + API-E2E + Profil-Layer
└── out/                   # Exportausgabe (gitignored)
```

## Quickstart — Export (on-prem, Praxisnetz)
```bash
pip install -r requirements.txt
cp config/config.example.yaml config/config.yaml   # Werte + Secret setzen

# Golden-Record-Testfall (verifizierter Einzelpatient)
python agent/export.py --config config/config.yaml --patient 3659 --out ./out

# Voll-Export bzw. inkrementell; optional --openehr, --epa, --embed-anhaenge
#   --db data/clinical.db  -> zusaetzlich in den lokalen Store (inkl. Vault, ETL-Job)
#   --profile mii|kbv      -> FHIR-Profil-Ausleitung (Default: r4)
python agent/export.py --config config/config.yaml --mode full        --out ./out --db data/clinical.db
python agent/export.py --config config/config.yaml --mode incremental --out ./out --db data/clinical.db

# Referenz-/Katalogdaten (einmalig/periodisch), optional in den Store (--db)
python reference/build_reference.py --config config/config.yaml --out ./out --db data/clinical.db
```

## Quickstart — Analyseplattform (Server + UI)
```bash
# Erstlauf mit echten Daten: Ersteinrichtung erzeugt Owner-Konto + TOTP im Browser
GREENBAY_MASTER_SECRET=<master-secret> GREENBAY_DB=data/clinical.db python -m server.main
# -> http://127.0.0.1:8420/  (Patientenauswahl · 360°-Sicht · Analyse · Verwaltung)

# Ohne Praxis-DB ausprobieren (synthetische Demo-Daten + Owner-Konto):
python tools/seed_demo.py
```

Sicherheitsmodell (docs/BENUTZERVERWALTUNG.md): Rollen mit Rechtematrix (owner, clinician,
mfa, analyst, researcher, auditor, admin_tech), Login mit Argon2id + TOTP, Datenschutz-
Modus-Badge auf jedem Screen, Break-Glass-Re-Identifikation nur mit Re-Auth + Begründung,
append-only-Audit mit Hash-Kette, Aggregatschutz (n < 5 maskiert) in der Analyse.

Die Schutzschichten sind für den **In-Praxis-Betrieb konfigurierbar** (alle Daten bleiben
im Haus, `config.yaml` → `privacy`): `mode: off` für reinen Klardaten-Betrieb; bei
pseudonymisierten Auswertungen steuern `gate: enforce|warn|off`, `free_text_deid` und
`keep_filenames`, ob Dokumente/Briefe/Dateinamen mit Namen durchgelassen werden — das
Assertion-Gate prüft dann nur noch die aktiven Schichten (Strukturfelder bleiben immer
geschützt).

## Tests
```bash
python -m pytest tests/ -q        # Smoke + Store + Auth/RBAC + API-E2E + Profile
python tests/validate_modules.py  # Vollvalidierung + Konzept-Doku-Abgleich (ohne DB)
```

Ausgabe des Exports: ein FHIR-Bundle je Patient unter `out/fhir/<pseudonym>.json`,
Watermark in `out/_watermark.json`, optional openEHR-Vorstufe unter `out/openehr/`.

## Dokument-Intelligence (Anzeige · SNOMED-Annotation · Analyse)
- **Konzept:** `docs/DOKUMENTE_ANNOTATION.md`; Module: `agent/documents.py` (Magic-Bytes,
  Text, OCR-Hook), `agent/annotate.py` (NER/Negation/Kontext → Overlay + abgeleitete
  Ressourcen), `reference/terminology.py` (lokaler Katalog + FHIR-Terminologieserver),
  `agent/extract_anhaenge.py` (BLOB-Extraktor, läuft lokal in der Praxis).
- **Export:** `python agent/export.py … --annotate [--ocr] [--terminology-server URL]`
  bzw. dauerhaft über Einstellungen/`annotation:`-Block der Config.
- **Analyse:** Kohorten-Kriterium „Dokument-Konzept (SNOMED)", Provenienz-Schalter
  (strukturiert/NLP/beides); UI zeigt annotierte Volltexte mit Highlights.
- **Mockup:** `ui/mockups/dokumentsicht.html`.

## KI-Integration (Konzept)
Arztbrief-Assistent, Transkription, KI-OCR/Embeddings, LLM-Annotation, Wissensassistent
(RAG über SOPs/AWMF-Leitlinien), NL→Kohorte/Auswertung und Code Interpreter
(Python-Sandbox je Session, Container-Profil + No-Admin-Fallback) — über ein
konfigurierbares Gateway (chat/embed/transcribe/ocr/code) zu extern bereitgestellten
Endpunkten, mit Datenklassen-Policy, Prompt-Gate, Audit und ai-provenance.
**Konzept + Stufenplan: `docs/KI_INTEGRATION.md`** (Stufe 0–4, jede einzeln abnehmbar).

## PVS-Erweiterung (FHIR/openEHR-natives Praxissystem)
Strangler-Ausbau zum PVS (medatixx bleibt zunächst Abrechnungs-/TI-Terminal):
klinischer Kernel (Ereignisstrom), Fall/Schein-Aggregat, Migration EUGASTRO→Kernel,
KVDT/ADT-Serializer, GOÄ/PADneXt. Einstieg: `docs/pvs/00-OVERVIEW.md`; CLI:
`python -m pvs.cli migrate|validate-golden|kvdt-dry-run|goae-invoice`.
PVS-Sicht (Prototyp) ist in der App-Navigation verlinkt (`/mockups/pvssicht.html`).

## Einstellungen (zentral in der UI)
Alle Laufzeit-Konfigurationen liegen im Bereich **Einstellungen** (Recht
`settings.manage`): Datenschutz (Modus, Gate-Policy, Freitext-De-ID, Dateinamen,
Date-Shift), Dokument-Intelligence (Annotation, OCR, Confidence, Terminologieserver),
Analyse-Provenienz, FHIR-Profil, Theme. Änderungen werden in `config/config.yaml`
fortgeschrieben, sodass Agent-/Nachtläufe dieselben Werte nutzen. Nur die
Quellverbindung (DB-Login) und der Zeitplan bleiben in Ersteinrichtung/Task.

## Oberfläche & Setup
- **Produktive UI:** `ui/app/` — wird vom Server unter `/` ausgeliefert; Design aus
  `ui/design/tokens.css` (Single Source of Truth). Screens gemäß `docs/UI_SPEC.md`.
- **Mockups (klickbar):** `ui/mockups/index.html` (Referenz, synthetische Daten).
- **Installer (No-Admin):** `installer/Setup.bat` (+ `first_run.py`, `Uninstall.bat`);
  signierbare `Setup.exe` via PyInstaller (siehe `docs/SETUP.md`).
