# -*- coding: utf-8 -*-
"""GOAe-Rechnung + PADneXt-Export (docs/pvs/50-GOAE-PADNEXT-SPEC.md).

Skeleton mit tragfaehiger Fachlogik: Positionen, Faktor-Schwellen mit
Begruendungspflicht, Nummernkreis, padx-Paket (ZIP mit Auftragsdatei +
Rechnungs-XML). # VERIFY: PADneXt-XSD (PADline) einbinden und validieren.
"""
from __future__ import annotations
import dataclasses, datetime as _dt, decimal, io, zipfile
from decimal import Decimal
from xml.sax.saxutils import escape

decimal.getcontext().prec = 12

# Faktor-Schwellen (Regelhoechstsaetze): darueber Begruendungspflicht (§12 GOAe)
SCHWELLE = {"aerztlich": Decimal("2.3"), "technisch": Decimal("1.8"),
            "labor": Decimal("1.15")}
PUNKTWERT_EUR = Decimal("0.0582873")  # VERIFY: aktueller GOAe-Punktwert


@dataclasses.dataclass
class GoaePosition:
    ziffer: str
    text: str
    datum: str
    punktzahl: int
    faktor: Decimal = Decimal("2.3")
    leistungsart: str = "aerztlich"     # aerztlich | technisch | labor
    begruendung: str | None = None
    anzahl: int = 1

    def __post_init__(self):
        self.faktor = Decimal(str(self.faktor))
        if self.faktor > SCHWELLE[self.leistungsart] and not self.begruendung:
            raise ValueError(
                f"GOAe {self.ziffer}: Faktor {self.faktor} > Schwellwert "
                f"{SCHWELLE[self.leistungsart]} erfordert Begruendung (§12 GOAe)")

    @property
    def betrag(self) -> Decimal:
        einfach = (PUNKTWERT_EUR * self.punktzahl).quantize(Decimal("0.01"))
        return (einfach * self.faktor * self.anzahl).quantize(Decimal("0.01"))


@dataclasses.dataclass
class GoaeRechnung:
    rechnungsnr: str
    datum: str
    patient: dict                      # Klardaten — on-prem
    behandler: dict                    # {name, titel, adresse}
    positionen: list[GoaePosition]
    auslagen: list[tuple[str, Decimal]] = dataclasses.field(default_factory=list)
    diagnosen: list[str] = dataclasses.field(default_factory=list)
    status: str = "ENTWURF"

    @property
    def summe_positionen(self) -> Decimal:
        return sum((p.betrag for p in self.positionen), Decimal("0.00"))

    @property
    def gesamt(self) -> Decimal:
        return self.summe_positionen + sum((a[1] for a in self.auslagen), Decimal("0.00"))


def naechste_rechnungsnr(letzte: str | None, praefix: str, jahr: int) -> str:
    """Nummernkreis-Fortfuehrung: '<praefix><jahr>-<lfd>' ab MAX der Migration."""
    lfd = 0
    if letzte and "-" in letzte:
        try:
            lfd = int(letzte.rsplit("-", 1)[1])
        except ValueError:
            lfd = 0
    return f"{praefix}{jahr}-{lfd + 1:05d}"


# --- PADneXt ----------------------------------------------------------------
def rechnung_xml(r: GoaeRechnung) -> str:
    """Minimales Rechnungs-XML in PADneXt-Struktur.
    # VERIFY: gegen offizielle padnext-XSD ausrichten + Schema-Validierung."""
    pos = "\n".join(
        f'    <goziffer go="GOAE" ziffer="{escape(p.ziffer)}" datum="{p.datum}" '
        f'anzahl="{p.anzahl}" faktor="{p.faktor}" betrag="{p.betrag}">'
        f'{escape(p.text)}'
        + (f'<begruendung>{escape(p.begruendung)}</begruendung>' if p.begruendung else "")
        + "</goziffer>"
        for p in r.positionen)
    diag = "\n".join(f"    <diagnose>{escape(d)}</diagnose>" for d in r.diagnosen)
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        f'<rechnung nummer="{escape(r.rechnungsnr)}" datum="{r.datum}" '
        f'gesamtbetrag="{r.gesamt}">\n'
        f'  <patient name="{escape(r.patient.get("name",""))}" '
        f'vorname="{escape(r.patient.get("vorname",""))}" '
        f'geburtsdatum="{escape(str(r.patient.get("geburtsdatum","")))}"/>\n'
        f'  <behandler>{escape(r.behandler.get("name",""))}</behandler>\n'
        f'  <positionen>\n{pos}\n  </positionen>\n'
        f'  <diagnosen>\n{diag}\n  </diagnosen>\n'
        '</rechnung>\n')


def padx_paket(rechnungen: list[GoaeRechnung], absender_kundennr: str) -> bytes:
    """padx: ZIP mit Auftragsdatei + Rechnungsdateien."""
    now = _dt.datetime.now().strftime("%Y%m%d%H%M%S")
    auftrag = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        f'<auftrag erstellt="{now}" kundennr="{escape(absender_kundennr)}" '
        f'anzahl="{len(rechnungen)}"/>\n')
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(f"{absender_kundennr}_{now}_auftrag.pad", auftrag)
        for r in rechnungen:
            z.writestr(f"rechnung_{r.rechnungsnr}.xml", rechnung_xml(r))
    return buf.getvalue()
