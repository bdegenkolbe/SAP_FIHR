-- PVS-Kernel-Schema (SQLite-first, Postgres-kompatibel gehalten)
-- Siehe docs/pvs/10-KERNEL-SPEC.md

CREATE TABLE IF NOT EXISTS events (
    seq           INTEGER PRIMARY KEY,          -- Postgres: BIGSERIAL/IDENTITY
    event_id      TEXT NOT NULL UNIQUE,
    occurred_at   TEXT NOT NULL,                -- ISO-8601
    recorded_at   TEXT NOT NULL,
    patient_id    TEXT NOT NULL,
    fall_id       TEXT,
    actor         TEXT,
    event_type    TEXT NOT NULL,
    resource_type TEXT NOT NULL,
    resource_id   TEXT NOT NULL,
    payload       TEXT NOT NULL,                -- FHIR-JSON, kanonisch
    source        TEXT NOT NULL,
    source_ref    TEXT,
    supersedes    TEXT REFERENCES events(event_id),
    hash          TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_events_source
    ON events(source, source_ref) WHERE source_ref IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_events_patient_time
    ON events(patient_id, occurred_at);
CREATE INDEX IF NOT EXISTS ix_events_resource
    ON events(resource_type, resource_id);

-- Materialisierter Ressourcen-Store: aktuelle Version je (type,id)
CREATE TABLE IF NOT EXISTS resources (
    resource_type TEXT NOT NULL,
    resource_id   TEXT NOT NULL,
    patient_id    TEXT,
    version       INTEGER NOT NULL DEFAULT 1,
    updated_at    TEXT NOT NULL,
    deleted       INTEGER NOT NULL DEFAULT 0,
    payload       TEXT NOT NULL,
    PRIMARY KEY (resource_type, resource_id)
);
CREATE INDEX IF NOT EXISTS ix_resources_patient ON resources(patient_id);

-- Fall/Schein-Aggregat (docs/pvs/20-FALL-SCHEIN-SPEC.md)
CREATE TABLE IF NOT EXISTS faelle (
    fall_id            TEXT PRIMARY KEY,
    patient_id         TEXT NOT NULL,
    quartal            TEXT NOT NULL,            -- "Q/JJJJ"
    fall_art           TEXT NOT NULL,            -- KURATIV|UEBERWEISUNG|BELEG|NOTFALL|PRIVAT|IGEL|HZV
    schein_untergruppe TEXT,
    kostentraeger      TEXT,                     -- JSON {ik,name,versichertenart,...}
    privat             TEXT,                     -- JSON {versicherung,...}
    betriebsstaette    TEXT,                     -- JSON {bsnr,...}
    behandler          TEXT,                     -- JSON [{lanr,kuerzel}]
    ueberweisung       TEXT,                     -- JSON
    gueltig_von        TEXT,
    gueltig_bis        TEXT,
    status             TEXT NOT NULL DEFAULT 'OFFEN',
    source_ref         TEXT UNIQUE               -- "Schein:<Id>"
);
CREATE INDEX IF NOT EXISTS ix_faelle_patient ON faelle(patient_id, quartal);

-- Quarantäne für Zuordnungsanomalien (PATID-Check, CONCEPT §1.5)
CREATE TABLE IF NOT EXISTS quarantine (
    id          INTEGER PRIMARY KEY,
    recorded_at TEXT NOT NULL,
    source_ref  TEXT NOT NULL,
    reason      TEXT NOT NULL,
    raw         TEXT NOT NULL
);

-- ETL-Zustand (High-Watermarks je Tabelle)
CREATE TABLE IF NOT EXISTS etl_state (
    table_name TEXT PRIMARY KEY,
    hwm_hex    TEXT,                             -- rowversion als Hex
    last_run   TEXT
);
