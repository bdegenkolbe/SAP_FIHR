# -*- coding: utf-8 -*-
"""Kernel-Store: SQLite-Implementierung (Dev/No-Admin), Schema portabel nach
PostgreSQL (docs/pvs/10-KERNEL-SPEC.md). SQLCipher-Option wie Plattform-Store.
"""
from __future__ import annotations
import json, os, sqlite3
from typing import Iterable, Optional

from pvs.model.events import Event

_SCHEMA = os.path.join(os.path.dirname(__file__), "schema.sql")


class KernelStore:
    def __init__(self, path: str):
        self.path = path
        self.con = sqlite3.connect(path)
        self.con.row_factory = sqlite3.Row
        self.con.executescript(open(_SCHEMA, encoding="utf-8").read())

    # -- Events --------------------------------------------------------------
    def find_event_by_source(self, source: str, source_ref: str) -> Optional[sqlite3.Row]:
        return self.con.execute(
            "SELECT * FROM events WHERE source=? AND source_ref=? "
            "ORDER BY seq DESC LIMIT 1", (source, source_ref)).fetchone()

    def append_event(self, ev: Event) -> str:
        """Idempotenter Append. Rueckgabe: 'inserted' | 'unchanged' | 'superseded'.

        Idempotenz-Schluessel ist (source, source_ref). Gleicher Schluessel +
        gleicher Hash => unchanged. Gleicher Schluessel-Praefix (Tabelle:PK) mit
        anderem Hash => neues Event mit supersedes (Korrektur/Quelldelta).
        """
        if ev.source_ref:
            prev = self.find_event_by_source(ev.source, ev.source_ref)
            if prev:
                if prev["hash"] == ev.hash:
                    return "unchanged"
                ev.supersedes = prev["event_id"]
                # source_ref bleibt gleich -> unique index: alten Eintrag
                # behalten wir; neuer bekommt Versions-Suffix
                ev.source_ref = f"{ev.source_ref}#v{prev['seq']}"
        r = ev.row()
        self.con.execute(
            "INSERT INTO events (event_id,occurred_at,recorded_at,patient_id,"
            "fall_id,actor,event_type,resource_type,resource_id,payload,source,"
            "source_ref,supersedes,hash) VALUES "
            "(:event_id,:occurred_at,:recorded_at,:patient_id,:fall_id,:actor,"
            ":event_type,:resource_type,:resource_id,:payload,:source,"
            ":source_ref,:supersedes,:hash)", r)
        self._materialize(ev)
        self.con.commit()
        return "superseded" if ev.supersedes else "inserted"

    def _materialize(self, ev: Event):
        row = self.con.execute(
            "SELECT version FROM resources WHERE resource_type=? AND resource_id=?",
            (ev.resource_type, ev.resource_id)).fetchone()
        if row:
            self.con.execute(
                "UPDATE resources SET version=?, updated_at=?, payload=?, patient_id=? "
                "WHERE resource_type=? AND resource_id=?",
                (row["version"] + 1, ev.recorded_at, json.dumps(ev.payload, ensure_ascii=False),
                 ev.patient_id, ev.resource_type, ev.resource_id))
        else:
            self.con.execute(
                "INSERT INTO resources (resource_type,resource_id,patient_id,version,"
                "updated_at,payload) VALUES (?,?,?,?,?,?)",
                (ev.resource_type, ev.resource_id, ev.patient_id, 1,
                 ev.recorded_at, json.dumps(ev.payload, ensure_ascii=False)))

    # -- Lesen ----------------------------------------------------------------
    def timeline(self, patient_id: str) -> list[sqlite3.Row]:
        """Aktuelle Akte: je Korrekturkette nur das juengste Event (Kopf der
        supersedes-Kette). Historie bleibt vollstaendig in events."""
        return self.con.execute(
            "SELECT * FROM events e WHERE e.patient_id=? AND NOT EXISTS "
            "  (SELECT 1 FROM events s WHERE s.supersedes = e.event_id) "
            "ORDER BY e.occurred_at, e.seq", (patient_id,)).fetchall()

    def current(self, patient_id: str, resource_type: str | None = None) -> list[dict]:
        q = "SELECT payload FROM resources WHERE patient_id=? AND deleted=0"
        p: list = [patient_id]
        if resource_type:
            q += " AND resource_type=?"
            p.append(resource_type)
        return [json.loads(r["payload"]) for r in self.con.execute(q, p)]

    # -- Fall-Aggregat ---------------------------------------------------------
    def upsert_fall(self, fall: dict):
        cols = ("fall_id patient_id quartal fall_art schein_untergruppe kostentraeger "
                "privat betriebsstaette behandler ueberweisung gueltig_von gueltig_bis "
                "status source_ref").split()
        vals = {c: fall.get(c) for c in cols}
        for c in ("kostentraeger", "privat", "betriebsstaette", "behandler", "ueberweisung"):
            if isinstance(vals[c], (dict, list)):
                vals[c] = json.dumps(vals[c], ensure_ascii=False)
        self.con.execute(
            f"INSERT INTO faelle ({','.join(cols)}) VALUES ({','.join(':'+c for c in cols)}) "
            f"ON CONFLICT(source_ref) DO UPDATE SET " +
            ",".join(f"{c}=excluded.{c}" for c in cols if c != "fall_id"), vals)
        self.con.commit()

    def faelle(self, patient_id: str | None = None, quartal: str | None = None) -> list[dict]:
        q, p = "SELECT * FROM faelle WHERE 1=1", []
        if patient_id:
            q += " AND patient_id=?"; p.append(patient_id)
        if quartal:
            q += " AND quartal=?"; p.append(quartal)
        out = []
        for r in self.con.execute(q, p):
            d = dict(r)
            for c in ("kostentraeger", "privat", "betriebsstaette", "behandler", "ueberweisung"):
                if d.get(c):
                    d[c] = json.loads(d[c])
            out.append(d)
        return out

    # -- Quarantaene / ETL-State -------------------------------------------------
    def quarantine(self, source_ref: str, reason: str, raw: dict):
        from pvs.model.events import now_iso
        self.con.execute(
            "INSERT INTO quarantine (recorded_at,source_ref,reason,raw) VALUES (?,?,?,?)",
            (now_iso(), source_ref, reason, json.dumps(raw, ensure_ascii=False)))
        self.con.commit()

    def get_hwm(self, table: str) -> str | None:
        r = self.con.execute("SELECT hwm_hex FROM etl_state WHERE table_name=?", (table,)).fetchone()
        return r["hwm_hex"] if r else None

    def set_hwm(self, table: str, hwm_hex: str):
        from pvs.model.events import now_iso
        self.con.execute(
            "INSERT INTO etl_state (table_name,hwm_hex,last_run) VALUES (?,?,?) "
            "ON CONFLICT(table_name) DO UPDATE SET hwm_hex=excluded.hwm_hex, "
            "last_run=excluded.last_run", (table, hwm_hex, now_iso()))
        self.con.commit()

    def close(self):
        self.con.close()
