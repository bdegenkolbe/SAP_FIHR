# -*- coding: utf-8 -*-
"""PVS-CLI (docs/pvs/00-OVERVIEW.md).

  python -m pvs.cli init-store --db ./out/pvs.db
  python -m pvs.cli migrate --config config/pvs.yaml [--patient N | --mode full|incremental]
  python -m pvs.cli validate-golden --db ./out/pvs.db --patient 76824
  python -m pvs.cli kvdt-dry-run --db ./out/pvs.db --quartal 2/2026 --out ./out/adt
  python -m pvs.cli goae-demo
"""
from __future__ import annotations
import argparse, os, sys


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    ap = argparse.ArgumentParser(prog="pvs")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("init-store")
    p.add_argument("--db", default="./out/pvs.db")

    p = sub.add_parser("migrate")
    p.add_argument("--config", required=True)
    p.add_argument("--db", default="./out/pvs.db")
    p.add_argument("--patient", type=int)
    p.add_argument("--mode", choices=("full", "incremental"))
    p.add_argument("--limit", type=int)

    p = sub.add_parser("validate-golden")
    p.add_argument("--db", required=True)
    p.add_argument("--patient", required=True)

    p = sub.add_parser("kvdt-dry-run")
    p.add_argument("--db", required=True)
    p.add_argument("--quartal", required=True)      # "Q/JJJJ"
    p.add_argument("--out", default="./out/adt")
    p.add_argument("--bsnr", default="000000000")
    p.add_argument("--kv", default="00")

    sub.add_parser("goae-demo")

    args = ap.parse_args(argv)

    if args.cmd == "init-store":
        from pvs.store.kernelstore import KernelStore
        os.makedirs(os.path.dirname(os.path.abspath(args.db)), exist_ok=True)
        KernelStore(args.db).close()
        print(f"Kernel-Store angelegt: {args.db}")

    elif args.cmd == "migrate":
        from pvs.etl import migrate as mig
        mig.main(["--config", args.config, "--db", args.db]
                 + (["--patient", str(args.patient)] if args.patient else [])
                 + (["--mode", args.mode] if args.mode else [])
                 + (["--limit", str(args.limit)] if args.limit else []))

    elif args.cmd == "validate-golden":
        from pvs.etl import validate_golden as vg
        vg.main(["--db", args.db, "--patient", args.patient])

    elif args.cmd == "kvdt-dry-run":
        from pvs.store.kernelstore import KernelStore
        from pvs.kvdt.serializer import serialize_quartal
        store = KernelStore(args.db)
        faelle = store.faelle(quartal=args.quartal)
        pats = {f["patient_id"]: _patient_ctx(store, f["patient_id"]) for f in faelle}
        content, stats = serialize_quartal(
            faelle, pats,
            bs={"bsnr": args.bsnr, "name": "Praxis"},
            paket={"laufende_nr": "001", "kvdt_version": "VERIFY",
                   "empfaenger_kv": args.kv})
        os.makedirs(args.out, exist_ok=True)
        path = os.path.join(args.out, f"{args.bsnr}_{args.quartal.replace('/','')}.con")
        with open(path, "w", encoding="iso-8859-15", newline="") as f:
            f.write(content)
        print(f"ADT-Datei: {path}  {stats}")

    elif args.cmd == "goae-demo":
        from decimal import Decimal
        from pvs.goae.goae import GoaePosition, GoaeRechnung, padx_paket
        r = GoaeRechnung(
            rechnungsnr="EUG2026-00001", datum="2026-07-14",
            patient={"name": "Muster", "vorname": "Max", "geburtsdatum": "1976-07-24"},
            behandler={"name": "Prof. Dr. med. Beispiel"},
            positionen=[
                GoaePosition("1", "Beratung", "2026-07-14", punktzahl=80),
                GoaePosition("8", "Untersuchung", "2026-07-14", punktzahl=260),
                GoaePosition("435", "Sonographie Abdomen", "2026-07-14",
                             punktzahl=200, leistungsart="technisch",
                             faktor=Decimal("1.8")),
            ],
            diagnosen=["K76.0 G MASLD"])
        pkg = padx_paket([r], absender_kundennr="DEMO")
        os.makedirs("./out", exist_ok=True)
        open("./out/demo.padx", "wb").write(pkg)
        print(f"Rechnung {r.rechnungsnr}: {r.gesamt} EUR, padx: ./out/demo.padx")


def _patient_ctx(store, patient_id: str) -> dict:
    """Patient-Kontext fuer KVDT aus dem Ressourcen-Store."""
    pats = store.current(patient_id, "Patient")
    p = pats[0] if pats else {}
    name = (p.get("name") or [{}])[0]
    bd = str(p.get("birthDate") or "")
    return {
        "patient_nr": (p.get("identifier") or [{}])[0].get("value", patient_id),
        "name": name.get("family", ""),
        "vorname": " ".join(name.get("given", [])),
        "geburtsdatum": f"{bd[8:10]}{bd[5:7]}{bd[0:4]}" if len(bd) >= 10 else "",
        "geschlecht": {"male": "M", "female": "W"}.get(p.get("gender"), "X"),
        "versichertennr": None,
    }


if __name__ == "__main__":
    main()
