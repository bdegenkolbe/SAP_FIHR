# -*- coding: utf-8 -*-
"""xDT-Grundsyntax (docs/pvs/40-KVDT-SERIALIZER-SPEC.md).

Zeile: LLL + FFFF + Inhalt + CR/LF, Laenge = 3+4+len+2.
Zeichensatz-Default ISO 8859-15.  # VERIFY: aktuelle KVDT-Satzbeschreibung.
"""
from __future__ import annotations

ENCODING = "iso-8859-15"
CRLF = "\r\n"


def encode_field(fk: str, value: str) -> str:
    if len(fk) != 4 or not fk.isdigit():
        raise ValueError(f"Feldkennung muss 4-stellig numerisch sein: {fk!r}")
    v = "" if value is None else str(value)
    length = 3 + 4 + len(v.encode(ENCODING)) + 2
    if length > 999:
        raise ValueError(f"Feld {fk} zu lang ({length})")
    return f"{length:03d}{fk}{v}{CRLF}"


def encode_satz(fields: list[tuple[str, str]]) -> str:
    """fields: geordnete (FK, Wert)-Liste; erstes Feld muss 8000 (Satzart) sein."""
    if not fields or fields[0][0] != "8000":
        raise ValueError("Satz muss mit FK 8000 (Satzart) beginnen")
    return "".join(encode_field(fk, v) for fk, v in fields if v not in (None, ""))


def parse(data: str) -> list[tuple[str, str]]:
    """Roundtrip-Parser (fuer Tests und XPM-Fehleranalyse)."""
    out = []
    i, n = 0, len(data)
    while i < n:
        length = int(data[i:i + 3])
        fk = data[i + 3:i + 7]
        content = data[i + 7:i + length - 2]
        out.append((fk, content))
        i += length
    return out


def satz_laenge_bytes(satz: str) -> int:
    return len(satz.encode(ENCODING))
