# -*- coding: utf-8 -*-
"""Deklaratives KVDT-Satzarten-Registry (docs/pvs/40-KVDT-SERIALIZER-SPEC.md).

ARBEITSSTAND: Struktur nach xDT-Systematik; Feldlisten sind gegen die aktuelle
KVDT-Satzbeschreibung der KBV zu verifizieren und zu vervollstaendigen
(# VERIFY, Zugang via KBV-ITA). Der Serializer ist registry-getrieben und
bleibt bei Verifikation unveraendert.
"""
from __future__ import annotations

# Feld: (fk, pflicht, quelle)  — quelle = dotted path in den Serialisierungs-Kontext
SATZARTEN: dict[str, list[tuple[str, bool, str]]] = {
    # Container/Paket-Rahmen  # VERIFY: vollstaendige Pflichtfelder
    "con0": [("8000", True, "=con0"),
             ("9105", True, "paket.laufende_nr"),
             ("9212", True, "paket.kvdt_version")],
    "besa": [("8000", True, "=besa"),
             ("0201", True, "bs.bsnr"),
             ("0203", True, "bs.name")],
    "adt0": [("8000", True, "=adt0"),
             ("9102", True, "paket.empfaenger_kv"),
             ("9103", True, "paket.erstellungsdatum"),   # TTMMJJJJ
             ("9106", True, "paket.zeichensatz"),
             ("9212", True, "paket.kvdt_version")],
    # Abrechnungsschein (ambulante Behandlung)  # VERIFY Satzart-Codes 0101..0104
    "0101": [("8000", True, "=0101"),
             ("3000", True, "patient.patient_nr"),
             ("3101", True, "patient.name"),
             ("3102", True, "patient.vorname"),
             ("3103", True, "patient.geburtsdatum"),      # TTMMJJJJ
             ("3110", True, "patient.geschlecht"),
             ("3105", False, "patient.versichertennr"),   # VERIFY vs. 3119 eGK-ID
             ("4101", True, "fall.quartal_jjjjq"),
             ("4102", False, "fall.ausstellungsdatum"),
             ("4104", True, "fall.kostentraeger_ik"),
             ("4121", False, "fall.gebuehrenordnung"),
             ("4122", False, "fall.abrechnungsgebiet"),
             ("4239", True, "fall.schein_untergruppe")],
    "adt9": [("8000", True, "=adt9"),
             ("9202", True, "paket.anzahl_saetze")],
    "con9": [("8000", True, "=con9")],
}

# Wiederholgruppen innerhalb 0101 (je Leistung / je Diagnose)
GRUPPE_LEISTUNG = [("5000", True, "datum"), ("5001", True, "gnr"),
                   ("5005", False, "multiplikator"), ("5006", False, "uhrzeit"),
                   ("5098", True, "bsnr"), ("5099", True, "lanr")]
GRUPPE_DIAGNOSE = [("6001", True, "icd"), ("6003", True, "sicherheit"),
                   ("6004", False, "lokalisation")]
