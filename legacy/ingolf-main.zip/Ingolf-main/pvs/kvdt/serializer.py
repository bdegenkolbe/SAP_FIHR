# -*- coding: utf-8 -*-
"""KVDT/ADT-Serializer: Fall-Aggregate -> ADT-Datei (Dry-Run fuer XPM).

Registry-getrieben (satzarten.py). PRIVAT/IGEL-Faelle erzeugen keinen Output
(Invariante 3, docs/pvs/20-FALL-SCHEIN-SPEC.md) — sie laufen ueber den GOAe-Pfad.
"""
from __future__ import annotations
import datetime as _dt

from pvs.kvdt.encoder import encode_satz
from pvs.kvdt.satzarten import SATZARTEN, GRUPPE_LEISTUNG, GRUPPE_DIAGNOSE


def _resolve(ctx: dict, path: str):
    if path.startswith("="):
        return path[1:]
    cur = ctx
    for p in path.split("."):
        if not isinstance(cur, dict):
            return None
        cur = cur.get(p)
    return cur


def build_satz(name: str, ctx: dict,
               leistungen: list[dict] | None = None,
               diagnosen: list[dict] | None = None) -> str:
    fields = []
    for fk, pflicht, quelle in SATZARTEN[name]:
        v = _resolve(ctx, quelle)
        if v in (None, "") and pflicht:
            raise ValueError(f"Satz {name}: Pflichtfeld {fk} ({quelle}) fehlt")
        fields.append((fk, v))
    for d in diagnosen or []:
        for fk, pflicht, key in GRUPPE_DIAGNOSE:
            v = d.get(key)
            if v in (None, "") and pflicht:
                raise ValueError(f"Diagnosegruppe: Pflichtfeld {fk} fehlt")
            fields.append((fk, v))
    for l in leistungen or []:
        for fk, pflicht, key in GRUPPE_LEISTUNG:
            v = l.get(key)
            if v in (None, "") and pflicht:
                raise ValueError(f"Leistungsgruppe: Pflichtfeld {fk} fehlt")
            fields.append((fk, v))
    return encode_satz(fields)


def quartal_jjjjq(quartal: str) -> str:
    q, jahr = quartal.split("/")
    return f"{jahr}{q}"


def serialize_quartal(faelle: list[dict], patient_by_id: dict,
                      bs: dict, paket: dict) -> tuple[str, dict]:
    """faelle: Kernel-Fall-Aggregate (GKV) + je Fall 'diagnosen'/'leistungen'.
    Rueckgabe: (ADT-Dateiinhalt, Statistik)."""
    stats = {"faelle": 0, "uebersprungen_privat": 0}
    body = []
    for f in faelle:
        if f["fall_art"] in ("PRIVAT", "IGEL"):
            stats["uebersprungen_privat"] += 1
            continue
        pat = patient_by_id[f["patient_id"]]
        ctx = {
            "patient": pat,
            "fall": {
                "quartal_jjjjq": quartal_jjjjq(f["quartal"]),
                "ausstellungsdatum": _ddmmyyyy(f.get("gueltig_von")),
                "kostentraeger_ik": (f.get("kostentraeger") or {}).get("ik"),
                "gebuehrenordnung": f.get("gebuehrenordnung"),
                "abrechnungsgebiet": f.get("abrechnungsgebiet", "00"),
                "schein_untergruppe": f.get("schein_untergruppe"),
            },
        }
        body.append(build_satz("0101", ctx,
                               leistungen=f.get("leistungen"),
                               diagnosen=f.get("diagnosen_kvdt")))
        stats["faelle"] += 1

    paket = dict(paket)
    paket.setdefault("erstellungsdatum", _dt.date.today().strftime("%d%m%Y"))
    paket.setdefault("zeichensatz", "2")   # VERIFY Codeliste 9106
    paket["anzahl_saetze"] = str(stats["faelle"])
    rahmen_ctx = {"paket": paket, "bs": bs}
    out = (build_satz("con0", rahmen_ctx) + build_satz("besa", rahmen_ctx)
           + build_satz("adt0", rahmen_ctx) + "".join(body)
           + build_satz("adt9", rahmen_ctx) + build_satz("con9", rahmen_ctx))
    return out, stats


def _ddmmyyyy(iso):
    if not iso:
        return None
    s = str(iso)
    return f"{s[8:10]}{s[5:7]}{s[0:4]}" if len(s) >= 10 else None
