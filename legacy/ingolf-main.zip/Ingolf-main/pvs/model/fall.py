# -*- coding: utf-8 -*-
"""Fall/Schein-Aggregat (docs/pvs/20-FALL-SCHEIN-SPEC.md).

Baut aus einer dbo.Schein-Zeile (Spalten wie in agent/export.py Q_SCHEIN
verifiziert) das Fall-Aggregat und liefert die KVDT-Feldzuordnung.
"""
from __future__ import annotations
import uuid
from typing import Any

# Geschlecht Quelle -> KVDT FK 3110 (VERIFY Codeliste aktueller Satzbeschreibung)
GESCHLECHT_KVDT = {1: "W", 2: "M", 3: "X", 4: "D"}  # Quelle: 2=m verifiziert

FALL_ART = ("KURATIV", "UEBERWEISUNG", "BELEG", "NOTFALL", "PRIVAT", "IGEL", "HZV")


def derive_fall_art(schein: dict) -> str:
    if schein.get("IsIgel"):
        return "IGEL"
    if schein.get("IsPrivat"):
        return "PRIVAT"
    if schein.get("HzvVertragKennung"):
        return "HZV"
    if schein.get("UeberweisungVon") or schein.get("BsnrUeberweiser"):
        return "UEBERWEISUNG"
    if schein.get("IsStationaer"):
        return "BELEG"
    return "KURATIV"


def quartal_norm(schein: dict) -> str:
    """Quelle liefert Quartal/Abrechnungsquartal; Normalform 'Q/JJJJ'."""
    q = schein.get("Abrechnungsquartal") or schein.get("Quartal") or ""
    q = str(q)
    if "/" in q:
        return q
    if len(q) == 5 and q.isdigit():  # QJJJJ oder JJJJQ — Jahr-Plausibilitaet entscheidet
        if q[0] in "1234" and 1990 <= int(q[1:]) <= 2199:
            return f"{q[0]}/{q[1:]}"          # QJJJJ (z. B. 22026)
        if q[4] in "1234" and 1990 <= int(q[:4]) <= 2199:
            return f"{q[4]}/{q[:4]}"          # JJJJQ (z. B. 20262)
    # Fallback: aus Ausstellungsdatum
    d = str(schein.get("AusstellungsDateTime") or schein.get("ScheinGueltigVon") or "")
    if len(d) >= 7:
        y, m = d[:4], int(d[5:7])
        return f"{(m - 1) // 3 + 1}/{y}"
    return ""


def build_fall(patient_id: str, schein: dict, behandler_kuerzel: str | None = None) -> dict:
    art = derive_fall_art(schein)
    fall = {
        "fall_id": str(uuid.uuid4()),
        "patient_id": patient_id,
        "quartal": quartal_norm(schein),
        "fall_art": art,
        "schein_untergruppe": schein.get("Scheinuntergruppe"),
        "kostentraeger": None,
        "privat": None,
        "betriebsstaette": None,
        "behandler": [{"kuerzel": behandler_kuerzel}] if behandler_kuerzel else [],
        "ueberweisung": None,
        "gueltig_von": schein.get("ScheinGueltigVon") or schein.get("AusstellungsDateTime"),
        "gueltig_bis": None,
        "status": "OFFEN",
        "source_ref": f"Schein:{schein.get('Id')}",
    }
    if art in ("PRIVAT", "IGEL"):
        fall["privat"] = {"versicherung": schein.get("KassenName"),
                          "rechnungs_typ": schein.get("RechnungsTyp")}
    else:
        fall["kostentraeger"] = {"ik": schein.get("Iknr"),
                                 "name": schein.get("KassenName")}
    if art == "UEBERWEISUNG":
        fall["ueberweisung"] = {
            "von": schein.get("UeberweisungVon"),
            "von_bsnr": schein.get("BsnrUeberweiser"),
            "von_lanr": schein.get("LanrUeberweiser"),
            "an": schein.get("UeberweisungAn"),
            "auftrag": schein.get("Auftrag"),
            "diagnose_verdacht": schein.get("DiagnoseVerdacht"),
            "zielauftrag": bool(schein.get("IsZielauftrag")),
        }
    return fall


def fall_to_fhir(fall: dict) -> list[dict]:
    """Projektion Fall -> FHIR Encounter + Account (+ Coverage bei GKV/PKV)."""
    enc = {
        "resourceType": "Encounter",
        "id": f"encounter-eug-{fall['source_ref'].split(':')[1]}",
        "status": "finished" if fall["status"] != "OFFEN" else "in-progress",
        "class": {"system": "http://terminology.hl7.org/CodeSystem/v3-ActCode",
                  "code": "AMB"},
        "subject": {"reference": f"Patient/{fall['patient_id']}"},
        "extension": [{
            "url": "https://greenbay-healthcare.de/fhir/StructureDefinition/fall-art",
            "valueCode": fall["fall_art"],
        }],
    }
    acc = {
        "resourceType": "Account",
        "id": f"account-eug-{fall['source_ref'].split(':')[1]}",
        "status": "active",
        "subject": [{"reference": f"Patient/{fall['patient_id']}"}],
        "description": f"Fall {fall['quartal']} ({fall['fall_art']})",
    }
    out = [enc, acc]
    kt = fall.get("kostentraeger") or {}
    pv = fall.get("privat") or {}
    if kt.get("ik") or pv.get("versicherung"):
        cov = {
            "resourceType": "Coverage",
            "id": f"coverage-eug-{fall['source_ref'].split(':')[1]}",
            "status": "active",
            "beneficiary": {"reference": f"Patient/{fall['patient_id']}"},
            "payor": [{"display": kt.get("name") or pv.get("versicherung")}],
            "type": {"coding": [{
                "system": "http://fhir.de/CodeSystem/versicherungsart-de-basis",
                "code": "GKV" if kt.get("ik") else "PKV"}]},
        }
        if kt.get("ik"):
            cov["payor"][0]["identifier"] = {
                "system": "http://fhir.de/sid/arge-ik/iknr", "value": str(kt["ik"])}
        out.append(cov)
    return out


# KVDT-Feldzuordnung (Struktur verbindlich, FK-Nummern VERIFY — siehe Spec §KVDT)
KVDT_FELDER_FALL = {
    "quartal": "4101",            # Format JJJJQ
    "ausstellungsdatum": "4102",
    "kostentraeger_ik": "4104",
    "ktab": "4106",               # VERIFY
    "gebuehrenordnung": "4121",
    "abrechnungsgebiet": "4122",
    "schein_untergruppe": "4239",
}
KVDT_FELDER_PATIENT = {
    "patient_nr": "3000", "name": "3101", "vorname": "3102",
    "geburtsdatum": "3103", "geschlecht": "3110",
    "versichertennr": "3105",     # VERIFY (eGK: Versicherten-ID 3119)
}
KVDT_FELDER_LEISTUNG = {
    "datum": "5000", "gnr": "5001", "multiplikator": "5005",
    "uhrzeit": "5006", "bsnr": "5098", "lanr": "5099",
}
KVDT_FELDER_DIAGNOSE = {
    "icd": "6001", "sicherheit": "6003", "lokalisation": "6004",
}
