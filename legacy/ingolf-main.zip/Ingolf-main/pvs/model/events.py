# -*- coding: utf-8 -*-
"""Ereignismodell des PVS-Kernels (docs/pvs/10-KERNEL-SPEC.md).

Append-only, idempotent ueber (source, source_ref), Korrektur via supersedes.
"""
from __future__ import annotations
import dataclasses, hashlib, json, uuid, datetime as _dt
from typing import Any, Optional

# Kontrolliertes event_type-Vokabular (v1) — nur additiv erweitern.
EVENT_TYPES = {
    "patient.angelegt", "patient.geaendert",
    "diagnose.dokumentiert", "befund.dokumentiert", "anamnese.dokumentiert",
    "verlauf.dokumentiert", "vitalwert.erfasst", "labor.ergebnis",
    "medikation.verordnet", "medikation.status", "heilmittel.verordnet",
    "au.ausgestellt", "brief.erstellt", "cave.gesetzt", "notiz.erfasst",
    "termin.geplant", "fall.eroeffnet", "fall.geschlossen",
    "leistung.erfasst", "rechnung.gestellt", "consent.erfasst",
    "dokument.erfasst",
}


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def now_iso() -> str:
    return _dt.datetime.now().replace(microsecond=0).isoformat()


@dataclasses.dataclass
class Event:
    occurred_at: str
    patient_id: str
    event_type: str
    resource_type: str
    resource_id: str
    payload: dict
    source: str
    source_ref: Optional[str] = None
    fall_id: Optional[str] = None
    actor: Optional[str] = None
    supersedes: Optional[str] = None
    event_id: str = dataclasses.field(default_factory=lambda: str(uuid.uuid4()))
    recorded_at: str = dataclasses.field(default_factory=now_iso)

    def __post_init__(self):
        if self.event_type not in EVENT_TYPES:
            raise ValueError(f"Unbekannter event_type: {self.event_type}")

    @property
    def hash(self) -> str:
        basis = canonical_json(
            {"p": self.payload, "pat": self.patient_id, "t": self.occurred_at}
        )
        return hashlib.sha256(basis.encode("utf-8")).hexdigest()

    def row(self) -> dict:
        return {
            "event_id": self.event_id, "occurred_at": self.occurred_at,
            "recorded_at": self.recorded_at, "patient_id": self.patient_id,
            "fall_id": self.fall_id, "actor": self.actor,
            "event_type": self.event_type, "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "payload": canonical_json(self.payload),
            "source": self.source, "source_ref": self.source_ref,
            "supersedes": self.supersedes, "hash": self.hash,
        }


def resource_id_for(kind: str, quell_pk: Any) -> str:
    """Stabile IDs fuer migrierte Objekte: '{typ}-eug-{pk}'."""
    return f"{kind.lower()}-eug-{quell_pk}"
