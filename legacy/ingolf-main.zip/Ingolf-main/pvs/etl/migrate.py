# -*- coding: utf-8 -*-
"""Migration EUGASTRO -> PVS-Kernel (docs/pvs/30-MIGRATION-SPEC.md).

Modi:
  --patient <id>        Golden-Record-Lauf (M1)
  --mode full           Voll-Migration (M2)
  --mode incremental    Delta ueber rowversion-HWM (M2)

Kernel laeuft on-prem => privacy.mode 'off' zulaessig, wenn target.zone=praxis
(M0-Gate). Export-Pfade nach aussen bleiben Sache des agent/-Exports.
"""
from __future__ import annotations
import argparse, json, os, yaml

from pvs.etl import eug_bridge as B
from pvs.etl.transform_events import bundle_to_events
from pvs.model.fall import build_fall  # fall_to_fhir: Projektion on demand
from pvs.store.kernelstore import KernelStore


def _privacy_from_cfg(cfg: dict) -> "B.Privacy":
    p = cfg.get("privacy", {})
    mode = p.get("mode", "pseudonymize")
    zone = cfg.get("target", {}).get("zone", "extern")
    if mode == "off" and zone != "praxis":
        raise SystemExit("M0-Gate: privacy.mode=off nur bei target.zone=praxis zulaessig.")
    secret = os.environ.get(p.get("hmac_key_env", "PSEUDO_HMAC_KEY"), "")
    return B.Privacy(mode=mode, secret=secret, date_shift=p.get("date_shift", True))


def migrate_patient(src, store: KernelStore, privacy, pid: int,
                    behandler: str | None = None) -> dict:
    stats = {"inserted": 0, "unchanged": 0, "superseded": 0, "faelle": 0}
    bundle, _comps = B.eug.build_patient_bundle(src, pid, privacy,
                                                openehr=False, epa=True,
                                                embed_anhaenge=False)
    if not bundle:
        return stats
    for ev in bundle_to_events(str(pid), bundle):
        stats[store.append_event(ev)] += 1

    # Fall-Aggregate direkt aus dbo.Schein (verifizierte Q_SCHEIN).
    # Bewusst KEINE zusaetzlichen FHIR-Events: der Bundle-Export (map_scheine)
    # liefert bereits den kanonischen Encounter je Schein — das Aggregat in
    # `faelle` ist die autoritative Abrechnungssicht; FHIR-Projektion bei
    # Bedarf via fall_to_fhir() (Konzept-Review K2).
    for schein in src.query(B.eug.Q_SCHEIN, (pid,)):
        fall = build_fall(str(pid), schein, behandler_kuerzel=behandler)
        store.upsert_fall(fall)
        stats["faelle"] += 1
    return stats


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--db", default="./out/pvs.db")
    ap.add_argument("--patient", type=int)
    ap.add_argument("--mode", choices=("full", "incremental"))
    ap.add_argument("--limit", type=int)
    args = ap.parse_args(argv)

    cfg = yaml.safe_load(open(args.config, encoding="utf-8"))
    privacy = _privacy_from_cfg(cfg)
    os.makedirs(os.path.dirname(os.path.abspath(args.db)), exist_ok=True)
    store = KernelStore(args.db)
    src = B.Source(cfg["source"]).connect()
    try:
        if args.patient:
            pids = [args.patient]
        elif args.mode == "incremental":
            hwm_hex = store.get_hwm("_global")
            hwm = bytes.fromhex(hwm_hex) if hwm_hex else None
            pids = sorted(src.changed_patient_ids(hwm, B.eug.RV_TABLES)) if hwm else []
            if hwm is None:
                raise SystemExit("Kein HWM — erst --mode full laufen lassen.")
        else:
            pids = [r["Id"] for r in src.query(B.eug.Q_PATIENT_ALL)]
        if args.limit:
            pids = pids[: args.limit]

        next_hwm = src.min_active_rowversion()
        total = {"inserted": 0, "unchanged": 0, "superseded": 0, "faelle": 0}
        for pid in pids:
            st = migrate_patient(src, store, privacy, pid)
            for k in total:
                total[k] += st[k]
        if not args.patient and next_hwm is not None:
            hexv = next_hwm.hex() if isinstance(next_hwm, (bytes, bytearray)) else str(next_hwm)
            store.set_hwm("_global", hexv)
        print(json.dumps({"patients": len(pids), **total}, ensure_ascii=False))
    finally:
        src.close()
        store.close()


if __name__ == "__main__":
    main()
