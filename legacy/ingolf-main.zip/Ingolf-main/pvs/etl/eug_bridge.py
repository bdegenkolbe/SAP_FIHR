# -*- coding: utf-8 -*-
"""Bruecke zum bestehenden Collector (agent/).

agent/ nutzt flache Modul-Imports (from dbsource import Source) und wird hier
per sys.path eingebunden — Single Source of Truth fuer verifizierte SQL,
Blob-Parser und FHIR-Mapper. Nichts duplizieren.
"""
from __future__ import annotations
import os, sys

_AGENT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "agent"))
if _AGENT not in sys.path:
    sys.path.insert(0, _AGENT)

import export as eug            # noqa: E402  (Q_*-Queries, build_patient_bundle)
import mappers as eug_mappers   # noqa: E402
from dbsource import Source     # noqa: E402,F401
from privacy import Privacy     # noqa: E402,F401
from meddok import parse_detail # noqa: E402,F401
