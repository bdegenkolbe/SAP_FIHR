# -*- coding: utf-8 -*-
"""Golden-Record-Validierung (docs/pvs/30-MIGRATION-SPEC.md).

Sollwerte #76824 fixiert aus den medatixx-Screens vom 14.07.2026.
Prueft den Kernel-Store nach Migration. Toleranz nur bei Formatierung
(Dezimalkomma/-punkt), nie beim Wert.
"""
from __future__ import annotations
import json
from pvs.store.kernelstore import KernelStore

GOLDEN_76824 = {
    "diagnosen": [
        {"icd": "I10.9-", "sicherheit": "G"},
        {"icd": "K76.0",  "sicherheit": "G"},
    ],
    "vitalwerte": [  # (datum_prefix, name, wert)
        ("2026-07-14", "Größe", 184.0), ("2026-07-14", "Gewicht", 91.0),
        ("2026-07-14", "BMI", 26.9),
        ("2022-05-18", "Gewicht", 95.0), ("2022-05-18", "BMI", 28.1),
        ("2022-05-18", "Puls", 73.0),
        ("2020-08-14", "Gewicht", 91.0), ("2020-08-14", "Puls", 77.0),
    ],
    "blutdruck": [("2022-05-18", 144, 101), ("2020-08-14", 136, 91)],
    "dauermedikation": [
        {"name_contains": "MOUNJARO 7.5", "seit": "2026-05-24"},
        {"name_contains": "CANDESARTAN",  "seit": "2026-05-24"},
    ],
    "medikation_weitere": [
        {"name_contains": "Mounjaro 5", "seit": "2026-02-05"},
        {"name_contains": "FLUTICASON", "seit": "2022-03-29"},
    ],
    "labor_20251218": [  # (kuerzel, wert, indikator oder None)
        ("LYMP%", 33.0, None), ("NEUT%", 55.0, None), ("MONO%", 8.3, None),
        ("EOS%", 1.70, None), ("BASO%", 0.90, None),
        ("QUICK", 101.0, None), ("INR", 1.00, None), ("PTT", 31.0, None),
        ("BZG", 5.9, "H"), ("CHOL", 5.47, "H"),
        ("LDL", 3.71, None), ("HDL", 1.23, None),
    ],
    "fall": {"quartal": "2/2026", "fall_art": "PRIVAT",
             "versicherung_contains": "Barmenia"},
    "cave_contains": "Bitte vom Labor",
    "timeline_erste_zeile": {"datum_prefix": "2026-07-14",
                             "text_contains": "g+c im Herbst"},
}


def _f(v):
    try:
        return float(str(v).replace(",", "."))
    except (TypeError, ValueError):
        return None


class Report:
    def __init__(self):
        self.checks: list[tuple[str, bool, str]] = []

    def add(self, name, ok, detail=""):
        self.checks.append((name, bool(ok), detail))

    @property
    def ok(self):
        return all(c[1] for c in self.checks)

    def render(self) -> str:
        lines = [f"{'PASS' if ok else 'FAIL':4s}  {name}" + (f"  [{d}]" if d and not ok else "")
                 for name, ok, d in self.checks]
        n = sum(1 for _, ok, _ in self.checks if ok)
        lines.append(f"---- {n}/{len(self.checks)} Checks bestanden ----")
        return "\n".join(lines)


def validate(store: KernelStore, patient_id: str, golden: dict = GOLDEN_76824) -> Report:
    rep = Report()
    obs = store.current(patient_id, "Observation")
    conds = store.current(patient_id, "Condition")
    meds = store.current(patient_id, "MedicationStatement") + \
        store.current(patient_id, "MedicationRequest")
    flags = store.current(patient_id, "Flag")

    # Diagnosen
    for g in golden["diagnosen"]:
        hit = any(any(c.get("code") == g["icd"] for c in r.get("code", {}).get("coding", []))
                  and g["sicherheit"] in json.dumps(r.get("note", []))
                  for r in conds)
        rep.add(f"Diagnose {g['icd']} ({g['sicherheit']})", hit)

    # Vitalwerte
    def vital(datum, name):
        for r in obs:
            if not str(r.get("effectiveDateTime", "")).startswith(datum):
                continue
            if r.get("code", {}).get("text") != name:
                continue
            return _f(r.get("valueQuantity", {}).get("value"))
        return None

    for datum, name, soll in golden["vitalwerte"]:
        ist = vital(datum, name)
        rep.add(f"Vital {datum} {name}={soll}", ist == soll, f"ist={ist}")
    for datum, sys_, dia in golden["blutdruck"]:
        s = vital(datum, "Blutdruck systolisch") or vital(datum, "RR sys")
        d = vital(datum, "Blutdruck diastolisch") or vital(datum, "RR dia")
        # Quelle speichert RR ggf. als kombinierten Wert -> Fallback Stringsuche
        if s is None or d is None:
            comb = [r for r in obs
                    if str(r.get("effectiveDateTime", "")).startswith(datum)
                    and "lutdruck" in json.dumps(r.get("code", {}), ensure_ascii=False)]
            ok = any(f"{sys_}" in json.dumps(r) and f"{dia}" in json.dumps(r) for r in comb)
        else:
            ok = (s, d) == (float(sys_), float(dia))
        rep.add(f"RR {datum} {sys_}/{dia}", ok)

    # Medikation
    for g in golden["dauermedikation"] + golden["medikation_weitere"]:
        hit = any(g["name_contains"].lower() in json.dumps(r, ensure_ascii=False).lower()
                  and g["seit"] in json.dumps(r) for r in meds)
        rep.add(f"Medikation {g['name_contains']} seit {g['seit']}", hit)

    # Labor 18.12.2025
    lab = [r for r in obs
           if str(r.get("effectiveDateTime", "")).startswith("2025-12-18")]
    def lab_val(kuerzel):
        for r in lab:
            for c in r.get("code", {}).get("coding", []):
                if c.get("code") == kuerzel:
                    interp = None
                    for i in r.get("interpretation", []):
                        for ic in i.get("coding", []):
                            interp = ic.get("code")
                    return _f(r.get("valueQuantity", {}).get("value")), interp
        return None, None
    for kuerzel, soll, ind in golden["labor_20251218"]:
        ist, ist_ind = lab_val(kuerzel)
        ok = ist == soll and (ind is None or ist_ind == ind)
        rep.add(f"Labor 18.12.2025 {kuerzel}={soll}{'/'+ind if ind else ''}",
                ok, f"ist={ist}/{ist_ind}")

    # Fall
    faelle = store.faelle(patient_id)
    g = golden["fall"]
    hit = any(f["quartal"] == g["quartal"] and f["fall_art"] == g["fall_art"]
              and g["versicherung_contains"].lower() in
              json.dumps(f.get("privat") or {}, ensure_ascii=False).lower()
              for f in faelle)
    rep.add(f"Fall {g['quartal']} {g['fall_art']} ({g['versicherung_contains']})",
            hit, f"faelle={len(faelle)}")

    # CAVE
    rep.add("CAVE-Flag",
            any(golden["cave_contains"].lower() in json.dumps(r, ensure_ascii=False).lower()
                for r in flags))

    # Timeline-Kopf
    tl = store.timeline(patient_id)
    t = golden["timeline_erste_zeile"]
    hit = any(str(r["occurred_at"]).startswith(t["datum_prefix"])
              and t["text_contains"].lower() in str(r["payload"]).lower()
              for r in tl)
    rep.add(f"Timeline-Eintrag {t['datum_prefix']} '{t['text_contains']}'", hit)
    return rep


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", required=True)
    ap.add_argument("--patient", required=True)
    a = ap.parse_args(argv)
    store = KernelStore(a.db)
    rep = validate(store, str(a.patient))
    print(rep.render())
    raise SystemExit(0 if rep.ok else 1)


if __name__ == "__main__":
    main()
