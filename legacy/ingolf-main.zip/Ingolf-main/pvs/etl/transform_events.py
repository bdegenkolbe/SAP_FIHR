# -*- coding: utf-8 -*-
"""FHIR-Bundle (aus agent/export.build_patient_bundle) -> Kernel-Events.

Dispatch resourceType (+ Kategorie-Hints) -> event_type gemaess
docs/pvs/10-KERNEL-SPEC.md. source_ref = fullUrl (uuid5, stabil je Quell-PK)
=> Idempotenz und supersedes bei Quelldeltas kommen aus dem Store.
"""
from __future__ import annotations
from typing import Iterable

from pvs.model.events import Event

_DATE_FIELDS = ("effectiveDateTime", "recordedDate", "authoredOn", "date",
                "issued", "created", "start", "occurrenceDateTime",
                "period.start")


def _get(d: dict, dotted: str):
    cur = d
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def occurred_at(res: dict) -> str:
    for f in _DATE_FIELDS:
        v = _get(res, f)
        if v:
            return str(v)
    return ""


def _obs_category(res: dict) -> str:
    for c in res.get("category", []):
        for cod in c.get("coding", []):
            if cod.get("code"):
                return cod["code"]
    return ""


def event_type_for(res: dict) -> str:
    rt = res.get("resourceType", "")
    if rt == "Patient":
        return "patient.angelegt"
    if rt == "Condition":
        return "diagnose.dokumentiert"
    if rt == "Observation":
        cat = _obs_category(res)
        if cat == "laboratory":
            return "labor.ergebnis"
        if cat == "vital-signs":
            return "vitalwert.erfasst"
        return "befund.dokumentiert"
    if rt == "DiagnosticReport":
        return "labor.ergebnis"
    if rt == "MedicationStatement":
        return "medikation.status"
    if rt == "MedicationRequest":
        return "medikation.verordnet"
    if rt == "Encounter":
        return "fall.eroeffnet"
    if rt == "Composition":
        return "brief.erstellt"
    if rt == "DocumentReference":
        txt = str(res.get("type", {}).get("text", ""))
        return "au.ausgestellt" if "rbeitsunf" in txt else "dokument.erfasst"
    if rt in ("Flag", "AllergyIntolerance"):
        return "cave.gesetzt"
    if rt == "Appointment":
        return "termin.geplant"
    if rt == "Invoice":
        return "rechnung.gestellt"
    if rt == "Claim":
        return "leistung.erfasst"   # Claim = Abrechnungskontext je Schein (map_scheine)
    if rt == "ServiceRequest":
        return "heilmittel.verordnet"
    if rt == "Consent":
        return "consent.erfasst"
    if rt == "Communication":
        return "notiz.erfasst"
    return "dokument.erfasst"


def bundle_to_events(patient_id: str, bundle: dict,
                     source: str = "migration:eugastro") -> Iterable[Event]:
    for entry in bundle.get("entry", []):
        res = entry.get("resource") or {}
        rt = res.get("resourceType")
        if not rt:
            continue
        yield Event(
            occurred_at=occurred_at(res),
            patient_id=str(patient_id),
            event_type=event_type_for(res),
            resource_type=rt,
            resource_id=res.get("id") or entry.get("fullUrl", "").split(":")[-1],
            payload=res,
            source=source,
            source_ref=entry.get("fullUrl"),
        )
