#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Export der Referenz-/Katalogdaten als FHIR-Terminologie/Definitionsressourcen.

Einmal-/periodischer Lauf (keine PHY -> keine Pseudonymisierung). Erzeugt:
  out/reference/labor_katalog.json     (ObservationDefinition[])
  out/reference/vitalparameter.json    (ObservationDefinition[])
  out/reference/medikament.json        (Medication[])
  out/reference/goae.json              (ChargeItemDefinition[])
  out/reference/meddok_kategorie.json  (CodeSystem)

Aufruf:  python reference/build_reference.py --config config/config.yaml --out ./out
"""
from __future__ import annotations
import argparse, json, os, sys

# Portable (embeddable) Python legt das Skriptverzeichnis nicht auf sys.path
# -> eigenes Verzeichnis, Repo-Root (store/) und agent/ explizit registrieren.
_HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (os.path.join(_HERE, "..", "agent"), os.path.dirname(_HERE), _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)
from dbsource import Source            # noqa: E402
import reference_mappers as R          # noqa: E402

Q_LABORKAT = """
SELECT Id, Ident, Bezeichnung, Einheit, Normwerte, IsGnr_Ebm, Gnr_Ebm, IsGnr_Goae, Gnr_Goae
FROM dbo.LaborIdentKatalog"""
Q_VITALPAR = "SELECT Id, Name, DisplayName, Masseinheit FROM dbo.Vitalparameter"
Q_MEDIKAMENT = """
SELECT Id, Pzn, Artikelname, Artikellangname, Darreichungsform, InhaltAnzahl, InhaltEinheit
FROM dbo.Medikament"""
Q_WIRKSTOFF = "SELECT Id_Medikament, Wirkstoff, Wirkstaerke, Rang FROM dbo.MedikamentWirkstoff"
Q_MEDATC = "SELECT Id_Medikament, AtcCode, Bezeichnung FROM dbo.MedikamentAtc"
Q_GOAE = """
SELECT Id, Ziffer, LegendeKurz, LegendeLang, GueltigVon, GueltigBis, Leistungsart
FROM dbo.GoaeZiffer"""
Q_MEDDOKKAT = "SELECT Id, Kuerzel, Bezeichnung FROM dbo.MedDokKategorie ORDER BY Id"


def load_config(path):
    try:
        import yaml
        cfg = yaml.safe_load(open(path, encoding="utf-8"))
    except ImportError:
        cfg = json.load(open(path, encoding="utf-8"))
    # password_ref/hmac_key_ref (DPAPI-Dateien aus den Einstellungen) aufloesen —
    # dieselbe Logik wie der Patienten-Export (KeyError 'password' sonst)
    from export import resolve_config
    return resolve_config(cfg, os.path.dirname(os.path.dirname(os.path.abspath(path))))


def _bundle(resources, bid):
    return {"resourceType": "Bundle", "id": bid, "type": "collection",
            "entry": [{"resource": r} for r in resources]}


def _write(out_dir, name, obj):
    with open(os.path.join(out_dir, name), "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def _safe(src, sql):
    try:
        return src.query(sql)
    except Exception as e:
        sys.stderr.write(f"[warn] {sql.split()[3] if len(sql.split())>3 else ''}: {e}\n")
        return []


STEPS = 6


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--out", default="./out")
    ap.add_argument("--db", help="Kataloge zusaetzlich in den lokalen Store laden "
                                 "(ref_resource, versioniert; CONCEPT.md 13.4)")
    args = ap.parse_args()

    import datetime as _dt

    def log(msg):
        print(f"[{_dt.datetime.now():%Y-%m-%d %H:%M:%S}] {msg}", flush=True)

    cfg = load_config(args.config)
    ref_dir = os.path.join(args.out, "reference")
    os.makedirs(ref_dir, exist_ok=True)

    # Mit --db laeuft der Lauf als Job (mode='reference') - die UI (Kataloge-
    # Ansicht) pollt den Fortschritt wie beim Patienten-Sync; PID erlaubt Abbruch.
    conn = job_id = None
    if args.db:
        from store.db import open_store, new_id
        conn = open_store(args.db)
        # Der Patienten-Sync darf parallel laufen und schreibt dauernd ->
        # grosszuegiges Lock-Timeout statt 'database is locked'-Abbruch
        conn.execute("PRAGMA busy_timeout=60000")
        job_id = new_id()
        conn.execute(
            "INSERT INTO etl_export_job (id, mode, privacy, target, stats)"
            " VALUES (?,?,?,?,?)",
            (job_id, "reference", "off", "ref",
             json.dumps({"pid": os.getpid(), "step": "Start", "done": 0, "total": STEPS})))
        conn.commit()

    counts: dict[str, int] = {}

    def step(i, name):
        log(f"[{i}/{STEPS}] {name}")
        if conn is not None:
            conn.execute(
                "UPDATE etl_export_job SET stats=? WHERE id=?",
                (json.dumps({"pid": os.getpid(), "step": name, "done": i - 1,
                             "total": STEPS, "counts": counts}), job_id))
            conn.commit()

    src = None
    try:
        log(f"Katalog-Lauf startet: out={ref_dir}{' db=' + args.db if args.db else ''}")
        step(1, "Verbindung zur Quell-DB")
        src = Source(cfg["source"]).connect()

        step(2, "Labor-Katalog")
        lab = R.map_labor_katalog(_safe(src, Q_LABORKAT))
        _write(ref_dir, "labor_katalog.json", _bundle(lab, "labor-katalog"))
        counts["Labor"] = len(lab)

        step(3, "Vitalparameter")
        vit = R.map_vitalparameter(_safe(src, Q_VITALPAR))
        _write(ref_dir, "vitalparameter.json", _bundle(vit, "vitalparameter"))
        counts["Vitalparameter"] = len(vit)

        step(4, "Medikamente (Wirkstoffe + ATC)")
        med_rows = _safe(src, Q_MEDIKAMENT)
        wk_by, atc_by = {}, {}
        for w in _safe(src, Q_WIRKSTOFF):
            wk_by.setdefault(w["Id_Medikament"], []).append(w)
        for a in _safe(src, Q_MEDATC):
            atc_by.setdefault(a["Id_Medikament"], a)  # erster ATC je Medikament
        med = R.map_medikament(med_rows, wk_by, atc_by)
        _write(ref_dir, "medikament.json", _bundle(med, "medikament"))
        counts["Medikamente"] = len(med)

        step(5, "GOÄ-Ziffern + MedDok-Kategorien")
        goae = R.map_goae(_safe(src, Q_GOAE))
        _write(ref_dir, "goae.json", _bundle(goae, "goae"))
        counts["GOÄ"] = len(goae)
        cs = R.map_meddok_kategorie(_safe(src, Q_MEDDOKKAT))
        _write(ref_dir, "meddok_kategorie.json", cs)
        counts["MedDok-Codes"] = len(cs.get("concept", []))

        step(6, "Kataloge in den Store laden")
        version = _dt.date.today().isoformat()
        if conn is not None:
            for catalog, resources in (("labor", lab), ("vitalparameter", vit),
                                       ("medikament", med), ("goae", goae),
                                       ("meddok", [cs])):
                for res in resources:
                    conn.execute(
                        "INSERT OR REPLACE INTO ref_resource (resource_type, id, catalog,"
                        " version, valid_from, content) VALUES (?,?,?,?,?,?)",
                        (res.get("resourceType", "?"), res.get("id") or res.get("url", "?"),
                         catalog, version, version,
                         json.dumps(res, ensure_ascii=False)))
            conn.execute(
                "UPDATE etl_export_job SET finished_at=datetime('now'), status='success',"
                " stats=? WHERE id=?",
                (json.dumps({"done": STEPS, "total": STEPS, "counts": counts,
                             "version": version}), job_id))
            conn.commit()
            log(f"Kataloge in Store geladen: {args.db} (Version {version})")

        log(f"Referenz-Export fertig -> {ref_dir}")
        log("  " + " | ".join(f"{k}: {v}" for k, v in counts.items()))
    except Exception as exc:
        log(f"ABBRUCH: {exc}")
        if conn is not None:
            conn.execute("UPDATE etl_export_job SET finished_at=datetime('now'),"
                         " status='failed', error=? WHERE id=?", (str(exc), job_id))
            conn.commit()
        raise
    finally:
        if src is not None:
            src.close()
        if conn is not None:
            conn.close()


if __name__ == "__main__":
    main()
