# -*- coding: utf-8 -*-
"""Mapper fuer Referenz-/Katalogdaten (KEINE PHY - keine Pseudonymisierung noetig).

Quelle -> FHIR:
  LaborIdentKatalog  -> ObservationDefinition (mit geschlechtsspez. Referenzbereichen)
  Vitalparameter     -> ObservationDefinition
  Medikament(+Wirkstoff+Atc) -> Medication (ingredient + ATC)
  GoaeZiffer         -> ChargeItemDefinition
  MedDokKategorie    -> CodeSystem (lokales Dokumenttyp-System)
"""
from __future__ import annotations
import json

SYS_LOCAL = "https://eugastro.local"
SYS_ATC = "http://fhir.de/CodeSystem/bfarm/atc"
SYS_PZN = "http://fhir.de/CodeSystem/ifa/pzn"

GENDER = {"2": "male", "1": "female"}   # systemspezifisch (wie im Agent)


def _rid(rt, key):
    return f"{rt}-{key}"


# --- LaborIdentKatalog -> ObservationDefinition ----------------------------
def map_labor_katalog(rows: list[dict]) -> list[dict]:
    out = []
    for r in rows:
        ident = r.get("Ident")
        obsdef = {
            "resourceType": "ObservationDefinition",
            "id": _rid("labtest", r.get("Id")),
            "code": {"coding": [{"system": f"{SYS_LOCAL}/labor-test", "code": ident,
                                 "display": r.get("Bezeichnung")}], "text": r.get("Bezeichnung")},
            "permittedDataType": ["Quantity"],
        }
        if r.get("Einheit"):
            obsdef["quantitativeDetails"] = {"unit": {"text": r["Einheit"]}}
        # Normwerte (JSON-Liste je Geschlecht) -> qualifiedInterval
        intervals = []
        try:
            for nw in json.loads(r.get("Normwerte") or "[]"):
                intervals.append({
                    "category": "reference",
                    "gender": GENDER.get(str(nw.get("Geschlecht")), None),
                    "text": (nw.get("NormalwertText") or "").replace("\r\n", " ").strip(),
                })
        except (ValueError, TypeError):
            pass
        if intervals:
            obsdef["qualifiedInterval"] = [{k: v for k, v in iv.items() if v} for iv in intervals]
        # EBM/GOAe-Kennzeichen als Extension
        for flag, val, url in [("IsGnr_Ebm", r.get("Gnr_Ebm"), "gnr-ebm"),
                               ("IsGnr_Goae", r.get("Gnr_Goae"), "gnr-goae")]:
            if r.get(flag) and val:
                obsdef.setdefault("extension", []).append(
                    {"url": f"{SYS_LOCAL}/{url}", "valueString": str(val)})
        out.append(obsdef)
    return out


# --- Vitalparameter -> ObservationDefinition -------------------------------
def map_vitalparameter(rows: list[dict]) -> list[dict]:
    out = []
    for r in rows:
        name = r.get("DisplayName") or r.get("Name")
        obsdef = {
            "resourceType": "ObservationDefinition",
            "id": _rid("vital", r.get("Id")),
            "category": [{"coding": [{"system": "http://terminology.hl7.org/CodeSystem/observation-category",
                                      "code": "vital-signs"}]}],
            "code": {"coding": [{"system": f"{SYS_LOCAL}/vital", "code": r.get("Name"),
                                 "display": name}], "text": name},
            "permittedDataType": ["Quantity"],
        }
        if r.get("Masseinheit"):
            obsdef["quantitativeDetails"] = {"unit": {"text": r["Masseinheit"]}}
        out.append(obsdef)
    return out


# --- Medikament (+ Wirkstoff + ATC) -> Medication --------------------------
def map_medikament(med_rows: list[dict], wirkstoff_by_med: dict, atc_by_med: dict) -> list[dict]:
    out = []
    for r in med_rows:
        mid = r.get("Id")
        coding = []
        if r.get("Pzn"):
            coding.append({"system": SYS_PZN, "code": str(r["Pzn"]), "display": r.get("Artikelname")})
        atc = atc_by_med.get(mid)
        if atc:
            coding.append({"system": SYS_ATC, "code": atc["AtcCode"], "display": atc.get("Bezeichnung")})
        med = {
            "resourceType": "Medication",
            "id": _rid("med", mid),
            "code": {"coding": coding or None,
                     "text": r.get("Artikellangname") or r.get("Artikelname")},
            "status": "active",
            "form": {"text": r.get("Darreichungsform")} if r.get("Darreichungsform") else None,
        }
        ings = wirkstoff_by_med.get(mid, [])
        if ings:
            med["ingredient"] = []
            for w in sorted(ings, key=lambda x: str(x.get("Rang") or "9")):
                med["ingredient"].append({
                    "itemCodeableConcept": {"text": w.get("Wirkstoff")},
                    "strength": {"numerator": {"value": None}, "extension": [
                        {"url": f"{SYS_LOCAL}/wirkstaerke", "valueString": w.get("Wirkstaerke")}]}
                    if w.get("Wirkstaerke") else None,
                })
        _clean(med)
        out.append(med)
    return out


# --- GoaeZiffer -> ChargeItemDefinition ------------------------------------
def map_goae(rows: list[dict]) -> list[dict]:
    out = []
    for r in rows:
        cid = {
            "resourceType": "ChargeItemDefinition",
            "id": _rid("goae", r.get("Id")),
            "status": "active",
            "code": {"coding": [{"system": f"{SYS_LOCAL}/goae", "code": (r.get("Ziffer") or "").strip(),
                                 "display": r.get("LegendeKurz")}], "text": r.get("LegendeKurz")},
            "description": r.get("LegendeLang"),
        }
        va, bis = r.get("GueltigVon"), r.get("GueltigBis")
        if va or bis:
            cid["applicability"] = [{"description": f"gueltig {va or ''}..{bis or ''}"}]
        _clean(cid)
        out.append(cid)
    return out


# --- MedDokKategorie -> CodeSystem -----------------------------------------
def map_meddok_kategorie(rows: list[dict]) -> dict:
    return {
        "resourceType": "CodeSystem",
        "id": "meddok-kategorie",
        "url": f"{SYS_LOCAL}/meddok-kategorie",
        "status": "active",
        "content": "complete",
        "concept": [{"code": r.get("Kuerzel"), "display": r.get("Bezeichnung")}
                    for r in rows if r.get("Kuerzel")],
    }


def _clean(obj):
    if isinstance(obj, dict):
        for k in list(obj):
            v = obj[k]
            if v is None:
                del obj[k]
            else:
                _clean(v)
                if v in ({}, []):
                    del obj[k]
    elif isinstance(obj, list):
        for it in obj:
            _clean(it)
    return obj
