#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Terminologie-Anbindung fuer die Dokument-Annotation.

Kapselt das Binding von erkannten Textspannen auf Kodiersysteme:
  - SNOMED CT   (primaeres klinisches Referenzsystem)
  - ICD-10-GM   (Diagnosen, Abrechnung/DRG)
  - LOINC       (Labor/Messungen)
  - ATC / PZN   (Medikation)

Zwei Provider-Strategien, hinter einem gemeinsamen Interface:

  (A) LocalCatalogProvider  -- Woerterbuch-Matching gegen die bereits im Projekt
      vorhandenen/beschaffbaren Kataloge (reference/). Braucht keine Online-Dienste,
      liefert v.a. ICD-10-GM / LOINC / ATC. SNOMED nur, wenn eine RF2-/Snapshot-Datei
      lokal eingespielt ist.

  (B) FhirTerminologyProvider -- spricht einen FHIR-Terminologieserver
      ($lookup, $validate-code, $translate, ValueSet/$expand). Damit laesst sich
      SNOMED CT sauber validieren und ICD<->SNOMED mappen (ConceptMap).

SNOMED-CT-Lizenz: Deutschland ist Mitglied bei SNOMED International; National Release
Center ist das BfArM. Die Nutzung im deutschen Gesundheitswesen ist ueber die nationale
Lizenz moeglich, erfordert aber eine (i.d.R. kostenfreie) Affiliate-Registrierung ueber
das BfArM/MLDS. Der konkrete Lizenz-/Registrierungsstatus ist projektseitig final zu
pruefen, bevor SNOMED produktiv gebunden wird. ICD-10-GM, ATC (amtliche Fassung) und
LOINC sind frei nutzbar.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Iterable, Sequence
import re

# Kanonische System-URIs (identisch zu mappers.py-Konventionen)
SYS_SNOMED = "http://snomed.info/sct"
SYS_ICD10GM = "http://fhir.de/CodeSystem/bfarm/icd-10-gm"
SYS_LOINC = "http://loinc.org"
SYS_ATC = "http://fhir.de/CodeSystem/bfarm/atc"


@dataclass(frozen=True)
class Concept:
    """Ein terminologisches Konzept (Ziel eines Bindings)."""
    system: str
    code: str
    display: str
    score: float = 1.0            # Matching-Konfidenz 0..1


@dataclass
class DictEntry:
    """Eintrag im lokalen Matching-Woerterbuch."""
    term: str                     # normalisierter Suchbegriff (lowercase)
    concept: Concept


class TerminologyProvider:
    """Gemeinsames Interface. Implementierungen liefern Konzepte zu einem Textspan."""

    def bind(self, text: str) -> list[Concept]:
        """Liefert kandidierende Konzepte fuer einen (kurzen) Textspan."""
        raise NotImplementedError

    def validate(self, system: str, code: str) -> bool:
        """Prueft, ob (system,code) gueltig ist. Default: optimistisch True."""
        return True

    def translate(self, concept: Concept, target_system: str) -> list[Concept]:
        """Mappt ein Konzept in ein Zielsystem (z.B. ICD<->SNOMED). Default: leer."""
        return []


def _normalize(s: str) -> str:
    s = s.lower().strip()
    s = s.replace("\u00ad", "")               # Soft-Hyphen
    s = re.sub(r"\s+", " ", s)
    return s


class LocalCatalogProvider(TerminologyProvider):
    """Woerterbuch-Matcher ueber lokal geladene Kataloge (kein Online-Dienst).

    Das Woerterbuch wird aus Katalogen aufgebaut (siehe reference/build_reference.py):
      - ICD-10-GM: Kode + Titel  (falls Katalogdatei vorhanden)
      - LOINC:     LaborIdentKatalog-Bezeichnungen -> LOINC (soweit gemappt)
      - ATC:       Medikament/Wirkstoff -> ATC
      - SNOMED:    nur wenn RF2-Description-Snapshot lokal vorliegt
    Ohne Katalogdateien bleibt der Provider leer und liefert keine Treffer
    (die Pipeline degradiert dann sauber auf 'nur Volltext, keine Codes').
    """

    def __init__(self, entries: Iterable[DictEntry] | None = None):
        self._by_term: dict[str, list[Concept]] = {}
        # laengste Terme zuerst -> greedy longest-match
        self._terms_sorted: list[str] = []
        if entries:
            self.add_entries(entries)

    def add_entries(self, entries: Iterable[DictEntry]) -> None:
        for e in entries:
            t = _normalize(e.term)
            if len(t) < 3:
                continue
            self._by_term.setdefault(t, []).append(e.concept)
        self._terms_sorted = sorted(self._by_term, key=len, reverse=True)

    def bind(self, text: str) -> list[Concept]:
        t = _normalize(text)
        return list(self._by_term.get(t, []))

    def find_spans(self, text: str) -> list[tuple[int, int, Concept]]:
        """Dictionary-NER: findet alle Woerterbuch-Terme im Text (longest-match,
        Wortgrenzen). Rueckgabe: (start, end, concept)."""
        norm = _normalize(text)
        # Positions-Map normalize->original ist nicht 1:1 nach re.sub; fuer die
        # Offset-Genauigkeit arbeitet die echte Pipeline auf Token-Ebene (siehe
        # annotate.py). Hier: einfache, robuste Suche auf Originaltext.
        low = text.lower()
        hits: list[tuple[int, int, Concept]] = []
        occupied = [False] * len(text)
        for term in self._terms_sorted:
            start = 0
            while True:
                i = low.find(term, start)
                if i < 0:
                    break
                j = i + len(term)
                left_ok = i == 0 or not low[i - 1].isalnum()
                right_ok = j >= len(low) or not low[j].isalnum()
                if left_ok and right_ok and not any(occupied[i:j]):
                    for c in self._by_term[term]:
                        hits.append((i, j, c))
                    for k in range(i, j):
                        occupied[k] = True
                start = j
        return sorted(hits, key=lambda h: h[0])

    @classmethod
    def from_reference_dir(cls, ref_dir: str) -> "LocalCatalogProvider":
        """Baut das Woerterbuch aus JSON-Katalogen unter reference/ (falls vorhanden).
        Erwartetes, optionales Format je Datei: Liste von {term, system, code, display}."""
        import os, json, glob
        entries: list[DictEntry] = []
        for f in glob.glob(os.path.join(ref_dir, "dict_*.json")):
            try:
                for row in json.load(open(f, encoding="utf-8")):
                    entries.append(DictEntry(
                        term=row["term"],
                        concept=Concept(row["system"], row["code"],
                                        row.get("display", row["term"]),
                                        float(row.get("score", 1.0)))))
            except Exception:
                continue
        return cls(entries)


class FhirTerminologyProvider(TerminologyProvider):
    """Anbindung an einen FHIR-Terminologieserver (z.B. Ontoserver, HAPI, Snowstorm).

    Nutzt Standardoperationen:
      - ValueSet/$expand   fuer Kandidatensuche (filter=Text)
      - CodeSystem/$lookup fuer Display/Validierung
      - ConceptMap/$translate fuer ICD<->SNOMED
    Nur Metadaten/Codes verlassen die Anwendung Richtung Server; KEINE Patiententexte,
    ausser explizit freigegebenen Suchbegriffen. Fuer strenge On-Prem-Szenarien laeuft
    der Terminologieserver lokal (Snowstorm/Ontoserver on-premise).
    """

    def __init__(self, base_url: str, snomed_valueset: str | None = None,
                 timeout: float = 5.0, verify_tls: bool = True):
        self.base = base_url.rstrip("/")
        self.snomed_vs = snomed_valueset or f"{SYS_SNOMED}?fhir_vs"
        self.timeout = timeout
        self.verify_tls = verify_tls

    def bind(self, text: str) -> list[Concept]:
        try:
            import requests
        except Exception:
            return []
        params = {"url": self.snomed_vs, "filter": text, "count": 5}
        try:
            r = requests.get(f"{self.base}/ValueSet/$expand", params=params,
                             timeout=self.timeout, verify=self.verify_tls)
            r.raise_for_status()
            out = []
            for c in r.json().get("expansion", {}).get("contains", []):
                out.append(Concept(c.get("system", SYS_SNOMED), c["code"],
                                   c.get("display", ""), 0.8))
            return out
        except Exception:
            return []

    def validate(self, system: str, code: str) -> bool:
        try:
            import requests
            r = requests.get(f"{self.base}/CodeSystem/$validate-code",
                             params={"url": system, "code": code},
                             timeout=self.timeout, verify=self.verify_tls)
            for p in r.json().get("parameter", []):
                if p.get("name") == "result":
                    return bool(p.get("valueBoolean"))
        except Exception:
            pass
        return True

    def translate(self, concept: Concept, target_system: str) -> list[Concept]:
        try:
            import requests
            r = requests.get(f"{self.base}/ConceptMap/$translate",
                             params={"system": concept.system, "code": concept.code,
                                     "targetsystem": target_system},
                             timeout=self.timeout, verify=self.verify_tls)
            out = []
            for p in r.json().get("parameter", []):
                if p.get("name") == "match":
                    part = {x["name"]: x for x in p.get("part", [])}
                    c = part.get("concept", {}).get("valueCoding", {})
                    if c:
                        out.append(Concept(c.get("system", target_system), c.get("code", ""),
                                           c.get("display", ""), 0.7))
            return out
        except Exception:
            return []


class CompositeProvider(TerminologyProvider):
    """Bündelt mehrere Provider; lokaler Matcher zuerst, Server als Ergaenzung."""

    def __init__(self, providers: Sequence[TerminologyProvider]):
        self.providers = list(providers)

    def bind(self, text: str) -> list[Concept]:
        seen, out = set(), []
        for p in self.providers:
            for c in p.bind(text):
                key = (c.system, c.code)
                if key not in seen:
                    seen.add(key); out.append(c)
        return out

    def validate(self, system: str, code: str) -> bool:
        return any(p.validate(system, code) for p in self.providers)

    def translate(self, concept: Concept, target_system: str) -> list[Concept]:
        out: list[Concept] = []
        for p in self.providers:
            out.extend(p.translate(concept, target_system))
        return out
