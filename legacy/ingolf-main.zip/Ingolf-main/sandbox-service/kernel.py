#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Sandbox-Kernel: persistenter Python-Interpreter je Session (Profil B).

Läuft IM Container (bzw. im Subprozess-Runner für Tests) und lauscht auf einem
Unix-Socket im Session-Verzeichnis — funktioniert daher auch mit --network none.
Protokoll: eine JSON-Zeile pro Request/Response.

  -> {"op": "exec", "code": "...", "cell_timeout": 30}
  <- {"ok": true, "stdout": "...", "stderr": "...", "error": null,
      "artifacts": [{"name": "plot.png", "size": 1234}], "duration_ms": 42}

Zustand (Variablen) bleibt über Zellen erhalten (gemeinsames globals-Dict).
Nach jeder Zelle werden offene matplotlib-Figuren automatisch als PNG gesichert
und neue/geänderte Dateien im Arbeitsverzeichnis als Artefakte gemeldet.
"""
from __future__ import annotations

import argparse
import contextlib
import io
import json
import os
import signal
import socket
import sys
import time
import traceback

os.environ.setdefault("MPLBACKEND", "Agg")   # headless Plots


class _CellTimeout(Exception):
    pass


def _alarm(_sig, _frm):
    raise _CellTimeout()


def _snapshot(workdir: str) -> dict[str, float]:
    out = {}
    for root, _dirs, files in os.walk(workdir):
        for f in files:
            p = os.path.join(root, f)
            try:
                out[os.path.relpath(p, workdir)] = os.path.getmtime(p)
            except OSError:
                pass
    return out


def _autosave_figures(workdir: str) -> None:
    if "matplotlib" not in sys.modules:
        return
    try:
        import matplotlib.pyplot as plt
        for num in plt.get_fignums():
            path = os.path.join(workdir, f"figure_{num}.png")
            plt.figure(num).savefig(path, dpi=120, bbox_inches="tight")
        plt.close("all")
    except Exception:
        pass


def run_cell(code: str, glb: dict, workdir: str, cell_timeout: int) -> dict:
    before = _snapshot(workdir)
    stdout, stderr = io.StringIO(), io.StringIO()
    error = None
    start = time.monotonic()
    if hasattr(signal, "SIGALRM") and cell_timeout > 0:
        signal.signal(signal.SIGALRM, _alarm)
        signal.alarm(cell_timeout)
    try:
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            exec(compile(code, "<zelle>", "exec"), glb)  # noqa: S102 - Sandbox-Zweck
    except _CellTimeout:
        error = f"Zeitlimit überschritten ({cell_timeout}s) — Zelle abgebrochen."
    except BaseException:
        error = traceback.format_exc(limit=8)
    finally:
        if hasattr(signal, "SIGALRM"):
            signal.alarm(0)
    _autosave_figures(workdir)
    after = _snapshot(workdir)
    artifacts = [{"name": name, "size": os.path.getsize(os.path.join(workdir, name))}
                 for name, mtime in after.items()
                 if name not in before or before[name] != mtime]
    return {"ok": error is None,
            "stdout": stdout.getvalue()[-100_000:],
            "stderr": stderr.getvalue()[-20_000:],
            "error": error,
            "artifacts": sorted(artifacts, key=lambda a: a["name"]),
            "duration_ms": int((time.monotonic() - start) * 1000)}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--sock", required=True)
    ap.add_argument("--workdir", required=True)
    args = ap.parse_args()

    os.makedirs(args.workdir, exist_ok=True)
    os.chdir(args.workdir)
    if os.path.exists(args.sock):
        os.unlink(args.sock)

    glb: dict = {"__name__": "__main__"}
    srv = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    srv.bind(args.sock)
    srv.listen(1)

    while True:
        conn, _ = srv.accept()
        with conn, conn.makefile("rwb") as f:
            line = f.readline()
            if not line:
                continue
            try:
                req = json.loads(line)
            except ValueError:
                continue
            if req.get("op") == "shutdown":
                return
            if req.get("op") == "exec":
                resp = run_cell(req.get("code", ""), glb, args.workdir,
                                int(req.get("cell_timeout", 30)))
                f.write(json.dumps(resp, ensure_ascii=False).encode("utf-8") + b"\n")
                f.flush()


if __name__ == "__main__":
    main()
