# -*- coding: utf-8 -*-
"""Session-Runner: startet/verwaltet einen Kernel je Session.

Zwei Implementierungen hinter derselben Schnittstelle:
- DockerRunner   (Produktion, Profil B): 1 Container pro Session,
  --network none, read-only Rootfs, Speicher-/CPU-/PID-Limits, non-root.
- SubprocessRunner (Dev/Tests, auch Basis für Profil A): Kernel als Subprozess
  mit geleerter Umgebung + rlimits (Linux). Gleiches Socket-Protokoll.

Auswahl über ENV SANDBOX_RUNNER=docker|subprocess (Default: docker).
"""
from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import sys
import time
import uuid
from pathlib import Path

KERNEL = Path(__file__).with_name("kernel.py")


class SandboxError(Exception):
    pass


class _BaseRunner:
    def __init__(self, sessions_root: str | Path):
        self.root = Path(sessions_root)
        self.root.mkdir(parents=True, exist_ok=True)

    def session_dir(self, sid: str) -> Path:
        return self.root / sid

    def workdir(self, sid: str) -> Path:
        return self.session_dir(sid) / "work"

    def _sock_path(self, sid: str) -> Path:
        return self.session_dir(sid) / "kernel.sock"

    def create(self) -> str:
        sid = uuid.uuid4().hex[:16]
        self.workdir(sid).mkdir(parents=True, exist_ok=True)
        self._start(sid)
        deadline = time.monotonic() + 20
        while not self._sock_path(sid).exists():
            if time.monotonic() > deadline:
                raise SandboxError("Kernel-Start fehlgeschlagen (Socket fehlt).")
            time.sleep(0.05)
        return sid

    def exec(self, sid: str, code: str, cell_timeout: int = 30) -> dict:
        sock_path = self._sock_path(sid)
        if not sock_path.exists():
            raise SandboxError("Session unbekannt oder beendet.")
        client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        # Service-seitiger Fallback: Kernel-Timeout + Puffer
        client.settimeout(cell_timeout + 10)
        try:
            client.connect(str(sock_path))
            payload = json.dumps({"op": "exec", "code": code,
                                  "cell_timeout": cell_timeout})
            client.sendall(payload.encode("utf-8") + b"\n")
            buf = b""
            while not buf.endswith(b"\n"):
                chunk = client.recv(65536)
                if not chunk:
                    break
                buf += chunk
        except socket.timeout:
            self.destroy(sid)   # haengender Kernel -> Session hart beenden
            raise SandboxError("Zelle reagiert nicht — Session wurde beendet.")
        finally:
            client.close()
        if not buf:
            raise SandboxError("Kernel hat die Verbindung beendet.")
        return json.loads(buf)

    def destroy(self, sid: str) -> None:
        self._stop(sid)
        shutil.rmtree(self.session_dir(sid), ignore_errors=True)

    # -- von Subklassen zu implementieren -----------------------------------
    def _start(self, sid: str) -> None: ...
    def _stop(self, sid: str) -> None: ...


class SubprocessRunner(_BaseRunner):
    """Kernel als lokaler Subprozess (Dev/Tests; Grundlage für Profil A).
    Isolation: geleerte ENV (kein Proxy/Token), eigenes Workdir, rlimits (Linux).
    KEIN Netz-Block — dafür ist der DockerRunner da."""

    def __init__(self, sessions_root, memory_mb: int = 512):
        super().__init__(sessions_root)
        self.memory_mb = memory_mb
        self._procs: dict[str, subprocess.Popen] = {}

    def _start(self, sid: str) -> None:
        env = {"PATH": os.environ.get("PATH", ""), "MPLBACKEND": "Agg",
               "HOME": str(self.workdir(sid)), "LANG": "C.UTF-8"}

        def limits():  # pragma: no cover - plattformabhängig
            try:
                import resource
                mem = self.memory_mb * 1024 * 1024
                resource.setrlimit(resource.RLIMIT_AS, (mem, mem))
                resource.setrlimit(resource.RLIMIT_NPROC, (64, 64))
            except Exception:
                pass

        self._procs[sid] = subprocess.Popen(
            [sys.executable, str(KERNEL), "--sock", str(self._sock_path(sid)),
             "--workdir", str(self.workdir(sid))],
            env=env, cwd=str(self.workdir(sid)),
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            preexec_fn=limits if os.name == "posix" else None)

    def _stop(self, sid: str) -> None:
        proc = self._procs.pop(sid, None)
        if proc and proc.poll() is None:
            proc.kill()
            proc.wait(timeout=5)


class DockerRunner(_BaseRunner):
    """1 Container pro Session (Profil B): kein Netz, read-only, non-root,
    Ressourcenlimits. Socket/Workdir per Bind-Mount des Session-Verzeichnisses."""

    def __init__(self, sessions_root, image: str = "greenbay-sandbox:latest",
                 memory: str = "1g", cpus: str = "1.0", pids: int = 128):
        super().__init__(sessions_root)
        self.image, self.memory, self.cpus, self.pids = image, memory, cpus, pids

    def _container(self, sid: str) -> str:
        return f"gb-sandbox-{sid}"

    def _start(self, sid: str) -> None:
        cmd = ["docker", "run", "-d", "--name", self._container(sid),
               "--network", "none", "--read-only",
               "--memory", self.memory, "--cpus", self.cpus,
               "--pids-limit", str(self.pids),
               "--security-opt", "no-new-privileges",
               "--tmpfs", "/tmp:size=64m",
               "-v", f"{self.session_dir(sid).resolve()}:/session",
               "--user", "65534:65534",           # nobody
               self.image,
               "python", "/opt/kernel.py", "--sock", "/session/kernel.sock",
               "--workdir", "/session/work"]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            raise SandboxError(f"docker run fehlgeschlagen: {result.stderr.strip()}")

    def _stop(self, sid: str) -> None:
        subprocess.run(["docker", "rm", "-f", self._container(sid)],
                       capture_output=True)


def make_runner(sessions_root: str | Path):
    kind = os.environ.get("SANDBOX_RUNNER", "docker")
    if kind == "subprocess":
        return SubprocessRunner(sessions_root,
                                memory_mb=int(os.environ.get("SANDBOX_MEMORY_MB", "512")))
    return DockerRunner(sessions_root,
                        image=os.environ.get("SANDBOX_IMAGE", "greenbay-sandbox:latest"),
                        memory=os.environ.get("SANDBOX_MEMORY", "1g"),
                        cpus=os.environ.get("SANDBOX_CPUS", "1.0"))
