# GREENBAY Sandbox-Service (Code Interpreter, Profil B)

Isolierte Python-Sandbox **pro Session** für den Code Interpreter der Plattform
(`docs/KI_INTEGRATION.md` §3.5). Läuft auf dem bereitgestellten KI-Host; die
Plattform spricht ihn über `server/ai/sandbox.RemoteSandbox` an (Kanal `code`).

## Eigenschaften
- **1 Container je Session** (`--network none`, read-only Rootfs, non-root/nobody,
  RAM-/CPU-/PID-Limits, tmpfs) — Kommunikation über Unix-Socket im gemounteten
  Session-Verzeichnis, daher trotz Netz-Isolation erreichbar.
- **Zustand über Zellen** (persistenter Kernel-Prozess), Arbeitsverzeichnis mit
  Datei-Upload/-Download, automatische matplotlib-Artefakte, Zell-Timeout,
  Idle-Reaper (Default 15 min), Session-Limit.
- Paket-Whitelist im Image: pandas, numpy, matplotlib, openpyxl, scipy.
- Auth per Bearer-Token; Port nur im Praxis-/VPN-Netz exponieren.

## Deployment (KI-Host)
```bash
cd sandbox-service
docker build -t greenbay-sandbox:latest .          # Sandbox-Image (Kernel)
SANDBOX_TOKEN=$(openssl rand -hex 32) docker compose up -d
curl -s -H "Authorization: Bearer $SANDBOX_TOKEN" http://localhost:8480/health
```

## API (Bearer-Token)
| Aufruf | Zweck |
|---|---|
| `POST /sessions` | Session anlegen → `{id}` |
| `POST /sessions/{id}/exec` `{code, cell_timeout?}` | Zelle ausführen → stdout/stderr/error, Artefaktliste, Dauer |
| `PUT /sessions/{id}/files/{name}` | Datei ins Arbeitsverzeichnis legen (Body = Bytes) |
| `GET /sessions/{id}/files[/{name}]` | Dateien listen / abholen |
| `DELETE /sessions/{id}` | Session beenden (Container wird entfernt) |

## Entwicklung/Tests ohne Docker
`SANDBOX_RUNNER=subprocess` startet den Kernel als lokalen Subprozess mit
identischem Protokoll (geleerte ENV + rlimits, aber **ohne** Netz-Block —
nur für Dev/Tests bzw. als Basis des No-Admin-Profils A). Die Plattform-Tests
(`tests/test_sandbox.py`) nutzen diesen Modus.

## Sicherheitsmodell
Die Sandbox erhält **nie** Zugriff auf Store, Quell-DB oder Credentials — sie
sieht ausschließlich die Dateien, die die Plattform explizit hineinlegt
(auditiertes Manifest auf Plattformseite). Ausbruchsfläche minimiert durch
kein Netz + read-only + non-root + no-new-privileges; optional gVisor/Kata als
Runtime-Härtung (`runtime: runsc` je Container ergänzen).
