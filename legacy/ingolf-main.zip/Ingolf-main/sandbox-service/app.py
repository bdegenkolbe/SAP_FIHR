# -*- coding: utf-8 -*-
"""GREENBAY Sandbox-Service (Profil B): Code-Interpreter-API, 1 Container je Session.

Läuft auf dem bereitgestellten KI-Host (docker-compose.yml). Die Plattform spricht
ihn über server/ai/sandbox.RemoteSandbox an. Auth: Bearer-Token (ENV SANDBOX_TOKEN).

  POST   /sessions                          -> {"id": ...}
  POST   /sessions/{id}/exec {code, cell_timeout?} -> Exec-Ergebnis + Artefaktliste
  GET    /sessions/{id}/files               -> Dateiliste im Arbeitsverzeichnis
  PUT    /sessions/{id}/files/{name}        (Body = Bytes) Datei hineinlegen
  GET    /sessions/{id}/files/{name}        Datei/Artefakt abholen
  DELETE /sessions/{id}                     Session beenden (Container weg)
  GET    /health                            Status + Runner-Art

Die Sandbox hat keinerlei Zugriff auf Plattform-Store/Quelle — sie sieht nur die
Dateien, die die Plattform explizit hineinlegt.
"""
from __future__ import annotations

import hmac
import os
import threading
import time
from pathlib import Path

from fastapi import Body, FastAPI, Header, HTTPException, Request, Response

from runner import SandboxError, make_runner

SESSIONS_ROOT = os.environ.get("SANDBOX_SESSIONS", "/var/lib/greenbay-sandbox")
TOKEN = os.environ.get("SANDBOX_TOKEN", "")
IDLE_SECONDS = int(os.environ.get("SANDBOX_IDLE_SECONDS", "900"))       # 15 min
MAX_SESSIONS = int(os.environ.get("SANDBOX_MAX_SESSIONS", "16"))
MAX_CELL_TIMEOUT = int(os.environ.get("SANDBOX_MAX_CELL_TIMEOUT", "120"))
MAX_FILE_MB = int(os.environ.get("SANDBOX_MAX_FILE_MB", "64"))

app = FastAPI(title="GREENBAY Sandbox-Service", docs_url=None, redoc_url=None)
runner = make_runner(SESSIONS_ROOT)
_last_used: dict[str, float] = {}
_lock = threading.Lock()


def _auth(authorization: str):
    if not TOKEN:
        raise HTTPException(503, "SANDBOX_TOKEN nicht konfiguriert.")
    supplied = authorization.removeprefix("Bearer ").strip()
    if not hmac.compare_digest(supplied, TOKEN):
        raise HTTPException(401, "Ungültiges Token.")


def _touch(sid: str):
    _last_used[sid] = time.monotonic()


def _safe_name(name: str) -> str:
    if not name or "/" in name or "\\" in name or name.startswith(".") or ".." in name:
        raise HTTPException(422, "Ungültiger Dateiname.")
    return name


def _reaper():  # Idle-Sessions einsammeln
    while True:
        time.sleep(30)
        cutoff = time.monotonic() - IDLE_SECONDS
        with _lock:
            for sid, ts in list(_last_used.items()):
                if ts < cutoff:
                    try:
                        runner.destroy(sid)
                    finally:
                        _last_used.pop(sid, None)


threading.Thread(target=_reaper, daemon=True).start()


@app.get("/health")
def health():
    return {"status": "ok", "runner": type(runner).__name__,
            "sessions": len(_last_used), "max_sessions": MAX_SESSIONS}


@app.post("/sessions")
def create_session(authorization: str = Header(default="")):
    _auth(authorization)
    with _lock:
        if len(_last_used) >= MAX_SESSIONS:
            raise HTTPException(429, "Session-Limit erreicht.")
        try:
            sid = runner.create()
        except SandboxError as exc:
            raise HTTPException(502, str(exc))
        _touch(sid)
    return {"id": sid, "idle_seconds": IDLE_SECONDS}


@app.post("/sessions/{sid}/exec")
def exec_cell(sid: str, payload: dict = Body(...),
              authorization: str = Header(default="")):
    _auth(authorization)
    if sid not in _last_used:
        raise HTTPException(404, "Session unbekannt oder abgelaufen.")
    code = payload.get("code", "")
    if not code.strip():
        raise HTTPException(422, "code fehlt.")
    cell_timeout = min(int(payload.get("cell_timeout", 30)), MAX_CELL_TIMEOUT)
    _touch(sid)
    try:
        result = runner.exec(sid, code, cell_timeout=cell_timeout)
    except SandboxError as exc:
        _last_used.pop(sid, None)
        raise HTTPException(410, str(exc))
    _touch(sid)
    return result


@app.get("/sessions/{sid}/files")
def list_files(sid: str, authorization: str = Header(default="")):
    _auth(authorization)
    if sid not in _last_used:
        raise HTTPException(404, "Session unbekannt oder abgelaufen.")
    workdir = runner.workdir(sid)
    if not workdir.exists():
        return {"files": []}
    files = [{"name": p.name, "size": p.stat().st_size}
             for p in workdir.iterdir() if p.is_file()]
    return {"files": sorted(files, key=lambda f: f["name"])}


@app.put("/sessions/{sid}/files/{name}")
async def put_file(sid: str, name: str, request: Request,
                   authorization: str = Header(default="")):
    _auth(authorization)
    if sid not in _last_used:
        raise HTTPException(404, "Session unbekannt oder abgelaufen.")
    name = _safe_name(name)
    data = await request.body()
    if len(data) > MAX_FILE_MB * 1024 * 1024:
        raise HTTPException(413, f"Datei > {MAX_FILE_MB} MB.")
    (runner.workdir(sid) / name).write_bytes(data)
    _touch(sid)
    return {"ok": True, "name": name, "size": len(data)}


@app.get("/sessions/{sid}/files/{name}")
def get_file(sid: str, name: str, authorization: str = Header(default="")):
    _auth(authorization)
    if sid not in _last_used:
        raise HTTPException(404, "Session unbekannt oder abgelaufen.")
    path = runner.workdir(sid) / _safe_name(name)
    if not path.is_file():
        raise HTTPException(404, "Datei nicht gefunden.")
    _touch(sid)
    return Response(content=path.read_bytes(),
                    media_type="application/octet-stream")


@app.delete("/sessions/{sid}")
def delete_session(sid: str, authorization: str = Header(default="")):
    _auth(authorization)
    runner.destroy(sid)
    _last_used.pop(sid, None)
    return {"ok": True}
