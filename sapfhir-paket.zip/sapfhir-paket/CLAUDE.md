# CLAUDE.md — sapfhir: IS-H/i.s.h.med → FHIR/Analytik (HIGL/UKL)

## Projektkontext
Quell-DB: MSSQL 10.50.8.250 (read-only), DB `Replicate`, Schema `sap` (Qlik-Replikat des
SAP IS-H/i.s.h.med). Konstanten: MANDT='100', EINRI='0001'. Change-Tables `<T>__ct`.
Haus-ETL-Referenz: DB `Analysen` (E-Statistik, base-table-main-Prozeduren).
HRP-Schema ist AUSGEKLAMMERT (Anweisung Björn).

## Verbindliche Methode
Lies ZUERST `docs/Analyse_Datenbank.md` — sie definiert das komplette Vorgehen:
1. **Dreiklang je Tabelle/Feld:** sapdatasheet.org → Schema live (PK-Uniqueness!) →
   Daten live (Fill-Rates, Top 1000, Werteverteilungen). Schema-Wahrheit ≠ Daten-Wahrheit.
2. **NPAT-zentrierte Breitensuche** über den FK-Graphen; jede neue Zieltabelle in die
   Warteschlange; Status je Tabelle in `config/tables.yaml` fortschreiben.
3. **Verkryptung:** personenidentifizierende Varchars (Namen, Adressen, VERNR/KVNR,
   EDIFACT-Inhalte NC301M/V/W, Freitexte) NIE im Klartext selektieren/loggen —
   nur HASHBYTES-SHA256 oder LEN/Initial. Details/Feldliste: Analyse_Datenbank.md §4.
4. **Verlustfreiheit:** unbekannte Codes nie raten, nie verwerfen → Rohcode unter
   `urn:ish:<katalog>`; kuratierte Displays nur bei gesicherter Deutung.
5. **Medizin ≠ Abrechnung:** Encounter bleiben unangetastet; NAPX→Account-Klammer,
   NFFZ→Extension. KEIN Encounter.replaces/partOf für Zusammenführungen.
6. **Datums-Pipeline:** Mapper (roh) → privacy (Shift/hash_id auf Rohwerten) →
   `normalize_resource()` (ISO-8601 Europe/Berlin) → NDJSON. Sentinels: `_echtes_datum`
   (0101-01-01 = SAP-Leerdatum via Qlik = OFFENER Fall → status in-progress).

## Wichtigste verifizierte Fakten (Kurzliste; Vollstand: config/tables.yaml + docs/VERIFY_LOG)
- NDRG hat ENGLISCHE Spalten (CLIENT/INSTITUTION/PATCASEID). NLEI/NLEM-Key = [MANDT,LNRLS].
- GPART == PERNR == PHYSNO (1:1, 236.114) → EIN Practitioner-ID-Schema für NGPA/NPER/
  NFPZ/NKBVLANR/NBSNR. Pipeline mergt NGPA(Name)+NPER(LANR/FACHR).
- Tote Felder in DIESEM Haus: NICP.OPART, NBEW.UNFAV/VGNREF/NFGREF, NFAL.FACHR/ENDTYP,
  NDIA.DIASI (Wahrheit: DIAGW). Bewegungskette per ORDER BY BWIDT/BWIZT ableiten.
- §301-Meldedaten: NC301S (Index) + NC301M (EDIFACT-Rohtext, gechunkt) + NC301V/W (Segmente).
- N1MEORDER leer → Medikation/Vitalwerte via COPRA5/6 (siehe DIAS-Baum) erschließen.
- Nicht replizierte Kataloge: TN14K, TN14O, N2DT, TN26B/D → Rohcode-only.

## Arbeitsregeln für Sessions
- Jede neue Erkenntnis SOFORT in `config/tables.yaml` (notes, 'verifiziert Rx') und bei
  Korrekturen in `docs/VERIFY_LOG_R8-R13.md` (neue Runde anhängen) dokumentieren.
- Mapper-Änderungen IMMER mit Test in `tests/test_core.py`; Referenz-Konsistenz
  (ID-Schemata) explizit asserten. `python -m pytest tests/ -q` muss grün sein.
- Online-Aggregate >50 Mio Zeilen (NLEI, N2LABOR001) timeouten → Lastfenster/Batch.
- Backlog-Reihenfolge: Analyse_Datenbank.md §8.
